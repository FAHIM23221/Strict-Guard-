# BUILD REPORT — Strict Guard v5.2.1

Date: 2026-11-07. Built for Olivia (Infinix X6886, Android 16).
Base: v5.2.0 source in this same directory (verified byte-identical to
~/workspace/your_files/Strict-Guard-v5.2.0-source.zip before editing).
Package: `app.strictguard`, versionName 5.2.1, versionCode 33, minSdk 29, targetSdk 34.
No APK was decompiled; built from the v5 source only, manual kotlinc + aapt2 + d8
route (Gradle cannot run in this sandbox).

## Result: SUCCEEDED

- **APK:** `~/workspace/your_files/Strict-Guard-v5.2.1.apk` — 763,975 bytes
- **SHA-256:** `327a2ec5782ce30cbfc86a8235c85ccf1f456b78514f0f8baed90830c8d8a183`
- **Signature:** apksigner verifies, 1 signer (same fresh debug keystore as v5/v5.1/v5.2,
  CN=Strict Guard, O=Self-built, C=BD). Signing scheme **v3 only** (v1/v2 false)
  — same apksigner 35.0.0 quirk as before; v3 covers Android 9+ and minSdk is 29.
- **Unit tests: 57/57 pass** (JUnit 4.13.2) — v5.2.0's 44, minus 4 removed
  Shorts tests, plus 3 YouTube-normal tests, plus 14 new tests in
  `AdminFixTest.kt` (Settings blocked by package + activity, sticky
  foreground resolution, lock rule).
- **No Accessibility:** no "accessibility" string in the dex, no
  AccessibilityService / BIND_ACCESSIBILITY in the manifest.
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no
  http(s) URL strings in the dex.
- **Shorts fully gone:** no "shorts" string in the dex except Kotlin
  stdlib's unrelated `ShortSpreadBuilder` (a 16-bit-short helper). No
  `f_shorts` / `blocked_shorts` strings, no `block_shorts` preference,
  no `Kind.SHORTS` in the code. Verified in the built APK.
- **NOT tested on a real device.** Olivia must uninstall v3.7, v4.0.0, v5.0.0,
  v5.1.0 and v5.2.0 first (different signing key) before installing v5.2.1.

## Task 1 — YouTube Shorts feature REMOVED entirely (Olivia asked)

- Removed: the Shorts toggle UI (switch + row) from MainActivity, the
  `BlockDecider.Kind.SHORTS` kind and its blocking rule, the persisted
  `block_shorts` preference and its EN/BN strings (`f_shorts`,
  `f_shorts_desc`, `blocked_shorts`), the Diagnostics line, and the
  4 Shorts unit tests (replaced by YouTube-normal tests).
- YouTube now behaves exactly as in v5.1.0: blocked during Strict Mode,
  during Night Lock, and after its 60-minute daily limit — and usable at
  all other times. YouTube Music likewise returns to normal (it was
  only ever blocked by the removed toggle, the Strict group rule, or
  its shared 60-minute limit).

## Task 2 — Device Admin bypass FIXED (Olivia found it on-device)

### The root cause (found by auditing GuardService)

`foregroundPackage()` only looked at UsageEvents from the last 3
seconds. If the user was already inside Settings when Strict was
turned on, or navigated *inside* Settings (Settings > Security >
Device admin apps is the SAME package, so no new MOVE_TO_FOREGROUND
event fires), then after 3 seconds the query returned null, `tick()`
returned early, and the guard went blind — Settings stayed open and
Device Admin could be turned off. The permission/admin checks never
ran either, because they sat after the early return.

### What changed

1. **Sticky foreground (new `ForegroundResolver.kt`, pure + tested).**
   The last-known foreground package is kept and reused when no new
   event arrives, and UsageStats' most-recently-used package (last
   2 minutes) is a second fallback. A package that was in the
   foreground does not stop being in the foreground just because no
   new event fired. The foreground activity class follows the same
   stickiness. Resolution order: fresh event > last-known > stats.
2. **Permission/admin checks run on EVERY tick**, even when no
   foreground package can be resolved (moved before the null return).
3. **Settings checked by package AND by activity class**
   (`BlockDecider.isSettingsActivity`). The Device Admin screen, the
   App info screen for Strict Guard itself, and every other Settings
   screen all live in `com.android.settings`; the activity check is a
   second layer for any OEM wrapper hosting a Settings activity under
   another package name. On XOS the Settings app is `com.android.settings`
   (verified: the Device Admin screen on Infinix is under Security in
   Settings) — no separate Transsion settings package was found in
   the XDA Infinix debloat list / bloatware registry, so none was
   invented; the activity-class check covers that case generically.
4. **In-app Device Admin control locked during Strict.** The setup
   rows were already disabled, but every setup action that opens a
   system Settings screen (Usage Access, Device Admin enable, Overlay,
   Home launcher role, Notification Access, Battery, App info) is now
   wrapped in a `guarded()` check that refuses with the locked toast
   while Strict is on. The "Start monitoring" button likewise refuses
   to open Usage Access Settings during Strict.
5. **Guard-not-running warning + self-heal (MainActivity).** If Usage
   Access is off, or the service was killed although it should be
   running, the main screen now shows a persistent warning that
   blocking is OFF instead of silently pretending. On resume, if
   monitoring is wanted (or Strict is on) and the service is not
   running, the app restarts it — this is the hole Olivia's bypass
   needed, because a dead guard blocks nothing. `GuardService.isRunning`
   (volatile flag, set in onCreate/onDestroy) backs both; Diagnostics
   also shows it.
6. **Kept:** admin-loss handling (Tamper Log entry + high-importance
   notification + blocking continues via UsageStats), the Strict
   schedule, lock-during-Strict, and Sidebar/Smart Panel blocking.

## Kept unchanged (verified by tests)

- Strict schedule (until midnight / N days / date+time, survives
  reboot, cannot be shortened during Strict), LOCK DURING STRICT,
  Strict blocks Facebook / Chrome / YouTube / AI groups itself,
  usage accumulated on EVERY 500 ms poll, floating / split-screen /
  PiP blocking, Night Lock + allowed-apps, custom blocklist, Tamper
  Log, Diagnostics, boot receiver, calm muted sage-green UI, one-tap
  Bangla/English switch (persisted), Dark + Light modes (persisted).

## Honest limits

- Up to ~500 ms visibility of a blocked app before the block screen.
- Device Admin CAN still be deactivated in Android Settings when
  Strict is OFF — Android genuinely lets the user do that, and no
  app can change it. During Strict, Settings is now blocked by
  package + activity with a sticky foreground check, the in-app
  admin control is locked, the guard self-heals if killed, and any
  loss is logged + notified. Deactivation outside Strict is still
  only logged, not prevented.
- A wall-clock schedule has one trade-off: if the user changes the
  wall clock AND reboots, the recomputed end follows the (changed)
  clock. Clock changes are logged to the Tamper Log.
- Force-stop from Settings stops the guard until the app is opened
  again (MainActivity then restarts it) or the phone reboots.
  Safe Mode / ADB / second profile can bypass, as before.
- No on-device testing in this sandbox. Olivia should test: turn
  Strict on, open Settings, go to Security > Device admin apps,
  and confirm the block screen appears; leave Settings open, turn
  Strict on from the notification / app, and confirm Settings is
  blocked within a second; turn the Shorts toggle search — it must
  be gone; open YouTube with Strict off and confirm it plays.

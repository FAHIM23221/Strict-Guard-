# Strict Guard v5.0.0 — built from zero

A self-control / app-blocker app for Olivia's Infinix X6886 (Android 16).
Written completely from scratch in `~/workspace/strict-guard-v5/` — no code
copied from the v4 source and nothing decompiled from the v3.7 APK.

- Package `app.strictguard`, version 5.0.0, code 30, minSdk 29, targetSdk 34.
- Pure Android framework + Kotlin stdlib only. No AndroidX, no viewBinding,
  no KSP, no INTERNET permission, **no Accessibility Service**.
- Bengali UI by default (matching the v3.7 screenshot), with a one-tap
  Bangla/English switch and a Light/Dark theme toggle — both persisted.
  English is the default language; Bengali is one tap away on the main
  screen and switches instantly, without restarting the app. The theme
  follows the system by default; the toggle stores an explicit override.
- Calm, muted design: no bright colours, no animations, no gamification,
  no streaks, no rewards.

## Features

- **Strict Mode until midnight**, no early exit (1-minute test mode only).
  Strict end is stored in `elapsedRealtime`, so changing the wall clock
  cannot end it early; clock changes are logged.
- **Night Lock** 00:00–06:00 by default, toggle + hours picker + allowed-apps
  picker. Notifications are silenced during Strict/Night (optional
  Notification Access).
- **Daily limits** — Facebook 2h, Chrome 1h30m, YouTube 1h, AI chat 30m —
  with bars + % on the main screen. Usage is accumulated on **every 500 ms
  poll** for the foreground app, so continuous use in one app reaches its
  limit and blocks mid-session (this was v4's bug, fixed here and covered
  by `UsageTrackerTest`).
- **Floating / split-screen / PiP blocking** — UsageStats
  `MOVE_TO_FOREGROUND` fires in every window mode, so a blocked app opened
  from the XOS sidebar as a floating window, in split-screen or in PiP is
  still caught by the 500 ms poll, then covered by an overlay + block
  screen + go-home. A blocked app may flash for up to ~500 ms.
- **Bypass-app blocking** during Strict/Night: Settings, Play Store,
  package installer, clone/parallel/work-profile apps.
- **Custom blocklist picker**, **Tamper Log** (permission loss, clock
  change, admin loss, blocked attempts), **Diagnostics** screen,
  **boot receiver** (guard restarts after reboot).
- Settings live in SharedPreferences `strictguard_store` (same name as
  v3.7, so v3.7 settings can carry over).

## Build

Manual build in this sandbox (Gradle does not work here):

```bash
bash build.sh   # kotlinc + aapt2 + d8 + zipalign + apksigner
# output/Strict-Guard-v5.0.0.apk
```

On a normal machine / Android Studio / GitHub Actions:

```bash
./gradlew :app:assembleDebug
```

## Honest limits

- A blocked app may be visible for up to ~500 ms before the block screen.
- Force-stop from Settings stops the guard until the app is opened again
  or the phone reboots (Settings is blocked during Strict, but not when
  Strict is off).
- Safe Mode disables all third-party apps, including this guard.
- ADB / USB debugging can uninstall or disable the app — keep it off.
- A second user / work / guest profile has its own apps.
- Factory reset is not a concern for Olivia (phone is on installment).
- No on-device testing has been done in this sandbox.

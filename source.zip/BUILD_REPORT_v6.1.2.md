# BUILD REPORT — Strict Guard v6.1.2 (two-bug fix release)

Date: 2026-11-08 (night). Built for Fahim (Infinix X6886, Android 16).
Base: v6.1.1 source in this same directory (SHA-256
`f8dc209a4de9a9c56713032cc64bb8ace9327d7822eabc70a4491fe4970a7553`).
No APK was decompiled; built from the v5/v6 source only, manual kotlinc + aapt2 + d8
route (Gradle cannot run in this sandbox).

## Result: SUCCEEDED

- **APK:** `~/workspace/your_files/Strict-Guard-v6.1.2.apk` — 859,141 bytes
- **SHA-256:** `d0e597daf1f32f0b088d0d6eedce312c518582ddc49796e4afbeecfece089b6c`
- **Source zip:** `~/workspace/your_files/Strict-Guard-v6.1.2-source.zip`
  (SHA-256 `6894d0595caaa5a0eb9c3f515808554ed3c31089fd53aa353e41640d6c84806a`, 118 files)
- **Signature:** apksigner verifies, 1 signer (same fresh debug keystore as
  v5/v5.1/v5.2/v5.2.1/v6.0.0/v6.1.0/v6.1.1, CN=Strict Guard, O=Self-built, C=BD).
  Signing scheme **v3 only** (v1/v2 false) — same apksigner 35.0.0 quirk as before;
  v3 covers Android 9+ and minSdk is 29.
- **Unit tests: 221/221 pass** (JUnit 4.13.2) — v6.1.1's 200 + 10 new in
  `StudyLockDeadlockTest.kt` + 11 new in `EntryDelayFixTest.kt` (see below).
- **No Accessibility:** 0 "accessibility" strings in the dex, no
  AccessibilityService / BIND_ACCESSIBILITY in the manifest.
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no
  http(s) URL strings in the dex.
- **New-code markers confirmed in the built APK's dex:** `DelayActivity`,
  `shouldRestartGuard`, `STUDY_APP_PACKAGE_ALT`, `isStudyApp`,
  `effectiveDelayPkg`, `needsActivityFallback`. HOME intent confirmed;
  `DelayActivity` confirmed in the manifest (exported=false,
  excludeFromRecents, noHistory, singleTop).
- **NOT tested on a real device.** Fahim must uninstall v6.1.1 first
  (different signing key) before installing v6.1.2, then pick Strict Guard
  as the default home launcher and redo the 7 setup steps.
- **Scope, per Fahim's instruction:** ONLY the two bugs below are fixed.
  No other feature or behaviour changed. (An earlier v6.1.2 build the
  same evening contained only the Study Lock fix; it was superseded
  by this build, which adds the Entry Delay fix under the same
  version — same versionCode 37, new APK hash above.)

## Bug 1 — Study Lock deadlocked against its own app (reported 2026-11-08 23:16)

Fahim's screenshots (`~/workspace/user/files/93094_0_aimo.jpg`,
`~/workspace/user/files/93093_1_ay3x.jpg`): during an active Study Lock,
tapping eTestPaper showed the block screen FOR eTestPaper itself
("Study Lock is on — only e test paper … until the 15 minutes are
done"), and the launcher showed a lock badge on EVERY app including
eTestPaper. The 15 fair minutes could never be completed, so the lock
could never end (except the 06:00 expiry). v6.1.1 otherwise worked
(app opened fine, launcher "6 months 29 days" countdown correct).
Fahim recovered on his own — he had only run a 1-minute test, so he
could fix the phone again. No emergency.

### Root cause — the lock recognised only ONE of TWO packages

The code hard-coded a single study-app package,
`com.nextive.eTestPaper` (the original "E-Test Paper for SSC & HSC"
listing). That listing was removed from Google Play on 2026-07-08
and replaced by the live listing "E-Test Paper : Smart Practice"
(verified 2026-11-08 on AppBrain: on Play since July 2026, v2.4.4,
updated 2026-11-05, 50,000+ installs) whose package is
`com.nextive.etestpaper` — same letters, all lower-case. Android
package names are case-sensitive, so Fahim's installed app (the live
listing) was treated as "any other app": the guard blocked it, the
timer never counted it as studying, the missing-app check reported
it missing, the 21:00 auto-launch targeted a package that is not
installed, and the launcher badged it locked. The pure decision
logic was correct for the hard-coded package — the package itself
was wrong.

### Fix (all in `app/src/main/java/app/strictguard/`)

- `StudyLock.kt`: new `STUDY_APP_PACKAGE_ALT = "com.nextive.etestpaper"`,
  `STUDY_APP_PACKAGES` set, `isStudyApp(pkg)` — both packages count
  as the study app, everywhere.
- `BlockDecider.kt`: `decideStudy` exempts both packages; `decide()`
  now exempts the study app FIRST, before every other rule (limit,
  break, Strict, Night, custom list) while a lock is active — defence
  in depth, so no branch can ever re-decide it as blocked; the Night
  exemption uses `isStudyApp` too.
- `GuardService.kt`: missing-app check, timer foreground check,
  auto-launch (tries both packages) and the Play Store button (now
  opens the LIVE listing, since the old one is delisted) all use the
  two-package recognition.
- Launcher badge: fixed through the same `decideStudy`/`decide` path
  (`LauncherLogic.tapDecision` returns null for the study app during
  a lock → no lock badge, tile opens the app).

### Tests — `StudyLockDeadlockTest.kt` (10 new)

Both packages recognised; `decideStudy` allows both, still blocks
other apps; `decide()` allows both even with Night + Strict on and
the study app on the custom list, still blocks other apps;
launcher tap allows the study app (no badge) and still blocks
others during a lock.

## Bug 2 — Entry Delay popup never appears (reported 2026-11-08 ~23:25)

Opening Facebook / TikTok / Instagram / YouTube showed NO 15-second
timer popup at all — the apps opened directly.

### Correction — the wait is 15 SECONDS

Fahim misspoke "15 minutes" in voice; the correct unit is seconds.
The code and strings were already seconds everywhere (default 15,
choices 10 / 15 / 30 in settings, "Wait %1$d seconds", Bengali
"সেকেন্ড"), so no unit change was needed — the tests below pin
seconds down (not done at 14.9 s, done at 15.0 s).

### Root causes — two defects, both fixed

1. **Dead guard, silently.** The delay popup only exists in the
   guard service's poll loop, but the self-heal restart in
   MainActivity/LauncherActivity required the persisted
   service-wanted flag — which only the service itself ever sets.
   On a fresh install, or after the service was force-stopped /
   killed before it ever ran (as happened escaping Bug 1's
   deadlock), the guard stayed dead and nothing restarted it,
   while the launcher still showed lock badges (pure UI logic) —
   so it looked like blocking worked while the delay (and all
   foreground enforcement) never ran. Fix:
   `StartupGuard.shouldRestartGuard(isRunning, hasUsageAccess)` —
   restart whenever Usage Access is granted, the setup signal
   that monitoring is wanted. The main page's guard-down warning
   now uses the same rule, so a dead guard is visible instead of
   silent. The service still sets the wanted flag itself on
   start, so boot restarts keep working.
2. **Silent overlay failure.** When the overlay permission was
   missing, `entryDelaySyncOverlay()` returned without showing
   anything — the wait ran invisibly and the app stayed usable.
   Fix: the countdown is now shown as the full-screen
   `DelayActivity` instead (same layout, same countdown, Back
   does nothing, leaving via Home resets the wait via the guard).
   The guard remains the only state machine: the activity only
   displays, finishes when the guard grants the wait, and as a
   backstop 1 second after the deadline (never earlier, so the
   app can never open before the full wait). While the activity
   is in the foreground the guard keeps counting the wait for
   the app underneath (`EntryDelay.effectiveDelayPkg`). If even
   the activity cannot be started, the failure is logged to the
   Tamper Log (`DELAY_NO_POPUP …`) instead of vanishing — the
   overlay setup step is the fix for that case. The setup
   overlay step itself already opens the system overlay
   permission screen; with the fallback, the popup appears
   either way.

### Tests — `EntryDelayFixTest.kt` (11 new)

`shouldRestartGuard` (dead + usage access → restart; running →
no; no usage access → no); the four reported apps get the delay,
WhatsApp never does, blocked apps never do; 15 seconds, not
minutes (not done at 14.9 s, done at 15.0 s); the fallback screen
keeps watching the social app underneath, leaving mid-wait still
resets; fallback needed when the overlay is missing or fails,
not needed when it shows.

## Install (for Fahim)

1. **Uninstall v6.1.1 first** (same signing-key rule as every
   version since v4 — Android will refuse to install over v6.1.1
   otherwise).
2. Install `Strict-Guard-v6.1.2.apk`.
3. Open it, set Strict Guard as the default home launcher and
   redo the 7 setup steps (Usage Access, Device Admin, Overlay,
   Launcher, Notification Access, Battery, Autostart) — the
   Overlay step matters for the popup: with it granted the popup
   is the overlay; without it the popup is the full-screen
   countdown screen instead. Either way it must now appear.
4. Test: open Facebook — the 15-second countdown must appear
   BEFORE the app is usable; wait it out, then Facebook opens.
   WhatsApp must open with no wait. At 21:00 the Study Lock must
   pull him into eTestPaper (either installed listing) and the
   15 fair minutes must count — eTestPaper must NOT show a block
   screen, and its launcher tile must have NO lock badge during
   the lock.

## Honest limits (unchanged)

- No on-device test was possible (no Android emulator/adb on this
  Linux VM). Both causes are established by code inspection plus
  Fahim's screenshots and the verified live Play Store listing;
  the real proof is Fahim opening v6.1.2 on his Infinix. If the
  popup still does not appear, the next step is checking the
  Tamper Log / Diagnostics in the app (the `DELAY_NO_POPUP` entry
  would name it) and whether the guard service is running.
- Safe Mode / ADB / a second profile can still bypass any
  app-level guard, as before.

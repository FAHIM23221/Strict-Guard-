# BUILD REPORT — Strict Guard v5.1.0

Date: 2026-11-07. Built for Olivia (Infinix X6886, Android 16).
Base: v5.0.0 source in this same directory (updated in place — no fork).
Package: `app.strictguard`, versionName 5.1.0, versionCode 31, minSdk 29, targetSdk 34.
No APK was decompiled; built from the v5 source only.

## Result: SUCCEEDED

- **APK:** `~/workspace/your_files/Strict-Guard-v5.1.0.apk` — 755,783 bytes
- **SHA-256:** `345572396c924fb054d4aa16f202cf784c8a14aa70aa9761922cfbed59fa8e9a`
- **Signature:** apksigner verifies, 1 signer (same fresh debug keystore as v5,
  CN=Strict Guard, O=Self-built, C=BD). Signing scheme **v3 only** (v1/v2 false)
  — same apksigner 35.0.0 quirk as v4/v5; v3 covers Android 9+ and minSdk is 29.
- **Unit tests: 31/31 pass** (JUnit 4.13.2) — v5's 26 + 5 new v5.1.0 tests.
- **No Accessibility:** no AccessibilityService / BIND_ACCESSIBILITY in the dex
  or manifest (only a code comment explaining why UsageStats is used instead).
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no http(s)
  strings in the dex.
- **NOT tested on a real device.** Olivia must uninstall v3.7, v4.0.0 and
  v5.0.0 first (different signing key) before installing v5.1.0.

## What changed in v5.1.0

1. **LOCK DURING STRICT (Olivia's rule, 2026-11-07 17:37).**
   - `Store.settingsLocked()` = Strict active (elapsedRealtime end).
   - Store setters refuse writes while locked: language, theme, Night Lock
     toggle/hours, custom blocklist, night allowed-apps, autostart confirm,
     tamper-log clear. Usage counting, tamper logging and the guard service
     are NOT locked.
   - MainActivity: a "Settings locked until Strict ends" banner appears
     during Strict; language/theme buttons, setup rows and the Night/custom
     feature rows are disabled (dimmed) and show a "Locked during Strict"
     toast if tapped. Tamper Log and Diagnostics stay readable (view-only).
   - AppPickerActivity / NightPickerActivity refuse to open during Strict
     (toast + finish); their Save buttons also refuse. Tamper Log Clear
     shows the locked toast during Strict.
   - New strings `locked_strict` / `locked_strict_short` in English + Bengali.

2. **STRICT NOW BLOCKS THE FOUR GROUPS (the v5 flaw Olivia found on-device).**
   - `BlockDecider` gains `Kind.STRICT_GROUP`. While Strict is on, any app
     in Facebook / Chrome-browsers / YouTube / AI groups returns
     STRICT_GROUP and is blocked — before the Night check, so a night-allowed
     group app is still blocked during Strict. Daily-limit blocking is
     unchanged when Strict is off.
   - `GuardService.reasonText` and `BlockActivity` map STRICT_GROUP to the
     "Strict Mode is on" message.

3. **Settings entry still blocked during Strict/Night:** `com.android.settings`
   remains in `Limits.BUILTIN_STRICT` (verified in source and by the
   `settingsAppStillBlockedDuringStrict` test); GuardService enforces it
   on every 500 ms UsageStats poll while running with Usage Access.

## Kept unchanged (verified)

- Usage accumulated on EVERY 500 ms poll (`GuardService.tick` calls
  `store.addUsage(group, 500ms)` + `tracker.tick` unconditionally) — the
  v4 bug is NOT back. Floating / split-screen / PiP blocking via
  UsageStats MOVE_TO_FOREGROUND, mode-agnostic.
- Night Lock 00:00–06:00 + allowed-apps picker, Tamper Log, Diagnostics,
  boot receiver, Device Admin, notification silencing, calm muted
  sage-green UI, one-tap Bangla/English switch (persisted), Dark + Light
  modes (persisted).

## Honest limits (same as v5)

- Up to ~500 ms visibility of a blocked app before the block screen.
- Force-stop from Settings stops the guard until the app is opened again
  or the phone reboots. Safe Mode / ADB / second profile can bypass.
- Device Admin can still be deactivated by the user in Android Settings —
  admin only blocks uninstall while active; that is an Android limit, not
  something this app can change. Settings blocking itself only works while
  GuardService is running with Usage Access — check "Monitoring is on".

# BUILD REPORT — Strict Guard v5.0.0 (built from zero)

Date: 2026-11-07. Built for Olivia (Infinix X6886, Android 16).
Workspace: `~/workspace/strict-guard-v5/`
Package: `app.strictguard`, versionName 5.0.0, versionCode 30, minSdk 29, targetSdk 34.

## Result: SUCCEEDED

- **APK:** `output/Strict-Guard-v5.0.0.apk` — 755,783 bytes
- **SHA-256:** `fb83eb0512e019d2d204c0545ca6efbfc3d8201db965906a9476da2fa48947e0`
- **Signature:** apksigner verifies, 1 signer (fresh debug keystore,
  CN=Strict Guard, O=Self-built, C=BD). Signing scheme **v3 only**
  (v1/v2 false) — the same apksigner 35.0.0 quirk seen with v4.0.0; v3
  covers Android 9 (API 28)+ and minSdk is 29, so it installs on every
  supported device including Olivia's Android 16. A Gradle build on a
  normal machine produces the usual v1+v2+v3.
- **Unit tests: 26/26 pass** (JUnit 4.13.2) — see below.
- **Dex:** single `classes.dex`; all 18 Kotlin source files present
  (verified with dexdump class list).
- **No Accessibility:** no `accessibility` string in the dex, no
  `BIND_ACCESSIBILITY_SERVICE` / `AccessibilityService` anywhere, no
  accessibility entries in the manifest. (The only "accessib" matches
  are Kotlin-stdlib internals `AccessibleLateinitPropertyLiteral` and
  `setAccessible` — reflection helpers, not Android Accessibility.)
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no
  `http://` / `https://` strings in the dex.
- **Bengali strings:** `values-bn/strings.xml` compiled into
  `resources.arsc` — e.g. `status_strict_off` has both `()` "Strict is
  off" and `(bn)` "Strict বন্ধ আছে".
- **NOT tested on a real device** (no Android device in this sandbox).
  Olivia must test on her Infinix X6886 and uninstall v3.7 first
  (different signing key). v4.0.0 must also be uninstalled first —
  same package name, different signing key.

## What was built — fresh from zero

No source files copied from `~/workspace/strict-guard-inspired/` and
nothing decompiled, extracted or copied from the v3.7 APK. The v3.7
screenshot (`~/workspace/user/files/92685_8_9jfw.jpg`) was read as an
image and used as the UI/feature reference only. All Kotlin, layouts,
strings, drawables and the manifest were written new for v5.

| File | Purpose |
|---|---|
| `Limits.kt` | Pure rules: 4 limit groups, builtin strict list, night/strict maths, duration formatting, `UsageTracker` |
| `UsageTracker.kt` (in Limits.kt) | Accumulates usage on EVERY 500 ms poll — the v4 bug fix |
| `Store.kt` | SharedPreferences `strictguard_store` (same name as v3.7); Strict end in elapsedRealtime; tamper log |
| `BlockDecider.kt` | Single blocking decision (limit / bypass / custom / night) |
| `Lang.kt` | Bengali/English locale + Light/Dark theme selection |
| `BaseActivity.kt` | Applies persisted language + theme before UI creation |
| `Util.kt` | Permission checks, launcher packages, go-home, app labels |
| `GuardService.kt` | START_STICKY foreground service, 500 ms UsageStats poll, overlay block screen, BlockActivity, go-home, permission-loss watch |
| `GuardAdminReceiver.kt` | Device Admin (watch-login only) |
| `BootReceiver.kt` / `SystemEventsReceiver.kt` | Restart on boot; log clock/package changes |
| `QuietListener.kt` | Notification listener: silences other apps' notifications during Strict/Night |
| `MainActivity.kt` | Dashboard: status card, usage bars, 7-step setup, features, Strict button, lang/theme toggles |
| `BlockActivity.kt` | Full-screen blocked screen; back press goes home |
| `StrictSetupActivity.kt` | Confirm Strict until midnight / 1-minute test mode |
| `NightPickerActivity.kt` | Night Lock hours picker |
| `AppPickerActivity.kt` | Searchable app picker (custom block list + Night allowed list) |
| `TamperLogActivity.kt` / `DiagnosticsActivity.kt` | Log viewer + diagnostics (shareable) |
| Layouts, strings (en + bn), calm muted themes (light/dark), device_admin.xml, launcher icons | Framework-only UI, `findViewById`, no AndroidX |
| `build.sh` + `build/assemble.py` | Manual build pipeline (kotlinc + aapt2 + d8 + zipalign + apksigner) |
| `build.gradle.kts`, `app/build.gradle.kts`, `.github/workflows/android.yml` | Gradle / GitHub Actions build for a normal machine |

## The v4 bug, fixed and proven

v4 accumulated daily usage only when the foreground app *changed*, so
continuous use in one app never reached its limit. v5's
`GuardService.tick()` calls `store.addUsage(group, 500ms)` and
`tracker.tick(group)` on **every** poll, whatever the foreground app is.

`UsageTrackerTest` proves it (all in `app/src/test/...`):
- `continuousUseInOneAppReachesLimit` — 3,600 identical ticks of the AI
  group (30 min limit) reach the limit exactly on tick 3,600.
- `limitNotReachedOneTickEarly` — 3,599 ticks do not reach it.
- `switchingAppsKeepsEachGroupsUsage`, `nullForegroundAccumulatesNothing`,
  `newDayResetsUsage`, `restoreKeepsPersistedUsage`.

Full test run: **26 tests, 0 failures** (`UsageTrackerTest` 6,
`LimitsTest` 7, `BlockDeciderTest` 8, `LangTest` 5).

## Feature list — what exists now (point at what to add next)

Olivia said more features of this kind will follow; nothing beyond the
brief was invented. Current features, each in its own file so a new one
can be added without touching the others:

1. Strict Mode until midnight (test mode 1 min) — `StrictSetupActivity`,
   `Store` (elapsedRealtime end), `GuardService`
2. Night Lock 00:00–06:00 + hours picker + allowed-apps picker —
   `NightPickerActivity`, `AppPickerActivity` (MODE_NIGHT)
3. Daily limits: Facebook 120m / Chrome 90m / YouTube 60m / AI 30m —
   `Limits`, `UsageTracker`, `Store`
4. Custom blocklist picker — `AppPickerActivity` (MODE_CUSTOM)
5. Floating / split-screen / PiP blocking (500 ms UsageStats poll) —
   `GuardService`
6. Bypass-app blocking (Settings, Play Store, installer, clone apps) —
   `Limits.BUILTIN_STRICT`, `BlockDecider`
7. Tamper Log — `Store.logTamper`, `TamperLogActivity`
8. Diagnostics — `DiagnosticsActivity`
9. Boot restart — `BootReceiver`
10. Notification silencing during Strict/Night — `QuietListener`
11. Clock-change / package-change logging — `SystemEventsReceiver`
12. Device Admin (watch-login only) — `GuardAdminReceiver`
13. Language switch EN ↔ BN (instant, persisted) — `Lang`, `Store.lang`
14. Theme switch Light ↔ Dark (system default, persisted override) —
    `Lang`, `BaseActivity`, `themes.xml`
15. 7-step setup checklist — `MainActivity.setupSteps()`

## UI — what matches the screenshot, what is new

Matches v3.7's screenshot: green status card ("Strict বন্ধ আছে /
আজকের সীমা সক্রিয়"), "দৈনিক সীমা সবসময় কার্যকর থাকে - Night Lock:
বন্ধ", "সেটআপ: ০ / ৭ ধাপ শেষ", "মনিটরিং সার্ভিস চালু করুন",
"আজকের ব্যবহার" with Facebook ২ ঘণ্টা / Chrome ১ ঘণ্টা ৩০ মিনিট /
YouTube ১ ঘণ্টা / AI চ্যাট ৩০ মিনিট + bars and %, 7 setup steps with
Bengali titles/descriptions + "বাকি আছে" badges, features (Night Lock,
allowed-apps picker, custom block list, Tamper Log, Diagnostics),
footer "দৈনিক সীমা অ্যাপে নির্ধারিত — অ্যাপ থেকে বদলানো যায় না",
bottom button "Strict Mode চালু করুন…".

New in v5 (Olivia's 2026-11-07 16:04 notes):
- **Language switch** — one tap in the header toggles English ↔ বাংলা
  for every string, instantly, without restarting the app (the current
  screen re-binds all its strings in place; new screens open in the
  chosen language). The choice persists. English is the default.
- **Theme switch** — one tap toggles Light ↔ Dark; persists. The
  default is to follow the system theme; the toggle stores an explicit
  override. Both themes use the same calm muted sage-green accent, and
  every screen (main, block screen, setup, Night Lock, Tamper Log,
  Diagnostics) uses theme attributes, so contrast stays readable in
  both modes.
- **Calm design** — muted colours only; no bright attention-grabbing
  colours, no animations, no gamification, no streaks, no rewards.

Could NOT be reproduced from the screenshot:
- **XOS Autostart detection** — Infinix's autostart setting cannot be
  read back by an app, so that setup step is a manual confirmation
  (tap opens the app settings page; the step is marked done when the
  user confirms it there). The guard still restarts on boot via the
  boot receiver.
- **"Recents lock"** — Android gives no API for locking an app in
  Recents without Accessibility; the step covers Autostart + the boot
  receiver instead. Stated honestly in the README.
- The screenshot's exact font/spacing is approximated with the system
  font; the layout, texts and colours match, the pixel metrics do not.

## Anti-bypass layers (strongest available WITHOUT root, WITHOUT Accessibility)

1. **Mode-agnostic foreground blocking.** UsageStats
   `MOVE_TO_FOREGROUND` fires in every window mode. A blocked app opened
   from the XOS sidebar as a floating window, in split-screen, or in PiP
   is still foreground, so the 500 ms poll sees it and blocks it.
2. **500 ms poll, START_STICKY foreground service** with a permanent
   notification.
3. **Overlay block screen** (full-screen, auto-hides after 6 s so it
   never traps the home screen) + BlockActivity + go-home.
4. **Device Admin (watch-login only)** — blocks uninstall while admin
   is active; admin disable is logged.
5. **Strict end in elapsedRealtime** — clock changes are logged and do
   NOT end Strict early.
6. **Permission-loss detection** — every poll checks Usage Access /
   Overlay / Admin; loss is logged to the Tamper Log.
7. **Boot receiver** — guard restarts after a reboot.
8. **Bypass-app blocking** — Settings, Play Store, installer, clone /
   parallel / work-profile apps locked during Strict/Night.
9. **Notification silencing** during Strict/Night (QuietListener).

## Honest limits — do NOT claim 0% bypass

- Up to ~500 ms visibility of a blocked app before the block screen.
- Force-stop from Settings stops the guard until the app is opened
  again or the phone reboots.
- Safe Mode disables all third-party apps, including this guard.
- ADB / USB debugging can uninstall or disable the app.
- A second user / work / guest profile has its own apps.
- Factory reset: not a concern for Olivia (phone on installment).

## Build notes

- `build.sh` runs: aapt2 compile → aapt2 link → javac R.java →
  kotlinc 1.9.22 → JUnit tests → d8 → assemble → zipalign → apksigner.
- One compile fix was needed: the android-35 stub jar omits
  `RoleManager.getRoleHolders()` — `isRoleHeld(ROLE_HOME)` is used
  instead (same check, present in the stub).
- Two deprecation warnings only: `MOVE_TO_FOREGROUND` and
  `checkOpNoThrow` — both still work on API 34/35.
- Gradle was NOT used in this sandbox (localhost TCP interception, as
  before). The Gradle project is included for a normal machine.

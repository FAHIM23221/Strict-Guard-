# Strict Guard v6.1.4 — Build Report

**Date:** 2026-11-09 ~03:20 Asia/Dhaka
**Base:** v6.1.3 (SHA-256 `2dcf4789af7dc66749b99df5995c65ae6d3d1f613496e738572ec1bf514cebb1`)
**Version:** versionCode 39, versionName 6.1.4, package `app.strictguard`
**Build route:** same manual kotlinc 1.9.22 + aapt2 + d8 route as v6.1.3. No decompile. No Gradle.
**Requested by:** Fahim, voice 2026-11-09 ~03:00 — "এখনই কাজ শুরু করে দাও" (start now).

## What changed — three hardening items only

### 1. Phone Master hidden + blocked during Strict Mode

Phone Master is Transsion's system cleaner. It can freeze / disable apps — including Strict Guard itself — so during Strict Mode it is a bypass route like Settings.

- **Verified package name:** `com.transsion.phonemaster` — Uptodown lists "Package Name: com.transsion.phonemaster" (developer TRANSSION MOBILE); APKMirror agrees across every version listed (e.g. 5.6.7.00001, "Package: com.transsion.phonemaster"). Hard-coded, like the study-app package — there is no UI to change it, so it cannot be weakened in a moment of temptation.
- **New file `PhoneMaster.kt`** (pure logic): `isPhoneMaster` (package), `isPhoneMasterActivity` (package OR activity class, same second layer as the Settings check, for OEM wrappers), `isPhoneMasterLabel` (label fallback, display filtering only — never used for a block decision, so a label can never block an unrelated app), `isHidden` / `visibleApps`.
- **Hidden:** `LauncherLogic.visibleApps()` filters it out of the launcher grid AND the hidden-apps (all-apps) dialog while Strict is on — it does not appear at all, not even dimmed, not even with a lock badge. `AppPickerActivity` filters it out of its searchable list too (defence in depth; the picker itself is locked during Strict anyway).
- **Blocked:** `BlockDecider.decide()` returns `STRICT_BYPASS` for it during Strict, before the daily-limit rules. The launcher's `tapDecision` already routes through `decide()`, so a leaked entry would still be blocked.
- **Scope is Strict Mode ONLY.** At night it is blocked only by the generic Night Lock rule like any other non-allowed app (`NIGHT`, not `STRICT_BYPASS`); in normal use it opens freely. When Strict ends it returns to the launcher normally.
- Hiding is display-only: the guard service blocks the launch itself, so it cannot be opened from Recents, a notification, or another launcher either.

### 2. Faster Settings block during Strict

**Why it was slow (audit):** two causes.
1. The foreground was only resolved AFTER the HSC reminders, the auto-theme check, the permission watch and the study trigger on every tick, and every tick paid for a UsageStats most-recent query even when the sticky foreground package was already known.
2. The poll itself ran every 500 ms.

**Fix:**
- New `BlockDecider.fastBlockDecision()` — checked FIRST on every poll while Strict is on, before any of that work. Covers Settings (package or activity), our own settings activities, and Phone Master. The resolved foreground is reused for the rest of the tick, so the tick pays for one foreground query instead of two.
- `currentForeground()` now queries UsageStats most-recent lazily — only when there is no fresh event AND no sticky package (e.g. right after a service restart).
- **Poll interval is now 250 ms while Strict is on** (`Limits.FAST_POLL_MS`), 500 ms otherwise. If Settings is already foreground when Strict starts, the sticky resolver sees it on the next poll and the fast path blocks it immediately — no wait for a new event.
- **Expected detection time, honestly:** worst case ~250 ms from opening Settings to the block landing (one poll interval plus one cheap foreground query). Not zero — polling cannot be truly instant without Accessibility, which is forbidden on this phone.
- **Accounting safety:** the interval is threaded through ALL usage accounting as the per-tick milliseconds (`UsageTracker.tick(groupId, today, tickMs)`, `store.addUsage`, `addSessionUsage`, `BreakCycle.onUseTick`, `StudyLock.onTick`), so a 250 ms tick adds 250 ms of usage — never 500 ms. Verified by test: the Facebook limit (120 min) takes exactly 14,400 ticks at 500 ms and 28,800 ticks at 250 ms.
- Battery: 4 UsageStats queries a second while Strict is on, 2 a second otherwise — the same order of magnitude as before; no new wakeups.

### 3. Faster boot guard

**Why there was a window (audit):** `onReceive` and the guard service share the app's main thread, so every millisecond the BOOT_COMPLETED receiver spent on slow work (the Keystore mirror decrypt in `MirrorStore.checkAndRestore`, alarm scheduling) delayed the guard's first enforcement tick by exactly that long. The direct-boot guard (since v6.0.0) already starts before the first unlock — the gap was in the BOOT_COMPLETED path.

**Fix:**
- `BootReceiver` (BOOT_COMPLETED / QUICKBOOT_POWERON) now requests the guard start from the cheap device-protected mirror alone, via the new pure `BootRestore.bootStartDecision(wallEnd, now, wanted)`, and only then runs the slow work (`bootSlowWork()`: mirror restore, schedule recovery, alarm scheduling, launcher open) on a background thread, so the receiver returns immediately and the service can actually start. The slow work is idempotent, so running it next to the service's own boot work is safe.
- `SystemEventsReceiver` (USER_UNLOCKED) got the same "enforce first" reorder: guard start requested before the mirror restore and alarm scheduling.
- The LOCKED_BOOT_COMPLETED (direct-boot) path was already minimal and is unchanged. The mirror-restore check in the service's `onStartCommand` is deliberately KEPT — its Tampered branch (mirror tampered → keep Strict on to the maximum duration) is a security check that must not be skipped.
- **Honest limit:** Android's own boot sequence cannot be shortened by any app — only the guard's own startup path can be made leaner. What this removes is the app's own ~0.1–0.6 s of mirror/alarm work from the critical path. The remaining window is Android's boot itself.

## What did NOT change

- No other feature changes. MCQ time-earning and tiered Strict double-confirm / cancel windows are NOT in this version (still awaiting Fahim's go-ahead).
- All v6.1.3 behaviour retained: always-unlocked six, circular study countdown, Night Lock defaults, break cycle, Warm Sand theme, HSC countdown, Friday Jumu'ah, force-stop / Clear Data mirror protection.
- No Accessibility Service. No INTERNET permission.

## Verification

- **Tests: 272/272 pass** (239 in v6.1.3 + 33 new).
  - `PhoneMasterTest` (18): verified package, package/activity/label identity, hidden during Strict / visible when off, `visibleApps` filter, `decide()` STRICT_BYPASS during Strict, allowed in normal use, generic NIGHT rule only at night.
  - `FastBlockTest` (10): fast path blocks Settings / own settings / Phone Master during Strict and is silent when Strict is off, launcher and block screen never fast-blocked, 250 ms interval during Strict / 500 ms otherwise, fast ticks count half as much (14,400 vs 28,800 ticks to the Facebook limit).
  - `BootSpeedTest` (5): `bootStartDecision` from mirror values only, agrees with `directBootGuardStart` for the same inputs on both boot layers.
- **aapt2 badging:** `package: name='app.strictguard' versionCode='39' versionName='6.1.4'`, minSdk 29, targetSdk 34.
- **apksigner:** Verifies, v3 scheme only (v1/v2/v4 false, 1 signer) — same as v6.1.3.
- **Accessibility:** 0 accessibility strings in the DEX, none in the manifest.
- **Permissions:** no INTERNET (same 12 permissions as v6.1.3).
- **New code in the APK:** `PhoneMaster` class present in `classes.dex`.
- **APK SHA-256:** `8b6665b0c5364efb7b51943894d3f770f03458f627c07af7d4987a2e17997851`
- **APK size:** 867,656 bytes

## Files changed

- New: `app/src/main/java/app/strictguard/PhoneMaster.kt`
- New tests: `PhoneMasterTest.kt`, `FastBlockTest.kt`, `BootSpeedTest.kt`
- Modified: `BlockDecider.kt` (Phone Master block + `fastBlockDecision`), `LauncherLogic.kt` (`visibleApps`), `LauncherActivity.kt` (grid + hidden-apps dialog filter), `AppPickerActivity.kt` (picker search filter), `Limits.kt` (`FAST_POLL_MS`, `pollIntervalMs`, `UsageTracker.tick` tickMs), `GuardService.kt` (dynamic poll interval, fast path at top of `tick()`, lazy `statsMostRecent`, tickMs accounting, `studyTick` tickMs), `BootReceiver.kt` (mirror-first start + background slow work), `BootRestore.kt` (`bootStartDecision`), `SystemEventsReceiver.kt` (unlock reorder), `AndroidManifest.xml` (39 / 6.1.4), `build.sh` (39 / 6.1.4, new test classes).

## Install

1. Install v6.1.4 **over** v6.1.3 — same signing key (signer certificate SHA-256 `0367b410108019d6c2e18a26609b7a619cbd75ad19a60bf3a4a9280f47ef6304` on both APKs, verified), so no uninstall is needed. If the phone refuses the install for any reason, uninstall v6.1.3 first and install fresh.
2. Set Strict Guard as the default launcher (if it asks again).
3. Redo the 7 setup steps (Overlay step matters for the study countdown circle).

(Only v3.7 and older need a forced uninstall first — different signing key.)

## Still owed / not tested on-device

- No on-device testing (no Android emulator / adb on this Linux computer). Fahim to test on his Infinix: (a) Phone Master invisible in the launcher during Strict and back when Strict ends; (b) Settings block now lands in ~a quarter of a second during Strict; (c) reboot with Strict on — guard enforcing by the time Settings can be opened.
- The v6.1.3 on-device checks are still open: whether his Brilliant stays unlocked (Brilliant.org vs Brilliant Connect), the six always-unlocked apps, the circular countdown at the 21:00 Study Lock.

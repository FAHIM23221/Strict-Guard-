# BUILD REPORT — Strict Guard v6.0.0

Date: 2026-11-08. Built for Fahim (Infinix X6886, Android 16).
Base: v5.2.1 source in this same directory (verified byte-identical to
~/workspace/your_files/Strict-Guard-v5.2.1-source.zip before editing).
Package: `app.strictguard`, versionName 6.0.0, versionCode 34, minSdk 29, targetSdk 34.
No APK was decompiled; built from the v5 source only, manual kotlinc + aapt2 + d8
route (Gradle cannot run in this sandbox).

**Rebuilt 2026-11-08 ~17:20 +06** after Fahim's two follow-ups: (1) launcher
design freedom — do not copy the v3.7 screenshot, use a cleaner design of our
own; (2) bypass as close to impossible as possible, closing the boot gap.
Same version 6.0.0 / code 34; the APK below is the rebuilt one.

## Result: SUCCEEDED

- **APK:** `~/workspace/your_files/Strict-Guard-v6.0.0.apk` — 780,745 bytes
- **SHA-256:** `a209c035713d4a3f122eadfcc0aaae42a7da5d9da55f20c0fa0a7afb89ace385`
- **Source zip:** `~/workspace/your_files/Strict-Guard-v6.0.0-source.zip`
  (85 files; SHA-256 is in the delivery message — the zip contains this
  report, so its hash is recorded outside it)
- **Signature:** apksigner verifies, 1 signer (same fresh debug keystore as
  v5/v5.1/v5.2/v5.2.1, CN=Strict Guard, O=Self-built, C=BD). Signing scheme
  **v3 only** (v1/v2 false) — same apksigner 35.0.0 quirk as before; v3 covers
  Android 9+ and minSdk is 29.
- **Unit tests: 87/87 pass** (JUnit 4.13.2) — v5.2.1's 57 + 17 in
  `LauncherTest.kt` (greetings, short duration text, grid sorting, tap
  decisions) + 13 new in `BootRestoreTest.kt` (direct-boot start, normal-boot
  start, launcher-on-boot, schedule recovery after reboot).
- **No Accessibility:** 0 "accessibility" strings in the dex, no
  AccessibilityService / BIND_ACCESSIBILITY in the manifest.
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no
  http(s) URL strings in the dex.
- **HOME intent filter confirmed in the built APK** (aapt2 xmltree):
  `LauncherActivity` declares MAIN + HOME + DEFAULT, exported, singleTask.
- **Direct-boot flags confirmed in the built APK** (aapt2 xmltree):
  `GuardService` and `BootReceiver` both `directBootAware=true`;
  `LOCKED_BOOT_COMPLETED`, `BOOT_COMPLETED`, `QUICKBOOT_POWERON` on
  BootReceiver; `USER_UNLOCKED` on SystemEventsReceiver.
- **Review video:** `~/workspace/your_files/Strict-Guard-v6.0.0-review.mp4`
  — 85 seconds, 720×1280, Bengali narration (see "Install-and-review"
  below).
- **NOT tested on a real device.** Fahim must uninstall v3.7, v4.0.0,
  v5.0.0, v5.1.0, v5.2.0 and v5.2.1 first (different signing key) before
  installing v6.0.0.

## New in v6.0.0 — custom home launcher

Fahim sent a screenshot of the old v3.7 launcher (file
`~/workspace/user/files/93035_0_elqp.jpg`) and asked for a beautiful,
very strong launcher like that one. v6.0.0 adds it, on top of v5.2.1:

- **LauncherActivity** (new, `HOME` + `DEFAULT` intent filters, singleTask):
  can be set as the default home launcher. Setup step 4 ("Default Home
  launcher", RoleManager) already existed — it now points at a real
  launcher. A "Home launcher" feature row on the dashboard also opens it.
- **Home screen — cleaner design of our own (Fahim's design freedom,
  2026-11-08):** the launcher does NOT copy the v3.7 screenshot. The
  greeting sits directly on the calm background with no card around it
  (launcher-like, airy): time-of-day greeting (শুভ সকাল / শুভ দুপুর /
  শুভ বিকেল / শুভ সন্ধ্যা / শুভ রাত্রি — 17:05 shows শুভ বিকেল), a big
  24h clock, and the date in Bengali (e.g. রবিবার, ৮ নভেম্বর ২০২৬).
  The Strict Mode card is the one sage-green anchor on the screen,
  with white usage rows inside it (new `item_usage_light.xml`, white
  fill on a translucent track): remaining time and the four
  "আজকের ব্যবহার" usage bars (Facebook, Chrome, YouTube, AI চ্যাট)
  with real stored limits and usage, e.g. "1h 46m / 2h". Below,
  "অ্যাপসমূহ" — a scrollable grid (4 per row) of installed launchable
  apps with icons and names, Strict Guard pinned first with a
  "পিন করা" badge. Still calm: muted sage-green, no bright colours,
  no animation, no gamification.
- **Tapping an app enforces the guard:** the tap goes through
  `LauncherLogic.tapDecision` — the same `BlockDecider` rules the guard
  service uses. A blocked tap (Strict Mode, Night Lock, daily limit
  reached, custom blocklist, or another home/launcher app during
  Strict/Night) opens the block screen instead and is written to the
  Tamper Log ("LAUNCHER_BLOCKED …"). Blocked apps are shown dimmed with
  a 🔒 mark. Allowed apps launch normally. Tapping Strict Guard opens
  the settings dashboard (MainActivity).
- **The launcher is the guard's home:** pressing Home returns here, not
  to the system launcher (when set as default home). Back on the
  launcher does nothing, as on a home screen.
- **Backend hardening:** boot receiver already restarts GuardService and
  restores the Strict schedule after reboot; the service is START_STICKY;
  LauncherActivity (like MainActivity) self-heals on resume — if
  monitoring is wanted or Strict is on and the guard was killed, it
  restarts the service and logs it; a warning is shown when blocking is
  off. UsageStats polling stays at 500 ms with the sticky foreground
  resolver from v5.2.1. **Rebuilt 2026-11-08 with the boot-gap hardening
  below** — the guard now starts before the user unlocks.

## Bypass hardening — closing the boot gap (Fahim, 2026-11-08)

Fahim's case: after power-off/power-on there is a window of a few
seconds before the guard starts, during which the app could be
uninstalled (open Settings → deactivate Device Admin → uninstall).
v6.0.0 closes that window in three layers, all unit-tested in
`BootRestoreTest.kt` (13 tests) and all verified present in the built
APK's manifest/dex:

1. **Guard starts BEFORE unlock (direct boot).** `BootReceiver` and
   `GuardService` are `directBootAware=true`. On `LOCKED_BOOT_COMPLETED`
   the receiver reads the Strict schedule from a **device-protected
   mirror** (`strictguard_boot` prefs — Strict wall-clock end +
   service-wanted, mirrored by `Store.mirrorBootState()` on every
   Strict start/end and every service-wanted change, because the
   normal prefs are credential-encrypted and unreadable before
   unlock). If Strict is on or monitoring is wanted, the guard starts
   immediately — it is already running when the lock screen opens, so
   by the time the user can touch Settings, Settings is already
   blocked while Strict is on.
2. **Launcher opens immediately on reboot.** On `BOOT_COMPLETED`
   (and `QUICKBOOT_POWERON`) the receiver recovers the Strict
   schedule from the wall-clock end, restarts the guard, and opens
   `LauncherActivity` right away when Strict is on or Strict Guard
   is the default home (needs the overlay permission for the
   background-activity exemption; if the start is refused, the
   default-home mechanism still shows the launcher first). Logged as
   `BOOT_LAUNCHER` / `BOOT_LAUNCHER_FAILED` in the Tamper Log.
3. **Unlock corrects a direct-boot start.** `GuardService` never
   crashes if its Store cannot initialise before unlock — `initStore()`
   retries on every 500 ms poll, and `onStartCommand` re-reads state
   (`refreshState()`) on every start. `SystemEventsReceiver` handles
   `USER_UNLOCKED`: it recovers the Strict schedule and restarts the
   guard with the real (credential-encrypted) state the moment the
   user unlocks, logging `UNLOCKED guard restarted`.

**Other bypass routes, re-checked for v6.0.0:**
- Uninstall while Strict is on: Device Admin stays active across
  reboot and blocks uninstall while active; the admin screen itself
  (Settings → Security → Device admin apps) is blocked by package +
  activity class while Strict is on, from the first second after
  unlock (layer 1). Admin loss is still logged + notified on every
  poll if it ever happens.
- Settings / Play Store / package installer / clone apps / Smart
  Panel: already in the builtin-strict list (v5.2.x), blocked during
  Strict/Night by UsageStats in every window mode (floating,
  split-screen, PiP) — the launcher tap path enforces the same rules,
  and the system launcher itself is blocked as a tap target during
  Strict, so Home cannot be used to escape.
- Clock change + reboot: Strict end is elapsedRealtime while running
  and wall-clock for reboot recovery; clock changes are logged.
- Force-stop: the guard restarts when MainActivity/LauncherActivity
  opens, or on the next reboot (layers 1–2).

**What Android still allows (honest limits, unchanged):**
- Device Admin CAN be deactivated in Android Settings when Strict is
  OFF — no app can prevent that. The protection is that Strict stays
  on across reboot and the admin screen is unreachable while it is on.
- Safe Mode, ADB (`adb uninstall` / `pm`), and a second user profile
  bypass any app-level guard. No app can close those without a
  device-owner/MDM setup, which this app is not.
- A blocked app can still flash for up to ~500 ms (one poll interval)
  before the block screen appears.

## Kept unchanged (verified by tests)

- Strict schedule (until midnight / N days / date+time, survives reboot,
  cannot be shortened during Strict), LOCK DURING STRICT, Strict blocks
  Facebook / Chrome / YouTube / AI groups itself, usage accumulated on
  EVERY 500 ms poll, floating / split-screen / PiP blocking, Sidebar /
  Smart Panel blocking, Night Lock + allowed-apps, custom blocklist,
  Tamper Log, Diagnostics, boot receiver, calm muted sage-green UI,
  one-tap Bangla/English switch (persisted), Dark + Light modes
  (persisted). The launcher's language/theme toggles are the same
  persisted switches, locked during Strict.

## How to set it as the default home

1. Install v6.0.0 (uninstall all older versions first).
2. Complete the setup steps in Strict Guard; step 4 ("Default Home
   launcher") opens the system home chooser — pick **Strict Guard**.
   Or press Home and pick Strict Guard as "Always".
3. The launcher can also be opened from the dashboard ("Home launcher")
   without being the default home — but it only guards the Home button
   once it IS the default home.

## Install-and-review (Fahim's post-build instruction, 2026-11-08)

Fahim asked: install the app on a computer, open it, go through
everything, review the whole app, and make a video of the app itself.

**What was actually attempted, honestly:**
- `adb devices` in this sandbox returns an empty list — no phone or
  tablet is attached.
- The Android SDK here has build-tools, cmdline-tools, platform-tools
  and platforms only. There is **no emulator binary, no system image,
  and no /dev/kvm** (no hardware virtualisation), and only ~745 MB of
  free RAM — a software-emulated AVD cannot boot here. Downloading a
  system image would not change that.
- So **no live install-and-open test was possible in this sandbox**.
  Nothing in this report claims otherwise.

**What was done instead:**
- A narrated walkthrough video was built from the app's **actual
  screens**: `~/workspace/your_files/Strict-Guard-v6.0.0-review.mp4`
  (85 s, 720×1280, H.264 + AAC, Bengali narration, 1,679,115 bytes,
  SHA-256 `60a8e36f3f6b6cd4c83909867cf2f25392fd32db9738fa02e03b059dceeade22`).
  Six slides, each rendered with PIL from the real layout XMLs and
  strings (`activity_launcher.xml`, dashboard, `BlockActivity`,
  boot flow): (1) title, (2) the new launcher, (3) dashboard,
  (4) block screen, (5) boot-gap timeline, (6) honest limits. The
  video itself says on the title slide that it is a walkthrough
  reconstruction, not a screen recording. Slides:
  `review/render_slides.py`; narration via TTS (Bengali, default
  voice — it may sound imperfect, as Bengali TTS quality varies).
- **Review verdict from the verified build** (unit tests 87/87,
  manifest + dex checks, no Accessibility, no INTERNET, HOME intent
  + direct-boot flags confirmed in the built APK): the code does what
  the spec says — launcher, tap blocking, Strict schedule recovery,
  boot-gap layers. What is **not** verified: that it installs and
  runs on a real phone, that the launcher actually becomes default
  home on XOS, that the overlay appears over a floating window, and
  that the direct-boot start fires on Fahim's Infinix. The real
  on-device test stays on his phone.

## Honest limits

- Up to ~500 ms visibility of a blocked app before the block screen.
- Device Admin CAN still be deactivated in Android Settings when
  Strict is OFF — Android genuinely lets the user do that, and no app
  can change it. During Strict, Settings is blocked by package +
  activity with a sticky foreground check, the in-app admin control is
  locked, the guard self-heals if killed, and any loss is logged +
  notified.
- The launcher only takes effect after Fahim picks it as the default
  home. Until then the system launcher is still reachable from Home.
- A wall-clock schedule has one trade-off: if the user changes the
  wall clock AND reboots, the recomputed end follows the (changed)
  clock. Clock changes are logged to the Tamper Log.
- Force-stop from Settings stops the guard until the app is opened
  again (MainActivity/LauncherActivity then restarts it) or the phone
  reboots. Safe Mode / ADB / second profile can bypass, as before.
- No on-device testing in this sandbox. Fahim should test: set Strict
  Guard as default home, press Home (it should show the launcher);
  turn Strict on and tap Facebook/YouTube in the grid (block screen);
  tap a normal app (it should open); reboot with Strict on and confirm
  Strict is still active and the launcher still appears on Home.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.strictguard"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.strictguard"
        minSdk = 29
        targetSdk = 34
        versionCode = 42
        versionName = "6.1.7"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Pure Android framework + Kotlin stdlib only. No AndroidX, no internet.
}

package app.strictguard

import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * HSC 2027 exam live countdown + reminders (v6.1.0).
 *
 * Target: HSC 2027 first exam, 6 June 2027, 10:00 AM Asia/Dhaka
 * (Bangla 1st Paper; theory ends 13 July 2027, practicals by
 * 18 July). Verified from the Education Minister's 14 May 2026
 * announcement (TBS / Daily Star / Prothom Alo / BSS).
 *
 * The countdown ticks every second in TWO places: at the very top
 * of the main page/dashboard and on the launcher home screen — the
 * FIRST element, HIGHLIGHTED (deep warm-brown card, large bold
 * cream numbers), pinned/sticky so it never scrolls away. It ticks
 * ONLY while the launcher/dashboard is visible (a 1-second handler
 * in the activity, started in onResume and stopped in onPause). No
 * background per-second wakeups — no battery drain when the screen
 * is off or another app is in front.
 *
 * Format: days + hours + minutes + seconds remaining, e.g.
 * "HSC পরীক্ষার বাকি ২০৯ দিন ১৪ ঘণ্টা ৩২ মিনিট ১০ সেকেন্ড".
 * Calm Warm Sand styling — no bright colours, no gamification.
 *
 * End states: when the countdown reaches zero show "HSC পরীক্ষা
 * শুরু হয়েছে" (exam started); after the exam period ends (13 July
 * 2027) show "HSC পরীক্ষা শেষ হয়েছে" instead of a negative
 * countdown. Never show negative time.
 *
 * The exam date is changeable in settings (date picker, time fixed
 * at 10:00 Dhaka — the board has said dates may be revised),
 * locked during Strict like every other setting.
 *
 * Reminders:
 * - Once-daily 08:00 Dhaka notification stating the days
 *   remaining, toggleable, default ON. Sent from the guard poll
 *   (the guard already runs continuously); no AlarmManager, no
 *   extra wakeups. If the guard is stopped, the reminder waits
 *   for the next run — it never fires twice in one day.
 * - Daily "one day less" alert: every midnight, when the
 *   days-remaining number drops by one, a full-screen popup on the
 *   next unlock (dismiss with "বুঝেছি", once per day) AND a
 *   high-priority notification. Messages are MOTIVATIONAL and
 *   urgent — they push him to change/improve, always stating one
 *   more day is gone, how many days are left, and that there is
 *   not much time in hand; firm but never shaming. Toggleable,
 *   default ON; survives reboot via persisted state. The popup is
 *   shown by the launcher/main activity on resume (the home screen
 *   is what he sees on unlock); the notification is posted by the
 *   guard the moment the drop is detected.
 *
 * Pure logic — fully unit-testable; the UI ticking, the picker and
 * the notifications live in the activities / [GuardService].
 */
object HscCountdown {

    const val ZONE_ID: String = "Asia/Dhaka"

    /** First exam: 6 June 2027, 10:00 AM Dhaka. */
    val DEFAULT_EXAM_MS: Long =
        ZonedDateTime.of(2027, 6, 6, 10, 0, 0, 0, ZoneId.of(ZONE_ID))
            .toInstant().toEpochMilli()

    /**
     * End of the exam period: after 13 July 2027 is over
     * (14 July 00:00 Dhaka) the countdown shows "exam ended".
     * Theory ends 13 July; practicals run to 18 July.
     */
    val EXAM_END_MS: Long =
        ZonedDateTime.of(2027, 7, 14, 0, 0, 0, 0, ZoneId.of(ZONE_ID))
            .toInstant().toEpochMilli()

    /** The 08:00 daily reminder fires at 08:00 Dhaka. */
    const val REMINDER_HOUR: Int = 8

    /** Calendar day ("yyyy-MM-dd") in Asia/Dhaka. */
    fun dayKey(nowWallMs: Long): String =
        ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID))
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))

    /** Hour of day (0–23) in Asia/Dhaka. */
    fun hourOfDay(nowWallMs: Long): Int =
        ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID)).hour

    /** Exam instant for a picked date (year, month0, day) at 10:00 Dhaka. */
    fun examMsForDate(year: Int, month0: Int, day: Int): Long =
        ZonedDateTime.of(year, month0 + 1, day, 10, 0, 0, 0, ZoneId.of(ZONE_ID))
            .toInstant().toEpochMilli()

    data class Parts(val days: Long, val hours: Int, val minutes: Int, val seconds: Int)

    /** Split a remaining duration into days / hours / minutes / seconds. Never negative. */
    fun decompose(remainingMs: Long): Parts {
        val totalSeconds = (remainingMs.coerceAtLeast(0L) / 1000L)
        return Parts(
            days = totalSeconds / 86_400L,
            hours = ((totalSeconds % 86_400L) / 3600L).toInt(),
            minutes = ((totalSeconds % 3600L) / 60L).toInt(),
            seconds = (totalSeconds % 60L).toInt()
        )
    }

    /** Whole days remaining (the number the reminders quote). */
    fun daysRemaining(nowWallMs: Long, examMs: Long): Long =
        decompose(examMs - nowWallMs).days

    /**
     * Launcher months format (v6.1.0, Fahim 2026-11-08): "209 days"
     * on the launcher feels like too much, so the launcher shows
     * FULL CALENDAR MONTHS + REMAINING DAYS instead — e.g. 8 Nov
     * 2026 → 6 June 2027 is 6 months 29 days (8 Nov + 6 months =
     * 8 May 2027; 8 May → 6 June = 29 days). Calendar months, not
     * 30-day chunks, so the number matches a wall calendar. The
     * value only changes at midnight (it is date-based, not
     * time-based), so the launcher does not tick hours/minutes/
     * seconds. The main page keeps the full d/h/m/s ticking, and
     * the daily "one day less" alerts still quote days.
     * Returns (0, 0) once the exam has started or ended.
     */
    data class MonthsDays(val months: Long, val days: Long)

    fun monthsAndDays(nowWallMs: Long, examMs: Long): MonthsDays {
        val zone = ZoneId.of(ZONE_ID)
        val nowDate = ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), zone).toLocalDate()
        val examDate = ZonedDateTime.ofInstant(Instant.ofEpochMilli(examMs), zone).toLocalDate()
        if (!examDate.isAfter(nowDate)) return MonthsDays(0L, 0L)
        val months = java.time.temporal.ChronoUnit.MONTHS.between(nowDate, examDate)
        val afterMonths = nowDate.plusMonths(months)
        val days = java.time.temporal.ChronoUnit.DAYS.between(afterMonths, examDate)
        return MonthsDays(months, days)
    }

    sealed class State {
        /** The exam is still ahead: live countdown. */
        data class Counting(val parts: Parts, val remainingMs: Long) : State()
        /** The countdown reached zero: the exam has started. */
        object Started : State()
        /** After 13 July 2027: the exam period is over. */
        object Ended : State()
    }

    fun state(nowWallMs: Long, examMs: Long, endMs: Long = EXAM_END_MS): State {
        if (nowWallMs >= endMs) return State.Ended
        val remaining = examMs - nowWallMs
        if (remaining <= 0L) return State.Started
        return State.Counting(decompose(remaining), remaining)
    }

    /**
     * The 08:00 daily reminder should fire now: reminders are on,
     * the exam is still ahead, it is 08:00 or later in Dhaka, and
     * no reminder has been sent today yet.
     */
    fun shouldSendReminder(
        nowWallMs: Long,
        examMs: Long,
        reminderEnabled: Boolean,
        lastSentDayKey: String
    ): Boolean {
        if (!reminderEnabled) return false
        if (state(nowWallMs, examMs) !is State.Counting) return false
        if (hourOfDay(nowWallMs) < REMINDER_HOUR) return false
        return dayKey(nowWallMs) != lastSentDayKey
    }

    /**
     * The days-remaining number dropped since it was last seen:
     * midnight passed and one more day is gone. The guard detects
     * this on its poll and posts the high-priority notification;
     * the launcher/main activity shows the popup on next unlock.
     * [lastSeenDays] < 0 means "never observed yet" — no alert on
     * the very first observation, only on a real drop.
     */
    fun dayDropped(lastSeenDays: Long, currentDays: Long): Boolean =
        lastSeenDays >= 0L && currentDays < lastSeenDays

    /**
     * The popup should be shown on this resume: a day-less event
     * is pending and it has not been shown yet.
     */
    fun shouldShowDayLessPopup(dayLessPending: Boolean, popupShownToday: Boolean): Boolean =
        dayLessPending && !popupShownToday

    /**
     * Rotating motivational day-less messages — 10 variants per
     * language (Fahim's tone refinement, 2026-11-08). Every one:
     * one more day is gone, how many days are left (%1$d), not much
     * time in hand — motivational and urgent, the kind of words that
     * push him to change/improve himself. Firm but never shaming,
     * never mocking. The message rotates with the days-remaining
     * number, so it changes every day. In Bengali the days number
     * is rendered in Bengali digits (২০৮, not 208).
     */
    val DAY_LESS_MESSAGES_BN: List<String> = listOf(
        "আরো একদিন কমে গেল — হাতে আছে মাত্র %1\$d দিন, বেশি সময় নেই। আজ থেকেই বদলাও।",
        "একটা দিন চলে গেল, আর ফিরবে না — বাকি %1\$d দিন। আজ থেকেই বদলাও।",
        "আরো একদিন কমে গেল — বাকি %1\$d দিন। সময় হাতে কম, আজকের পড়াটা আজই শেষ করো।",
        "গতকালের মতো আজও যদি কেটে যায়, তাহলে হাতে থাকবে মাত্র %1\$d দিন। এখনই শুরু করো।",
        "সময় কমছে — বাকি %1\$d দিন। নিজেকে বদলানোর সময় এখনই।",
        "আরো একদিন শেষ — হাতে সময় কম, পড়াটা আজই শেষ করো। বাকি %1\$d দিন।",
        "%1\$d দিন বাকি — প্রতিটা দিন গুনে গুনে যাচ্ছে, কাজে লাগাও।",
        "আরো একদিন চলে গেল — বাকি %1\$d দিন। কালকের জন্য ফেলে রেখো না, আজই করো।",
        "একদিন কমে গেল — হাতে মাত্র %1\$d দিন। ছোট করে হলেও আজ থেকেই এগোও।",
        "সময় এগিয়ে যাচ্ছে — বাকি %1\$d দিন। আজকের পড়াটা শেষ করো, কাল আর ফিরবে না।"
    )

    val DAY_LESS_MESSAGES_EN: List<String> = listOf(
        "One more day is gone — only %1\$d days left, and there isn't much time. Start changing today.",
        "A day has passed and it will never come back — %1\$d days left. Change from today.",
        "One more day down — %1\$d days left. Time is short; finish today's study today.",
        "If today slips away like yesterday, only %1\$d days will remain. Start now.",
        "Time is shrinking — %1\$d days left. The time to change yourself is right now.",
        "One more day is over — time is short, finish today's study today. Only %1\$d days left.",
        "%1\$d days left — every day is counting down, one by one. Make it count.",
        "One more day is gone — %1\$d days left. Don't leave it for tomorrow; do it today.",
        "A day is gone — only %1\$d days in hand. Even small steps count, start today.",
        "Time is moving on — %1\$d days left. Finish today's study; tomorrow won't come back."
    )

    fun dayLessMessage(daysLeft: Long, bengali: Boolean): String {
        val list = if (bengali) DAY_LESS_MESSAGES_BN else DAY_LESS_MESSAGES_EN
        val index = ((daysLeft % list.size) + list.size) % list.size
        val text = String.format(list[index.toInt()], daysLeft)
        return if (bengali) Limits.toBengaliDigits(text) else text
    }
}

package app.strictguard

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.TextView
import java.lang.ref.WeakReference

/**
 * v6.1.2 — full-screen Entry Delay countdown.
 *
 * The delay popup normally shows as a TYPE_APPLICATION_OVERLAY
 * view from the guard service, which needs the overlay permission.
 * When that permission is missing — or the overlay view cannot be
 * added — the wait must STILL be shown, so the guard starts this
 * activity instead. It is the same countdown (same layout, same
 * 15-second default, 10 / 15 / 30 choices), full-screen, with no
 * way to skip it: Back does nothing, and leaving via Home makes
 * the guard reset the wait, so a fresh full wait is required on
 * return.
 *
 * This activity owns NO timer state: the guard service
 * ([GuardService]) is the only state machine. The activity only
 * displays the countdown from the deadline it was given, and
 * finishes when the guard says the wait is done
 * ([finishIfShowing]) — or, as a backstop, 1 second after the
 * deadline (never earlier, so the app can never open before the
 * full wait, even if the guard's tick lands late). While this
 * screen is in the foreground the guard keeps counting the wait
 * for the app underneath (see [EntryDelay.effectiveDelayPkg]).
 */
class DelayActivity : BaseActivity() {

    companion object {
        const val EXTRA_PKG = "pkg"
        const val EXTRA_SECONDS = "seconds"
        const val EXTRA_DEADLINE_ELAPSED = "deadlineElapsed"

        /** The currently shown instance, if any (weak — never leaks it). */
        private var current: WeakReference<DelayActivity>? = null

        /** Start the countdown screen for [pkg]. False when the start itself failed. */
        fun launch(
            context: Context,
            pkg: String,
            seconds: Int,
            deadlineElapsed: Long
        ): Boolean {
            return try {
                val i = Intent(context, DelayActivity::class.java).apply {
                    putExtra(EXTRA_PKG, pkg)
                    putExtra(EXTRA_SECONDS, seconds)
                    putExtra(EXTRA_DEADLINE_ELAPSED, deadlineElapsed)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(i)
                true
            } catch (e: Exception) {
                false
            }
        }

        /** True when this activity is currently showing the wait for [pkg]. */
        fun isShowing(pkg: String): Boolean =
            current?.get()?.let { it.waitPkg == pkg && !it.isFinishing } == true

        /** Finish the countdown screen for [pkg], if it is showing. */
        fun finishIfShowing(pkg: String) {
            val act = current?.get() ?: return
            if (act.waitPkg == pkg && !act.isFinishing) act.finish()
        }
    }

    private var waitPkg: String? = null
    private var deadlineElapsed: Long = 0L
    private var countdownView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            updateCountdown()
            // Backstop: never finish before deadline + 1 s — the
            // guard normally finishes this screen first, at the
            // tick that grants the wait.
            if (SystemClock.elapsedRealtime() >= deadlineElapsed + 1_000L) {
                finish()
                return
            }
            handler.postDelayed(this, 200L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.overlay_entry_delay)
        waitPkg = intent.getStringExtra(EXTRA_PKG) ?: ""
        val seconds = intent.getIntExtra(EXTRA_SECONDS, EntryDelay.DEFAULT_SECONDS)
        deadlineElapsed = intent.getLongExtra(EXTRA_DEADLINE_ELAPSED, 0L)
        findViewById<TextView>(R.id.delayTitle).text =
            getString(R.string.delay_title, Util.appLabel(this, waitPkg ?: ""))
        findViewById<TextView>(R.id.delayText).text =
            getString(R.string.delay_text, seconds)
        countdownView = findViewById(R.id.delayCountdown)
        current = WeakReference(this)
        updateCountdown()
        handler.postDelayed(ticker, 200L)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        if (current?.get() == this) current = null
        super.onDestroy()
    }

    /** Back does nothing — the wait must be waited out. */
    override fun onBackPressed() {
        // No-op on purpose.
    }

    private fun updateCountdown() {
        // Seconds left until the deadline, rounded up so "15"
        // shows at the start and "1" until the last second.
        val leftMs = (deadlineElapsed - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
        val secs = (leftMs + 999L) / 1000L
        val bn = if (isStoreReady()) Lang.isBengali(store.lang) else false
        countdownView?.text = if (bn) Limits.toBengaliDigits(secs.toString()) else secs.toString()
    }
}

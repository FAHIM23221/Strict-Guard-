package app.strictguard

import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/**
 * App picker used for two lists: the custom block list and the Night Lock
 * allowed-apps list. Shows every launchable installed app, searchable.
 */
class AppPickerActivity : BaseActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_CUSTOM = "custom"
        const val MODE_NIGHT = "night"
    }

    private data class AppEntry(val pkg: String, val label: String)

    private val all = ArrayList<AppEntry>()
    private val shown = ArrayList<AppEntry>()
    private val selected = HashSet<String>()
    private lateinit var adapter: BaseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // v5.1.0: block/allowed lists are locked during Strict.
        if (store.settingsLocked()) {
            Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        setContentView(R.layout.activity_picker)

        val mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_CUSTOM
        findViewById<TextView>(R.id.pickerTitle).setText(
            if (mode == MODE_NIGHT) R.string.picker_night_title
            else R.string.picker_custom_title
        )
        selected.addAll(
            if (mode == MODE_NIGHT) store.nightAllowed else store.customBlock
        )

        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (ai in apps) {
            if (ai.packageName == packageName) continue
            if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue
            val label = pm.getApplicationLabel(ai).toString()
            all.add(AppEntry(ai.packageName, label))
        }
        all.sortBy { it.label.lowercase() }
        // v6.1.4 — Phone Master never appears in the picker's
        // searchable list while Strict is on. (The picker itself
        // is locked during Strict — see above — so this is defence
        // in depth: the list can never be used to surface it.)
        if (store.isStrictActive()) {
            all.removeAll { PhoneMaster.isHidden(it.pkg, it.label, true) }
        }
        shown.addAll(all)

        adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = convertView ?: LayoutInflater.from(this@AppPickerActivity)
                    .inflate(R.layout.item_app, parent, false)
                val e = shown[position]
                view.findViewById<TextView>(R.id.tvLabel).text = e.label
                view.findViewById<TextView>(R.id.tvPkg).text = e.pkg
                try {
                    val icon = pm.getApplicationIcon(e.pkg)
                    view.findViewById<ImageView>(R.id.ivIcon).setImageDrawable(icon)
                } catch (ex: Exception) {
                }
                val cb = view.findViewById<CheckBox>(R.id.cbApp)
                cb.isChecked = e.pkg in selected
                view.setOnClickListener {
                    if (e.pkg in selected) selected.remove(e.pkg) else selected.add(e.pkg)
                    cb.isChecked = e.pkg in selected
                }
                return view
            }
        }
        findViewById<ListView>(R.id.lvApps).adapter = adapter

        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = (s?.toString() ?: "").trim().lowercase()
                shown.clear()
                shown.addAll(
                    if (q.isEmpty()) all
                    else all.filter { it.label.lowercase().contains(q) || it.pkg.contains(q) }
                )
                adapter.notifyDataSetChanged()
            }
        })

        findViewById<Button>(R.id.btnSavePicker).setOnClickListener {
            if (store.settingsLocked()) {
                Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
                finish()
                return@setOnClickListener
            }
            if (mode == MODE_NIGHT) store.nightAllowed = selected
            else store.customBlock = selected
            store.logTamper(
                if (mode == MODE_NIGHT) "NIGHT_ALLOWED ${selected.size} apps"
                else "CUSTOM_BLOCK ${selected.size} apps"
            )
            finish()
        }
    }
}

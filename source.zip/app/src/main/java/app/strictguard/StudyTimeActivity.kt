package app.strictguard

import android.os.Bundle
import android.widget.Button
import android.widget.TimePicker
import android.widget.Toast

/**
 * Nightly Study Lock time picker (24-hour view). Only the TIME is
 * changed here. The linked app (e test paper) is PERMANENT —
 * hard-coded in [StudyLock] — and there is no UI anywhere to change
 * or remove it. The on/off switch for the feature itself lives on
 * the main screen row (v6.1.7, [Store.studyLockEnabled]), not here.
 */
class StudyTimeActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The time is locked during Strict, like every other setting.
        if (store.settingsLocked()) {
            Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        setContentView(R.layout.activity_study_time)

        val tp = findViewById<TimePicker>(R.id.tpStudy)
        tp.setIs24HourView(true)
        tp.hour = store.studyTimeMin / 60
        tp.minute = store.studyTimeMin % 60

        findViewById<Button>(R.id.btnSaveStudyTime).setOnClickListener {
            if (store.settingsLocked()) {
                Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
                finish()
                return@setOnClickListener
            }
            store.studyTimeMin = tp.hour * 60 + tp.minute
            store.logTamper("STUDY_TIME ${store.studyTimeMin}")
            finish()
        }
    }
}

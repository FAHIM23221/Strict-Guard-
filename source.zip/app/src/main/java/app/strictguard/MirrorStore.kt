package app.strictguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

/**
 * The Strict-state mirror file ([StrictMirror]) — Android side.
 *
 * Location: shared storage, MediaStore Downloads, relative path
 * `Download/StrictGuard`, file `strict_guard_state.bin`. This is a
 * shared/public location, NOT app-private storage and NOT
 * app-specific external storage — so Android's "Clear Data" (which
 * wipes the app's private data + app-specific external files) does
 * NOT delete it. It survives Clear Data on Android 16.
 *
 * No storage permission is needed: on API 29+ (scoped storage) an
 * app can insert, read and delete its OWN MediaStore Downloads
 * entries without READ/WRITE_EXTERNAL_STORAGE. The app's manifest
 * gains no new permission for this.
 *
 * The file is found by DISPLAY_NAME + RELATIVE_PATH (the app's own
 * entry). Writes replace the entry's content in place. All I/O is
 * best-effort and never throws: if shared storage is unavailable
 * (e.g. direct boot before unlock) the mirror is simply not
 * written/read, and the normal Store remains the source of truth.
 *
 * Remaining hole (stated in the report too): a user who finds this
 * file with a file manager and deletes it defeats the Clear Data
 * defence. Deleting it cannot shorten Strict — it only removes the
 * backup; if the Store still has Strict, Strict stays on.
 */
object MirrorStore {

    private const val RELATIVE_PATH = "Download/StrictGuard"
    private const val DISPLAY_NAME = "strict_guard_state.bin"
    private const val MIME_TYPE = "application/octet-stream"
    private const val ADMIN_MISSING_NOTIF_ID = 1003

    private fun findMirrorUri(context: Context): android.net.Uri? {
        return try {
            val resolver = context.contentResolver
            val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Downloads._ID)
            val selection =
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND " +
                    "${MediaStore.Downloads.RELATIVE_PATH}=?"
            val args = arrayOf(DISPLAY_NAME, "$RELATIVE_PATH/")
            resolver.query(uri, projection, selection, args, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(
                        cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    )
                    android.content.ContentUris.withAppendedId(uri, id)
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Read the mirror file's bytes, or null if there is no mirror. Never throws. */
    fun readMirror(context: Context): ByteArray? {
        return try {
            val uri = findMirrorUri(context) ?: return null
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
    }

    /** Write (or replace) the mirror file. Returns true on success. Never throws. */
    fun writeMirror(context: Context, bytes: ByteArray): Boolean {
        return try {
            val resolver = context.contentResolver
            val existing = findMirrorUri(context)
            val uri = existing ?: run {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, DISPLAY_NAME)
                    put(MediaStore.Downloads.MIME_TYPE, MIME_TYPE)
                    put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
                }
                resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false
            }
            resolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
                ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Delete the mirror file. Returns true if it is gone afterwards. Never throws. */
    fun deleteMirror(context: Context): Boolean {
        return try {
            val uri = findMirrorUri(context) ?: return true
            context.contentResolver.delete(uri, null, null) >= 0
        } catch (e: Exception) {
            false
        }
    }

    /** Encode + write the mirror for the Store's current Strict state. */
    fun writeStrictMirror(context: Context, store: Store): Boolean {
        val wallEnd = store.strictEndWall()
        if (wallEnd <= 0L) return false
        return try {
            val crypto = KeystoreMirrorCrypto()
            val bytes = StrictMirror.encode(
                StrictMirror.MirrorState(wallEnd, System.currentTimeMillis()),
                crypto
            )
            writeMirror(context, bytes)
        } catch (e: Exception) {
            false
        }
    }

    /** What a restore attempt found. */
    enum class RestoreOutcome { NOTHING, RESTORED, RESTORED_TAMPERED, EXPIRED_DELETED }

    /**
     * Check the mirror and restore Strict if the Store lost it
     * (e.g. Clear Data was tapped during Strict). Call from app
     * launch, boot receiver and launcher start — whenever the app
     * (re)starts with a possibly-empty Store.
     *
     * - No mirror / Store already has Strict → nothing.
     * - Mirror valid + end in the future → restore the Store's
     *   Strict state to the mirror's end time, log
     *   DATA_CLEARED_DURING_STRICT, rewrite the mirror.
     * - Mirror valid but expired → delete it.
     * - Mirror tampered → restore Strict to the maximum duration
     *   (never trust a shortened end), log MIRROR_TAMPERED.
     * After any restore, if Device Admin is missing (nearly
     * impossible — Clear Data does not remove admin, and Settings
     * is blocked during Strict), log it and post a notification
     * asking him to re-enable admin.
     * Never throws.
     */
    fun checkAndRestore(context: Context, store: Store): RestoreOutcome {
        return try {
            val bytes = readMirror(context)
            val decision = StrictMirror.decideRestore(
                bytes,
                store.strictEndWall(),
                store.isStrictActive(),
                System.currentTimeMillis(),
                KeystoreMirrorCrypto()
            )
            when (decision) {
                StrictMirror.Restore.NoMirror -> RestoreOutcome.NOTHING
                StrictMirror.Restore.AlreadyActive -> RestoreOutcome.NOTHING
                StrictMirror.Restore.Expired -> {
                    deleteMirror(context)
                    RestoreOutcome.EXPIRED_DELETED
                }
                is StrictMirror.Restore.Restored -> {
                    // startStrictUntil also rewrites the mirror.
                    store.startStrictUntil(decision.state.strictEndWallMs, false)
                    store.logTamper("DATA_CLEARED_DURING_STRICT restored until ${decision.state.strictEndWallMs}")
                    afterRestoreAdminCheck(context, store)
                    RestoreOutcome.RESTORED
                }
                StrictMirror.Restore.Tampered -> {
                    val fallback = StrictMirror.tamperFallbackEndMs(System.currentTimeMillis())
                    store.startStrictUntil(fallback, false)
                    store.logTamper("MIRROR_TAMPERED kept Strict on until $fallback")
                    afterRestoreAdminCheck(context, store)
                    RestoreOutcome.RESTORED_TAMPERED
                }
            }
        } catch (e: Exception) {
            RestoreOutcome.NOTHING
        }
    }

    private fun afterRestoreAdminCheck(context: Context, store: Store) {
        try {
            if (Util.isAdminActive(context)) return
            store.logTamper("ADMIN_MISSING_AFTER_RESTORE")
            postAdminMissingNotification(context)
        } catch (e: Exception) {
        }
    }

    private fun postAdminMissingNotification(context: Context) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val ch = NotificationChannel(
                    GuardService.ADMIN_CHANNEL_ID,
                    context.getString(R.string.admin_lost_title),
                    NotificationManager.IMPORTANCE_HIGH
                )
                nm.createNotificationChannel(ch)
            }
            val open = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(context, GuardService.ADMIN_CHANNEL_ID)
                .setContentTitle(context.getString(R.string.admin_lost_title))
                .setContentText(context.getString(R.string.admin_missing_after_restore))
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(ADMIN_MISSING_NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }
}

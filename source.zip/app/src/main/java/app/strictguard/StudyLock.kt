package app.strictguard

import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * Nightly Study Lock (v6.1.0).
 *
 * Every night at the set time (default 21:00, Asia/Dhaka) the guard
 * interrupts whatever Fahim is doing, shows a full-screen overlay
 * and automatically launches the e test paper app. A 15-minute study
 * lock then starts. During those 15 minutes every other app is
 * blocked — he cannot use anything else except the e test paper app
 * and receiving phone calls.
 *
 * The LINKED APP is PERMANENT and NOT user-changeable: the package
 * is hard-coded here ([STUDY_APP_PACKAGE]) with NO UI to change or
 * remove it. The feature itself, however, CAN be turned off
 * entirely as of v6.1.7 ([Store.studyLockEnabled], default ON) —
 * that toggle and the TIME may both be changed, in settings (both
 * locked during Strict, so the lock for tonight cannot be dodged by
 * flipping the switch mid-session).
 *
 * The app was researched 2026-11-08: "E-Test Paper for SSC & HSC"
 * by StudyPlex / Nextive Solution LLC — board questions, model
 * tests and HSC final model test for SSC/HSC students in Bangladesh.
 * Package verified on two independent APK listings (APKPure, with
 * SHA-256, and AppBrain): com.nextive.eTestPaper.
 *
 * v6.1.2 — THERE ARE TWO LISTINGS, AND THAT DEADLOCKED THE LOCK:
 * the old "E-Test Paper for SSC & HSC" (com.nextive.eTestPaper)
 * was removed from Google Play on 2026-07-08, and StudyPlex
 * replaced it with the live Play Store listing "E-Test Paper :
 * Smart Practice" (AppBrain, verified 2026-11-08: on Play since
 * July 2026, v2.4.4, updated 2026-11-05, 50,000+ installs) whose
 * package is com.nextive.etestpaper — same letters, all
 * lower-case. Android package names are case-sensitive, so the
 * v6.1.0/v6.1.1 code recognised ONLY the old package: Fahim's
 * installed app (the live listing) was treated as "any other app"
 * and blocked by its own Study Lock, the lock could never
 * complete, and the launcher showed a lock badge on eTestPaper
 * itself (screenshots 2026-11-08 23:16). The lock therefore
 * recognises BOTH packages as the study app ([isStudyApp]) — the
 * old one and the live one — everywhere: blocking, the timer,
 * launching, and the missing-app check. If neither is installed
 * the lock still reports it missing as before. Fahim should still
 * confirm which of the two is on his phone, but either one now
 * works.
 *
 * FAIRNESS — the 15 minutes must be continuous:
 * - Only time with the e test paper app in the foreground AND the
 *   screen on (and the keyguard not locked) counts.
 * - Screen off / keyguard / phone call / system UI pauses the timer
 *   (minutes are kept, just not counted).
 * - Leaving the app for any other app resets the accumulated time to
 *   zero — a fresh continuous 15 minutes is required.
 * - One attention check midway (~7.5 min): an "আমি পড়ছি" prompt
 *   must be tapped within 60 seconds, otherwise the timer pauses
 *   until it is tapped.
 *
 * Once per night: after completion the lock does not trigger again
 * until the next night. A leftover lock from a previous night
 * expires at 06:00 the next morning (the night is over). If the
 * e test paper app is NOT installed when the lock triggers, the
 * overlay explains it must be installed (with a button opening its
 * Play Store page), other apps stay blocked, and STUDY_APP_MISSING
 * is logged — the night is never silently skipped.
 *
 * REBOOT — the lock state is persisted. If the phone reboots
 * mid-lock, the lock resumes; completed minutes before the reboot
 * are kept ONLY if the session was continuous at the last tick
 * before the reboot (the last recorded tick had the study app in
 * the foreground with the screen on). If the session was already
 * paused then (screen off, call, …), the minutes reset to zero:
 * "continuous" means one unbroken block of studying. One sub-second
 * race remains: if he left the app less than one poll (500 ms)
 * before the reboot, that tick never ran, so up to 500 ms of credit
 * can be kept — negligible.
 *
 * Pure logic — fully unit-testable; the Android side (overlay,
 * launching, screen/keyguard checks, persistence) lives in
 * [GuardService] and [Store].
 */
object StudyLock {

    /**
     * PERMANENT link. Hard-coded on purpose: there is no UI to
     * change or remove it and no toggle to disable the feature.
     * The primary package is the original "E-Test Paper for SSC &
     * HSC" listing.
     */
    const val STUDY_APP_PACKAGE = "com.nextive.eTestPaper"

    /**
     * v6.1.2 — the live Play Store listing, "E-Test Paper : Smart
     * Practice" (StudyPlex, on Play since July 2026, v2.4.4). Same
     * app family, same developer — but a DIFFERENT package:
     * all lower-case `etestpaper`. The old listing was removed
     * from Play on 2026-07-08, so a fresh install from Play is
     * this one. Both packages are the study app; see [isStudyApp].
     * This is also the package the missing-app Play Store button
     * opens, because it is the listing that still exists.
     */
    const val STUDY_APP_PACKAGE_ALT = "com.nextive.etestpaper"

    /** Every package that counts as the study app. */
    val STUDY_APP_PACKAGES: Set<String> =
        setOf(STUDY_APP_PACKAGE, STUDY_APP_PACKAGE_ALT)

    /**
     * True when [pkg] is the study app — either of its two Play
     * Store packages. Used by EVERY Study Lock check (blocking,
     * timer, launching, missing-app) so a package-name difference
     * can never again turn the lock against its own app.
     */
    fun isStudyApp(pkg: String): Boolean = pkg in STUDY_APP_PACKAGES

    /** Google Play Store package (exempt during a missing-study-app lock). */
    const val PLAY_STORE_PKG = "com.android.vending"

    /** Display name used in the UI (EN/BN strings carry the rest). */
    const val STUDY_APP_NAME = "e test paper"

    /** One study lock per night lasts 15 continuous fair minutes. */
    const val DURATION_MS: Long = 15L * 60L * 1000L

    /** The attention check fires midway, at 7 minutes 30 seconds. */
    const val ATTENTION_AT_MS: Long = 7L * 60L * 1000L + 30_000L

    /** The attention prompt must be tapped within 60 seconds. */
    const val ATTENTION_TIMEOUT_MS: Long = 60_000L

    /** Default nightly time: 21:00. Stored as minutes since midnight. */
    const val DEFAULT_TIME_MIN: Int = 21 * 60

    /** A leftover lock from a previous night expires at 06:00. */
    const val NIGHT_END_HOUR: Int = 6

    const val ZONE_ID: String = "Asia/Dhaka"

    /** Calendar day ("yyyy-MM-dd") in Asia/Dhaka — the "night" key. */
    fun dayKey(nowWallMs: Long): String =
        ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID))
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))

    /** Today's trigger instant for a time given as minutes since midnight. */
    fun triggerTimeToday(nowWallMs: Long, timeMin: Int): Long {
        val today = ZonedDateTime.ofInstant(
            Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID)
        ).toLocalDate()
        return today.atTime(timeMin / 60, timeMin % 60)
            .atZone(ZoneId.of(ZONE_ID)).toInstant().toEpochMilli()
    }

    /**
     * True when tonight's lock should start now: the feature is
     * enabled, the set time has arrived, no lock is active, and
     * tonight's lock neither started nor completed yet.
     *
     * [enabled] is [Store.studyLockEnabled] (v6.1.7); it defaults to
     * true so every release through v6.1.6 — where the feature could
     * never be disabled — keeps behaving exactly as before.
     */
    fun shouldTrigger(
        nowWallMs: Long,
        timeMin: Int,
        triggerDay: String,
        doneDay: String,
        active: Boolean,
        enabled: Boolean = true
    ): Boolean {
        if (!enabled) return false
        if (active) return false
        val today = dayKey(nowWallMs)
        if (triggerDay == today || doneDay == today) return false
        return nowWallMs >= triggerTimeToday(nowWallMs, timeMin)
    }

    /**
     * True when a lock left over from a previous night should expire:
     * it is a later calendar day and it is 06:00 or later — the night
     * is over. A lock that started tonight is never expired by this,
     * even after midnight (a 21:00 lock may run past 00:00).
     */
    fun shouldExpire(nowWallMs: Long, triggerDay: String, active: Boolean): Boolean {
        if (!active) return false
        val today = dayKey(nowWallMs)
        if (triggerDay == today) return false
        val hour = ZonedDateTime.ofInstant(
            Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID)
        ).hour
        return hour >= NIGHT_END_HOUR
    }

    /** What the foreground / screen state means for the timer. */
    enum class Mode {
        /** Study app in the foreground, screen on: time counts. */
        STUDYING,
        /** Screen off, keyguard, call or system UI: paused, kept. */
        PAUSED,
        /** Any other app in the foreground: reset to zero. */
        LEFT
    }

    /** Persisted timer state for one lock session. */
    data class TickState(
        val accumulatedMs: Long,
        val attentionDone: Boolean,
        /** Wall-clock when the attention prompt appeared, 0 = not pending. */
        val attentionSinceMs: Long
    )

    data class TickResult(
        val state: TickState,
        /** True while the attention prompt must be shown. */
        val attentionDue: Boolean,
        /** True when the 15 fair minutes are complete. */
        val completed: Boolean,
        /** True when leaving the app threw away earned minutes. */
        val didReset: Boolean
    )

    /**
     * One timer step (one guard poll, [pollMs] long).
     *
     * - LEFT: accumulated time resets to zero and the attention check
     *   resets too — a fresh continuous 15 minutes is required.
     * - PAUSED: nothing changes (minutes kept, not counted). A pending
     *   attention prompt stays due, so it is still there on return.
     * - STUDYING: time counts, except while an attention prompt has
     *   been untapped for more than 60 seconds (paused until tapped).
     *   The prompt first appears when the accumulated time crosses
     *   [ATTENTION_AT_MS]; it fires only once per session.
     */
    fun onTick(
        state: TickState,
        mode: Mode,
        nowWallMs: Long,
        pollMs: Long
    ): TickResult {
        if (mode == Mode.LEFT) {
            val lost = state.accumulatedMs > 0L
            return TickResult(
                TickState(0L, false, 0L),
                attentionDue = false,
                completed = false,
                didReset = lost
            )
        }
        if (mode == Mode.PAUSED) {
            return TickResult(
                state,
                attentionDue = state.attentionSinceMs != 0L,
                completed = false,
                didReset = false
            )
        }
        // STUDYING.
        if (state.attentionSinceMs != 0L &&
            nowWallMs - state.attentionSinceMs > ATTENTION_TIMEOUT_MS
        ) {
            // Attention prompt untapped for over 60 seconds: paused
            // until it is tapped (the tap clears it in the Store).
            return TickResult(
                state,
                attentionDue = true,
                completed = false,
                didReset = false
            )
        }
        val accumulated = state.accumulatedMs + pollMs
        var attentionSince = state.attentionSinceMs
        var due = attentionSince != 0L
        if (!state.attentionDone && attentionSince == 0L && accumulated >= ATTENTION_AT_MS) {
            attentionSince = nowWallMs
            due = true
        }
        return TickResult(
            TickState(accumulated, state.attentionDone, attentionSince),
            attentionDue = due,
            completed = accumulated >= DURATION_MS,
            didReset = false
        )
    }

    /**
     * Reboot resume: completed minutes are kept ONLY if the session
     * was continuous at the last tick before the reboot (the study
     * app was in the foreground with the screen on). If it was
     * already paused then, the minutes reset to zero.
     */
    fun resumeAccumulated(accumulatedMs: Long, lastStudying: Boolean): Long =
        if (lastStudying) accumulatedMs else 0L
}

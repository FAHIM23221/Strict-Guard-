package app.strictguard

/**
 * Pure foreground-resolution rules (v5.2.1).
 *
 * THE v5.2.0 BUG THIS FIXES: the guard only looked at UsageEvents from
 * the last 3 seconds. If the user was already inside Settings when
 * Strict was turned on, or navigated *inside* Settings (Settings ->
 * Security -> Device admin apps is the SAME package, so no new
 * MOVE_TO_FOREGROUND event fires), then after 3 seconds the query
 * returned null, tick() returned early, and the guard went blind —
 * Settings stayed open and Device Admin could be turned off.
 *
 * The fix is sticky: the last-known foreground package is kept and
 * reused when no new event arrives, and UsageStats' most-recently-used
 * package is a second fallback. A package that was in the foreground
 * does not stop being in the foreground just because no new event
 * fired — the user is still looking at it.
 */
object ForegroundResolver {

    /**
     * @param eventPkg package from the latest MOVE_TO_FOREGROUND event
     *   (null when no event fired in the query window)
     * @param lastKnownPkg last foreground package seen (sticky)
     * @param statsPkg most-recently-used package from UsageStats
     */
    fun resolve(eventPkg: String?, lastKnownPkg: String?, statsPkg: String?): String? =
        eventPkg ?: lastKnownPkg ?: statsPkg

    /** Same stickiness for the foreground activity class. */
    fun resolveActivity(eventClass: String?, lastKnownClass: String?): String? =
        eventClass ?: lastKnownClass
}

package app.strictguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * v6.1.5 — Device Admin loss handling, in one place.
 *
 * WHY THIS EXISTS: losing Device Admin during Strict Mode IS the
 * bypass — with admin off, Strict Guard can be force-stopped and
 * uninstalled. v6.1.4 only detected the loss on the guard's poll
 * (which does not run at all before the service's first tick) and
 * posted a dismissible notification. Two layers are added here:
 *
 *  1. A PERSISTENT alert: while Strict is on, the admin-lost
 *     notification is ongoing (not swipe-dismissible) and is
 *     cancelled only when admin comes back. It opens the app so
 *     admin can be turned back on.
 *  2. An INDEPENDENT detection path: [GuardAdminReceiver.onDisabled]
 *     fires even when the guard service itself is dead (Android
 *     delivers it to the app process), so admin loss is caught
 *     even outside the poll loop. It logs the loss, posts the
 *     alert, and re-asserts Strict from the surviving mirror on a
 *     background thread.
 *
 * HONEST LIMIT: no app can PREVENT the user from turning admin
 * off — Android delivers onDisabled after the fact, and
 * onDisableRequested can only show a warning, never veto. What
 * this does is make the loss visible the moment it happens and
 * keep Strict itself alive from the mirror, so the bypass costs
 * the attacker the Strict state too: even if the app is then
 * uninstalled and reinstalled, the mirror (MediaStore Downloads,
 * outside the app's private data) is re-checked on the next app
 * launch and Strict comes back. The remaining hole is the same
 * as before: code cannot run until the user opens the app or the
 * phone reboots after a reinstall.
 */
object AdminLoss {

    /** Alert when Strict is on and admin is off — nothing else is a loss. */
    fun shouldAlert(strictActive: Boolean, adminActive: Boolean): Boolean =
        strictActive && !adminActive

    /** The alert stays (ongoing, not swipe-dismissible) while Strict is on. */
    fun shouldPersist(strictActive: Boolean): Boolean = strictActive

    /** The admin channel, created idempotently wherever the alert is posted. */
    private fun ensureAdminChannel(context: Context) {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                GuardService.ADMIN_CHANNEL_ID,
                context.getString(R.string.admin_lost_title),
                NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(ch)
        } catch (e: Exception) {
        }
    }

    /**
     * Post the admin-lost alert. [persistent] = Strict is on: the
     * notification is ongoing and cannot be swiped away; it is
     * cancelled by [cancelAdminLostNotification] when admin
     * returns. Never throws.
     */
    fun postAdminLostNotification(context: Context, persistent: Boolean) {
        try {
            ensureAdminChannel(context)
            val open = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(context, GuardService.ADMIN_CHANNEL_ID)
                .setContentTitle(context.getString(R.string.admin_lost_title))
                .setContentText(context.getString(R.string.admin_lost_text))
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setOngoing(persistent)
                .setAutoCancel(!persistent)
                .build()
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(GuardService.ADMIN_NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }

    /** Remove the admin-lost alert (admin is back on). Never throws. */
    fun cancelAdminLostNotification(context: Context) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(GuardService.ADMIN_NOTIF_ID)
        } catch (e: Exception) {
        }
    }

    /**
     * Called from [GuardAdminReceiver.onDisabled] — the callback
     * Android delivers even when the guard service is dead. Logs
     * the loss, posts the alert when Strict is on, and re-asserts
     * Strict from the surviving mirror on a background thread, so
     * losing admin cannot also silently lose the Strict state.
     * Everything is guarded: in direct boot the Store may be
     * unreadable, in which case the boot mirror decides whether
     * Strict is on and the restore waits for the service's
     * transition to normal mode. Never throws.
     */
    fun handleDisabled(context: Context) {
        try {
            val store = try {
                Store(context)
            } catch (e: Exception) {
                null
            }
            val strictActive = store?.isStrictActive()
                ?: run {
                    val (wallEnd, _) = Store.bootMirrorState(context)
                    Limits.strictWallActive(System.currentTimeMillis(), wallEnd)
                }
            try {
                store?.logTamper("ADMIN_DISABLED")
            } catch (e: Exception) {
            }
            if (!shouldAlert(strictActive, adminActive = false)) return
            postAdminLostNotification(context, persistent = true)
            val s = store ?: return
            Thread {
                try {
                    MirrorStore.checkAndRestore(context, s)
                } catch (e: Exception) {
                }
            }.start()
        } catch (e: Exception) {
        }
    }
}

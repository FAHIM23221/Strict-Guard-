package app.strictguard

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Calendar

/**
 * Optional notification watch: while Strict Mode or Night Lock is active,
 * posted notifications from other apps are silenced (cancelled), except
 * this app's own and the dialer. Requires Notification Access, which the
 * user grants from the setup checklist.
 */
class QuietListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        if (n.packageName == packageName) return
        if (n.packageName == "com.android.dialer") return
        val store = Store(this)
        val strict = store.isStrictActive()
        val night = store.nightEnabled && Limits.nightActive(
            Calendar.getInstance(), store.nightStartMin, store.nightEndMin
        )
        if (strict || night) {
            try {
                cancelNotification(n.key)
            } catch (e: Exception) {
            }
        }
    }
}

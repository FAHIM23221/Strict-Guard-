package app.strictguard

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/**
 * Language ("en" default, "bn") and theme ("system" default, "light",
 * "dark") helpers. Pure framework only.
 */
object Lang {

    fun localeFor(lang: String): Locale =
        if (lang == "bn") Locale("bn") else Locale.ENGLISH

    fun isBengali(lang: String): Boolean = lang == "bn"

    fun wrapContext(base: Context, lang: String): Context {
        val locale = localeFor(lang)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }

    /**
     * Switch the language of the CURRENT activity instantly, without
     * restarting it: re-point this context's resources at the new locale
     * and let the caller re-bind every visible string from resources.
     * New activities still get the locale via [wrapContext].
     */
    @Suppress("DEPRECATION")
    fun applyLocaleInPlace(context: Context, lang: String) {
        val locale = localeFor(lang)
        Locale.setDefault(locale)
        val res = context.resources
        val config = Configuration(res.configuration)
        config.setLocale(locale)
        res.updateConfiguration(config, res.displayMetrics)
    }

    /** Resolve the stored theme pref against the device's current mode. */
    fun effectiveTheme(themePref: String, uiModeNightMask: Int): String =
        when (themePref) {
            "dark" -> "dark"
            "light" -> "light"
            else -> if (uiModeNightMask == Configuration.UI_MODE_NIGHT_YES) "dark" else "light"
        }

    fun themeRes(effectiveTheme: String): Int =
        if (effectiveTheme == "dark") R.style.Theme_StrictGuard_Dark
        else R.style.Theme_StrictGuard_Light

    fun isSystemNight(context: Context): Boolean {
        val mask = context.resources.configuration.uiMode and
            Configuration.UI_MODE_NIGHT_MASK
        return mask == Configuration.UI_MODE_NIGHT_YES
    }
}

package app.strictguard

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build

/**
 * v6.1.1 — first-launch crash fix + defensive startup.
 *
 * ROOT CAUSE of the v6.1.0 crash (found 2026-11-08, Fahim's Infinix
 * X6886, Android 16, first tap on the icon right after install):
 *
 * BaseActivity.onResume() called
 *     registerReceiver(themeReceiver, IntentFilter(ACTION_THEME_CHANGED))
 * with NO export flag. The action is our own custom action
 * ("app.strictguard.THEME_CHANGED"), NOT a system broadcast, so the
 * Android 14 system-broadcast exception does not apply. Apps with
 * targetSdkVersion 34+ MUST pass RECEIVER_EXPORTED or
 * RECEIVER_NOT_EXPORTED when registering a receiver (Android 14
 * behaviour change, still enforced on Android 15/16); without it
 * the system throws
 *     SecurityException: "One of RECEIVER_EXPORTED or
 *     RECEIVER_NOT_EXPORTED should be specified when a receiver
 *     isn't being registered exclusively for system broadcasts."
 * onResume() has no try/catch, so the exception killed the process
 * on the very first resume of MainActivity — before Fahim ever saw
 * inside the app ("Strict Guard keeps stopping" over the home
 * screen). The receiver was added in v6.1.0 for the auto-theme
 * switch, which is why v6.0.0 opened fine and v6.1.0 crashed
 * immediately. v6.0.0's BaseActivity has no registerReceiver call.
 *
 * FIX: [registerPrivateReceiver] uses the 3-arg overload with
 * RECEIVER_NOT_EXPORTED on API 33+ (the overload only exists from
 * API 33 — calling it on older devices would be a
 * NoSuchMethodError, so the SDK is checked first) and the old
 * 2-arg call below API 33, wrapped in try/catch either way.
 *
 * The rest of this object is the same rule applied to every other
 * first-launch step: NO permission has been granted yet and NO
 * prior data exists on a fresh install, so every startup step runs
 * through [runSafe]/[runSafeOr] and a failure in one subsystem
 * (alarms, mirror/Keystore, study lock, countdown, guard service)
 * can never kill the app launch. Features and behaviour are
 * otherwise unchanged — this is a crash-fix release, not a redesign.
 */
object StartupGuard {

    /** The flags overload of registerReceiver exists from API 33 (Tiramisu). */
    fun useFlagOverload(sdkInt: Int): Boolean =
        sdkInt >= Build.VERSION_CODES.TIRAMISU

    /**
     * Flag for the receiver registration on this SDK, or null when
     * the old 2-arg overload must be used (below API 33).
     * Our receiver only ever hears our own app's broadcast, so it
     * must NOT be exported.
     */
    fun receiverFlagForSdk(sdkInt: Int): Int? =
        if (useFlagOverload(sdkInt)) Context.RECEIVER_NOT_EXPORTED else null

    /** Run one startup step; a failure is swallowed so it can never
     *  kill the app launch. Returns true when the step ran cleanly. */
    fun runSafe(block: () -> Unit): Boolean {
        return try {
            block()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Run one startup step that produces a value; the fallback is
     *  returned when the step throws. */
    fun <T> runSafeOr(block: () -> T, fallback: T): T {
        return try {
            block()
        } catch (e: Exception) {
            fallback
        }
    }

    /**
     * Register a receiver for our own app's broadcast, the Android
     * 14 way. Returns true when the receiver is registered.
     * Never throws — on failure the theme-change broadcast is
     * simply not received while this activity is open (the guard
     * poll still applies the auto theme, and onResume re-evaluates
     * it), which is strictly better than crashing the launch.
     */
    fun registerPrivateReceiver(
        activity: Activity,
        receiver: BroadcastReceiver,
        filter: IntentFilter
    ): Boolean {
        return try {
            if (useFlagOverload(Build.VERSION.SDK_INT)) {
                activity.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                activity.registerReceiver(receiver, filter)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * v6.1.2 — when the guard service must be (re)started from a
     * visible activity. The old rule also required the persisted
     * service-wanted flag (or Strict on) — but that flag is only
     * ever set by the service itself, so on a fresh install, or
     * after the service was force-stopped / killed before it ever
     * ran, the guard was dead and nothing restarted it: the
     * launcher still showed lock badges (pure UI) while nothing
     * actually enforced anything — no delay popup, no usage
     * counting, no foreground blocks. Usage Access granted IS the
     * setup signal: once it is granted, monitoring is wanted and
     * the guard must run. The service sets the wanted flag itself
     * on start, so boot restarts keep working too.
     */
    fun shouldRestartGuard(isRunning: Boolean, hasUsageAccess: Boolean): Boolean =
        !isRunning && hasUsageAccess

    /**
     * Start the guard service without ever crashing the caller.
     * A start from the background can be refused on Android 12+
     * (ForegroundServiceStartNotAllowedException) — that must be a
     * missed start, not a crash. Returns true when the start was
     * requested.
     */
    fun startGuardService(context: Context): Boolean {
        return try {
            val i = Intent(context, GuardService::class.java)
                .setAction(GuardService.ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Same as [startGuardService], for a start that came from boot / unlock. */
    fun startGuardServiceFromBoot(context: Context): Boolean {
        return try {
            val i = Intent(context, GuardService::class.java)
                .setAction(GuardService.ACTION_START)
                .putExtra(GuardService.EXTRA_FROM_BOOT, true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}

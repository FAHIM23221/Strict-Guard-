package app.strictguard

/**
 * One-way setup permission buttons (v6.1.0).
 *
 * Once a setup permission is granted, its button becomes permanently
 * dead in the app: greyed out, showing "Allowed ✓", and tapping it
 * does nothing — it must not open Settings again or offer a way to
 * turn the permission off. The button state is re-checked on every
 * resume (after returning from the system permission screen) and the
 * "granted before" fact is persisted in [Store], so the dead state
 * survives restarts.
 *
 * One necessary exception: if Android reports the permission was
 * later revoked from outside the app (via system Settings), the
 * button must re-enable so the guard can be repaired — otherwise a
 * revoked permission could never be re-granted. That is the
 * `wasGranted && !done` case below: the state goes back to PENDING
 * and the caller logs the revocation to the Tamper Log with a
 * notification ([isRevocation] identifies it).
 *
 * Pure logic — fully unit-testable. The Android side lives in
 * [MainActivity] (row rendering + revocation detection on resume).
 */
object SetupRowState {

    enum class State {
        /** Not granted yet — tappable (opens the system screen). */
        PENDING,
        /** Granted — permanently dead in the app, tap does nothing. */
        GRANTED_DEAD,
        /** Not granted, but Strict Mode locks all settings. */
        LOCKED
    }

    /**
     * @param done the permission is currently granted (live check)
     * @param wasGranted the permission was granted before (persisted)
     * @param strictLocked Strict Mode is on (settings locked)
     */
    fun state(done: Boolean, wasGranted: Boolean, strictLocked: Boolean): State =
        when {
            done -> State.GRANTED_DEAD
            wasGranted -> State.PENDING // revoked outside the app: re-enable to repair
            strictLocked -> State.LOCKED
            else -> State.PENDING
        }

    /** True when a previously granted permission is now un-granted. */
    fun isRevocation(done: Boolean, wasGranted: Boolean): Boolean =
        !done && wasGranted
}

package app.strictguard

/**
 * Entry Delay for social-feed apps (v6.1.0).
 *
 * Whenever a social media app is opened, a full-screen popup appears
 * FIRST with a countdown timer, and the app can only be entered after
 * the full wait — never before. The delay applies on EVERY open, not
 * once per day. Leaving the app (or turning the screen off) during
 * the countdown RESETS the timer — the full wait must be done
 * continuously.
 *
 * Default wait: 15 seconds (Fahim said 10 or 15 — 15 is used), with
 * a choice of 10 / 15 / 30 seconds in settings. Toggle default ON,
 * locked during Strict like other settings.
 *
 * Apps covered (the SOCIAL group, defined here in code):
 * - Facebook (+ Lite), Instagram (+ Lite), TikTok (+ Lite), X
 *   (Twitter), Snapchat, LinkedIn, Reddit, Pinterest, Threads,
 *   Tumblr, VK, BeReal, Likee, Quora, Discord
 * - YouTube + YouTube Music (added at Fahim's correction — YouTube
 *   keeps its daily limit + break cycle as well; the delay is on top)
 *
 * NOT covered: WhatsApp and other pure messengers (WhatsApp,
 * Messenger, Telegram, Signal, Viber, IMO) — messaging is not a
 * social feed. Fahim confirmed WhatsApp stays excluded.
 *
 * Precedence: Strict Mode / Night Lock / daily limit / break cycle /
 * Study Lock blocks take precedence — the delay never grants access
 * when the app is otherwise blocked. The delay only runs when
 * [BlockDecider] returns null (the app is otherwise allowed).
 *
 * Mechanics (GuardService): the app is already in the foreground
 * behind the delay overlay (TYPE_APPLICATION_OVERLAY, full-screen,
 * clickable, Warm Sand). The overlay shows the live countdown; when
 * it reaches zero the overlay dismisses and the app — already open
 * underneath — becomes usable. Usage is NOT counted while the delay
 * overlay covers the app (the wait is not use). If the foreground
 * changes or the screen goes off mid-wait, the timer resets. If the
 * service restarts mid-wait, the timer also resets (a fresh full
 * wait is required — the safe direction).
 *
 * Honest limit, same as every other guard action: the app can be
 * visible for up to one poll (~500 ms) before the delay overlay
 * covers it.
 *
 * Pure logic — fully unit-testable; the overlay + foreground
 * watching live in [GuardService].
 */
object EntryDelay {

    /** Default wait: 15 seconds. */
    const val DEFAULT_SECONDS: Int = 15

    /** Duration choices offered in settings. */
    val CHOICES_SECONDS: IntArray = intArrayOf(10, 15, 30)

    /**
     * Social-feed apps that get the entry delay. WhatsApp and other
     * pure messengers are deliberately NOT here.
     */
    val SOCIAL_PACKAGES: Set<String> = setOf(
        "com.facebook.katana", // Facebook
        "com.facebook.lite", // Facebook Lite
        "com.instagram.android", // Instagram
        "com.instagram.lite", // Instagram Lite
        "com.zhiliaoapp.musically", // TikTok
        "com.zhiliaoapp.musically.go", // TikTok Lite
        "com.twitter.android", // X (Twitter)
        "com.snapchat.android", // Snapchat
        "com.linkedin.android", // LinkedIn
        "com.reddit.frontpage", // Reddit
        "com.pinterest", // Pinterest
        "com.instagram.barcelona", // Threads
        "com.tumblr", // Tumblr
        "com.vk", // VK
        "com.bereal.ft", // BeReal
        "video.like", // Likee
        "com.quora.android", // Quora
        "com.discord", // Discord (community/social)
        "com.google.android.youtube", // YouTube (also has limit + break cycle)
        "com.google.android.apps.youtube.music" // YouTube Music
    )

    /** Messengers that are explicitly NOT delayed (for the tests + docs). */
    val EXCLUDED_MESSENGERS: Set<String> = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.facebook.orca",
        "org.telegram.messenger",
        "org.telegram.messenger.web",
        "org.thoughtcrime.securesms",
        "com.viber.voip",
        "com.imo.android.imoim"
    )

    fun isDelayApp(pkg: String): Boolean = pkg in SOCIAL_PACKAGES

    /**
     * True when the delay gate should run for this foreground app:
     * the toggle is on, the app is a social-feed app, and nothing
     * else blocks it ([blocked] is the BlockDecider result — a
     * Strict / Night / limit / break / Study decision means the
     * delay never runs, because the app is not opening at all).
     */
    fun shouldDelay(pkg: String, enabled: Boolean, blocked: Boolean): Boolean =
        enabled && !blocked && isDelayApp(pkg) &&
            !AlwaysAllowed.isAlwaysAllowed(pkg)

    /** Milliseconds left of a wait that started at [startedElapsedMs]. */
    fun remainingMs(startedElapsedMs: Long, durationSec: Int, nowElapsedMs: Long): Long =
        (durationSec * 1000L - (nowElapsedMs - startedElapsedMs)).coerceAtLeast(0L)

    /** True when the full wait has elapsed. */
    fun isDone(startedElapsedMs: Long, durationSec: Int, nowElapsedMs: Long): Boolean =
        remainingMs(startedElapsedMs, durationSec, nowElapsedMs) <= 0L

    /** Whole seconds left, for the countdown text (rounds up so "15" shows at the start). */
    fun remainingSeconds(startedElapsedMs: Long, durationSec: Int, nowElapsedMs: Long): Long =
        (remainingMs(startedElapsedMs, durationSec, nowElapsedMs) + 999L) / 1000L

    /** Only 10 / 15 / 30 are valid durations; anything else falls back to the default. */
    fun validDuration(seconds: Int): Int =
        if (seconds in CHOICES_SECONDS) seconds else DEFAULT_SECONDS

    /**
     * v6.1.2 — full-screen fallback for the countdown popup.
     * The popup normally shows as a TYPE_APPLICATION_OVERLAY view
     * from the guard service, which needs the overlay permission.
     * When that permission is missing (or the overlay cannot be
     * added), the wait MUST still be shown — as the full-screen
     * [app.strictguard.DelayActivity] instead of silently letting
     * the app open. The activity's class name, for the guard to
     * recognise it as the foreground screen.
     */
    const val DELAY_ACTIVITY_CLASS = "app.strictguard.DelayActivity"

    /**
     * v6.1.2 — which package the delay state machine should watch
     * on this tick. While the [DelayActivity] is in the foreground,
     * the resolved foreground package is Strict Guard itself — but
     * the wait belongs to [delayPkg], the social app underneath.
     * Returning [delayPkg] here keeps the wait running (and the
     * timer counting) while the fallback screen covers the app;
     * any other foreground package is watched as itself, so
     * leaving mid-wait still resets the timer.
     */
    fun effectiveDelayPkg(
        foregroundPkg: String,
        foregroundActivity: String?,
        ownPackage: String,
        delayPkg: String?
    ): String =
        if (delayPkg != null && foregroundPkg == ownPackage &&
            foregroundActivity == DELAY_ACTIVITY_CLASS
        ) delayPkg else foregroundPkg

    /**
     * v6.1.2 — true when the countdown must be shown as the
     * full-screen activity instead of the overlay: the overlay
     * permission is missing, or the overlay view could not be
     * added. Either way the popup appears — the wait is never
     * silently skipped.
     */
    fun needsActivityFallback(hasOverlay: Boolean, overlayShown: Boolean): Boolean =
        !hasOverlay || !overlayShown
}

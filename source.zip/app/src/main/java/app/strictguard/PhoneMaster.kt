package app.strictguard

/**
 * v6.1.4 — Phone Master (Fahim, 2026-11-09).
 *
 * Phone Master is Transsion's system cleaner / junk cleaner
 * (verified 2026-11-09: Uptodown lists Package Name
 * com.transsion.phonemaster, developer TRANSSION MOBILE;
 * APKMirror agrees across every version listed, e.g. 5.6.7.00001
 * "Package: com.transsion.phonemaster"). On Fahim's Infinix it
 * can freeze / disable apps — including Strict Guard itself —
 * so during Strict Mode it is a bypass route like Settings:
 * invisible in the launcher and unlaunchable anywhere the guard
 * controls. When Strict ends it is an ordinary app again.
 *
 * Scope is Strict Mode ONLY (not Night Lock, not normal use).
 * The package is hard-coded on purpose, like the study-app link:
 * there is no UI to change it, so it cannot be weakened in a
 * moment of temptation.
 *
 * Pure logic — fully unit-testable.
 */
object PhoneMaster {

    /** Verified package (Uptodown + APKMirror, 2026-11-09). */
    const val PACKAGE = "com.transsion.phonemaster"

    /** Display label, for the launcher-hiding fallback only. */
    const val LABEL = "Phone Master"

    /** True when [pkg] is Phone Master, by package name. */
    fun isPhoneMaster(pkg: String): Boolean = pkg == PACKAGE

    /**
     * True when the foreground screen belongs to Phone Master — by
     * package, or by activity class (same second layer as the
     * Settings check, for OEM wrappers hosting its activities
     * under another package name).
     */
    fun isPhoneMasterActivity(pkg: String, activityClass: String?): Boolean {
        if (pkg == PACKAGE) return true
        return activityClass != null && activityClass.startsWith("$PACKAGE.")
    }

    /**
     * Label fallback, for DISPLAY filtering only (launcher grid,
     * hidden-apps dialog, picker search): an app whose label is
     * exactly "Phone Master" is the same tool even if it was
     * renamed or repackaged. Never used for a block decision —
     * blocking is by package only, so a label can never block an
     * unrelated app.
     */
    fun isPhoneMasterLabel(label: String?): Boolean =
        label != null && label.trim().equals(LABEL, ignoreCase = true)

    /**
     * True when this app must be HIDDEN (not shown at all — not
     * even dimmed, not even with a lock badge) while Strict is on.
     */
    fun isHidden(pkg: String, label: String?, strict: Boolean): Boolean =
        strict && (isPhoneMaster(pkg) || isPhoneMasterLabel(label))

    /** The launcher list with Phone Master removed while Strict is on. */
    fun visibleApps(
        apps: List<LauncherLogic.AppEntry>,
        strict: Boolean
    ): List<LauncherLogic.AppEntry> =
        if (!strict) apps else apps.filter { !isHidden(it.pkg, it.label, true) }
}

package app.strictguard

import android.os.Bundle
import android.widget.Button
import android.widget.TextView

/**
 * Daily "one day less" alert — full-screen popup, shown on next
 * unlock when the HSC days-remaining number dropped at midnight.
 * Dismiss with "বুঝেছি". Shown once per day: the pending flag is
 * cleared when this opens, and the day is recorded, so a second
 * resume the same day does not show it again.
 */
class DayLessAlertActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day_less_alert)
        val days = HscCountdown.daysRemaining(
            System.currentTimeMillis(), store.hscExamMs
        )
        val bn = Lang.isBengali(store.lang)
        findViewById<TextView>(R.id.dayLessMessage).text =
            HscCountdown.dayLessMessage(days, bn)
        // Mark it shown now, so it cannot re-fire today.
        store.hscDayLessPending = false
        store.hscDayLessPopupDay = HscCountdown.dayKey(System.currentTimeMillis())
        findViewById<Button>(R.id.btnDayLessOk).setOnClickListener { finish() }
    }

    override fun onBackPressed() {
        finish()
    }
}

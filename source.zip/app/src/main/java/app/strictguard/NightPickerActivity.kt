package app.strictguard

import android.os.Bundle
import android.widget.Button
import android.widget.TimePicker
import android.widget.Toast

/** Night Lock hours picker (24-hour view). */
class NightPickerActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // v5.1.0: Night Lock hours are locked during Strict.
        if (store.settingsLocked()) {
            Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        setContentView(R.layout.activity_night)

        val tpStart = findViewById<TimePicker>(R.id.tpStart)
        val tpEnd = findViewById<TimePicker>(R.id.tpEnd)
        tpStart.setIs24HourView(true)
        tpEnd.setIs24HourView(true)
        tpStart.hour = store.nightStartMin / 60
        tpStart.minute = store.nightStartMin % 60
        tpEnd.hour = store.nightEndMin / 60
        tpEnd.minute = store.nightEndMin % 60

        findViewById<Button>(R.id.btnSaveNight).setOnClickListener {
            if (store.settingsLocked()) {
                Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
                finish()
                return@setOnClickListener
            }
            store.nightStartMin = tpStart.hour * 60 + tpStart.minute
            store.nightEndMin = tpEnd.hour * 60 + tpEnd.minute
            store.logTamper(
                "NIGHT_HOURS ${store.nightStartMin}-${store.nightEndMin}"
            )
            finish()
        }
    }
}

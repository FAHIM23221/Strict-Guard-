package app.strictguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Restart the guard after a reboot — at the earliest moment Android
 * allows, so the boot window Fahim named (a few seconds after
 * power-on, before the guard starts, when the app could be
 * uninstalled) is closed as far as Android allows.
 *
 * Three layers (v6.0.0):
 *  1. LOCKED_BOOT_COMPLETED (direct boot, before the user unlocks):
 *     the normal SharedPreferences are credential-encrypted and may
 *     be unreadable, so the decision is read from the
 *     device-protected mirror [Store.bootMirrorState] (Strict wall
 *     end + service-wanted, mirrored on every Strict start). If
 *     Strict is on or monitoring is wanted, the guard starts now —
 *     it is already running when the lock screen opens.
 *  2. BOOT_COMPLETED: recover the schedule from the wall-clock end,
 *     restart the guard, and open the launcher immediately (it is
 *     the default home, so the system shows it first anyway; the
 *     explicit launch covers the case where the overlay permission
 *     grants the background-activity exemption).
 *  3. USER_UNLOCKED (SystemEventsReceiver): re-read the real state
 *     and restart the guard, correcting a direct-boot start.
 *
 * Honest limit: Android still lets the user deactivate Device Admin
 * when Strict is OFF, and Safe Mode / ADB / a second profile bypass
 * any app-level guard. What this closes is the *boot gap*: by the
 * time the user can touch Settings, the guard is already running
 * and Settings is blocked while Strict is on.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // v6.1.1: a receiver that throws crashes the app process
        // ("keeps stopping") — on boot, before any permission or
        // setup exists. Every step below is guarded.
        try {
            onReceiveSafe(context, intent)
        } catch (e: Exception) {
        }
    }

    private fun onReceiveSafe(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_LOCKED_BOOT_COMPLETED -> {
                val (wallEnd, wanted) = Store.bootMirrorState(context)
                if (BootRestore.directBootGuardStart(
                        wallEnd, System.currentTimeMillis(), wanted
                    )
                ) {
                    startGuard(context)
                }
            }
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON" -> {
                // v6.1.4 — enforce FIRST. Why: onReceive and the
                // guard service share the app's main thread, so
                // every millisecond spent here (the Keystore mirror
                // decrypt in checkAndRestore, alarm scheduling)
                // delayed the guard's first enforcement tick by
                // exactly that long — the refresh window Fahim
                // reported. The mirror read is cheap; the guard
                // start is requested from that decision alone.
                // Everything slow (Store, mirror restore, alarm
                // scheduling, launcher open) runs on a background
                // thread afterwards, so this receiver returns
                // immediately and the service can actually start.
                // The slow work is idempotent, so running it next
                // to the service's own boot work is safe. Honest
                // limit: Android's own boot sequence cannot be
                // shortened by any app — only the guard's own
                // startup path can be made leaner.
                val (wallEnd, wanted) = Store.bootMirrorState(context)
                if (BootRestore.bootStartDecision(
                        wallEnd, System.currentTimeMillis(), wanted
                    )
                ) {
                    startGuard(context)
                }
                Thread {
                    try {
                        bootSlowWork(context)
                    } catch (e: Exception) {
                    }
                }.start()
            }
        }
    }

    /**
     * v6.1.4 — the slow boot work, moved off the receiver's critical
     * path: it runs on a background thread AFTER the guard start was
     * requested, so it can never delay the first enforcement tick.
     * Same work as before (mirror restore, schedule recovery,
     * alarm scheduling, launcher open), same order, same guards.
     * Never throws.
     */
    private fun bootSlowWork(context: Context) {
        val store = Store(context)
        store.logTamper("BOOT")
        // v6.1.0 Clear Data defence: if the Store lost Strict but
        // the mirror outside the app's private data still says
        // Strict is on, restore it immediately.
        MirrorStore.checkAndRestore(context, store)
        // v5.2.0: a scheduled Strict end is stored as wall-clock
        // millis — recompute the elapsedRealtime end now, or Strict
        // would be lost (or stale) after the reboot.
        store.recoverStrictAfterBoot()
        // v6.1.0: a leftover mirror whose end has passed is cleaned
        // up here (and on the next guard tick).
        if (store.strictEndWall() > 0L && !store.isStrictActive()) {
            store.checkStrictEnded()
        }
        // v6.1.0 Friday prayer alarm: re-schedule after reboot.
        PrayerAlarmScheduler.scheduleNext(context)
        // Open the launcher immediately on reboot: Strict on, or
        // this app is the default home. Needs the overlay permission
        // for the background-activity exemption; if the start is
        // refused, the default-home mechanism still shows the
        // launcher first.
        val strict = store.isStrictActive()
        if (BootRestore.shouldOpenLauncher(strict, Util.isDefaultLauncher(context)) &&
            Util.hasOverlay(context)
        ) {
            try {
                val i = Intent(context, LauncherActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                store.logTamper("BOOT_LAUNCHER")
            } catch (e: Exception) {
                store.logTamper("BOOT_LAUNCHER_FAILED")
            }
        }
    }

    private fun startGuard(context: Context) {
        // v6.1.1: startForegroundService() from a receiver can be
        // refused on Android 12+ (background start) — a missed
        // start, never a crash.
        StartupGuard.startGuardServiceFromBoot(context)
    }
}

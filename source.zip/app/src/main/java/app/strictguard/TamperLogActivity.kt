package app.strictguard

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

/** Tamper Log viewer. */
class TamperLogActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_list)

        findViewById<TextView>(R.id.listTitle).setText(R.string.tamper_title)
        val tv = findViewById<TextView>(R.id.tvContent)
        val clear = findViewById<Button>(R.id.btnClear)
        clear.visibility = View.VISIBLE
        fun show() {
            val log = store.tamperLog()
            tv.text = if (log.isBlank()) getString(R.string.tamper_empty) else log
        }
        show()
        clear.setOnClickListener {
            if (store.settingsLocked()) {
                Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
            } else { store.clearTamper(); show() }
        }
    }
}

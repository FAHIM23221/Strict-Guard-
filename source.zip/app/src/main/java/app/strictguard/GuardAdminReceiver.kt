package app.strictguard

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Device Admin — watch-login only. Prevents easy uninstall while active. */
class GuardAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        Store(context).logTamper("ADMIN_ENABLED")
    }

    /**
     * v6.1.5 — [AdminLoss.handleDisabled] does the whole job now:
     * log the loss, post the persistent alert when Strict is on,
     * and re-assert Strict from the surviving mirror. This callback
     * fires even when the guard service is dead, so it is the
     * independent second detection path next to the poll. It also
     * fires in direct boot, where Store() can throw — [AdminLoss]
     * falls back to the boot mirror there and never throws.
     */
    override fun onDisabled(context: Context, intent: Intent) {
        AdminLoss.handleDisabled(context)
    }
}

package app.strictguard

/**
 * The single blocking decision, shared by the guard service and the UI.
 * Pure logic — fully unit-testable.
 *
 * v5.2.1: the YouTube Shorts feature is REMOVED entirely (Olivia asked
 * for it to go). YouTube behaves exactly as in v5.1.0: blocked during
 * Strict Mode, during Night Lock, and after its 60-minute daily limit —
 * and usable at all other times. There is no SHORTS kind any more.
 */
object BlockDecider {

    enum class Kind { LIMIT, STRICT_BYPASS, CUSTOM, NIGHT, STRICT_GROUP, BREAK, SELF_BLOCK, STUDY }

    /**
     * v6.1.0 Study Lock: during a lock, every app except the study
     * app and phone apps is blocked — same block screen, its own
     * reason. [studyActive] + [studyMissing] carry the lock state;
     * [studyApp] is the hard-coded package (StudyLock).
     * v6.1.2: the study app is recognised by [StudyLock.isStudyApp]
     * — BOTH of its Play Store packages (the original
     * com.nextive.eTestPaper and the live com.nextive.etestpaper).
     * [studyApp] is kept as a parameter for callers that already
     * pass the primary package; a package equal to it is always a
     * study app, and so is the alternate listing. Either way the
     * study app itself is never blocked by the lock; phone apps
     * are exempt (a call pauses the timer, it does not reset it).
     * The Play Store is exempt ONLY while the study app is missing,
     * so the install button can be used. The lock never blocks the
     * launcher or this app's own launcher (handled by the guard's
     * self-block rules for settings activities).
     * Checked after LIMIT/BREAK (they keep their own reasons) and
     * before Strict/Night: a lock at 21:00 must block everything
     * even when Strict/Night are off, and the study app must still
     * open when Strict is on (Strict blocks the AI group, not the
     * study app — the study app is in no limit group).
     */
    fun decideStudy(
        pkg: String,
        studyActive: Boolean,
        studyMissing: Boolean,
        studyApp: String,
        isPhoneApp: Boolean
    ): Decision? {
        // v6.1.3 always-unlocked apps: never a STUDY decision.
        if (AlwaysAllowed.isAlwaysAllowed(pkg)) return null
        if (!studyActive) return null
        if (pkg == studyApp || StudyLock.isStudyApp(pkg) || isPhoneApp) return null
        if (studyMissing && pkg == StudyLock.PLAY_STORE_PKG) return null
        return Decision(Kind.STUDY)
    }

    data class Decision(
        val kind: Kind,
        val groupId: String? = null,
        val breakUntilMs: Long = 0L
    )

    /**
     * True when the foreground screen belongs to the system Settings
     * app — by package, or by activity class. The Device Admin screen
     * (Settings > Security > Device admin apps), the App info screen
     * for Strict Guard itself, and every other Settings screen all
     * live in com.android.settings, so blocking the package blocks
     * them all. The activity check is a second layer for OEM wrappers
     * that host a Settings activity under another package name.
     */
    fun isSettingsActivity(pkg: String, activityClass: String?): Boolean {
        if (pkg == "com.android.settings") return true
        return activityClass != null &&
            activityClass.startsWith("com.android.settings")
    }

    /**
     * v6.1.0 self-block: during Strict Mode, Strict Guard's own
     * settings / dashboard activities must not open at all — the app
     * can only be opened again when Strict ends. The launcher (home
     * screen) and the block screen itself are exempt: the launcher
     * must keep working as Home, and the block screen is what the
     * self-block shows. Checked by activity class, the same approach
     * as the v5.2.1 Settings fix — the package alone cannot tell the
     * launcher apart from the dashboard, they are the same app.
     * NOT applied during Night Lock: Night Lock keeps its old
     * behaviour (the app's settings stay openable at night).
     * The activity class may be null when the foreground was resolved
     * from UsageStats only; then this returns false rather than
     * risk blocking the home screen.
     */
    fun isOwnSettingsActivity(
        pkg: String,
        activityClass: String?,
        ownPackage: String
    ): Boolean {
        if (pkg != ownPackage) return false
        if (activityClass == null) return false
        if (!activityClass.startsWith("$ownPackage.")) return false
        val simple = activityClass.substringAfterLast('.')
        return simple != "LauncherActivity" && simple != "BlockActivity"
    }

    /**
     * v6.1.4 fast path — the block decision the guard checks FIRST
     * on every poll while Strict is on, before the heavier per-tick
     * work (HSC reminders, auto theme, permission watch, usage
     * counting). Covers the bypass routes that must die the instant
     * they appear: Settings (package or activity), our own settings
     * activities, and Phone Master. Returns the decision to enforce,
     * or null to continue with the normal tick. Pure logic, so the
     * fast path itself is unit-testable.
     */
    fun fastBlockDecision(
        pkg: String,
        foregroundActivity: String?,
        ownPackage: String,
        strict: Boolean
    ): Decision? {
        if (!strict) return null
        if (isSettingsActivity(pkg, foregroundActivity)) {
            return Decision(Kind.STRICT_BYPASS)
        }
        if (isOwnSettingsActivity(pkg, foregroundActivity, ownPackage)) {
            return Decision(Kind.SELF_BLOCK)
        }
        if (PhoneMaster.isPhoneMasterActivity(pkg, foregroundActivity)) {
            return Decision(Kind.STRICT_BYPASS)
        }
        return null
    }

    /**
     * @param pkg foreground package
     * @param strict Strict Mode currently active
     * @param night Night Lock currently active
     * @param nightAllowed packages allowed during Night Lock
     * @param custom user custom block list (applies during Strict/Night)
     * @param limitReached group ids whose daily limit is used up
     * @param isLauncher true for the current home/launcher packages
     * @param ownPackage this app's package — never blocked
     * @param breakEnabled the Break Cycle toggle (v6.1.0)
     * @param breakUntilByGroup wall-clock break end per group id, 0 = not in a break
     * @param nowWallMs current wall-clock time, for the break check
     * @param studyActive a Study Lock is running tonight (v6.1.0)
     * @param studyMissing the study app is not installed (v6.1.0)
     * @param studyApp the hard-coded study app package (v6.1.0)
     * @param isPhoneApp the foreground app is a phone/dialer app (v6.1.0)
     */
    fun decide(
        pkg: String,
        strict: Boolean,
        night: Boolean,
        nightAllowed: Set<String>,
        custom: Set<String>,
        limitReached: Set<String>,
        isLauncher: Boolean,
        ownPackage: String,
        foregroundActivity: String? = null,
        breakEnabled: Boolean = true,
        breakUntilByGroup: Map<String, Long> = emptyMap(),
        nowWallMs: Long = 0L,
        studyActive: Boolean = false,
        studyMissing: Boolean = false,
        studyApp: String = StudyLock.STUDY_APP_PACKAGE,
        isPhoneApp: Boolean = false
    ): Decision? {
        if (pkg == ownPackage || isLauncher) return null

        // v6.1.3 Always-unlocked apps (Fahim, 2026-11-09): Brilliant,
        // bKash, Nagad, Claude, WhatsApp, Messenger have NO rules at
        // all — exempt from Strict, Night, limits, break, delay,
        // Study Lock and the custom list. Checked FIRST, before every
        // other rule (same defence-in-depth pattern as the study-app
        // exemption in v6.1.2), so no later branch can ever re-block
        // one of them. This reverses the v6.1.0 rule that Claude
        // stayed blocked in Strict/Night.
        if (AlwaysAllowed.isAlwaysAllowed(pkg)) return null

        // v6.1.2 defence in depth — the Study Lock can never block
        // its own app. This runs FIRST, before every other rule
        // (limit, break, Strict, Night, custom list): if a lock is
        // active and this is the study app (either of its packages),
        // it is allowed, full stop. v6.1.0/v6.1.1 only exempted the
        // study app inside decideStudy, after LIMIT/BREAK — and the
        // exemption missed the live Play Store package entirely, so
        // the lock deadlocked against its own app. No later branch
        // may ever re-decide the study app as blocked while a lock
        // is active.
        if (studyActive && StudyLock.isStudyApp(pkg)) return null

        // v6.1.4 — Phone Master (Fahim, 2026-11-09): Transsion's
        // system cleaner can freeze/disable apps, so during Strict
        // Mode it is blocked like Settings — by package AND by
        // activity class. Strict ONLY: at night or in normal use it
        // opens normally. Checked before the daily-limit rules (it
        // is in no limit group, so the order only matters for the
        // reason shown).
        if (strict && PhoneMaster.isPhoneMasterActivity(pkg, foregroundActivity)) {
            return Decision(Kind.STRICT_BYPASS)
        }

        // Daily limit reached — blocked all day, whatever the mode.
        // v6.1.0 Claude exemption: Claude never counts toward the AI
        // limit, so a used-up AI limit must not block it.
        val group = Limits.groupFor(pkg)
        val isClaude = Limits.isLimitExempt(pkg)
        if (group != null && group.id in limitReached && !isClaude) {
            return Decision(Kind.LIMIT, group.id)
        }

        // v6.1.0 Break Cycle: a forced 20-minute break after one
        // session of use. LIMIT (above) wins when both apply.
        // Checked before Strict/Night so the block screen can show
        // the break reason with its countdown instead of a generic one.
        // Claude is exempt from the break cycle too.
        if (breakEnabled && group != null && !isClaude) {
            val until = breakUntilByGroup[group.id] ?: 0L
            if (BreakCycle.isInBreak(until, nowWallMs)) {
                return Decision(Kind.BREAK, group.id, until)
            }
        }

        // v6.1.0 Study Lock: during a lock, everything except the
        // study app and phone apps is blocked. Checked after
        // LIMIT/BREAK so they keep their own reasons, and before
        // Strict/Night so the lock blocks even when those are off.
        val study = decideStudy(
            pkg, studyActive, studyMissing, studyApp, isPhoneApp
        )
        if (study != null) return study

        if (strict || night) {
            // Bypass routes stay locked during Strict/Night. Settings
            // is checked by package AND by activity class, so the
            // Device Admin screen and the App info screen for this
            // app cannot be reached while Strict is on.
            if (pkg in Limits.BUILTIN_STRICT || isSettingsActivity(pkg, foregroundActivity)) {
                return Decision(Kind.STRICT_BYPASS)
            }
            // User's custom list is fully blocked during Strict/Night.
            if (pkg in custom) return Decision(Kind.CUSTOM)
        }

        // v5.1.0 — Strict Mode itself blocks all four limit groups
        // (Facebook / Chrome / YouTube / AI), as v3.7 did. Daily limits
        // still apply on their own when Strict is off (checked above).
        // This runs before the Night check so a night-allowed app in one
        // of the groups is still blocked while Strict is on.
        if (strict && group != null) return Decision(Kind.STRICT_GROUP, group.id)

        // Night Lock: everything except the allowed list is blocked.
        // v6.1.0 Study Lock: the study app itself is exempt from
        // Night Lock while a lock is active — otherwise Night Lock
        // hours covering 21:00 would block the very app the lock is
        // trying to open, and the lock could never complete. (The
        // default Night Lock 00:00–06:00 does not overlap 21:00.)
        if (night && pkg !in nightAllowed &&
            !(studyActive && StudyLock.isStudyApp(pkg))
        ) return Decision(Kind.NIGHT)

        return null
    }
}

package app.strictguard

/**
 * Pure launcher logic — no Android framework calls, fully unit-testable.
 *
 * v6.0.0: the custom launcher (home screen) added to Strict Guard.
 * The launcher shows a greeting card, the Strict Mode card with the
 * four usage bars, and a scrollable grid of installed apps. Tapping
 * an app goes through the same [BlockDecider] rules as the guard
 * service, so a blocked app shows the block screen instead of opening.
 */
object LauncherLogic {

    enum class Greeting { MORNING, NOON, AFTERNOON, EVENING, NIGHT }

    /** 05–11 সকাল, 12–15 দুপুর, 16–18 বিকেল, 19–20 সন্ধ্যা, else রাত্রি. */
    fun greetingFor(hourOfDay: Int): Greeting = when (hourOfDay) {
        in 5..11 -> Greeting.MORNING
        in 12..15 -> Greeting.NOON
        in 16..18 -> Greeting.AFTERNOON
        in 19..20 -> Greeting.EVENING
        else -> Greeting.NIGHT
    }

    /**
     * Short duration text like the v3.7 launcher screenshot:
     * "1h 46m", "5m", "2h". Bengali digits when [bengaliDigits] is true.
     */
    fun formatShort(ms: Long, bengaliDigits: Boolean): String {
        val totalMinutes = (ms / 60_000L).toInt().coerceAtLeast(0)
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        val raw = when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h}h"
            else -> "${m}m"
        }
        return if (bengaliDigits) Limits.toBengaliDigits(raw) else raw
    }

    /** "1h 46m / 2h" — used / limit, as shown under each usage bar. */
    fun usageText(usedMs: Long, limitMs: Long, bengaliDigits: Boolean): String =
        "${formatShort(usedMs, bengaliDigits)} / ${formatShort(limitMs, bengaliDigits)}"

    data class AppEntry(val pkg: String, val label: String)

    /**
     * Sort the launcher grid: Strict Guard itself is pinned first,
     * everything else alphabetical by label (case-insensitive).
     */
    fun sortApps(apps: List<AppEntry>, ownPackage: String): List<AppEntry> {
        val deduped = apps.distinctBy { it.pkg }
        val pinned = deduped.filter { it.pkg == ownPackage }
        val rest = deduped.filter { it.pkg != ownPackage }
            .sortedBy { it.label.lowercase() }
        return pinned + rest
    }

    /**
     * v6.1.4 — the launcher list with Phone Master removed while
     * Strict is on: it must not appear in the grid at all (not
     * even dimmed, not even with a lock badge), and not in the
     * hidden-apps dialog either. When Strict is off it is an
     * ordinary app again. Hiding is display-only — the guard
     * service blocks the launch itself ([BlockDecider.decide]),
     * so Phone Master cannot be opened from Recents, a
     * notification, or another launcher either.
     */
    fun visibleApps(apps: List<AppEntry>, strict: Boolean): List<AppEntry> =
        PhoneMaster.visibleApps(apps, strict)

    /**
     * What happens when the user taps an app on the launcher grid.
     * Returns the [BlockDecider.Decision] when the tap must be blocked,
     * or null when the app may open. Strict Guard itself opens its
     * own settings screen — except during Strict Mode, when the tap
     * is self-blocked (v6.1.0) and shows the block screen instead.
     *
     * Two layers, matching the guard service:
     * - another home/launcher app is a bypass route during Strict or
     *   Night Lock: tapping it must not escape to the system launcher.
     * - everything else goes through [BlockDecider.decide], the same
     *   rules the guard service enforces (Strict groups, Night Lock,
     *   daily limits, custom list, Settings / bypass apps).
     */
    fun tapDecision(
        pkg: String,
        strict: Boolean,
        night: Boolean,
        nightAllowed: Set<String>,
        custom: Set<String>,
        limitReached: Set<String>,
        launcherPackages: Set<String>,
        ownPackage: String,
        foregroundActivity: String? = null,
        breakEnabled: Boolean = true,
        breakUntilByGroup: Map<String, Long> = emptyMap(),
        nowWallMs: Long = 0L,
        studyActive: Boolean = false,
        studyMissing: Boolean = false,
        isPhoneApp: Boolean = false
    ): BlockDecider.Decision? {
        if (pkg == ownPackage) {
            // v6.1.0 Study Lock: the app's own settings are "anything
            // else" during a lock, so the tile is blocked with the
            // STUDY reason (the guard service catches every other
            // path to the app as well).
            return when {
                strict -> BlockDecider.Decision(BlockDecider.Kind.SELF_BLOCK)
                studyActive -> BlockDecider.Decision(BlockDecider.Kind.STUDY)
                else -> null
            }
        }
        // v6.1.3 always-unlocked apps: checked before the
        // launcher-bypass branch and before decide() — no rule
        // anywhere in the tap path can block one of the six.
        if (AlwaysAllowed.isAlwaysAllowed(pkg)) return null
        if (pkg in launcherPackages && (strict || night)) {
            return BlockDecider.Decision(BlockDecider.Kind.STRICT_BYPASS)
        }
        // v6.1.0 Study Lock: during a lock only the study app and
        // phone apps may be opened from the launcher. The guard
        // service enforces the same rule if the app is reached any
        // other way, so this is a fast path, not the only gate.
        val study = BlockDecider.decideStudy(
            pkg, studyActive, studyMissing,
            StudyLock.STUDY_APP_PACKAGE, isPhoneApp
        )
        if (study != null) return study
        return BlockDecider.decide(
            pkg, strict, night, nightAllowed, custom, limitReached,
            pkg in launcherPackages, ownPackage, foregroundActivity,
            breakEnabled, breakUntilByGroup, nowWallMs,
            studyActive, studyMissing, StudyLock.STUDY_APP_PACKAGE, isPhoneApp
        )
    }
}

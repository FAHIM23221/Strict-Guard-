package app.strictguard

/**
 * Force-stop / Clear Data protection for Strict Mode (v6.1.0).
 *
 * Android facts (verified, do not overclaim):
 * 1. FORCE STOP: an app that is an ACTIVE Device Admin has its
 *    Force Stop button greyed out by Android's Settings app itself
 *    — and the Disable/Uninstall button too. So Strict Mode now
 *    REQUIRES active Device Admin to start: StrictSetupActivity
 *    refuses to start Strict until admin is on. Since the Settings
 *    app is already blocked during Strict, the "deactivate admin"
 *    toggle cannot be reached while Strict is on. Protection holds
 *    ONLY while Device Admin is active — if admin is off, Strict
 *    cannot start at all.
 * 2. CLEAR DATA: Android offers NO API to grey out or disable the
 *    "Clear Data / Clear Storage" button — the button will still be
 *    tappable. The defence is therefore STATE SURVIVAL, not button
 *    removal: the Strict state (strict-on + wall-clock end time) is
 *    mirrored to an encrypted, HMAC-protected file OUTSIDE the app's
 *    private data. Private internal storage and app-specific
 *    external storage are both wiped by Clear Data, so the mirror
 *    lives in shared storage (MediaStore Downloads, see
 *    [MirrorStore]) — a shared/public location that survives Clear
 *    Data on Android 16. On the next app launch / boot receiver /
 *    launcher start, if the mirror says Strict is still on, Strict
 *    is restored immediately, even with a fresh empty Store.
 *    The mirror is HMAC/checksummed: editing it to shorten Strict
 *    is detected and logged, and a tampered mirror NEVER shortens
 *    Strict — it restores Strict to the maximum duration instead.
 * 3. When Strict ends NORMALLY (schedule expiry), the mirror is
 *    deleted, so clearing data afterwards is a clean slate and
 *    fully allowed again. Same when Strict is off: no mirror, no
 *    interference. Test-mode end also deletes it.
 * 4. "Disable" is already greyed out for active device admins
 *    (same Android behaviour as Force Stop — verified by the same
 *    rule). "Clear cache" is harmless: no state lives in the cache.
 * 5. Force-stop gap detection: the guard writes its last tick
 *    timestamp every poll. On the next service start, if Strict is
 *    on and the last tick is stale (over 15 minutes) and the start
 *    did NOT come from boot/unlock, the gap is logged as
 *    FORCE_STOP_DETECTED. A reboot explains the gap too, so boot
 *    starts are excluded — a phone left off overnight then booted
 *    is a reboot, not a force-stop. If the user force-stops and
 *    then reboots instead of launching the app, the gap is
 *    genuinely indistinguishable and is not logged — documented.
 * 6. Single package only: no second app, no watcher app.
 *
 * Remaining hole, stated plainly: a user who finds the mirror file
 * with a file manager and deletes it can still defeat the
 * Clear Data defence — the mirror cannot protect itself. What
 * deleting it does NOT do is shorten Strict: the mirror is only a
 * backup; if the Store still has Strict, Strict stays on.
 *
 * Pure logic — fully unit-testable. The Keystore crypto and the
 * MediaStore file I/O live in [MirrorCrypto] / [MirrorStore];
 * [StrictMirror] only decides, given bytes.
 */
object StrictMirror {

    /** Payload format version. */
    const val VERSION: Int = 1

    /** Force-stop gap: last guard tick older than this. */
    const val FORCE_STOP_GAP_MS: Long = 15L * 60L * 1000L

    /** The Strict state a mirror carries. */
    data class MirrorState(
        /** Wall-clock end of Strict (epoch millis). */
        val strictEndWallMs: Long,
        /** Wall-clock time the mirror was written. */
        val createdWallMs: Long
    )

    /** What a mirror check found. */
    sealed class Restore {
        /** No mirror file exists — nothing to restore. */
        object NoMirror : Restore()
        /** The Store already has Strict active — nothing to do. */
        object AlreadyActive : Restore()
        /** Mirror is valid and Strict is still on: restore this state. */
        data class Restored(val state: MirrorState) : Restore()
        /** Mirror is valid but its end time has passed: delete it. */
        object Expired : Restore()
        /** HMAC/auth failed or the payload is unparseable: keep Strict on. */
        object Tampered : Restore()
    }

    /** Serialize a mirror payload (before encryption). */
    fun buildPayload(state: MirrorState): ByteArray =
        "v$VERSION\n${state.strictEndWallMs}\n${state.createdWallMs}\n".toByteArray(Charsets.UTF_8)

    /** Parse a decrypted payload. Null = unparseable (tampered). */
    fun parsePayload(plain: ByteArray): MirrorState? {
        return try {
            val lines = String(plain, Charsets.UTF_8).split("\n")
            if (lines.size < 3 || lines[0] != "v$VERSION") return null
            val end = lines[1].toLongOrNull() ?: return null
            val created = lines[2].toLongOrNull() ?: return null
            if (end <= 0L || created <= 0L) return null
            MirrorState(end, created)
        } catch (e: Exception) {
            null
        }
    }

    /** Encrypt a state into mirror bytes. */
    fun encode(state: MirrorState, crypto: MirrorCrypto): ByteArray =
        crypto.encrypt(buildPayload(state))

    /** Decrypt + parse mirror bytes. Null = tampered / unreadable. */
    fun decode(bytes: ByteArray, crypto: MirrorCrypto): MirrorState? {
        val plain = try {
            crypto.decrypt(bytes)
        } catch (e: Exception) {
            null
        } ?: return null
        return parsePayload(plain)
    }

    /**
     * Decide what a mirror means right now.
     *
     * @param mirrorBytes the mirror file's bytes, or null if absent
     * @param storeWallEnd the Store's Strict wall end (0 = Store has no Strict)
     * @param storeActive the Store's Strict is currently active
     * @param nowWallMs current wall-clock time
     */
    fun decideRestore(
        mirrorBytes: ByteArray?,
        storeWallEnd: Long,
        storeActive: Boolean,
        nowWallMs: Long,
        crypto: MirrorCrypto
    ): Restore {
        if (mirrorBytes == null) return Restore.NoMirror
        if (storeActive && storeWallEnd > 0L) return Restore.AlreadyActive
        val state = decode(mirrorBytes, crypto) ?: return Restore.Tampered
        if (state.strictEndWallMs <= nowWallMs) return Restore.Expired
        return Restore.Restored(state)
    }

    /**
     * End time to use when the mirror is tampered: the maximum
     * Strict duration from now. A tampered mirror is never trusted
     * to shorten Strict — the safe direction is the longest allowed.
     */
    fun tamperFallbackEndMs(nowWallMs: Long): Long =
        nowWallMs + Limits.MAX_STRICT_DAYS * Limits.DAY_MS

    /**
     * Force-stop gap detection (pure): Strict is on, the last guard
     * tick is stale, and this service start did NOT come from boot
     * or unlock (a reboot explains the gap, a force-stop does not).
     */
    fun shouldLogForceStopGap(
        strictActive: Boolean,
        lastTickWallMs: Long,
        nowWallMs: Long,
        startedFromBoot: Boolean
    ): Boolean {
        if (!strictActive || startedFromBoot) return false
        if (lastTickWallMs <= 0L) return false
        return nowWallMs - lastTickWallMs > FORCE_STOP_GAP_MS
    }
}

package app.strictguard

/**
 * v6.1.3 — Always-unlocked apps (Fahim, 2026-11-09).
 *
 * These six apps have NO rules at all — they are always unlocked:
 * Brilliant, bKash, Nagad, Claude, WhatsApp, Messenger. They are
 * exempt from EVERYTHING: Strict Mode, Night Lock, daily limits,
 * break cycle, entry delay, Study Lock, and the custom blocklist.
 * The launcher never shows a lock badge on them, and their usage
 * is never counted.
 *
 * This REVERSES the earlier rule (v6.1.0) that Claude stayed
 * blocked during Strict Mode and Night Lock — Fahim now wants
 * Claude fully exempt too, like the other five. WhatsApp was
 * already excluded from the entry delay only; it is now exempt
 * from everything, as is Messenger.
 *
 * Packages verified 2026-11-09 (never guessed — each one checked
 * against Google Play / AppBrain / APK listings):
 * - Brilliant: TWO apps share the "Brilliant" name, and both are
 *   included — Fahim's launcher shows "Brilliant" and either one
 *   could be it:
 *   (a) Brilliant (brilliant.org learning app):
 *   org.brilliant.android — Google Play
 *   (id=org.brilliant.android), AppBrain, APKFab.
 *   (b) Brilliant Connect (Bangladeshi IP-calling app, InterCloud):
 *   com.brilliant.connect.com.bd — APKMirror (v3.6.4, 2026-07-19)
 *   and Uptodown agree across every version listed.
 *   A label fallback ([isAlwaysAllowedLabel]) covers a renamed or
 *   repackaged variant of either one.
 * - bKash: com.bKash.customerapp — NOTE the capital K, package
 *   names are case-sensitive (Uptodown, APKMirror, Play URL
 *   id=com.bKash.customerapp). The merchant / business variants
 *   (com.bKash.merchantapp, com.bkash.businessapp) are NOT
 *   included — only the customer app Fahim uses.
 * - Nagad: com.konasl.nagad — AppBrain
 *   (appbrain.com/app/nagad/com.konasl.nagad) and andro.io.
 *   The agent / DSO variants (com.konasl.nagad.agent,
 *   com.konasl.nagad.dso) are NOT included.
 * - Claude: com.anthropic.claude — already in Limits.CLAUDE_PACKAGE.
 * - WhatsApp: com.whatsapp — Uptodown / APKFab / Play.
 *   (WhatsApp Business, com.whatsapp.w4b, is NOT included —
 *   Fahim named WhatsApp only.)
 * - Messenger: com.facebook.orca — already in the FACEBOOK group
 *   list in Limits.kt; without this exemption Messenger would
 *   count toward Facebook's 120-minute limit and be blocked by
 *   Strict Mode as a Facebook-group app.
 *
 * The set is hard-coded on purpose, like the study-app link:
 * there is no UI to change it, so it cannot be weakened in a
 * moment of temptation. Checked FIRST in BlockDecider.decide()
 * (before every other rule, same defence-in-depth pattern as the
 * study-app exemption in v6.1.2), in decideStudy(), in the
 * launcher tap path, in the entry-delay gate, and in usage
 * counting — so no later branch can ever re-block one of them.
 *
 * v6.1.3 — Night Lock default: the same six are the default
 * Night Lock allowed-apps list (see [defaultNightAllowed]).
 * Fahim asked that during Night Lock these six already be there
 * in the launcher — he must not have to add them separately.
 * He can still add more apps, or remove some of the six, in the
 * Night Lock picker; an explicit saved choice always wins over
 * the default.
 */
object AlwaysAllowed {

    const val BRILLIANT = "org.brilliant.android"
    const val BKASH = "com.bKash.customerapp"
    const val NAGAD = "com.konasl.nagad"
    const val CLAUDE = "com.anthropic.claude"
    const val WHATSAPP = "com.whatsapp"
    const val MESSENGER = "com.facebook.orca"

    /** The six always-unlocked apps. */
    val PACKAGES: Set<String> = setOf(
        BRILLIANT, BKASH, NAGAD, CLAUDE, WHATSAPP, MESSENGER
    )

    /** True when [pkg] is one of the six always-unlocked apps. */
    fun isAlwaysAllowed(pkg: String): Boolean = pkg in PACKAGES

    /**
     * The Night Lock allowed-apps list when no explicit choice has
     * ever been saved: the six always-unlocked apps. Once Fahim
     * saves a list in the Night Lock picker ([hasStored] true),
     * that saved list is used exactly as saved — including if he
     * removed one of the six or added others. Pure logic, so the
     * Store getter delegates to this and it stays unit-testable
     * without Android framework classes.
     */
    fun defaultNightAllowed(
        hasStored: Boolean,
        stored: Set<String>?
    ): Set<String> =
        if (hasStored) stored ?: emptySet() else PACKAGES
}

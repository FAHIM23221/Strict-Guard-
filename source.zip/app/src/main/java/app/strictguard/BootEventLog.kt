package app.strictguard

import android.content.Context

/**
 * v6.1.6 — boot-time events, written to device-protected storage.
 *
 * THE SHADE HOLE (Fahim, 2026-11-09 ~03:51, Infinix X6886): after a
 * restart, while the home screen was still loading, he pulled down
 * the Quick Settings shade and tapped the gear — Settings opened
 * even though Strict was on and v6.1.5 claimed the boot gap closed.
 *
 * Why the v6.1.5 boot mode could not see it: boot blocks lived
 * ONLY in GuardService's in-memory list ([GuardService
 * .bootBlockedEvents]), flushed into the Tamper Log when boot mode
 * ended normally. If the service process died before graduating to
 * the normal path, the evidence that Settings was opened during
 * Strict at boot died with it. The Tamper Log itself lives in
 * credential-encrypted prefs, unreadable before unlock — but
 * device-protected prefs ARE writable before unlock, so boot events
 * are recorded here the moment they happen and drained into the
 * Tamper Log on graduation. If the process dies first, the events
 * survive in these prefs and are drained on the next graduation
 * (or the next app launch that flushes them).
 *
 * The MediaStore Strict mirror is NOT a second pre-unlock source
 * for this: its Keystore keys are unavailable before unlock, and
 * shared storage itself may be unavailable in direct boot
 * (MirrorStore says so in its own header). The device-protected
 * boot mirror (Strict wall end + service-wanted) stays the only
 * pre-unlock Strict signal.
 *
 * Everything here is best-effort and never throws: a failed write
 * loses one log line, never enforcement.
 */
object BootEventLog {

    const val PREFS = "boot_events"
    private const val K_EVENTS = "events"
    const val MAX_EVENTS = 50

    /** "BOOT_BLOCKED com.android.settings/<class> (STRICT_BYPASS)". */
    fun formatBlockEvent(
        pkg: String,
        activityClass: String?,
        kind: BlockDecider.Kind
    ): String =
        "BOOT_BLOCKED $pkg/${activityClass ?: "?"} (${kind.name})"

    fun formatAdminLostEvent(): String =
        "BOOT_ADMIN_LOST device-admin turned off in Settings"

    /** Pure: append one event, capped at [MAX_EVENTS]. Used by tests. */
    fun append(events: List<String>, event: String): List<String> =
        (events + event).takeLast(MAX_EVENTS)

    /** Append one event to device-protected prefs. Never throws. */
    fun record(context: Context, event: String) {
        try {
            val p = context.applicationContext
                .createDeviceProtectedStorageContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val existing = p.getString(K_EVENTS, "") ?: ""
            val lines = existing.split("\n").filter { it.isNotBlank() }
            p.edit()
                .putString(K_EVENTS, append(lines, event).joinToString("\n"))
                .apply()
        } catch (e: Exception) {
        }
    }

    /** Read + clear all recorded events. Never throws. */
    fun drain(context: Context): List<String> {
        return try {
            val p = context.applicationContext
                .createDeviceProtectedStorageContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val existing = p.getString(K_EVENTS, "") ?: ""
            val lines = existing.split("\n").filter { it.isNotBlank() }
            p.edit().putString(K_EVENTS, "").apply()
            lines
        } catch (e: Exception) {
            emptyList()
        }
    }
}

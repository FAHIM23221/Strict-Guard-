package app.strictguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Logs clock changes (a Strict-evasion attempt) and package install/remove
 * events to the Tamper Log. Strict end is stored in elapsedRealtime, so
 * changing the wall clock does NOT end Strict early.
 *
 * v6.0.0: USER_UNLOCKED — the guard may have started in direct boot
 * with empty state (credential-encrypted prefs unreadable before
 * unlock). The moment the user unlocks, the real prefs are readable:
 * recover the Strict schedule and restart the guard, so there is no
 * exploitable gap between unlock and the first poll.
 */
class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // v6.1.1: a receiver that throws crashes the app process.
        // PACKAGE_ADDED fires at install time — before any setup —
        // so this must never throw, whatever the system hands us.
        try {
            onReceiveSafe(context, intent)
        } catch (e: Exception) {
        }
    }

    private fun onReceiveSafe(context: Context, intent: Intent) {
        val store = Store(context)
        when (intent.action) {
            Intent.ACTION_USER_UNLOCKED -> {
                store.recoverStrictAfterBoot()
                // v6.1.4 — same "enforce first" rule as the boot
                // receiver: request the guard start BEFORE the
                // slow mirror restore and alarm scheduling, so the
                // unlock boundary has no gap either. The direct-boot
                // guard is usually already running by now; this
                // restarts it with the real (unlocked) state.
                if (store.serviceWanted || store.isStrictActive()) {
                    // v6.1.1: a background start can be refused on
                    // Android 12+ — a missed start, never a crash.
                    StartupGuard.startGuardServiceFromBoot(context)
                    store.logTamper("UNLOCKED guard restarted")
                }
                // v6.1.0 Clear Data defence: restore Strict from the
                // mirror if the Store lost it; re-schedule the Friday
                // prayer alarm after unlock.
                MirrorStore.checkAndRestore(context, store)
                PrayerAlarmScheduler.scheduleNext(context)
            }
            Intent.ACTION_TIME_CHANGED -> store.logTamper("CLOCK_CHANGED time-set")
            Intent.ACTION_TIMEZONE_CHANGED -> store.logTamper("CLOCK_CHANGED timezone")
            Intent.ACTION_PACKAGE_ADDED -> {
                val pkg = intent.data?.schemeSpecificPart ?: return
                if (!intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) {
                    store.logTamper("PACKAGE_INSTALLED $pkg")
                }
            }
            Intent.ACTION_PACKAGE_REMOVED -> {
                val pkg = intent.data?.schemeSpecificPart ?: return
                if (!intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) {
                    store.logTamper("PACKAGE_REMOVED $pkg")
                }
            }
        }
    }
}

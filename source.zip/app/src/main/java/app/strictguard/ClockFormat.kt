package app.strictguard

import java.util.Locale

/**
 * Clock format for the launcher clock (v6.1.0).
 *
 * 24-hour (default): "17:05" — the behaviour before this change.
 * 12-hour: "5:05 PM" with a clear AM/PM marker. In Bengali the
 * marker is "পূর্বাহ্ণ" (AM) / "অপরাহ্ণ" (PM), the standard Bengali
 * locale markers. Pure logic — fully unit-testable.
 */
object ClockFormat {

    /**
     * Format a time of day. [hour24] is 0–23, [minute] is 0–59.
     * [use24h] true gives "17:05"; false gives "5:05 PM".
     * [bengali] selects the AM/PM marker language (digits stay
     * Latin, as the launcher clock has always shown them).
     */
    fun format(hour24: Int, minute: Int, use24h: Boolean, bengali: Boolean): String {
        if (use24h) {
            return String.format(Locale.US, "%02d:%02d", hour24, minute)
        }
        val hour12 = hour24 % 12
        val h = if (hour12 == 0) 12 else hour12
        val marker = if (hour24 < 12) {
            if (bengali) "পূর্বাহ্ণ" else "AM"
        } else {
            if (bengali) "অপরাহ্ণ" else "PM"
        }
        return String.format(Locale.US, "%d:%02d %s", h, minute, marker)
    }
}

package app.strictguard

import android.content.Context
import android.content.Intent
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Auto theme by time (v6.1.0).
 *
 * When the "অটো থিম" toggle is ON (default), the theme follows the
 * clock in Asia/Dhaka: Light from 06:00, Dark from 18:00, every day.
 * The switch is evaluated whenever the app resumes and on every
 * GuardService poll, so it applies even if the app was closed at the
 * switch time, and it survives reboot (the setting and the last
 * applied state are persisted in [Store]).
 *
 * How a manual toggle still works: the automatic switch only fires
 * when the desired theme differs from the last theme the automatic
 * switch applied. If the user manually changes the theme at 10:00,
 * the desired theme (light) still equals the last auto-applied theme
 * (light, applied at 06:00), so nothing is forced back — the manual
 * choice holds until the next scheduled switch (18:00), when the
 * desired theme becomes dark and the automatic switch fires again.
 *
 * The automatic switch itself still applies during Strict Mode: it
 * is automatic, not a manual settings change, so it bypasses the
 * lock-during-Strict guard ([Store.setThemeAuto]). The toggle itself
 * is locked during Strict like every other setting.
 *
 * Pure logic ([desiredTheme], [hourInDhaka], [themeToApply]) is
 * fully unit-testable; [maybeApplyAutoTheme] is the thin Android
 * side that persists the switch and tells open activities to
 * recreate ([BaseActivity] listens for [ACTION_THEME_CHANGED]).
 */
object AutoTheme {

    /** Broadcast sent when the automatic switch changes the theme. */
    const val ACTION_THEME_CHANGED = "app.strictguard.THEME_CHANGED"

    /** The switch times are Asia/Dhaka local time. */
    const val ZONE_ID = "Asia/Dhaka"

    /** Light mode starts at 06:00. */
    const val LIGHT_FROM_HOUR = 6

    /** Dark mode starts at 18:00. */
    const val DARK_FROM_HOUR = 18

    /** Light from 06:00 up to (but not including) 18:00, dark otherwise. */
    fun desiredTheme(hour24: Int): String =
        if (hour24 in LIGHT_FROM_HOUR until DARK_FROM_HOUR) "light" else "dark"

    /** Hour of day (0–23) in Asia/Dhaka for a wall-clock instant. */
    fun hourInDhaka(nowMillis: Long): Int =
        ZonedDateTime.ofInstant(
            Instant.ofEpochMilli(nowMillis), ZoneId.of(ZONE_ID)
        ).hour

    /**
     * The theme the automatic switch should apply right now, or null
     * when nothing should change: auto theme off, or the desired
     * theme is already the last one the automatic switch applied
     * (which is also what lets a manual override hold until the next
     * scheduled switch time). [lastApplied] is null before the first
     * automatic switch (fresh install), so the current period's
     * theme is applied once.
     */
    fun themeToApply(
        autoEnabled: Boolean,
        nowMillis: Long,
        lastApplied: String?
    ): String? {
        if (!autoEnabled) return null
        val desired = desiredTheme(hourInDhaka(nowMillis))
        return if (desired != lastApplied) desired else null
    }

    /**
     * Evaluate the automatic switch now. Applies it (persisting the
     * theme and the last-applied state) and broadcasts
     * [ACTION_THEME_CHANGED] when a switch is due. Returns true when
     * a switch was applied. Never throws — callers run this on the
     * guard poll and on resume, where a failure must not break the
     * guard or the activity.
     */
    fun maybeApplyAutoTheme(context: Context, store: Store): Boolean {
        return try {
            val toApply = themeToApply(
                store.autoTheme, System.currentTimeMillis(), store.autoThemeApplied
            ) ?: return false
            store.setThemeAuto(toApply)
            store.autoThemeApplied = toApply
            // v6.1.1: address the broadcast at our own package so it
            // is explicit, not implicit (Android 14 restricts
            // implicit intents to internal components). The receiver
            // is registered RECEIVER_NOT_EXPORTED, so only our app
            // can hear it either way.
            context.sendBroadcast(
                Intent(ACTION_THEME_CHANGED).setPackage(context.packageName)
            )
            true
        } catch (e: Exception) {
            false
        }
    }
}

package app.strictguard

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.DatePicker
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TimePicker
import android.widget.Toast
import java.util.Calendar

/**
 * v5.2.0 — Start Strict Mode with a schedule the user picks:
 * until midnight, for a number of days, or until a chosen date + time.
 * The end is stored as wall-clock epoch millis (survives reboot) and
 * can never be shortened or changed while Strict is on: this screen
 * refuses to open during Strict, and Store setters refuse writes.
 */
class StrictSetupActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (store.isStrictActive()) {
            Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        setContentView(R.layout.activity_strict)

        val rg = findViewById<RadioGroup>(R.id.rgSchedule)
        val etDays = findViewById<EditText>(R.id.etDays)
        val dpDate = findViewById<DatePicker>(R.id.dpDate)
        val tpTime = findViewById<TimePicker>(R.id.tpTime)
        val cbTest = findViewById<CheckBox>(R.id.cbTest)
        tpTime.setIs24HourView(true)
        // Default date/time: tomorrow, same time.
        val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        dpDate.init(
            tomorrow.get(Calendar.YEAR), tomorrow.get(Calendar.MONTH),
            tomorrow.get(Calendar.DAY_OF_MONTH), null
        )
        tpTime.hour = tomorrow.get(Calendar.HOUR_OF_DAY)
        tpTime.minute = tomorrow.get(Calendar.MINUTE)

        fun refreshInputs() {
            val dateMode = rg.checkedRadioButtonId == R.id.rbDate
            val daysMode = rg.checkedRadioButtonId == R.id.rbDays
            etDays.isEnabled = daysMode
            etDays.alpha = if (daysMode) 1f else 0.5f
            dpDate.isEnabled = dateMode
            dpDate.alpha = if (dateMode) 1f else 0.5f
            tpTime.isEnabled = dateMode
            tpTime.alpha = if (dateMode) 1f else 0.5f
        }
        rg.setOnCheckedChangeListener { _, _ -> refreshInputs() }
        refreshInputs()

        findViewById<Button>(R.id.btnCancel).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnConfirm).setOnClickListener {
            // v6.1.0 — Strict Mode REQUIRES active Device Admin.
            // An active device admin has its Force Stop button (and
            // its Disable button) greyed out by Android's Settings
            // app itself, and Settings is blocked during Strict, so
            // admin cannot be deactivated while Strict is on. Without
            // admin, force-stop would end Strict — so Strict refuses
            // to start until admin is on. The prompt offers to enable
            // it right here.
            if (!Util.isAdminActive(this)) {
                android.app.AlertDialog.Builder(this)
                    .setTitle(getString(R.string.admin_required_title))
                    .setMessage(getString(R.string.admin_required_text))
                    .setPositiveButton(getString(R.string.admin_required_enable)) { _, _ ->
                        val intent = android.content.Intent(
                            android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN
                        ).apply {
                            putExtra(
                                android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                                android.content.ComponentName(this@StrictSetupActivity, GuardAdminReceiver::class.java)
                            )
                            putExtra(
                                android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                getString(R.string.admin_required_text)
                            )
                        }
                        try {
                            startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(this, R.string.admin_required_text, Toast.LENGTH_LONG).show()
                        }
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
                return@setOnClickListener
            }
            val test = cbTest.isChecked
            if (test) {
                startStrictUntil(System.currentTimeMillis() + 60_000L, true, "STRICT_START test-1min")
                return@setOnClickListener
            }
            val nowWall = System.currentTimeMillis()
            val wallEnd: Long = when (rg.checkedRadioButtonId) {
                R.id.rbDays -> {
                    val days = etDays.text.toString().trim().toIntOrNull() ?: -1
                    if (!Limits.validScheduleDays(days)) {
                        Toast.makeText(this, R.string.strict_invalid_days, Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                    Limits.wallEndForDays(nowWall, days)
                }
                R.id.rbDate -> {
                    val end = Limits.wallEndForDateTime(
                        dpDate.year, dpDate.month, dpDate.dayOfMonth,
                        tpTime.hour, tpTime.minute
                    )
                    if (!Limits.validScheduleDateTime(end, nowWall)) {
                        val msg = if (end <= nowWall + 60_000L) R.string.strict_invalid_date
                        else R.string.strict_invalid_date_far
                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                    end
                }
                else -> nowWall + Limits.msUntilMidnight(Calendar.getInstance())
            }
            val label = when (rg.checkedRadioButtonId) {
                R.id.rbDays -> "STRICT_START days until $wallEnd"
                R.id.rbDate -> "STRICT_START date until $wallEnd"
                else -> "STRICT_START until-midnight"
            }
            startStrictUntil(wallEnd, false, label)
        }
    }

    private fun startStrictUntil(wallEndMs: Long, test: Boolean, logLine: String) {
        store.startStrictUntil(wallEndMs, test)
        store.logTamper(logLine)
        // v6.1.1: the service start must never crash this screen.
        StartupGuard.startGuardService(this)
        Toast.makeText(this, R.string.toast_strict_started, Toast.LENGTH_SHORT).show()
        finish()
    }
}

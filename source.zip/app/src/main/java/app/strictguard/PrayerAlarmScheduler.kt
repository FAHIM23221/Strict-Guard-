package app.strictguard

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Schedules the Friday 09:00 prayer alarm with AlarmManager.
 *
 * Exact when the system permits it (SCHEDULE_EXACT_ALARM —
 * granted by default on API 31+, the user can revoke it in
 * Settings), inexact otherwise. Either way the guard poll is a
 * second fallback (see GuardService.fridayTick), so the alarm
 * still rings if exact alarms are revoked. A single persisted
 * "last rung day" is shared by both paths, so the alarm never
 * rings twice on the same Friday.
 *
 * Re-scheduled on boot (BootReceiver / USER_UNLOCKED) and after
 * every firing (the receiver schedules the next Friday). When the
 * toggle is off, the alarm is cancelled.
 * Never throws.
 */
object PrayerAlarmScheduler {

    private const val REQUEST_CODE = 9001

    fun alarmIntent(context: Context): PendingIntent {
        val i = Intent(context, PrayerAlarmReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun scheduleNext(context: Context) {
        try {
            val store = Store(context)
            if (!store.fridayAlarmEnabled) {
                cancel(context)
                return
            }
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val at = FridayPrayer.nextFriday0900(System.currentTimeMillis())
            val pi = alarmIntent(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (FridayPrayer.useExactAlarm(am.canScheduleExactAlarms())) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: Exception) {
        }
    }

    fun cancel(context: Context) {
        try {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(alarmIntent(context))
        } catch (e: Exception) {
        }
    }
}

package app.strictguard

/**
 * Pure boot-restore decisions (v6.0.0 bypass hardening).
 *
 * The bypass Fahim named: after power-off/power-on there is a window
 * of a few seconds before the guard starts, during which the app
 * could be uninstalled (open Settings, deactivate Device Admin,
 * uninstall). The fix has three layers, and every layer is a pure
 * decision here so it can be unit-tested without Android:
 *  1. Start the guard BEFORE the user unlocks, on
 *     LOCKED_BOOT_COMPLETED (direct boot), from the
 *     device-protected mirror of the Strict schedule — so the guard
 *     is already running when the lock screen opens and Settings is
 *     blocked from the first second the user can touch anything.
 *  2. On BOOT_COMPLETED, recover the schedule, restart the guard,
 *     and open the launcher immediately (it is the default home, so
 *     the system shows it first anyway).
 *  3. On USER_UNLOCKED, re-read the real (credential-encrypted)
 *     state and restart the guard, so a direct-boot start that ran
 *     with empty state is corrected the moment the user unlocks.
 *
 * Honest limit, kept in the code so nobody over-claims: Android
 * still lets the user deactivate Device Admin when Strict is OFF,
 * and Safe Mode / ADB / a second profile bypass any app-level
 * guard. What this closes is the *boot gap* — by the time the user
 * can touch Settings, the guard is already running.
 */
object BootRestore {
    /** Start the guard on a normal boot: Strict on, or monitoring wanted. */
    fun shouldStartGuard(strictActive: Boolean, serviceWanted: Boolean): Boolean =
        strictActive || serviceWanted

    /**
     * Start the guard during direct boot (before unlock), from the
     * device-protected mirror: Strict wall-clock end still in the
     * future, or monitoring wanted.
     */
    fun directBootGuardStart(
        strictWallEndMs: Long,
        nowWallMs: Long,
        serviceWanted: Boolean
    ): Boolean =
        serviceWanted || Limits.strictWallActive(nowWallMs, strictWallEndMs)

    /** Open the launcher right after boot: Strict on, or it is the default home. */
    fun shouldOpenLauncher(strictActive: Boolean, isDefaultHome: Boolean): Boolean =
        strictActive || isDefaultHome
    /**
     * v6.1.4 — the boot-path decision, from the cheap
     * device-protected mirror only (Strict's wall-clock end +
     * whether the guard is wanted at all). The receiver requests
     * the guard start from THIS decision, before any slow work
     * (mirror restore, alarm scheduling, launcher open) — so
     * enforcement is never gated on the slow work. Pure, so the
     * ordering rule itself is unit-testable.
     */
    fun bootStartDecision(
        strictWallEndMs: Long,
        nowWallMs: Long,
        serviceWanted: Boolean
    ): Boolean =
        shouldStartGuard(Limits.strictWallActive(nowWallMs, strictWallEndMs), serviceWanted)
}

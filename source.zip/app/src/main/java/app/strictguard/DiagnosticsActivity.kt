package app.strictguard

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.util.Calendar

/** Diagnostics screen: every guard's status in one place, shareable as text. */
class DiagnosticsActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_list)

        findViewById<TextView>(R.id.listTitle).setText(R.string.diag_title)
        val tv = findViewById<TextView>(R.id.tvContent)
        val share = findViewById<Button>(R.id.btnClear)
        share.visibility = android.view.View.VISIBLE
        share.setText(R.string.diag_share)

        val lines = ArrayList<String>()
        lines.add("Strict Guard 6.0.0 (code 34)")
        lines.add("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        lines.add("Package: $packageName")
        lines.add("Guard service running now: ${GuardService.isRunning}")
        lines.add("Usage Access: ${Util.hasUsageAccess(this)}")
        lines.add("Overlay: ${Util.hasOverlay(this)}")
        lines.add("Device Admin: ${Util.isAdminActive(this)}")
        lines.add("Device Admin monitored: yes (loss is logged + notification)")
        lines.add("Settings blocked during Strict/Night: yes (package + activity)")
        lines.add("Strict ends (wall clock): " +
            if (store.strictEndWall() > 0L) java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm", java.util.Locale.US
            ).format(java.util.Date(store.strictEndWall())) else "-")
        lines.add("Battery optimisation ignored: ${Util.isIgnoringBatteryOptimizations(this)}")
        lines.add("Notification Access: ${Util.isNotificationListenerEnabled(this)}")
        lines.add("Default launcher: ${Util.isDefaultLauncher(this)}")
        lines.add("Autostart confirmed: ${store.autostartConfirmed}")
        lines.add("Monitoring wanted: ${store.serviceWanted}")
        lines.add("Strict active: ${store.isStrictActive()}" +
            if (store.isStrictActive()) " (test=${store.isTestMode()})" else "")
        lines.add("Night Lock: ${store.nightEnabled} " +
            "${store.nightStartMin / 60}:${"%02d".format(store.nightStartMin % 60)}-" +
            "${store.nightEndMin / 60}:${"%02d".format(store.nightEndMin % 60)}")
        lines.add("Night active now: ${store.nightEnabled && Limits.nightActive(Calendar.getInstance(), store.nightStartMin, store.nightEndMin)}")
        for (g in Limits.GROUPS) {
            val used = store.usageFor(g.id)
            // v6.1.7: show the EFFECTIVE (possibly raised) limit, plus
            // the group's own default when it differs, so Diagnostics
            // still tells the whole truth.
            val effMin = Limits.effectiveLimitMinutes(g.limitMinutes, store.limitOverrideMinFor(g.id))
            val defaultNote = if (effMin != g.limitMinutes) " (default ${g.limitMinutes} min)" else ""
            lines.add("Usage ${g.id}: ${used / 60_000} min / $effMin min$defaultNote (${Limits.percent(used, store.effectiveLimitMs(g))}%)")
        }
        lines.add("Custom block: ${store.customBlock.size} apps")
        lines.add("Night allowed: ${store.nightAllowed.size} apps")
        lines.add("Tamper log entries: ${store.tamperLog().lines().count { it.isNotBlank() }}")
        val text = lines.joinToString("\n")
        tv.text = text

        share.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(i, getString(R.string.diag_share)))
        }
    }
}

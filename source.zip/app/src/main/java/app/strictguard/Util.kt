package app.strictguard

import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

object Util {

    fun goHome(context: Context) {
        val i = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(i)
    }

    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(), context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasOverlay(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun isAdminActive(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(context, GuardAdminReceiver::class.java))
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun isNotificationListenerEnabled(context: Context): Boolean {
        val flat = ComponentName(context, QuietListener::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            context.contentResolver, "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(flat)
    }

    /**
     * v6.1.7 hardening — USB debugging (adb) is a classic bypass
     * route (adb shell pm disable/uninstall, adb shell input, …).
     * Reading the system setting needs no special permission.
     */
    fun isAdbEnabled(context: Context): Boolean =
        Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1

    /**
     * v6.1.7 hardening — Android Safe Mode disables all
     * third-party apps, including this one's guard service. There
     * is no way to stop Safe Mode from a normal app; this only lets
     * the guard log, once it is running again, that a window with
     * no enforcement happened.
     */
    fun isSafeMode(context: Context): Boolean = context.packageManager.isSafeMode

    fun isDefaultLauncher(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val role = context.getSystemService(Context.ROLE_SERVICE) as android.app.role.RoleManager
        return role.isRoleHeld(android.app.role.RoleManager.ROLE_HOME)
    }

    /** Packages of the current home/launcher apps — never blocked. */
    fun launcherPackages(context: Context): Set<String> {
        val out = HashSet<String>()
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val pm = context.packageManager
        for (ri in pm.queryIntentActivities(home, PackageManager.MATCH_DEFAULT_ONLY)) {
            out.add(ri.activityInfo.packageName)
        }
        return out
    }

    fun appLabel(context: Context, pkg: String): String {
        return try {
            val ai = context.packageManager.getApplicationInfo(pkg, 0)
            context.packageManager.getApplicationLabel(ai).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    fun openAppSettings(context: Context) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(i)
    }

    fun requestNotificationListenerAccess(context: Context) {
        val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(i)
    }

    fun isQuietListenerEnabled(context: Context): Boolean =
        isNotificationListenerEnabled(context)

    /** True when this package is installed (any version). Never throws. */
    fun isAppInstalled(context: Context, pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * True when this package is a phone app — the default dialer or
     * the in-call UI. During the Study Lock, receiving a phone call
     * is allowed (the timer pauses, it does not reset). The default
     * dialer is read from the system, so it works with whatever
     * dialer the phone uses (XOS dialer, Google Dialer, …).
     */
    fun isPhoneApp(context: Context, pkg: String): Boolean {
        if (pkg == "com.android.incallui" || pkg == "com.android.server.telecom") return true
        return try {
            val tm = context.getSystemService(Context.TELECOM_SERVICE)
                as android.telecom.TelecomManager
            pkg == tm.defaultDialerPackage
        } catch (e: Exception) {
            false
        }
    }
}

package app.strictguard

import java.util.Calendar

/**
 * Pure blocking rules. No Android framework calls here (except Calendar for
 * night-window maths) so this file is fully unit-testable on the JVM.
 *
 * Daily limits (fixed in the app, matching Olivia's v3.7 screenshot):
 *   Facebook 120 min, Chrome 90 min, YouTube 60 min, AI chat 30 min.
 */
object Limits {

    data class Group(val id: String, val packages: Set<String>, val limitMinutes: Int) {
        val limitMs: Long get() = limitMinutes * 60L * 1000L
    }

    val FACEBOOK = Group(
        "facebook",
        setOf(
            "com.facebook.katana", "com.facebook.lite",
            "com.facebook.orca", "com.facebook.pages.app"
        ),
        120
    )

    val CHROME = Group(
        "chrome",
        setOf(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev",
            "com.chrome.canary", "com.microsoft.emmx", "com.opera.browser",
            "com.brave.browser", "org.mozilla.firefox", "com.opera.mini.native"
        ),
        90
    )

    val YOUTUBE = Group(
        "youtube",
        setOf(
            "com.google.android.youtube",
            "com.google.android.apps.youtube.music"
        ),
        60
    )

    val AI = Group(
        "ai",
        setOf(
            "com.openai.chatgpt", "com.anthropic.claude",
            "com.google.android.apps.bard", "com.microsoft.copilot",
            "com.perplexity.app", "ai.character.app"
        ),
        30
    )

    val GROUPS: List<Group> = listOf(FACEBOOK, CHROME, YOUTUBE, AI)

    fun groupFor(pkg: String): Group? = GROUPS.firstOrNull { pkg in it.packages }

    /**
     * v6.1.7 — each group's daily limit may now be RAISED from
     * inside the app (Store.effectiveLimitMs), with a hard ceiling:
     * no group's limit can ever exceed 2 hours (120 minutes), and a
     * group can never be raised below its own default here — only
     * up, and never past the cap. Facebook's default is already the
     * cap (120), so it has no room to raise and gets no override UI.
     * This function is the pure rule both ends go through; the
     * override value itself is read from / written to Store.
     */
    const val MAX_LIMIT_MINUTES: Int = 120

    fun effectiveLimitMinutes(defaultMinutes: Int, overrideMinutes: Int): Int =
        if (overrideMinutes <= defaultMinutes) defaultMinutes
        else overrideMinutes.coerceAtMost(MAX_LIMIT_MINUTES)

    /**
     * v6.1.0 — Claude exemption (Fahim: "I want to use Claude
     * unlimited"). Verified package: com.anthropic.claude — it is in
     * the AI group list above, and Google Play / APK listings confirm
     * that is the official Claude by Anthropic app. Claude is exempt
     * from the AI daily limit (30 min) and the AI break cycle only:
     * its usage is never counted.
     * v6.1.3 — the exemption is now TOTAL: Claude is one of the six
     * always-unlocked apps in [AlwaysAllowed], exempt from Strict
     * Mode and Night Lock too (Fahim reversed his v6.1.0 decision).
     * [isLimitExempt] stays as the usage-counting check; the full
     * exemption lives in AlwaysAllowed and is checked first in
     * BlockDecider.decide(). Claude stays in the AI group so the
     * group still resolves for the other AI apps.
     */
    const val CLAUDE_PACKAGE = "com.anthropic.claude"

    /** True for apps exempt from daily limits and the break cycle. */
    fun isLimitExempt(pkg: String): Boolean = pkg == CLAUDE_PACKAGE

    /**
     * Apps that must stay locked while Strict Mode or Night Lock is active,
     * because they are bypass routes: system settings (force-stop / uninstall
     * / permission revoke), the store and the installer, and clone / parallel
     * / work-profile apps that run a second copy of a blocked app.
     */
    val BUILTIN_STRICT: Set<String> = setOf(
        "com.android.settings",
        "com.android.vending",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.google.android.apps.docs", // Drive can sideload APKs
        "com.lbe.parallel.intl",
        "com.excelliance.dualaid",
        "com.parallel.space.lite",
        "com.oasisfeng.island",
        "com.gspace.android",
        "com.shelter.work",
        "com.dualspace.multispace",
        "com.applisto.appclone",
        "com.cloneapp",
        "com.multi.parallel",
        // v5.2.0 — Infinix XOS sidebar / Smart Panel helpers (verified:
        // "com.transsion.smartpanel" is the XOS Smart Panel in the XDA
        // Infinix debloat list and the Infinix bloatware registry;
        // "com.transsion.XOSLauncher" is the XOS launcher). The
        // Smart Panel is what launches apps as floating windows from
        // the sidebar, so it stays locked during Strict/Night. The
        // real block is still mode-agnostic UsageStats polling — this
        // list is only a second layer.
        "com.transsion.smartpanel",
        "com.transsion.XOSLauncher"
    )

    /** Poll interval of the guard service. */
    const val POLL_MS: Long = 500L

    /**
     * v6.1.4 — faster poll while Strict is on: the Settings block
     * must land in ~250 ms, not ~500 ms. Only Strict uses the fast
     * interval (4 UsageStats queries a second is fine while the
     * user is actively being guarded); everything else stays at
     * 500 ms. The interval is threaded through ALL usage
     * accounting ([UsageTracker.tick], [GuardService] addUsage /
     * session / break / study ticks) as the per-tick milliseconds,
     * so the faster poll never over-counts usage — a 250 ms tick
     * adds 250 ms, never 500 ms.
     */
    const val FAST_POLL_MS: Long = 250L

    /** Poll interval for this tick: fast while Strict is on. */
    fun pollIntervalMs(strictActive: Boolean): Long =
        if (strictActive) FAST_POLL_MS else POLL_MS

    /**
     * v5.2.1 — the lock-during-Strict rule, as pure logic: settings
     * (including the in-app Device Admin control) may only be changed
     * while Strict Mode is NOT active. Store.settingsLocked() is the
     * negation of this.
     */
    fun settingsChangeAllowed(strictActive: Boolean): Boolean = !strictActive

    /** Night Lock default window: 00:00 - 06:00. */
    const val NIGHT_DEFAULT_START_MIN: Int = 0
    const val NIGHT_DEFAULT_END_MIN: Int = 6 * 60

    fun nightActive(now: Calendar, startMin: Int, endMin: Int): Boolean {
        val m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        return if (startMin <= endMin) m in startMin until endMin
        else m >= startMin || m < endMin
    }

    fun strictActive(nowElapsedRealtime: Long, strictEndElapsed: Long): Boolean =
        strictEndElapsed > 0L && nowElapsedRealtime < strictEndElapsed

    // ---- v5.2.0 Strict schedule (pure, unit-testable) ----
    // Strict can now end at a wall-clock time the user picks: until
    // midnight, after N days, or at a chosen date + time. The end is
    // stored as wall-clock epoch millis so it survives a reboot; while
    // the phone is running, the elapsedRealtime end (derived from the
    // wall end) still governs, so changing the wall clock alone cannot
    // end Strict early. After a reboot the elapsed end is recomputed
    // from the wall end (see Store.recoverStrictAfterBoot).
    // v6.1.0: raised from 365 to 1095 days (3 years). The old 30-day
    // cap was v3.7's; the v6 base already allowed 365, and Fahim
    // asked to set Strict longer still. The mirror (StrictMirror)
    // stores the end as epoch millis, so a 3-year end needs no
    // extra work — verified by a mirror round-trip test.
    const val MAX_STRICT_DAYS: Int = 1095
    const val DAY_MS: Long = 24L * 60L * 60L * 1000L

    fun validScheduleDays(days: Int): Boolean = days in 1..MAX_STRICT_DAYS

    /** Wall-clock end for "Strict for N days from now". -1 if invalid. */
    fun wallEndForDays(nowWallMs: Long, days: Int): Long =
        if (!validScheduleDays(days)) -1L else nowWallMs + days * DAY_MS

    /** Wall-clock end for a chosen date + time (month is 0-based, as in Calendar). */
    fun wallEndForDateTime(year: Int, month0: Int, day: Int, hour: Int, minute: Int): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month0)
            set(Calendar.DAY_OF_MONTH, day)
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    /** A chosen end must be at least 1 minute ahead and at most 1095 days ahead. */
    fun validScheduleDateTime(wallEndMs: Long, nowWallMs: Long): Boolean =
        wallEndMs > nowWallMs + 60_000L && wallEndMs <= nowWallMs + MAX_STRICT_DAYS * DAY_MS

    fun strictWallActive(nowWallMs: Long, wallEndMs: Long): Boolean =
        wallEndMs > 0L && nowWallMs < wallEndMs

    /**
     * ElapsedRealtime end recomputed from the wall-clock end after a
     * reboot. Returns 0 when the wall end has already passed.
     */
    fun recoveredElapsedEnd(nowElapsedMs: Long, nowWallMs: Long, wallEndMs: Long): Long =
        if (!strictWallActive(nowWallMs, wallEndMs)) 0L
        else nowElapsedMs + (wallEndMs - nowWallMs)

    /** Milliseconds from now until the next local midnight. */
    fun msUntilMidnight(now: Calendar): Long {
        val midnight = (now.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return midnight.timeInMillis - now.timeInMillis
    }

    /** "2 hours 30 minutes" style text, in the given locale's words/digits. */
    fun formatDuration(ms: Long, bengaliDigits: Boolean): String {
        val totalMinutes = (ms / 60_000L).toInt()
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return if (bengaliDigits) {
            val hs = toBengaliDigits("$h")
            val ms2 = toBengaliDigits("$m")
            when {
                h > 0 && m > 0 -> "$hs ঘণ্টা $ms2 মিনিট"
                h > 0 -> "$hs ঘণ্টা"
                else -> "$ms2 মিনিট"
            }
        } else {
            when {
                h > 0 && m > 0 -> "$h h $m min"
                h > 0 -> "$h h"
                else -> "$m min"
            }
        }
    }

    private val LATIN = "0123456789".toCharArray()
    private val BENGALI = "০১২৩৪৫৬৭৮৯".toCharArray()

    fun toBengaliDigits(s: String): String {
        val out = StringBuilder(s.length)
        for (c in s) {
            val i = LATIN.indexOf(c)
            out.append(if (i >= 0) BENGALI[i] else c)
        }
        return out.toString()
    }

    fun percent(usedMs: Long, limitMs: Long): Int =
        if (limitMs <= 0L) 0 else ((usedMs * 100L) / limitMs).toInt().coerceIn(0, 100)
}

/**
 * v6.1.0 — Break Cycle (বিরতি সাইকেল). Pure logic, fully unit-testable.
 *
 * Daily limits stay exactly as before and are NOT changeable in the
 * app (Facebook 120, Chrome 90, YouTube 60, AI 30 minutes). On top
 * of the daily limit, each group has a forced break cycle: use for
 * one session, then a forced 20-minute break, then use again,
 * repeating until the daily total is used up.
 *
 * Session quotas (Fahim's numbers for Facebook/YouTube; Chrome/AI
 * generalise the same rule — session = half the daily limit, break
 * always 20 minutes):
 *   Facebook 40 min use / 20 min break (40/20/40/20/40 = 120 total)
 *   YouTube  30 min use / 20 min break (30/20/30 = 60 total)
 *   Chrome   45 min use / 20 min break (45/20/45 = 90 total)
 *   AI chat  15 min use / 20 min break (15/20/15 = 30 total)
 *
 * Rules: session usage accumulates across app opens within the same
 * day — closing the app early does NOT reset the session. When a
 * session quota is reached the app is blocked for a full 20-minute
 * wall-clock break; the break cannot be skipped by reopening the
 * app and it survives reboot (breakUntil is a wall-clock epoch,
 * persisted). Break time does NOT count toward the daily limit.
 * When the daily limit is reached, the app stays blocked for the
 * rest of the day (LIMIT wins over BREAK).
 */
object BreakCycle {

    const val BREAK_MINUTES: Int = 20
    const val BREAK_MS: Long = 20L * 60L * 1000L

    fun sessionQuotaMs(groupId: String): Long = when (groupId) {
        "facebook" -> 40L * 60L * 1000L
        "youtube" -> 30L * 60L * 1000L
        "chrome" -> 45L * 60L * 1000L
        "ai" -> 15L * 60L * 1000L
        else -> Long.MAX_VALUE
    }

    fun isInBreak(breakUntilMs: Long, nowWallMs: Long): Boolean =
        breakUntilMs > 0L && nowWallMs < breakUntilMs

    fun breakRemainingMs(breakUntilMs: Long, nowWallMs: Long): Long =
        (breakUntilMs - nowWallMs).coerceAtLeast(0L)

    /**
     * Outcome of one foreground-use tick for a group.
     * @param sessionUsedMs session usage so far today (before this tick)
     * @param tickMs usage added by this tick (usually the 500 ms poll)
     * @param dailyUsedMs daily total AFTER this tick's usage was added
     * @param limitMs the group's daily limit
     * @param breakUntilMs current break end (wall clock), 0 if none
     */
    data class TickOutcome(
        val sessionUsedMs: Long,
        val breakUntilMs: Long,
        val breakStarted: Boolean
    )

    fun onUseTick(
        groupId: String,
        sessionUsedMs: Long,
        tickMs: Long,
        dailyUsedMs: Long,
        limitMs: Long,
        breakUntilMs: Long,
        nowWallMs: Long
    ): TickOutcome {
        if (isInBreak(breakUntilMs, nowWallMs)) {
            // In a break: no usage may accumulate.
            return TickOutcome(sessionUsedMs, breakUntilMs, false)
        }
        val sessionAfter = sessionUsedMs + tickMs
        // Daily limit reached at the same moment: LIMIT wins, no break.
        if (dailyUsedMs >= limitMs) {
            return TickOutcome(sessionAfter, 0L, false)
        }
        if (sessionAfter >= sessionQuotaMs(groupId)) {
            return TickOutcome(0L, nowWallMs + BREAK_MS, true)
        }
        return TickOutcome(sessionAfter, 0L, false)
    }
}
/**
 * Accumulates daily usage. THE critical rule (learned from v4's bug):
 * [tick] is called on EVERY poll with the currently-foreground group,
 * and it adds [Limits.POLL_MS] for that group each time — even when the
 * foreground app has not changed. Continuous use in one app therefore
 * reaches its limit and triggers a block mid-session.
 *
 * Returns the group id whose limit was reached by this tick, or null.
 */
class UsageTracker(private val pollMs: Long = Limits.POLL_MS) {

    private val usedMs = HashMap<String, Long>()
    private var day: String = ""

    /**
     * @param tickMs milliseconds this tick actually covers (v6.1.4:
     *   the poll interval is 250 ms while Strict is on, 500 ms
     *   otherwise — the caller passes it, so a fast tick adds
     *   250 ms, never 500 ms). Defaults to the construction
     *   interval for the older call sites.
     * @param limitMsOverride v6.1.7 — the group's EFFECTIVE limit
     *   (Store.effectiveLimitMs), when the caller has one to pass.
     *   Null (every pre-v6.1.7 call site) keeps using the group's
     *   own fixed [Limits.Group.limitMs], exactly as before.
     */
    fun tick(
        groupId: String?,
        today: String,
        tickMs: Long = pollMs,
        limitMsOverride: Long? = null
    ): String? {
        if (today != day) {
            day = today
            usedMs.clear()
        }
        if (groupId == null) return null
        val group = Limits.GROUPS.firstOrNull { it.id == groupId } ?: return null
        val total = (usedMs[groupId] ?: 0L) + tickMs
        usedMs[groupId] = total
        return if (total >= (limitMsOverride ?: group.limitMs)) groupId else null
    }

    fun used(groupId: String, today: String): Long {
        if (today != day) return 0L
        return usedMs[groupId] ?: 0L
    }

    /** Restore persisted usage (from Store) after a process restart. */
    fun restore(today: String, values: Map<String, Long>) {
        day = today
        usedMs.clear()
        usedMs.putAll(values)
    }

    fun snapshot(): Map<String, Long> = HashMap(usedMs)
}

package app.strictguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Fires the Friday 09:00 prayer alarm. Marks the day as rung
 * (shared with the guard-poll fallback, so the alarm never rings
 * twice), shows the alarm as a high-priority notification with a
 * full-screen intent ([PrayerAlarmActivity] — alarm sound +
 * vibration + dismiss), and schedules next Friday's alarm.
 * Never throws.
 */
class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            val store = Store(context)
            if (!store.fridayAlarmEnabled) return
            val today = FridayPrayer.dayKey(System.currentTimeMillis())
            if (store.fridayLastRungDay == today) return
            store.fridayLastRungDay = today
            showAlarm(context)
            PrayerAlarmScheduler.scheduleNext(context)
        } catch (e: Exception) {
            try {
                PrayerAlarmScheduler.scheduleNext(context)
            } catch (e2: Exception) {
            }
        }
    }

    /** Shared by the receiver and the guard-poll fallback. */
    fun showAlarm(context: Context) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val ch = NotificationChannel(
                    GuardService.PRAYER_CHANNEL_ID,
                    context.getString(R.string.friday_alarm_title),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    enableVibration(true)
                    setSound(
                        android.media.RingtoneManager.getDefaultUri(
                            android.media.RingtoneManager.TYPE_ALARM
                        ),
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                            .build()
                    )
                }
                nm.createNotificationChannel(ch)
            }
            val open = Intent(context, PrayerAlarmActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pi = PendingIntent.getActivity(
                context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(context, GuardService.PRAYER_CHANNEL_ID)
                .setContentTitle(context.getString(R.string.friday_alarm_title))
                .setContentText(context.getString(R.string.friday_alarm_text))
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .build()
            nm.notify(GuardService.PRAYER_COUNTDOWN_NOTIF_ID, n)
            // Also try to open the alarm screen directly (works when
            // the app is in the foreground; the full-screen intent
            // covers the locked/background case).
            try {
                context.startActivity(open)
            } catch (e: Exception) {
            }
        } catch (e: Exception) {
        }
    }
}

package app.strictguard

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView

/**
 * Base activity: applies the persisted language and theme before the
 * UI is created. Every activity in the app extends this.
 * Pure Android framework only — no AndroidX.
 *
 * Theme default is "system" (follow the device); the toggle on the main
 * screen stores an explicit "light"/"dark" override.
 */
open class BaseActivity : Activity() {

    protected lateinit var store: Store

    /** True when the Store was read successfully. Subclasses use
     *  this instead of `::store.isInitialized` — the backing field
     *  of an inherited lateinit var is not accessible from a
     *  subclass (kotlinc error). */
    protected fun isStoreReady(): Boolean = ::store.isInitialized

    override fun attachBaseContext(newBase: Context) {
        // v6.1.1: on a fresh install no permission/data exists yet,
        // and before unlock the credential-encrypted prefs may be
        // unreadable — a Store() failure here must never kill the
        // launch. Fall back to the un-wrapped base (English).
        var base = newBase
        try {
            base = Lang.wrapContext(newBase, Store(newBase).lang)
        } catch (e: Exception) {
        }
        super.attachBaseContext(base)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // v6.1.1: same rule — if the Store cannot be read yet, the
        // activity still opens (default theme); onResume guards
        // every use of `store` with ::store.isInitialized.
        var theme = "system"
        try {
            store = Store(this)
            theme = store.theme
        } catch (e: Exception) {
        }
        val mask = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        try {
            setTheme(Lang.themeRes(Lang.effectiveTheme(theme, mask)))
        } catch (e: Exception) {
        }
        super.onCreate(savedInstanceState)
    }

    /** Recreate when the guard service flips the theme at 06:00/18:00
     *  while this activity is already open. */
    private val themeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            recreate()
        }
    }

    override fun onResume() {
        super.onResume()
        // v6.1.0 auto theme: evaluate the 06:00/18:00 switch whenever
        // the app resumes, so it applies even if the app was closed
        // at the switch time. A switch here recreates the activity
        // with the new theme; the receiver below covers a switch
        // that happens while the activity is already open.
        if (::store.isInitialized) {
            // v6.1.1: the switch must never crash the resume.
            val switched = StartupGuard.runSafeOr(
                { AutoTheme.maybeApplyAutoTheme(this, store) }, false
            )
            if (switched) {
                StartupGuard.runSafe { recreate() }
                return
            }
        }
        // v6.1.1 — THE v6.1.0 CRASH FIX: the old call was
        //     registerReceiver(themeReceiver, IntentFilter(...))
        // with no export flag. Our action is custom, not a system
        // broadcast, so on targetSdk 34+ (Android 14/15/16) that
        // throws SecurityException on the FIRST resume of the FIRST
        // activity — the app died before Fahim ever saw inside it.
        // StartupGuard registers with RECEIVER_NOT_EXPORTED on
        // API 33+ (and the old call below), and never throws.
        StartupGuard.registerPrivateReceiver(
            this, themeReceiver, IntentFilter(AutoTheme.ACTION_THEME_CHANGED)
        )
    }

    override fun onPause() {
        try {
            unregisterReceiver(themeReceiver)
        } catch (e: Exception) {
            // Receiver was never registered (e.g. recreated in onResume).
        }
        super.onPause()
    }

    /** Effective theme right now ("light" or "dark"). */
    protected fun effectiveTheme(): String {
        val mask = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return Lang.effectiveTheme(store.theme, mask)
    }

    // ---- HSC live countdown ticker (v6.1.0) ----
    // Ticks once per second ONLY while the activity is visible:
    // started by the activity in onResume, stopped in onPause. No
    // background per-second wakeups. The countdown card is the FIRST
    // element at the top of both the main page and the launcher,
    // pinned above the scroll area.
    private val hscHandler = Handler(Looper.getMainLooper())
    private var hscNumbersView: TextView? = null
    private var hscLabelView: TextView? = null
    private var hscMonthsOnly: Boolean = false
    private val hscTicker = object : Runnable {
        override fun run() {
            updateHscCountdown()
            hscHandler.postDelayed(this, 1000L)
        }
    }

    /**
     * Start the 1-second countdown ticker. [numbersView] shows the
     * live "209 days 14 hours 32 minutes 10 seconds" (or the
     * started/ended state); [labelView] is the "HSC পরীক্ষার বাকি"
     * label — pass null on the launcher, where the countdown shows
     * ONLY the numbers, no label at all. [monthsOnly] is true on
     * the launcher: it shows full calendar months + remaining days
     * ("৬ মাস ২৯ দিন") instead of days/hours/minutes/seconds — the
     * value only changes at midnight, so the text is rewritten
     * only when it actually changes (no visible ticking).
     */
    protected fun startHscTicker(numbersView: TextView, labelView: TextView?, monthsOnly: Boolean = false) {
        hscNumbersView = numbersView
        hscLabelView = labelView
        hscMonthsOnly = monthsOnly
        hscHandler.removeCallbacks(hscTicker)
        updateHscCountdown()
        hscHandler.postDelayed(hscTicker, 1000L)
    }

    protected fun stopHscTicker() {
        hscHandler.removeCallbacks(hscTicker)
        hscNumbersView = null
        hscLabelView = null
        hscMonthsOnly = false
    }

    private fun updateHscCountdown() {
        val numbers = hscNumbersView ?: return
        if (!::store.isInitialized) return
        val bn = Lang.isBengali(store.lang)
        when (val state = HscCountdown.state(System.currentTimeMillis(), store.hscExamMs)) {
            is HscCountdown.State.Counting -> {
                hscLabelView?.visibility = android.view.View.VISIBLE
                val text = if (hscMonthsOnly) {
                    // Launcher: months + remaining days, numbers only.
                    val md = HscCountdown.monthsAndDays(System.currentTimeMillis(), store.hscExamMs)
                    formatMonthsText(md.months, md.days, bn)
                } else {
                    val parts = state.parts
                    if (bn) {
                        Limits.toBengaliDigits(
                            "${parts.days} দিন ${parts.hours} ঘণ্টা ${parts.minutes} মিনিট ${parts.seconds} সেকেন্ড"
                        )
                    } else {
                        "${parts.days} days ${parts.hours} hours ${parts.minutes} minutes ${parts.seconds} seconds"
                    }
                }
                // In months mode the value only changes at midnight:
                // rewrite only when it changed, so nothing ticks.
                if (!hscMonthsOnly || numbers.text.toString() != text) {
                    numbers.text = text
                }
            }
            HscCountdown.State.Started -> {
                hscLabelView?.visibility = android.view.View.GONE
                numbers.text = getString(R.string.hsc_started)
            }
            HscCountdown.State.Ended -> {
                hscLabelView?.visibility = android.view.View.GONE
                numbers.text = getString(R.string.hsc_ended)
            }
        }
    }

    /** "6 months 29 days" / "৬ মাস ২৯ দিন" (zero parts omitted). */
    private fun formatMonthsText(months: Long, days: Long, bengali: Boolean): String {
        val mWord = if (bengali) "মাস" else "months"
        val dWord = if (bengali) "দিন" else "days"
        val raw = when {
            months > 0 && days > 0 -> "$months $mWord $days $dWord"
            months > 0 -> "$months $mWord"
            else -> "$days $dWord"
        }
        return if (bengali) Limits.toBengaliDigits(raw) else raw
    }

    /**
     * Daily "one day less" popup: if a day-less event is pending
     * and it has not been shown today, open the full-screen alert
     * activity (dismiss with "বুঝেছি"). Called by the launcher and
     * the main page on resume — the home screen is what he sees on
     * unlock. The activity itself clears the pending flag, so it
     * shows once per day however often the activities resume.
     */
    protected fun maybeShowDayLessAlert() {
        if (!::store.isInitialized) return
        if (!store.hscDayLessEnabled) return
        val today = HscCountdown.dayKey(System.currentTimeMillis())
        if (!HscCountdown.shouldShowDayLessPopup(
                store.hscDayLessPending, store.hscDayLessPopupDay == today
            )
        ) return
        try {
            startActivity(Intent(this, DayLessAlertActivity::class.java))
        } catch (e: Exception) {
        }
    }
}

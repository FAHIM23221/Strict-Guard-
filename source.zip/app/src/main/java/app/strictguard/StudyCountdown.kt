package app.strictguard

/**
 * v6.1.3 — Circular study countdown (Fahim, 2026-11-09).
 *
 * During the Nightly Study Lock's 15 fair minutes in eTestPaper,
 * a small circular countdown runs at the top of the screen,
 * counting down the remaining study time until 15:00 is done.
 * Pure logic — the overlay window itself lives in GuardService;
 * this object is the state machine the service drives every tick,
 * fully unit-testable.
 *
 * PAUSE RULES (same fairness rules as StudyLock.onTick):
 * - Screen off / keyguard / phone call / system UI: PAUSED, kept.
 * - eTestPaper leaves the foreground for any other app: the
 *   countdown HIDE — the timer itself resets to zero (StudyLock
 *   Mode.LEFT), so there is nothing to show until he returns.
 * - IDLE: the countdown PAUSES when the user is idle.
 *
 * HONEST LIMIT — what "idle" means here, stated plainly:
 * WITHOUT an Accessibility Service the guard CANNOT observe
 * touches, scrolls or taps inside another app (eTestPaper).
 * There is no API that tells us the eTestPaper screen "stays
 * still". So idle is defined through the attention check that
 * already exists: midway through the 15 minutes (~7:30) an
 * "আমি পড়ছি" prompt appears, and it must be tapped within
 * 60 seconds. The circular countdown overlay itself is tappable
 * — tapping the circle IS that confirmation (and it resumes a
 * paused countdown). If the prompt stays untapped for over
 * 60 seconds, the countdown is idle-paused and stays paused
 * until the circle is tapped. That is the closest honest
 * approximation of "screen still" without Accessibility, and
 * the build report says so — this file never claims true
 * touch detection inside eTestPaper.
 *
 * The overlay must never block eTestPaper's own touches: it is
 * a small view at the top only, FLAG_NOT_TOUCH_MODAL, so touches
 * outside the circle pass straight through to the app below.
 * It disappears when the 15 minutes complete or the lock ends.
 */
object StudyCountdown {

    /** What the circle shows on this tick. */
    enum class State {
        /** Do not show the circle at all. */
        HIDDEN,
        /** Counting down — ring filling, time ticking. */
        RUNNING,
        /** Shown but frozen — dimmed, with a pause mark. */
        PAUSED
    }

    /** Milliseconds of study time left, from accumulated time. */
    fun remainingMs(accumulatedMs: Long): Long =
        (StudyLock.DURATION_MS - accumulatedMs).coerceAtLeast(0L)

    /** Ring fill 0.0 (just started) to 1.0 (15:00 done). */
    fun progressFraction(accumulatedMs: Long): Float =
        (accumulatedMs.toFloat() / StudyLock.DURATION_MS.toFloat())
            .coerceIn(0f, 1f)

    /** Ring progress in whole seconds (max 900) for a ProgressBar. */
    fun progressSeconds(accumulatedMs: Long): Int =
        (accumulatedMs / 1000L).toInt().coerceIn(0, 900)

    /** "15:00", "07:32", "00:00" — seconds round UP so the full
     *  15:00 shows at the start and 00:00 only at the end. */
    fun displayText(remainingMs: Long): String {
        val seconds = (remainingMs + 999L) / 1000L
        val m = seconds / 60
        val s = seconds % 60
        return "%02d:%02d".format(m, s)
    }

    /**
     * True when the countdown is idle-paused: the attention prompt
     * has been untapped for more than the 60-second timeout.
     * [attentionSinceMs] is 0 when no prompt is pending.
     */
    fun isIdlePaused(
        attentionSinceMs: Long,
        nowWallMs: Long
    ): Boolean =
        attentionSinceMs != 0L &&
            nowWallMs - attentionSinceMs > StudyLock.ATTENTION_TIMEOUT_MS

    /**
     * The circle's state for one tick.
     *
     * @param studyActive a Study Lock is running tonight
     * @param studyMissing the study app is not installed
     * @param mode this tick's StudyLock mode (STUDYING / PAUSED / LEFT)
     * @param attentionOverdue [isIdlePaused] for this tick
     */
    fun state(
        studyActive: Boolean,
        studyMissing: Boolean,
        mode: StudyLock.Mode,
        attentionOverdue: Boolean
    ): State {
        if (!studyActive || studyMissing) return State.HIDDEN
        if (mode == StudyLock.Mode.LEFT) return State.HIDDEN
        if (mode != StudyLock.Mode.STUDYING || attentionOverdue) {
            return State.PAUSED
        }
        return State.RUNNING
    }
}

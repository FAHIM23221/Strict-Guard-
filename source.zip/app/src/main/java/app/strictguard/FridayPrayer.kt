package app.strictguard

import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * Friday prayer alarm + Jumu'ah countdown alerts (v6.1.0).
 *
 * Friday ONLY — never daily.
 *
 * 1. 09:00 alarm: every Friday at 09:00 an alarm preset in the
 *    backend rings ONCE automatically — alarm sound + vibration +
 *    full-screen dismiss ([PrayerAlarmActivity]). Scheduled with
 *    AlarmManager (exact when permitted, inexact fallback) and
 *    re-scheduled on boot; the guard poll is a second fallback, so
 *    the alarm still rings if exact alarms are revoked. A single
 *    persisted "last rung day" is shared by both paths, so the alarm
 *    never rings twice on the same Friday.
 * 2. Jumu'ah countdown alerts (13:00 prayer) — the earlier hourly
 *    10:00–19:00 "নামাজের সময় হয়ে গেছে" plan was CANCELLED by
 *    Fahim (2026-11-08 ~18:28). Only these five, then STOP — no
 *    alerts after the prayer starts:
 *      10:00 "আর ৩ ঘণ্টা বাকি"      (3 hours left)
 *      11:00 "আর ২ ঘণ্টা বাকি"      (2 hours left)
 *      12:00 "আর ১ ঘণ্টা বাকি"      (1 hour left)
 *      12:30 "আর ৩০ মিনিট বাকি"     (30 minutes left)
 *      13:00 "জুম্মার নামাজের সময় হয়ে গেছে" (time for Jumu'ah)
 *    Sent from the guard poll (no extra wakeups); each fires once
 *    per Friday, tracked by a persisted "last alert" key.
 *
 * Toggleable (default ON), locked during Strict like other
 * settings. Survives reboot (alarm re-scheduled on boot; alert
 * state is persisted). Exact-alarm permission with fallback (see
 * [PrayerAlarmScheduler]).
 *
 * Pure logic — fully unit-testable; the AlarmManager scheduling,
 * the receiver and the alarm activity are Android code.
 */
object FridayPrayer {

    const val ZONE_ID: String = "Asia/Dhaka"

    /** The Friday alarm rings at 09:00 Dhaka. */
    const val ALARM_HOUR: Int = 9

    /** Jumu'ah prayer: 13:00 (1 PM) Dhaka. */
    const val PRAYER_HOUR: Int = 13

    /** Countdown alert slots for the 13:00 prayer: (hour, minute, key). */
    val COUNTDOWN_SLOTS: List<Triple<Int, Int, String>> = listOf(
        Triple(10, 0, "10:00"),
        Triple(11, 0, "11:00"),
        Triple(12, 0, "12:00"),
        Triple(12, 30, "12:30"),
        Triple(13, 0, "13:00")
    )

    /** Calendar day ("yyyy-MM-dd") in Asia/Dhaka. */
    fun dayKey(nowWallMs: Long): String =
        ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID))
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))

    fun isFriday(nowWallMs: Long): Boolean =
        ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID))
            .dayOfWeek == DayOfWeek.FRIDAY

    /** Next Friday 09:00 Dhaka (today 09:00 if it is Friday and before 09:00). */
    fun nextFriday0900(nowWallMs: Long): Long {
        var day = ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID))
        while (day.dayOfWeek != DayOfWeek.FRIDAY) day = day.plusDays(1)
        var at0900 = day.withHour(ALARM_HOUR).withMinute(0).withSecond(0).withNano(0)
        if (at0900.toInstant().toEpochMilli() <= nowWallMs) at0900 = at0900.plusDays(7)
        return at0900.toInstant().toEpochMilli()
    }

    /**
     * The 09:00 alarm should ring now (guard-poll fallback path):
     * it is Friday, it is 09:00 or later, and it has not rung today.
     * The AlarmManager path uses the same persisted day flag, so
     * the two paths can never double-ring.
     */
    fun shouldRingAlarm(nowWallMs: Long, enabled: Boolean, lastRungDayKey: String): Boolean {
        if (!enabled || !isFriday(nowWallMs)) return false
        val dt = ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID))
        if (dt.hour < ALARM_HOUR) return false
        return dayKey(nowWallMs) != lastRungDayKey
    }

    /**
     * Which Jumu'ah countdown alert is due now, if any: the
     * earliest slot whose time has passed today and which has not
     * been sent yet. [lastSentKey] is "yyyy-MM-dd|HH:mm" of the last
     * alert sent, "" if none — only ONE key is stored, so a slot
     * counts as sent when it is at or before the last sent slot's
     * time on the same day (slots always fire in order). Returns
     * the slot key ("10:00" …), or null. Only one alert per poll
     * tick — the next slot fires on the next tick at the earliest
     * (they are an hour apart, so this never delays one). After
     * the 13:00 alert every slot is at or before the last sent
     * one, so nothing fires again — the alerts STOP.
     */
    fun dueCountdownAlert(
        nowWallMs: Long,
        enabled: Boolean,
        lastSentKey: String
    ): String? {
        if (!enabled || !isFriday(nowWallMs)) return null
        val today = dayKey(nowWallMs)
        val dt = ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowWallMs), ZoneId.of(ZONE_ID))
        val nowMin = dt.hour * 60 + dt.minute
        // Minutes of the last slot sent today (-1 = none yet).
        // A stale key from another day does not count.
        val lastMin = if (lastSentKey.startsWith("$today|")) {
            val hm = lastSentKey.substringAfter("|").split(":")
            val h = hm.getOrNull(0)?.toIntOrNull()
            val m = hm.getOrNull(1)?.toIntOrNull()
            if (h != null && m != null) h * 60 + m else -1
        } else {
            -1
        }
        for ((hour, minute, key) in COUNTDOWN_SLOTS) {
            val slotMin = hour * 60 + minute
            if (slotMin <= lastMin) continue // already sent today
            if (nowMin < slotMin) continue
            return key
        }
        return null
    }

    /** Use an exact alarm only when the system permits it; otherwise fall back. */
    fun useExactAlarm(canScheduleExactAlarms: Boolean): Boolean = canScheduleExactAlarms
}

package app.strictguard

import android.os.Bundle
import android.widget.Button
import android.widget.TextView

/** Full-screen blocked screen. Back press goes home — no way back into the app. */
class BlockActivity : BaseActivity() {

    companion object {
        const val EXTRA_PKG = "pkg"
        const val EXTRA_KIND = "kind"
        const val EXTRA_GROUP = "group"
        const val EXTRA_BREAK_UNTIL = "break_until"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_block)

        val pkg = intent.getStringExtra(EXTRA_PKG) ?: ""
        val kind = intent.getStringExtra(EXTRA_KIND) ?: ""
        val label = Util.appLabel(this, pkg)
        findViewById<TextView>(R.id.blockedApp).text = label
        val reason = when (kind) {
            BlockDecider.Kind.LIMIT.name -> getString(R.string.blocked_limit)
            BlockDecider.Kind.STRICT_BYPASS.name -> getString(R.string.blocked_bypass)
            BlockDecider.Kind.STRICT_GROUP.name -> getString(R.string.blocked_strict)
            BlockDecider.Kind.CUSTOM.name -> getString(R.string.blocked_custom)
            BlockDecider.Kind.NIGHT.name -> getString(R.string.blocked_night)
            // v6.1.0: a break block is a different reason from a
            // daily-limit block — show the live countdown so the user
            // knows exactly when the app opens again.
            BlockDecider.Kind.BREAK.name -> {
                val until = intent.getLongExtra(EXTRA_BREAK_UNTIL, 0L)
                val remaining = BreakCycle.breakRemainingMs(
                    until, System.currentTimeMillis()
                )
                getString(R.string.blocked_break) + "\n" + getString(
                    R.string.break_remaining,
                    Limits.formatDuration(remaining, Lang.isBengali(store.lang))
                )
            }
            // v6.1.0 self-block: Strict Guard itself, during Strict.
            BlockDecider.Kind.SELF_BLOCK.name -> getString(R.string.blocked_self)
            // v6.1.0 Study Lock: everything else is blocked while studying.
            BlockDecider.Kind.STUDY.name -> getString(R.string.blocked_study)
            else -> getString(R.string.blocked_strict)
        }
        findViewById<TextView>(R.id.blockedReason).text = reason
        findViewById<Button>(R.id.btnGoHome).setOnClickListener { goHomeAndFinish() }
    }

    override fun onBackPressed() {
        goHomeAndFinish()
    }

    private fun goHomeAndFinish() {
        Util.goHome(this)
        finish()
    }
}

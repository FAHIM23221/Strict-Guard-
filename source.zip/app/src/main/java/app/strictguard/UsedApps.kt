package app.strictguard

/**
 * Hide Unused Apps in the launcher (v6.1.0).
 *
 * Strict Guard already has Usage Access, so the launcher can see
 * which apps are actually used. When the "Show only used apps"
 * toggle is ON, the grid shows only apps with foreground use in the
 * last 30 days (from UsageStats) plus Strict Guard itself, pinned
 * first. Newly installed apps get a 7-day grace period (shown until
 * classified). Apps with no foreground use in the last 30 days (or
 * never used) are hidden from the grid.
 *
 * Hiding is ONLY a launcher display filter — never an uninstall or
 * a block. Hidden apps are not blocked, just not shown while the
 * toggle is ON. Nothing becomes unreachable: the grid gets a
 * "Hidden apps (n)" row that opens the full list, and turning the
 * toggle OFF restores the full grid immediately (the filter is
 * applied fresh on every launcher resume, so there is no state to
 * undo). Pure logic — fully unit-testable; the UsageStats queries
 * live in [LauncherActivity].
 */
object UsedApps {

    /** An app counts as used if it was in the foreground this recently. */
    const val USED_WINDOW_MS: Long = 30L * 24L * 60L * 60L * 1000L

    /** A newly installed app is shown for this long, even if unused. */
    const val GRACE_MS: Long = 7L * 24L * 60L * 60L * 1000L

    /**
     * True when this app should be shown while the filter is ON.
     *
     * @param pkg the app's package
     * @param lastUsedMs wall-clock millis of its last foreground use,
     *   0 = never used (or unknown)
     * @param installedMs wall-clock millis it was installed
     *   (firstInstallTime), 0 = unknown
     * @param nowWallMs current wall-clock time
     * @param ownPackage Strict Guard's own package — always shown
     */
    fun isShown(
        pkg: String,
        lastUsedMs: Long,
        installedMs: Long,
        nowWallMs: Long,
        ownPackage: String
    ): Boolean {
        // Strict Guard itself is always shown, pinned first.
        if (pkg == ownPackage) return true
        // Used in the last 30 days (boundary inclusive).
        if (lastUsedMs > 0 && nowWallMs - lastUsedMs <= USED_WINDOW_MS) return true
        // Newly installed: 7-day grace period, even if never used.
        if (installedMs > 0 && nowWallMs - installedMs <= GRACE_MS) return true
        return false
    }

    /**
     * Split the grid into (shown, hidden). When the filter is OFF,
     * everything is shown and nothing is hidden — that is what makes
     * the toggle fully reversible: turning it OFF restores the full
     * grid immediately, with no restart and no state to undo.
     */
    fun filterApps(
        apps: List<LauncherLogic.AppEntry>,
        lastUsedByPkg: Map<String, Long>,
        installedByPkg: Map<String, Long>,
        nowWallMs: Long,
        ownPackage: String,
        enabled: Boolean
    ): Pair<List<LauncherLogic.AppEntry>, List<LauncherLogic.AppEntry>> {
        if (!enabled) return Pair(apps, emptyList())
        val shown = ArrayList<LauncherLogic.AppEntry>()
        val hidden = ArrayList<LauncherLogic.AppEntry>()
        for (app in apps) {
            if (isShown(
                    app.pkg,
                    lastUsedByPkg[app.pkg] ?: 0L,
                    installedByPkg[app.pkg] ?: 0L,
                    nowWallMs, ownPackage
                )
            ) {
                shown.add(app)
            } else {
                hidden.add(app)
            }
        }
        return Pair(shown, hidden)
    }
}

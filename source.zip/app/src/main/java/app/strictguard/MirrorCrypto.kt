package app.strictguard

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encryption for the Strict-state mirror ([StrictMirror]).
 *
 * Two keys in the Android Keystore (hardware-backed where the phone
 * supports it):
 * - AES/GCM 256-bit for confidentiality + authenticity (the GCM tag
 *   already detects tampering),
 * - HmacSHA256 for the explicit HMAC the feature requires.
 *
 * Keystore keys survive Clear Data: they live in the keystore
 * daemon, keyed by the app's UID, not in the app's private data.
 * They are deleted only on uninstall. Keys are created on first
 * use; if the Keystore is unavailable (e.g. direct boot before
 * unlock) every call fails soft (null / false) and the mirror is
 * simply not written — the mirror is a best-effort defence, never
 * a crash.
 *
 * Wire format: [12-byte IV][AES/GCM ciphertext + 16-byte tag]
 * [32-byte HMAC-SHA256 over IV + ciphertext].
 * Decrypt verifies the HMAC first (constant-time compare), then
 * the GCM tag, then returns the plaintext. Any failure returns
 * null — a tampered mirror is never trusted.
 */
interface MirrorCrypto {
    fun encrypt(plain: ByteArray): ByteArray
    fun decrypt(data: ByteArray): ByteArray?
}

class KeystoreMirrorCrypto : MirrorCrypto {

    companion object {
        private const val ENC_ALIAS = "sg_mirror_enc"
        private const val MAC_ALIAS = "sg_mirror_mac"
        private const val IV_LEN = 12
        private const val TAG_LEN_BITS = 128
        private const val HMAC_LEN = 32
    }

    private fun keystore(): KeyStore? = try {
        KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    } catch (e: Exception) {
        null
    }

    private fun encKey(): SecretKey? {
        val ks = keystore() ?: return null
        return try {
            if (ks.containsAlias(ENC_ALIAS)) {
                (ks.getEntry(ENC_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
            } else {
                val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
                gen.init(
                    KeyGenParameterSpec.Builder(
                        ENC_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .setRandomizedEncryptionRequired(true)
                        .setUserAuthenticationRequired(false)
                        .build()
                )
                gen.generateKey()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun macKey(): SecretKey? {
        val ks = keystore() ?: return null
        return try {
            if (ks.containsAlias(MAC_ALIAS)) {
                (ks.getEntry(MAC_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
            } else {
                val gen = KeyGenerator.getInstance("HmacSHA256", "AndroidKeyStore")
                gen.init(
                    KeyGenParameterSpec.Builder(
                        MAC_ALIAS,
                        KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
                    ).build()
                )
                gen.generateKey()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun hmac(key: SecretKey, data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(key)
        return mac.doFinal(data)
    }

    private fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean {
        if (a.size != b.size) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].toInt() xor b[i].toInt())
        return diff == 0
    }

    override fun encrypt(plain: ByteArray): ByteArray {
        val enc = encKey() ?: throw IllegalStateException("no enc key")
        val macK = macKey() ?: throw IllegalStateException("no mac key")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, enc)
        val iv = cipher.iv // 12 random bytes from the GCM cipher
        val ciphertext = cipher.doFinal(plain)
        val body = iv + ciphertext
        return body + hmac(macK, body)
    }

    override fun decrypt(data: ByteArray): ByteArray? {
        return try {
            if (data.size < IV_LEN + HMAC_LEN + 16) return null
            val macK = macKey() ?: return null
            val enc = encKey() ?: return null
            val body = data.copyOfRange(0, data.size - HMAC_LEN)
            val tag = data.copyOfRange(data.size - HMAC_LEN, data.size)
            if (!constantTimeEquals(tag, hmac(macK, body))) return null
            val iv = body.copyOfRange(0, IV_LEN)
            val ciphertext = body.copyOfRange(IV_LEN, body.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, enc, GCMParameterSpec(TAG_LEN_BITS, iv))
            cipher.doFinal(ciphertext)
        } catch (e: Exception) {
            null
        }
    }
}

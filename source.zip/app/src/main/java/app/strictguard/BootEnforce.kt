package app.strictguard

/**
 * v6.1.5 — direct-boot enforcement decisions (pure, unit-tested).
 *
 * THE GAP FAHIM PROVED ON-DEVICE (2026-11-09 ~03:30, Infinix X6886,
 * v6.1.4): he restarted the phone and, DURING the boot loading —
 * while the system was still booting up — opened Settings and
 * turned off Device Admin. The v6.1.4 "faster boot guard" was not
 * fast enough, because the gap was never in the receiver alone.
 * In code order, v6.1.4's boot path was:
 *
 *  1. LOCKED_BOOT_COMPLETED → BootReceiver reads the cheap
 *     device-protected mirror and calls startForegroundService.
 *     That part was fast — but it only STARTED the service.
 *  2. GuardService.onStartCommand: the Store (credential-encrypted
 *     prefs) is unreadable before unlock, so initStore() failed
 *     and onStartCommand returned START_STICKY with NO
 *     startForeground and NO poll loop. The service was alive and
 *     enforcing NOTHING. Worse, a service started via
 *     startForegroundService that never calls startForeground
 *     within the system timeout is killed by Android — so the
 *     direct-boot service was most likely dead by unlock time,
 *     and enforcement had to cold-start after unlock.
 *  3. USER_UNLOCKED → SystemEventsReceiver → startForegroundService.
 *     USER_UNLOCKED is NOT in Android's documented foreground-service
 *     background-start exemption list (BOOT_COMPLETED and
 *     LOCKED_BOOT_COMPLETED are; USER_UNLOCKED is not), so that
 *     start can be refused — the exception was swallowed and
 *     nothing retried until BOOT_COMPLETED, which on XOS can
 *     arrive seconds after the user is already interacting.
 *  4. Even when the start succeeded, onStartCommand ran
 *     MirrorStore.checkAndRestore — a MediaStore query plus a
 *     Keystore key load + HMAC + AES-GCM decrypt, cold after boot —
 *     BEFORE startForeground and the first poll post. v6.1.4 moved
 *     that work out of the *receiver*; it still sat in the
 *     *service* before the first enforcement tick.
 *  5. Only then did the first tick run and the Settings fast path
 *     block anything. A human opening Settings and navigating to
 *     Device Admin takes ~5–10 s; the guard needed longer than
 *     that to become enforcing, so Fahim won.
 *
 * THE FIX (v6.1.5): the service enforces from the device-protected
 * boot mirror ALONE, from LOCKED_BOOT_COMPLETED, with no Store:
 * startForeground immediately (minimal notification), then a
 * 100 ms boot poll that only resolves the foreground and
 * fast-blocks Settings / Phone Master / our own settings. The
 * moment the Store becomes readable the service graduates to the
 * normal path (flushing what boot mode saw into the Tamper Log).
 * On the normal path, startForeground + first poll now come
 * BEFORE the slow mirror restore, which runs on a background
 * thread. The USER_UNLOCKED start is kept as a retry — but
 * enforcement no longer depends on it, because the service is
 * already warm and polling by unlock time.
 *
 * HONEST LIMIT (kept in code so nobody over-claims): no
 * third-party app code can run before LOCKED_BOOT_COMPLETED —
 * Android's own boot up to that point is untouchable, and the
 * user cannot interact with anything then anyway. After the
 * receiver fires, the remaining window is the process start plus
 * one boot poll (100 ms) — well under a second once the system
 * is usable, and a human needs ~5–10 s to reach the Device Admin
 * toggle. It is NOT literally zero: if the system kills the
 * process and cold-starts it at unlock, the first tick can take
 * ~1 s; and if the OEM lets Settings open from the lock-screen
 * shade without unlocking, no app can block that pre-unlock
 * surface (overlays cannot cover the keyguard). What is closed
 * is the window Fahim used: after unlock, Settings is blocked
 * within one poll, before anyone can navigate to Device Admin.
 *
 * v6.1.6 — THE QUICK SETTINGS SHADE (Fahim, 2026-11-09 ~03:51):
 * after a restart, while the home screen was still loading, he
 * pulled the shade down and tapped the gear — Settings opened
 * even though Strict was on. The shade itself cannot be closed
 * by any app: it is SystemUI, above every app window including
 * TYPE_APPLICATION_OVERLAY, and intercepting the gear tap would
 * need Accessibility (forbidden on this phone) or device-owner.
 * The closable point is Settings reaching the foreground — and
 * v6.1.5 had three holes exactly there, all fixed in v6.1.6:
 *  1. `blockBoot()` never showed the full-screen overlay (the
 *     normal path does). Before any activity of ours is visible,
 *     Android can refuse a service's activity start, so a
 *     refused/delayed BlockActivity left NOTHING covering
 *     Settings. The boot block now shows the overlay too — a
 *     window add needs no activity-start exemption, so it covers
 *     Settings the moment the block lands.
 *  2. The launcher/main self-heal ran AFTER the slow mirror
 *     restore (~0.5–3 s, main thread). If the boot service never
 *     started, the guard restarted only after that work, while
 *     the shade was already usable. The guard restart is now
 *     FIRST in both activities, and the mirror restore moved to
 *     a background thread.
 *  3. Boot blocks lived only in memory. They are now also
 *     written to device-protected prefs the moment they happen
 *     ([BootEventLog]), so the Tamper Log entry survives even if
 *     the service dies before graduating.
 * Residual window, stated plainly: the cold process start under
 * boot load (typically 1–3 s after LOCKED_BOOT_COMPLETED) cannot
 * be shortened by the app. The shade gear can be tapped in that
 * window — but the moment the service is up, the next 100 ms
 * boot tick covers Settings with the overlay, and the block is
 * retried every 500 ms while Settings stays in the foreground.
 */
object BootEnforce {

    /**
     * Fastest poll while the service runs on mirror state alone.
     * Shorter than the Strict-on poll (250 ms): boot mode lasts
     * seconds at most, so the extra UsageStats queries are
     * negligible, and the first post-unlock tick is what closes
     * the gap.
     */
    const val BOOT_POLL_MS: Long = 100L

    /**
     * Enforce during direct boot: Strict's wall-clock end is still
     * in the future, or monitoring is wanted. Same decision as
     * [BootRestore.directBootGuardStart] — delegated, not
     * duplicated, so the two boot-start sites can never disagree.
     */
    fun shouldBootEnforce(
        strictWallEndMs: Long,
        nowWallMs: Long,
        serviceWanted: Boolean
    ): Boolean =
        BootRestore.directBootGuardStart(strictWallEndMs, nowWallMs, serviceWanted)

    /**
     * Strict counts as ON in boot mode when the mirror wall end is
     * in the future. The boot-mode fast block uses this as its
     * `strict` flag, so Settings / Phone Master are blocked from
     * the very first boot tick.
     */
    fun bootStrictActive(strictWallEndMs: Long, nowWallMs: Long): Boolean =
        Limits.strictWallActive(nowWallMs, strictWallEndMs)

    /**
     * v6.1.6 — retry interval for a boot-mode block. 500 ms: if
     * the first BlockActivity start was refused (background
     * activity rules, before any activity of ours is visible),
     * the next attempt comes half a second later, not two — the
     * overlay (shown with the block) covers the screen in the
     * meantime. The normal path keeps 2000 ms: its activity start
     * is not refused once the app is visible.
     */
    fun bootBlockRetryMs(bootMode: Boolean): Long =
        if (bootMode) 500L else 2000L

    /**
     * v6.1.6 — the boot-mode block shows the full-screen overlay
     * whenever the overlay permission exists. The overlay is a
     * window add, not an activity start, so it needs no
     * background-activity exemption — it is the cover that works
     * while the BlockActivity start can still be refused. Without
     * the permission there is no overlay to show, and the block
     * screen is the only cover.
     */
    fun shouldShowBootOverlay(hasOverlayPermission: Boolean): Boolean =
        hasOverlayPermission
}

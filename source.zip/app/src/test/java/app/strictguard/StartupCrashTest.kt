package app.strictguard

import android.content.Context
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.1 — first-launch crash fix tests.
 *
 * The v6.1.0 crash: BaseActivity.onResume() called
 * registerReceiver(themeReceiver, IntentFilter(...)) with no export
 * flag. The action is our own custom action, not a system
 * broadcast, so on targetSdk 34+ (Android 14/15/16) the system
 * throws SecurityException on the FIRST resume of the FIRST
 * activity — the app died before Fahim ever saw inside it.
 * These tests pin the fixed registration rule and the defensive
 * startup rule (one failing subsystem must never kill the launch).
 */
class StartupCrashTest {

    // ---- Receiver registration rule (the crash fix) ----

    @Test
    fun `flag overload is used on API 33 and above only`() {
        assertFalse(StartupGuard.useFlagOverload(29))
        assertFalse(StartupGuard.useFlagOverload(32))
        assertTrue(StartupGuard.useFlagOverload(33))
        assertTrue(StartupGuard.useFlagOverload(34))
        assertTrue(StartupGuard.useFlagOverload(35))
        assertTrue(StartupGuard.useFlagOverload(36))
    }

    @Test
    fun `receiver flag is NOT_EXPORTED on API 33+ and null below`() {
        // Below API 33 the 3-arg overload does not exist — calling
        // it there would be a NoSuchMethodError, so no flag.
        assertNull(StartupGuard.receiverFlagForSdk(29))
        assertNull(StartupGuard.receiverFlagForSdk(32))
        assertEquals(Context.RECEIVER_NOT_EXPORTED, StartupGuard.receiverFlagForSdk(33))
        assertEquals(Context.RECEIVER_NOT_EXPORTED, StartupGuard.receiverFlagForSdk(34))
        assertEquals(Context.RECEIVER_NOT_EXPORTED, StartupGuard.receiverFlagForSdk(35))
        assertEquals(Context.RECEIVER_NOT_EXPORTED, StartupGuard.receiverFlagForSdk(36))
    }

    @Test
    fun `receiver is private, never exported`() {
        // Our receiver only ever hears our own app's broadcast
        // (AutoTheme.ACTION_THEME_CHANGED, sent with setPackage),
        // so it must be NOT_EXPORTED — never RECEIVER_EXPORTED.
        for (sdk in 33..36) {
            assertEquals(Context.RECEIVER_NOT_EXPORTED, StartupGuard.receiverFlagForSdk(sdk))
        }
    }

    // ---- Defensive startup: one failing step must not kill the launch ----

    @Test
    fun `runSafe runs the step and returns true`() {
        var ran = false
        assertTrue(StartupGuard.runSafe { ran = true })
        assertTrue(ran)
    }

    @Test
    fun `runSafe swallows the exact Android 14 registerReceiver SecurityException`() {
        val ok = StartupGuard.runSafe {
            throw SecurityException(
                "One of RECEIVER_EXPORTED or RECEIVER_NOT_EXPORTED should be specified " +
                    "when a receiver isn't being registered exclusively for system broadcasts"
            )
        }
        assertFalse(ok)
    }

    @Test
    fun `runSafe swallows RuntimeException and IllegalStateException`() {
        assertFalse(StartupGuard.runSafe { throw RuntimeException("prefs locked") })
        assertFalse(StartupGuard.runSafe { throw IllegalStateException("store not ready") })
        assertFalse(StartupGuard.runSafe { throw NullPointerException("no view yet") })
    }

    @Test
    fun `runSafeOr returns the fallback when the step throws`() {
        val boom: () -> String = { throw RuntimeException("keystore locked") }
        assertEquals("en", StartupGuard.runSafeOr(boom, "en"))
        assertEquals("bn", StartupGuard.runSafeOr({ "bn" }, "en"))
    }

    @Test
    fun `first-launch init survives each subsystem throwing`() {
        // Model of MainActivity/LauncherActivity onResume in v6.1.1:
        // boot recovery, mirror/Keystore, guard start, refresh,
        // countdown ticker and day-less popup are each guarded, so a
        // failure in one must not stop the rest from running.
        val ran = mutableListOf<String>()
        val steps: List<() -> Unit> = listOf(
            { ran.add("recover"); throw RuntimeException("boot") },
            { ran.add("mirror"); throw SecurityException("keystore") },
            { ran.add("guard-start"); throw SecurityException("FGS start refused") },
            { ran.add("refresh") },
            { ran.add("ticker"); throw IllegalStateException("ticker") },
            { ran.add("alert") }
        )
        for (step in steps) StartupGuard.runSafe(step)
        assertEquals(
            listOf("recover", "mirror", "guard-start", "refresh", "ticker", "alert"),
            ran
        )
    }

    @Test
    fun `first-launch init survives every subsystem throwing`() {
        // Even if everything fails, the launch itself must not throw.
        val steps: List<() -> Unit> = listOf(
            { throw RuntimeException("a") },
            { throw SecurityException("b") },
            { throw IllegalStateException("c") }
        )
        for (step in steps) StartupGuard.runSafe(step)
    }

    // ---- Exact alarms: denied permission falls back to inexact ----

    @Test
    fun `exact alarm denied falls back to inexact, granted stays exact`() {
        assertFalse(FridayPrayer.useExactAlarm(false))
        assertTrue(FridayPrayer.useExactAlarm(true))
    }
}

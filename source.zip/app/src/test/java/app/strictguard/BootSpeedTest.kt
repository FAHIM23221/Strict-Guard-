package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.4 — the faster boot guard (Fahim, 2026-11-09).
 *
 * After restart there was a refresh window where Settings could be
 * opened to turn off admin access and uninstall the app. The
 * direct-boot guard (since v6.0.0) already starts before the first
 * unlock — the gap was the BOOT_COMPLETED receiver doing its slow
 * work (Keystore mirror decrypt, alarm scheduling) BEFORE asking
 * for the guard start, on the same main thread the service starts
 * on. Every millisecond there delayed the first enforcement tick
 * by exactly that long.
 *
 * The fix: the receiver now requests the guard start from the
 * cheap device-protected mirror alone
 * ([BootRestore.bootStartDecision]), then does the slow work on a
 * background thread. The USER_UNLOCKED path got the same
 * "enforce first" reorder. These tests pin the decision seam —
 * that the start decision needs ONLY the mirror values (Strict's
 * wall end + whether the guard is wanted) and agrees with the
 * direct-boot decision for the same inputs. The ordering itself
 * (start requested before slow work, slow work off the main
 * thread) is in BootReceiver / SystemEventsReceiver and is
 * verified by inspection of that small, commented code.
 *
 * Honest limit, kept: Android's own boot sequence cannot be
 * shortened by any app — only the guard's own startup path can
 * be made leaner. What this removes is the app's own ~0.1–0.6 s
 * of mirror/alarm work from the critical path.
 */
class BootSpeedTest {

    private val nowWall = 1_792_000_000_000L // fixed "now" (Nov 2026)
    private val futureWall = nowWall + 4 * 60 * 60_000L // Strict ends in 4h
    private val pastWall = nowWall - 60_000L // Strict ended 1 minute ago

    // ---- bootStartDecision: mirror values only, guard starts when Strict is on ----

    @Test
    fun startsWhenStrictWallInFuture() {
        assertTrue(BootRestore.bootStartDecision(futureWall, nowWall, serviceWanted = false))
    }

    @Test
    fun doesNotStartWhenStrictWallPassed() {
        assertFalse(BootRestore.bootStartDecision(pastWall, nowWall, serviceWanted = false))
    }

    @Test
    fun doesNotStartWithNoMirror() {
        assertFalse(BootRestore.bootStartDecision(0L, nowWall, serviceWanted = false))
    }

    @Test
    fun startsWhenServiceWantedEvenIfStrictEnded() {
        assertTrue(BootRestore.bootStartDecision(pastWall, nowWall, serviceWanted = true))
        assertTrue(BootRestore.bootStartDecision(0L, nowWall, serviceWanted = true))
    }

    // ---- The two boot layers agree: same mirror, same decision ----

    @Test
    fun bootDecisionAgreesWithDirectBootDecision() {
        val cases = listOf(
            Triple(futureWall, false, true),
            Triple(pastWall, false, false),
            Triple(0L, false, false),
            Triple(pastWall, true, true),
            Triple(futureWall, true, true)
        )
        for ((wallEnd, wanted, expected) in cases) {
            assertEquals(
                "wallEnd=$wallEnd wanted=$wanted",
                expected,
                BootRestore.bootStartDecision(wallEnd, nowWall, wanted)
            )
            assertEquals(
                "direct boot wallEnd=$wallEnd wanted=$wanted",
                expected,
                BootRestore.directBootGuardStart(wallEnd, nowWall, wanted)
            )
        }
    }
}

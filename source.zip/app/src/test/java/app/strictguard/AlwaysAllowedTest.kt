package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.3 Always-unlocked apps tests — pure logic, no Android framework.
 *
 * Brilliant, bKash, Nagad, Claude, WhatsApp and Messenger have NO
 * rules at all: exempt from Strict Mode, Night Lock, daily limits,
 * break cycle, entry delay, Study Lock and the custom blocklist.
 * Every other app is unchanged (a non-exempt app in the same
 * situations is still blocked).
 */
class AlwaysAllowedTest {

    private val now = 1_700_000_000_000L
    private val six = listOf(
        "org.brilliant.android", // Brilliant
        "com.bKash.customerapp", // bKash (capital K — case-sensitive)
        "com.konasl.nagad", // Nagad
        "com.anthropic.claude", // Claude
        "com.whatsapp", // WhatsApp
        "com.facebook.orca" // Messenger
    )
    private val facebook = "com.facebook.katana"
    private val chatgpt = "com.openai.chatgpt"

    @Test
    fun allSixPackagesAreInTheSet() {
        assertEquals(6, AlwaysAllowed.PACKAGES.size)
        for (pkg in six) assertTrue(pkg, AlwaysAllowed.isAlwaysAllowed(pkg))
    }

    @Test
    fun packageNamesAreCaseSensitive() {
        // The bKash package has a capital K — the lower-case
        // spelling is a different (non-existent) package and must
        // NOT be exempt. Same lesson as the eTestPaper deadlock.
        assertFalse(AlwaysAllowed.isAlwaysAllowed("com.bkash.customerapp"))
        assertFalse(AlwaysAllowed.isAlwaysAllowed("com.nextive.etestpaper"))
    }

    @Test
    fun otherAppsAreNotExempt() {
        assertFalse(AlwaysAllowed.isAlwaysAllowed(facebook))
        assertFalse(AlwaysAllowed.isAlwaysAllowed(chatgpt))
        assertFalse(AlwaysAllowed.isAlwaysAllowed("com.android.settings"))
        assertFalse(AlwaysAllowed.isAlwaysAllowed("com.google.android.youtube"))
        assertFalse(AlwaysAllowed.isAlwaysAllowed("com.zhiliaoapp.musically"))
    }

    @Test
    fun allSixAllowedDuringStrictMode() {
        for (pkg in six) {
            val d = BlockDecider.decide(
                pkg, true, false, emptySet(), setOf(pkg),
                emptySet(), false, "app.strictguard", null
            )
            assertNull("$pkg must open during Strict", d)
        }
        // Control: Facebook is still blocked by Strict.
        val fb = BlockDecider.decide(
            facebook, true, false, emptySet(), emptySet(),
            emptySet(), false, "app.strictguard", null
        )
        assertEquals(BlockDecider.Kind.STRICT_GROUP, fb?.kind)
    }

    @Test
    fun allSixAllowedDuringNightLock() {
        for (pkg in six) {
            val d = BlockDecider.decide(
                pkg, false, true, emptySet(), emptySet(),
                emptySet(), false, "app.strictguard", null
            )
            assertNull("$pkg must open during Night Lock", d)
        }
        val fb = BlockDecider.decide(
            facebook, false, true, emptySet(), emptySet(),
            emptySet(), false, "app.strictguard", null
        )
        assertEquals(BlockDecider.Kind.NIGHT, fb?.kind)
    }

    @Test
    fun allSixAllowedDuringStudyLock() {
        for (pkg in six) {
            // Study Lock active, app installed (studyMissing false).
            val d = BlockDecider.decide(
                pkg, false, false, emptySet(), emptySet(),
                emptySet(), false, "app.strictguard", null,
                true, emptyMap(), now, true, false,
                StudyLock.STUDY_APP_PACKAGE, false
            )
            assertNull("$pkg must open during Study Lock", d)
            assertNull(
                BlockDecider.decideStudy(pkg, true, false, StudyLock.STUDY_APP_PACKAGE, false)
            )
        }
        val fb = BlockDecider.decide(
            facebook, false, false, emptySet(), emptySet(),
            emptySet(), false, "app.strictguard", null,
            true, emptyMap(), now, true, false,
            StudyLock.STUDY_APP_PACKAGE, false
        )
        assertEquals(BlockDecider.Kind.STUDY, fb?.kind)
    }

    @Test
    fun messengerAllowedAfterFacebookLimitReached() {
        // Messenger is in the Facebook group — without the exemption
        // its use would count toward Facebook's 120-minute limit and
        // the used-up limit would block it. The exemption wins.
        val d = BlockDecider.decide(
            "com.facebook.orca", false, false, emptySet(), emptySet(),
            setOf("facebook"), false, "app.strictguard", null
        )
        assertNull(d)
        val fb = BlockDecider.decide(
            facebook, false, false, emptySet(), emptySet(),
            setOf("facebook"), false, "app.strictguard", null
        )
        assertEquals(BlockDecider.Kind.LIMIT, fb?.kind)
    }

    @Test
    fun allSixAllowedDuringBreakAndInCustomList() {
        val until = now + 20L * 60_000L
        for (pkg in six) {
            val d = BlockDecider.decide(
                pkg, true, true, emptySet(), setOf(pkg),
                setOf("facebook", "ai"), false, "app.strictguard", null,
                true, mapOf("facebook" to until, "ai" to until), now,
                true, false, StudyLock.STUDY_APP_PACKAGE, false
            )
            assertNull("$pkg must open under every rule at once", d)
        }
    }

    @Test
    fun launcherTapAllSixNeverBlocked() {
        for (pkg in six) {
            assertNull(
                "$pkg launcher tile must have no lock badge",
                LauncherLogic.tapDecision(
                    pkg, true, true, emptySet(), setOf(pkg),
                    setOf("facebook", "ai"), emptySet(), "app.strictguard", null,
                    true, mapOf("facebook" to now + 20L * 60_000L), now,
                    true, false, false
                )
            )
        }
    }

    @Test
    fun entryDelayNeverAppliesToTheSix() {
        for (pkg in six) {
            assertFalse(
                "$pkg must never get the entry delay",
                EntryDelay.shouldDelay(pkg, true, false)
            )
        }
    }

    @Test
    fun nightAllowedDefaultsToTheSixUntilSaved() {
        // Fresh install / never opened the Night picker: the six
        // are pre-set — Fahim must not add them separately.
        assertEquals(
            AlwaysAllowed.PACKAGES,
            AlwaysAllowed.defaultNightAllowed(false, null)
        )
        assertEquals(
            AlwaysAllowed.PACKAGES,
            AlwaysAllowed.defaultNightAllowed(false, emptySet())
        )
        // An explicitly saved list wins exactly as saved — even an
        // empty one, and even one that drops some of the six.
        val saved = setOf("com.android.dialer", "com.whatsapp")
        assertEquals(saved, AlwaysAllowed.defaultNightAllowed(true, saved))
        assertEquals(emptySet<String>(), AlwaysAllowed.defaultNightAllowed(true, emptySet()))
        assertEquals(emptySet<String>(), AlwaysAllowed.defaultNightAllowed(true, null))
    }
}

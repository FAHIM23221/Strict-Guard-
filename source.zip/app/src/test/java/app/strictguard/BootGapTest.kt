package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * v6.1.5 — boot-gap tests.
 *
 * Fahim proved the gap on-device (2026-11-09 ~03:30, Infinix
 * X6886, v6.1.4): after a restart, during the boot loading, he
 * opened Settings and turned off Device Admin. The v6.1.4 path
 * only STARTED the service at LOCKED_BOOT_COMPLETED and then
 * enforced nothing until the Store became readable after unlock
 * — and even then the mirror restore ran before the first poll.
 * These tests pin the v6.1.5 contract at the pure-decision level:
 * boot mode enforces from the mirror alone, the first poll
 * blocks Settings, and admin loss is an alert + a mirror
 * re-assert, never a silent loss.
 */
class BootGapTest {

    // ---- Boot mode starts enforcement from the mirror alone ----

    @Test
    fun `boot enforces when Strict wall end is in the future`() {
        val now = 1_000_000L
        assertTrue(
            BootEnforce.shouldBootEnforce(
                strictWallEndMs = now + 3_600_000L,
                nowWallMs = now,
                serviceWanted = false
            )
        )
    }

    @Test
    fun `boot enforces when service is wanted even if Strict is off`() {
        val now = 1_000_000L
        assertTrue(
            BootEnforce.shouldBootEnforce(
                strictWallEndMs = 0L,
                nowWallMs = now,
                serviceWanted = true
            )
        )
    }

    @Test
    fun `boot does not enforce when nothing is wanted and Strict is off`() {
        val now = 1_000_000L
        assertFalse(
            BootEnforce.shouldBootEnforce(
                strictWallEndMs = 0L,
                nowWallMs = now,
                serviceWanted = false
            )
        )
    }

    @Test
    fun `boot does not enforce when Strict already ended`() {
        val now = 1_000_000L
        assertFalse(
            BootEnforce.shouldBootEnforce(
                strictWallEndMs = now - 1_000L,
                nowWallMs = now,
                serviceWanted = false
            )
        )
    }

    @Test
    fun `boot Strict is active exactly while the mirror wall end is in the future`() {
        val now = 1_000_000L
        assertTrue(BootEnforce.bootStrictActive(now + 60_000L, now))
        assertFalse(BootEnforce.bootStrictActive(now - 1L, now))
        assertFalse(BootEnforce.bootStrictActive(0L, now))
    }

    // ---- The boot poll is fast enough to beat a human ----

    @Test
    fun `boot poll is 100ms - far faster than the strict-on poll`() {
        assertEquals(100L, BootEnforce.BOOT_POLL_MS)
        assertTrue(BootEnforce.BOOT_POLL_MS < Limits.FAST_POLL_MS)
        assertTrue(Limits.FAST_POLL_MS < Limits.POLL_MS)
    }

    @Test
    fun `boot poll interval is consistent with the poll ladder`() {
        // 100 ms boot < 250 ms Strict-on < 500 ms normal: the
        // first post-unlock tick is the one that closes the gap.
        assertTrue(
            BootEnforce.BOOT_POLL_MS < Limits.FAST_POLL_MS &&
                Limits.FAST_POLL_MS < Limits.POLL_MS
        )
    }

    // ---- Settings is blocked from the very first poll ----

    @Test
    fun `Settings is blocked by the fast path from the first boot tick`() {
        // The boot tick uses the same rule as the normal fast path,
        // with strict forced on from the mirror — so Settings, by
        // package or by activity, is a block from tick one.
        assertTrue(
            BlockDecider.fastBlockDecision(
                "com.android.settings", null, "app.strictguard", strict = true
            ) != null
        )
        assertTrue(
            BlockDecider.fastBlockDecision(
                "com.example.other",
                "com.android.settings.DeviceAdminSettings",
                "app.strictguard", strict = true
            ) != null
        )
    }

    @Test
    fun `the Device Admin screen is Settings - blocked, not a separate case`() {
        // The Device Admin toggle lives inside com.android.settings,
        // so blocking the package blocks the toggle itself.
        assertTrue(BlockDecider.isSettingsActivity("com.android.settings", null))
        assertTrue(
            BlockDecider.isSettingsActivity(
                "com.android.settings",
                "com.android.settings.DeviceAdminSettings"
            )
        )
    }

    @Test
    fun `Phone Master is blocked by the fast path from the first boot tick`() {
        assertTrue(
            BlockDecider.fastBlockDecision(
                "com.transsion.phonemaster", null, "app.strictguard", strict = true
            ) != null
        )
    }

    @Test
    fun `the fast path blocks nothing when Strict is off`() {
        assertEquals(
            null,
            BlockDecider.fastBlockDecision(
                "com.android.settings", null, "app.strictguard", strict = false
            )
        )
    }

    // ---- Admin loss: alert + mirror re-assert, never silent ----

    @Test
    fun `admin loss alerts only when Strict is on`() {
        assertTrue(AdminLoss.shouldAlert(strictActive = true, adminActive = false))
        assertFalse(AdminLoss.shouldAlert(strictActive = false, adminActive = false))
        assertFalse(AdminLoss.shouldAlert(strictActive = true, adminActive = true))
    }

    @Test
    fun `admin alert persists while Strict is on`() {
        assertTrue(AdminLoss.shouldPersist(strictActive = true))
        assertFalse(AdminLoss.shouldPersist(strictActive = false))
    }

    @Test
    fun `mirror re-assert restores Strict after admin loss`() {
        // The backstop: even if the app is uninstalled and
        // reinstalled after admin is lost, the mirror outside the
        // app's private data still says Strict is on — and the
        // next app launch restores it.
        val now = 1_700_000_000_000L
        val end = now + 3_600_000L
        val bytes = StrictMirror.encode(StrictMirror.MirrorState(end, now), crypto)
        val restored = StrictMirror.decideRestore(bytes, 0L, false, now, crypto)
        assertTrue(restored is StrictMirror.Restore.Restored)
        assertEquals(
            end,
            (restored as StrictMirror.Restore.Restored).state.strictEndWallMs
        )
    }

    @Test
    fun `mirror does not resurrect Strict after it ended`() {
        val now = 1_700_000_000_000L
        val past = StrictMirror.encode(
            StrictMirror.MirrorState(now - Limits.DAY_MS, now - 2L * Limits.DAY_MS),
            crypto
        )
        assertTrue(
            StrictMirror.decideRestore(past, 0L, false, now, crypto)
                is StrictMirror.Restore.Expired
        )
    }

    /** Test-only [MirrorCrypto]: AES/GCM + HMAC-SHA256, fixed keys
     *  (same contract as [StrictMirrorTest]'s, whose copy is
     *  private to that class). */
    private class TestCrypto : MirrorCrypto {
        private val encKey: SecretKey = run {
            val gen = KeyGenerator.getInstance("AES")
            gen.init(256)
            gen.generateKey()
        }
        private val macKey: SecretKey = SecretKeySpec(
            ByteArray(32) { (it * 7 + 3).toByte() }, "HmacSHA256"
        )

        override fun encrypt(plain: ByteArray): ByteArray {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, encKey)
            val body = cipher.iv + cipher.doFinal(plain)
            val mac = Mac.getInstance("HmacSHA256").apply { init(macKey) }.doFinal(body)
            return body + mac
        }

        override fun decrypt(data: ByteArray): ByteArray? {
            return try {
                if (data.size < 12 + 32 + 16) return null
                val body = data.copyOfRange(0, data.size - 32)
                val tag = data.copyOfRange(data.size - 32, data.size)
                val expected = Mac.getInstance("HmacSHA256").apply { init(macKey) }.doFinal(body)
                if (!tag.contentEquals(expected)) return null
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(
                    Cipher.DECRYPT_MODE, encKey,
                    GCMParameterSpec(128, body.copyOfRange(0, 12))
                )
                cipher.doFinal(body.copyOfRange(12, body.size))
            } catch (e: Exception) {
                null
            }
        }
    }

    private val crypto = TestCrypto()
}

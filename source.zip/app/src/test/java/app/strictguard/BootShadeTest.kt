package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.6 — the Quick Settings shade bypass (Fahim, 2026-11-09 ~03:51,
 * Infinix X6886, v6.1.5): after a restart, while the home screen was
 * still loading, he pulled the shade down and tapped the gear —
 * Settings opened even though Strict was on.
 *
 * The shade itself cannot be closed by any app: it is SystemUI,
 * above every app window including TYPE_APPLICATION_OVERLAY, and
 * intercepting the gear tap would need Accessibility (forbidden on
 * this phone) or device-owner. The closable point is Settings
 * reaching the foreground — and v6.1.5 had three holes exactly
 * there, pinned by these tests at the pure-decision level:
 *  1. The boot block never showed the full-screen overlay (the
 *     normal path does). Before any activity of ours is visible,
 *     Android can refuse a service's activity start, so a refused
 *     BlockActivity left NOTHING covering Settings. The boot block
 *     now shows the overlay too, and retries every 500 ms.
 *  2. The launcher/main self-heal ran AFTER the slow mirror
 *     restore (~0.5–3 s, main thread). The guard restart is now
 *     FIRST (gate: not running + Usage Access granted).
 *  3. Boot blocks lived only in memory. They are now also written
 *     to device-protected prefs the moment they happen
 *     ([BootEventLog]), so the Tamper Log entry survives even if
 *     the service dies before graduating.
 */
class BootShadeTest {

    private val own = "app.strictguard"
    private val settings = "com.android.settings"
    private val systemUi = "com.android.systemui"

    // ---- The shade launch: Settings is the foreground, not SystemUI ----

    @Test
    fun `shade gear launch resolves to Settings not the shade`() {
        // Pulling the shade leaves SystemUI as the last-known
        // package; tapping the gear fires a fresh MOVE_TO_FOREGROUND
        // for Settings. The fresh event wins — the guard must see
        // Settings, not keep reporting the shade.
        val resolved = ForegroundResolver.resolve(settings, systemUi, null)
        assertEquals(settings, resolved)
    }

    @Test
    fun `shade itself is never fast-blocked`() {
        // SystemUI is the shade / status bar, not an app to block.
        // Blocking it would be wrong (and impossible — it is a
        // system window). Only what the shade LAUNCHES is blocked.
        val d = BlockDecider.fastBlockDecision(systemUi, null, own, strict = true)
        assertNull(d)
    }

    @Test
    fun `settings from the shade is blocked with no activity class`() {
        // A shade launch may surface Settings before any activity
        // class is known (null class) — the package alone must be
        // enough to block it.
        val d = BlockDecider.fastBlockDecision(settings, null, own, strict = true)
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun `phone master from the shade is blocked too`() {
        val d = BlockDecider.fastBlockDecision(
            PhoneMaster.PACKAGE, null, own, strict = true
        )
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun `fast path stays silent when Strict is off`() {
        val d = BlockDecider.fastBlockDecision(settings, null, own, strict = false)
        assertNull(d)
    }

    // ---- Boot block: overlay + fast retry ----

    @Test
    fun `boot block shows the overlay when the permission exists`() {
        assertTrue(BootEnforce.shouldShowBootOverlay(hasOverlayPermission = true))
    }

    @Test
    fun `boot block has no overlay without the permission`() {
        assertFalse(BootEnforce.shouldShowBootOverlay(hasOverlayPermission = false))
    }

    @Test
    fun `boot block retries faster than the normal path`() {
        assertEquals(500L, BootEnforce.bootBlockRetryMs(bootMode = true))
        assertEquals(2000L, BootEnforce.bootBlockRetryMs(bootMode = false))
        assertTrue(
            BootEnforce.bootBlockRetryMs(true) < BootEnforce.bootBlockRetryMs(false)
        )
    }

    @Test
    fun `boot poll is faster than the strict poll`() {
        assertTrue(BootEnforce.BOOT_POLL_MS < Limits.FAST_POLL_MS)
    }

    // ---- Boot events: recorded the moment they happen ----

    @Test
    fun `boot block event names the package and the reason`() {
        val event = BootEventLog.formatBlockEvent(
            settings, "com.android.settings.Settings",
            BlockDecider.Kind.STRICT_BYPASS
        )
        assertTrue(event.contains(settings))
        assertTrue(event.contains("STRICT_BYPASS"))
        assertTrue(event.startsWith("BOOT_BLOCKED"))
    }

    @Test
    fun `boot block event tolerates an unknown activity class`() {
        val event = BootEventLog.formatBlockEvent(
            settings, null, BlockDecider.Kind.STRICT_BYPASS
        )
        assertTrue(event.contains(settings))
        assertTrue(event.contains("?"))
    }

    @Test
    fun `boot admin lost event is a fixed string`() {
        assertEquals(
            "BOOT_ADMIN_LOST device-admin turned off in Settings",
            BootEventLog.formatAdminLostEvent()
        )
    }

    @Test
    fun `boot event log caps at fifty entries`() {
        var events: List<String> = emptyList()
        for (i in 1..60) {
            events = BootEventLog.append(events, "BOOT_BLOCKED pkg$i")
        }
        assertEquals(BootEventLog.MAX_EVENTS, events.size)
        assertEquals("BOOT_BLOCKED pkg60", events.last())
        assertEquals("BOOT_BLOCKED pkg11", events.first())
    }

    // ---- Boot mode still enforces from the mirror alone — and its limit ----

    @Test
    fun `boot strict is off when the mirror wall end is missing`() {
        // Documents the limit: if the boot mirror has no Strict wall
        // end (Strict started before the mirror existed, or the write
        // failed), boot mode starts the service when wanted but the
        // fast block stays off until the Store reads after unlock.
        // The mirror is written on every Strict start/end, so this
        // only bites for a Strict that predates the mirror.
        assertFalse(BootEnforce.bootStrictActive(0L, 1_000_000L))
    }

    @Test
    fun `boot strict is on while the mirror wall end is in the future`() {
        assertTrue(BootEnforce.bootStrictActive(1_000_000L + 3_600_000L, 1_000_000L))
    }

    // ---- Self-heal gate: the launcher's first step ----

    @Test
    fun `guard restarts when not running and usage access is granted`() {
        assertTrue(StartupGuard.shouldRestartGuard(isRunning = false, hasUsageAccess = true))
    }

    @Test
    fun `guard does not restart when it is already running`() {
        assertFalse(StartupGuard.shouldRestartGuard(isRunning = true, hasUsageAccess = true))
    }

    @Test
    fun `guard does not restart without usage access`() {
        assertFalse(StartupGuard.shouldRestartGuard(isRunning = false, hasUsageAccess = false))
    }
}

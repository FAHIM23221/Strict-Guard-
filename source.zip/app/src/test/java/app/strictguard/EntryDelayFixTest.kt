package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.2 — Entry Delay popup-never-shows regression tests.
 *
 * What Fahim reported 2026-11-08 ~23:25: opening a social app
 * (Facebook, TikTok, Instagram, YouTube) showed NO 15-second
 * timer popup at all — the app opened directly.
 *
 * Two defects, both fixed here:
 * 1. DEAD GUARD, SILENTLY. The guard service is the only thing
 *    that shows the popup (and enforces everything else), but
 *    the self-heal restart required the persisted service-wanted
 *    flag — which only the service itself ever sets. On a fresh
 *    install, or after the service was force-stopped / killed
 *    before it ever ran, the guard stayed dead and nothing
 *    restarted it, while the launcher still showed lock badges
 *    (pure UI) — so it looked like blocking worked while the
 *    delay never appeared. Fix: restart whenever Usage Access
 *    is granted ([StartupGuard.shouldRestartGuard]).
 * 2. SILENT OVERLAY FAILURE. When the overlay permission was
 *    missing, the countdown state machine ran invisibly and the
 *    app stayed usable — the wait was skipped without a trace.
 *    Fix: the countdown is now shown as the full-screen
 *    [DelayActivity] instead ([EntryDelay.needsActivityFallback],
 *    [EntryDelay.effectiveDelayPkg]).
 *
 * The wait itself is 15 SECONDS (default; 10 / 15 / 30 seconds
 * in settings) — Fahim misspoke "15 minutes" in voice; the
 * code and strings were already seconds, and these tests pin
 * that down.
 */
class EntryDelayFixTest {

    private val own = "app.strictguard"
    private val facebook = "com.facebook.katana"
    private val tiktok = "com.zhiliaoapp.musically"
    private val instagram = "com.instagram.android"
    private val youtube = "com.google.android.youtube"
    private val whatsapp = "com.whatsapp"

    // ---- 1. the guard restarts whenever Usage Access is granted ----

    @Test
    fun guardRestartsWhenDeadAndUsageAccessGranted() {
        assertTrue(StartupGuard.shouldRestartGuard(isRunning = false, hasUsageAccess = true))
    }

    @Test
    fun guardDoesNotRestartWhenAlreadyRunning() {
        assertFalse(StartupGuard.shouldRestartGuard(isRunning = true, hasUsageAccess = true))
    }

    @Test
    fun guardDoesNotRestartWithoutUsageAccess() {
        // Fresh install / setup not done: no usage access, no
        // monitoring to restart.
        assertFalse(StartupGuard.shouldRestartGuard(isRunning = false, hasUsageAccess = false))
        assertFalse(StartupGuard.shouldRestartGuard(isRunning = true, hasUsageAccess = false))
    }

    // ---- 2a. the four reported apps get the delay; WhatsApp does not ----

    @Test
    fun reportedSocialAppsGetTheDelay() {
        for (pkg in listOf(facebook, tiktok, instagram, youtube)) {
            assertTrue("$pkg should be delayed", EntryDelay.isDelayApp(pkg))
            assertTrue(
                "$pkg shouldDelay when enabled and unblocked",
                EntryDelay.shouldDelay(pkg, enabled = true, blocked = false)
            )
        }
    }

    @Test
    fun whatsappNeverGetsTheDelay() {
        assertFalse(EntryDelay.isDelayApp(whatsapp))
        assertFalse(EntryDelay.shouldDelay(whatsapp, enabled = true, blocked = false))
    }

    @Test
    fun blockedAppsNeverGetTheDelay() {
        // Strict / Night / limit / break blocks take precedence.
        for (pkg in listOf(facebook, youtube)) {
            assertFalse(EntryDelay.shouldDelay(pkg, enabled = true, blocked = true))
        }
    }

    // ---- 2b. the wait is 15 SECONDS, and no entry before it ends ----

    @Test
    fun waitIsFifteenSecondsNotMinutes() {
        assertEquals(15, EntryDelay.DEFAULT_SECONDS)
        val start = 100_000L
        // 14.9 s in: NOT done — no entry before the full wait.
        assertFalse(EntryDelay.isDone(start, 15, start + 14_900L))
        assertEquals(1L, EntryDelay.remainingSeconds(start, 15, start + 14_900L))
        // At exactly 15 s the wait is done.
        assertTrue(EntryDelay.isDone(start, 15, start + 15_000L))
        assertEquals(0L, EntryDelay.remainingSeconds(start, 15, start + 15_000L))
    }

    // ---- 2c. the fallback screen keeps the wait running ----

    @Test
    fun delayActivityForegroundKeepsWatchingTheSocialApp() {
        // While the full-screen DelayActivity covers Facebook, the
        // state machine must watch Facebook — not Strict Guard.
        assertEquals(
            facebook,
            EntryDelay.effectiveDelayPkg(
                facebook, "com.facebook.katana.MainActivity", own, facebook
            )
        )
        assertEquals(
            facebook,
            EntryDelay.effectiveDelayPkg(
                own, EntryDelay.DELAY_ACTIVITY_CLASS, own, facebook
            )
        )
    }

    @Test
    fun leavingMidWaitStillResets() {
        // Any other foreground screen is watched as itself, so
        // leaving (Home, Recents, another app) resets the wait.
        assertEquals(
            "com.android.launcher",
            EntryDelay.effectiveDelayPkg(
                "com.android.launcher", "com.android.launcher.Launcher",
                own, facebook
            )
        )
        assertEquals(
            own,
            EntryDelay.effectiveDelayPkg(
                own, "app.strictguard.MainActivity", own, facebook
            )
        )
    }

    @Test
    fun noWaitMeansForegroundIsWatchedAsItself() {
        assertEquals(
            facebook,
            EntryDelay.effectiveDelayPkg(
                facebook, "com.facebook.katana.MainActivity", own, null
            )
        )
        assertEquals(
            own,
            EntryDelay.effectiveDelayPkg(
                own, EntryDelay.DELAY_ACTIVITY_CLASS, own, null
            )
        )
    }

    @Test
    fun fallbackNeededWithoutOverlayOrWhenOverlayFails() {
        // No overlay permission: activity fallback, always.
        assertTrue(EntryDelay.needsActivityFallback(hasOverlay = false, overlayShown = false))
        assertTrue(EntryDelay.needsActivityFallback(hasOverlay = false, overlayShown = true))
        // Permission granted but the overlay view could not be
        // added: fallback too — never a silent skip.
        assertTrue(EntryDelay.needsActivityFallback(hasOverlay = true, overlayShown = false))
        // Overlay showing: no fallback.
        assertFalse(EntryDelay.needsActivityFallback(hasOverlay = true, overlayShown = true))
    }
}

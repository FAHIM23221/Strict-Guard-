package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.4 — the faster Settings block (Fahim, 2026-11-09).
 *
 * The Settings block existed but was SLOW: opening Settings during
 * Strict showed the block popup only after a few seconds — enough
 * to change things. Two causes, both fixed:
 *  1. The foreground was only resolved AFTER the HSC reminders, the
 *     auto-theme check, the permission watch and the study trigger
 *     on every tick, and every tick paid for a UsageStats
 *     most-recent query even when the sticky package was known.
 *     Now the bypass routes are checked FIRST ([BlockDecider.
 *     fastBlockDecision]) on every poll, before any of that work.
 *  2. The poll itself ran every 500 ms. While Strict is on it now
 *     runs every 250 ms ([Limits.FAST_POLL_MS]) — so the worst
 *     case from opening Settings to the block landing is ~250 ms
 *     plus one cheap foreground query, not seconds.
 *
 * The interval is threaded through ALL usage accounting as the
 * per-tick milliseconds, so a 250 ms tick adds 250 ms of usage —
 * never 500 ms. These tests pin that: the Facebook limit (120 min)
 * takes exactly twice as many 250 ms ticks as 500 ms ticks.
 *
 * Honest limit, kept: polling cannot be truly instant without
 * Accessibility (which is forbidden on this phone). The guarantee
 * is the interval above, not zero latency.
 */
class FastBlockTest {

    private val own = "app.strictguard"
    private val settings = "com.android.settings"
    private val pm = PhoneMaster.PACKAGE

    // ---- The fast path: bypass routes die first, during Strict only ----

    @Test
    fun settingsBlockedByFastPathDuringStrict() {
        val d = BlockDecider.fastBlockDecision(settings, null, own, strict = true)
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun settingsBlockedByActivityClassOnFastPath() {
        val d = BlockDecider.fastBlockDecision(
            "com.android.settings",
            "com.android.settings.SubSettings",
            own, strict = true
        )
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun ownSettingsBlockedByFastPathDuringStrict() {
        val d = BlockDecider.fastBlockDecision(
            own, "$own.MainActivity", own, strict = true
        )
        assertEquals(BlockDecider.Kind.SELF_BLOCK, d?.kind)
    }

    @Test
    fun phoneMasterBlockedByFastPathDuringStrict() {
        val d = BlockDecider.fastBlockDecision(pm, null, own, strict = true)
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun fastPathIsSilentWhenStrictOff() {
        assertNull(BlockDecider.fastBlockDecision(settings, null, own, strict = false))
        assertNull(BlockDecider.fastBlockDecision(pm, null, own, strict = false))
        assertNull(BlockDecider.fastBlockDecision(own, "$own.MainActivity", own, strict = false))
    }

    @Test
    fun fastPathLetsOrdinaryAppsThrough() {
        assertNull(
            BlockDecider.fastBlockDecision(
                "com.example.notes", null, own, strict = true
            )
        )
        // The launcher and the block screen itself are never
        // fast-blocked: the launcher must stay open, the block
        // screen must be able to show.
        assertNull(
            BlockDecider.fastBlockDecision(
                own, "$own.LauncherActivity", own, strict = true
            )
        )
        assertNull(
            BlockDecider.fastBlockDecision(
                own, "$own.BlockActivity", own, strict = true
            )
        )
    }

    // ---- The interval: 250 ms during Strict, 500 ms otherwise ----

    @Test
    fun pollIntervalIs250msDuringStrict() {
        assertEquals(250L, Limits.FAST_POLL_MS)
        assertEquals(250L, Limits.pollIntervalMs(strictActive = true))
    }

    @Test
    fun pollIntervalStays500msWhenStrictOff() {
        assertEquals(500L, Limits.POLL_MS)
        assertEquals(500L, Limits.pollIntervalMs(strictActive = false))
    }

    // ---- Accounting: a fast tick adds 250 ms, never 500 ms ----

    private fun ticksToFacebookLimit(tickMs: Long): Int {
        val tracker = UsageTracker()
        var ticks = 0
        while (true) {
            ticks++
            val reached = tracker.tick("facebook", "2026-11-09", tickMs)
            if (reached != null) return ticks
            check(ticks < 100_000) { "limit never reached" }
        }
    }

    @Test
    fun fastTicksCountHalfAsMuchAsNormalTicks() {
        // Facebook limit is 120 min = 7,200,000 ms:
        // 14,400 ticks at 500 ms, 28,800 ticks at 250 ms.
        assertEquals(14_400, ticksToFacebookLimit(500L))
        assertEquals(28_800, ticksToFacebookLimit(250L))
    }
}

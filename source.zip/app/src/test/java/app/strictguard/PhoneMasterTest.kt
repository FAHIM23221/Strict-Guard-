package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.4 — Phone Master (Fahim, 2026-11-09).
 *
 * Phone Master is Transsion's system cleaner: it can freeze /
 * disable apps, including Strict Guard itself. During Strict Mode
 * it must be invisible in the launcher (grid, hidden-apps dialog,
 * picker search) and unlaunchable anywhere the guard controls.
 * When Strict ends it is an ordinary app again. Scope is Strict
 * Mode ONLY — at night it is blocked only by the generic Night
 * Lock rule like any other non-allowed app, and in normal use it
 * opens freely.
 *
 * Package verified 2026-11-09: Uptodown lists Package Name
 * com.transsion.phonemaster (developer TRANSSION MOBILE);
 * APKMirror agrees across every version listed.
 */
class PhoneMasterTest {

    private val own = "app.strictguard"
    private val pm = PhoneMaster.PACKAGE
    private val other = "com.facebook.katana"

    private fun apps() = listOf(
        LauncherLogic.AppEntry(pm, "Phone Master"),
        LauncherLogic.AppEntry(other, "Facebook"),
        LauncherLogic.AppEntry("com.google.android.youtube", "YouTube")
    )

    // ---- Identity: the verified package, by package and by activity ----

    @Test
    fun packageNameIsVerifiedTranssionPackage() {
        assertEquals("com.transsion.phonemaster", PhoneMaster.PACKAGE)
    }

    @Test
    fun isPhoneMasterByPackage() {
        assertTrue(PhoneMaster.isPhoneMaster(pm))
        assertFalse(PhoneMaster.isPhoneMaster(other))
    }

    @Test
    fun isPhoneMasterActivityByPackageAlone() {
        assertTrue(PhoneMaster.isPhoneMasterActivity(pm, null))
        assertTrue(PhoneMaster.isPhoneMasterActivity(pm, "com.example.SomeActivity"))
    }

    @Test
    fun isPhoneMasterActivityByActivityClass() {
        // An OEM wrapper hosting Phone Master's activities under
        // another package name is still Phone Master.
        assertTrue(
            PhoneMaster.isPhoneMasterActivity(
                "com.transsion.something",
                "com.transsion.phonemaster.ui.MainActivity"
            )
        )
    }

    @Test
    fun isPhoneMasterActivityFalseForUnrelated() {
        assertFalse(PhoneMaster.isPhoneMasterActivity(other, "com.facebook.katana.MainActivity"))
        assertFalse(PhoneMaster.isPhoneMasterActivity(other, null))
    }

    @Test
    fun labelFallbackMatchesPhoneMasterLabel() {
        assertTrue(PhoneMaster.isPhoneMasterLabel("Phone Master"))
        assertTrue(PhoneMaster.isPhoneMasterLabel("phone master"))
        assertFalse(PhoneMaster.isPhoneMasterLabel("Phone"))
        assertFalse(PhoneMaster.isPhoneMasterLabel(null))
    }

    // ---- Hiding: invisible during Strict, ordinary otherwise ----

    @Test
    fun hiddenDuringStrictByPackage() {
        assertTrue(PhoneMaster.isHidden(pm, "Phone Master", strict = true))
    }

    @Test
    fun hiddenDuringStrictByLabelFallback() {
        // Renamed / repackaged, same label: still hidden from the
        // launcher while Strict is on.
        assertTrue(PhoneMaster.isHidden("com.example.renamed", "Phone Master", strict = true))
    }

    @Test
    fun notHiddenWhenStrictOff() {
        assertFalse(PhoneMaster.isHidden(pm, "Phone Master", strict = false))
    }

    @Test
    fun otherAppsNeverHidden() {
        assertFalse(PhoneMaster.isHidden(other, "Facebook", strict = true))
    }

    @Test
    fun visibleAppsRemovesPhoneMasterDuringStrict() {
        val visible = PhoneMaster.visibleApps(apps(), strict = true)
        assertEquals(2, visible.size)
        assertTrue(visible.none { it.pkg == pm })
        assertTrue(visible.any { it.pkg == other })
    }

    @Test
    fun visibleAppsKeepsPhoneMasterWhenStrictOff() {
        val visible = PhoneMaster.visibleApps(apps(), strict = false)
        assertEquals(3, visible.size)
        assertTrue(visible.any { it.pkg == pm })
    }

    @Test
    fun launcherLogicVisibleAppsDelegates() {
        val visible = LauncherLogic.visibleApps(apps(), strict = true)
        assertTrue(visible.none { it.pkg == pm })
        assertEquals(3, LauncherLogic.visibleApps(apps(), strict = false).size)
    }

    // ---- Blocking: decide() treats it like Settings during Strict ----

    private fun decide(
        pkg: String,
        strict: Boolean,
        night: Boolean,
        activity: String? = null
    ) = BlockDecider.decide(
        pkg = pkg,
        strict = strict,
        night = night,
        nightAllowed = emptySet(),
        custom = emptySet(),
        limitReached = emptySet(),
        isLauncher = false,
        ownPackage = own,
        foregroundActivity = activity
    )

    @Test
    fun blockedDuringStrictLikeSettings() {
        val d = decide(pm, strict = true, night = false)
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun blockedDuringStrictByActivityClass() {
        val d = decide(
            "com.transsion.something", strict = true, night = false,
            activity = "com.transsion.phonemaster.ui.MainActivity"
        )
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun allowedInNormalUse() {
        assertNull(decide(pm, strict = false, night = false))
    }

    @Test
    fun atNightOnlyTheGenericNightRuleApplies() {
        // Strict ONLY for the Phone-Master-specific block: at night
        // it is blocked like any other non-allowed app (NIGHT), not
        // by the STRICT_BYPASS rule.
        val d = decide(pm, strict = false, night = true)
        assertEquals(BlockDecider.Kind.NIGHT, d?.kind)
    }

    @Test
    fun strictBypassWinsOverNight() {
        val d = decide(pm, strict = true, night = true)
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun otherAppsUnaffectedByPhoneMasterRule() {
        // A neutral app (in no limit group) is untouched by the
        // Phone Master rule during Strict.
        assertNull(decide("com.example.notes", strict = true, night = false))
    }
}

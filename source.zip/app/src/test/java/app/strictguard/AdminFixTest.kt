package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v5.2.1 tests — the Device Admin bypass Olivia found on-device, and
 * the removal of the YouTube Shorts feature.
 *
 * The bypass: the guard only looked at UsageEvents from the last
 * 3 seconds. Sitting inside Settings for more than 3 seconds (or
 * navigating inside Settings, where no new MOVE_TO_FOREGROUND event
 * fires) made the query return null, tick() returned early, and the
 * guard went blind — Device Admin could be turned off during Strict.
 */
class AdminFixTest {

    private val own = "app.strictguard"

    // ---- Settings blocked during Strict / Night (package) ----

    @Test
    fun settingsBlockedDuringStrict() {
        assertEquals(
            BlockDecider.Kind.STRICT_BYPASS,
            BlockDecider.decide(
                "com.android.settings", true, false,
                emptySet(), emptySet(), emptySet(), false, own
            )?.kind
        )
    }

    @Test
    fun settingsBlockedDuringNight() {
        assertEquals(
            BlockDecider.Kind.STRICT_BYPASS,
            BlockDecider.decide(
                "com.android.settings", false, true,
                emptySet(), emptySet(), emptySet(), false, own
            )?.kind
        )
    }

    @Test
    fun settingsNotBlockedWhenStrictAndNightOff() {
        assertNull(
            BlockDecider.decide(
                "com.android.settings", false, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
    }

    // ---- Settings blocked by ACTIVITY class, not just package ----
    // The Device Admin screen (Settings > Security > Device admin
    // apps) and the App info screen for Strict Guard itself are
    // Settings activities. Even if such a screen were hosted under
    // another package name, its activity class still gives it away.

    @Test
    fun deviceAdminActivityBlockedDuringStrict() {
        val d = BlockDecider.decide(
            "com.android.settings", true, false,
            emptySet(), emptySet(), emptySet(), false, own,
            "com.android.settings.Settings\$DeviceAdminSettingsActivity"
        )
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun appInfoActivityBlockedDuringStrict() {
        val d = BlockDecider.decide(
            "com.android.settings", true, false,
            emptySet(), emptySet(), emptySet(), false, own,
            "com.android.settings.applications.InstalledAppDetailsTop"
        )
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun settingsActivityUnderOtherPackageStillBlocked() {
        assertTrue(
            BlockDecider.isSettingsActivity(
                "com.example.oemsettings",
                "com.android.settings.Settings\$DeviceAdminSettingsActivity"
            )
        )
        val d = BlockDecider.decide(
            "com.example.oemsettings", true, false,
            emptySet(), emptySet(), emptySet(), false, own,
            "com.android.settings.Settings\$DeviceAdminSettingsActivity"
        )
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun nonSettingsActivityNotFlagged() {
        assertFalse(
            BlockDecider.isSettingsActivity(
                "com.google.android.youtube",
                "com.google.android.apps.youtube.app.WatchWhileActivity"
            )
        )
        assertFalse(BlockDecider.isSettingsActivity("com.example.game", null))
    }

    // ---- YouTube NOT blocked outside Strict / Night / limit ----
    // (Shorts feature removed: no toggle, no SHORTS kind.)

    @Test
    fun youtubeAndMusicUsableOutsideStrict() {
        assertNull(
            BlockDecider.decide(
                "com.google.android.youtube", false, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
        assertNull(
            BlockDecider.decide(
                "com.google.android.apps.youtube.music", false, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
    }

    // ---- Sticky foreground resolution (the actual bypass fix) ----

    @Test
    fun resolverFreshEventWins() {
        assertEquals(
            "com.android.settings",
            ForegroundResolver.resolve(
                "com.android.settings", "com.example.game", "com.example.other"
            )
        )
    }

    @Test
    fun resolverReusesLastKnownWhenNoEvent() {
        // No event in the last 3 s (user sitting inside Settings):
        // the guard must still see Settings, not go blind.
        assertEquals(
            "com.android.settings",
            ForegroundResolver.resolve(null, "com.android.settings", null)
        )
        assertEquals(
            "com.android.settings",
            ForegroundResolver.resolve(null, "com.android.settings", "com.example.other")
        )
    }

    @Test
    fun resolverFallsBackToStatsWhenNothingElseKnown() {
        // Settings was already foreground before Strict was turned
        // on: no event, no sticky package — UsageStats still knows.
        assertEquals(
            "com.android.settings",
            ForegroundResolver.resolve(null, null, "com.android.settings")
        )
    }

    @Test
    fun resolverNullWhenNothingKnown() {
        assertNull(ForegroundResolver.resolve(null, null, null))
    }

    @Test
    fun resolverActivityIsStickyToo() {
        assertEquals(
            "com.android.settings.Settings\$DeviceAdminSettingsActivity",
            ForegroundResolver.resolveActivity(
                null, "com.android.settings.Settings\$DeviceAdminSettingsActivity"
            )
        )
        assertEquals(
            "com.android.settings.Settings",
            ForegroundResolver.resolveActivity(
                "com.android.settings.Settings",
                "com.android.settings.Settings\$DeviceAdminSettingsActivity"
            )
        )
    }

    // ---- Admin control locked during Strict (pure lock rule) ----

    @Test
    fun settingsChangeAllowedOnlyWhenStrictOff() {
        assertTrue(Limits.settingsChangeAllowed(false))
        assertFalse(Limits.settingsChangeAllowed(true))
    }
}

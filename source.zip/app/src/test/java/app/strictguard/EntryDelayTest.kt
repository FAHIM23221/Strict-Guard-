package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.0 Entry Delay tests — pure countdown / gate logic, no
 * Android framework.
 *
 * Default wait 15 s, choices 10 / 15 / 30 s. The delay runs on
 * EVERY open of a social-feed app (Facebook, Instagram, TikTok, X,
 * Snapchat, LinkedIn, Reddit, … and YouTube + YouTube Music);
 * WhatsApp and other pure messengers are excluded. Strict / Night /
 * limit / break blocks take precedence — the delay never grants
 * access when the app is otherwise blocked.
 */
class EntryDelayTest {

    private val facebook = "com.facebook.katana"
    private val instagram = "com.instagram.android"
    private val tiktok = "com.zhiliaoapp.musically"
    private val youtube = "com.google.android.youtube"
    private val youtubeMusic = "com.google.android.apps.youtube.music"
    private val whatsapp = "com.whatsapp"
    private val telegram = "org.telegram.messenger"
    private val chrome = "com.android.chrome"

    @Test
    fun defaultsAndChoices() {
        assertEquals(15, EntryDelay.DEFAULT_SECONDS)
        assertEquals(listOf(10, 15, 30), EntryDelay.CHOICES_SECONDS.toList())
        assertEquals(15, EntryDelay.validDuration(15))
        assertEquals(10, EntryDelay.validDuration(10))
        assertEquals(30, EntryDelay.validDuration(30))
        // Anything else falls back to the default 15 s.
        assertEquals(15, EntryDelay.validDuration(5))
        assertEquals(15, EntryDelay.validDuration(20))
        assertEquals(15, EntryDelay.validDuration(0))
    }

    @Test
    fun socialAppsAreDelayed() {
        for (pkg in listOf(facebook, instagram, tiktok, youtube, youtubeMusic)) {
            assertTrue("$pkg should be a delay app", EntryDelay.isDelayApp(pkg))
        }
        assertTrue(EntryDelay.isDelayApp("com.twitter.android")) // X
        assertTrue(EntryDelay.isDelayApp("com.snapchat.android"))
        assertTrue(EntryDelay.isDelayApp("com.linkedin.android"))
        assertTrue(EntryDelay.isDelayApp("com.reddit.frontpage"))
    }

    @Test
    fun messengersAndOtherAppsAreNotDelayed() {
        // WhatsApp stays EXCLUDED, as Fahim confirmed.
        assertFalse(EntryDelay.isDelayApp(whatsapp))
        assertFalse(EntryDelay.isDelayApp(telegram))
        assertFalse(EntryDelay.isDelayApp("com.facebook.orca")) // Messenger
        assertFalse(EntryDelay.isDelayApp("org.thoughtcrime.securesms")) // Signal
        assertFalse(EntryDelay.isDelayApp(chrome))
    }

    @Test
    fun delayGateRequiresEnabledAndUnblocked() {
        assertTrue(EntryDelay.shouldDelay(facebook, enabled = true, blocked = false))
        assertFalse(EntryDelay.shouldDelay(facebook, enabled = false, blocked = false))
        // Strict / Night / limit / break blocks take precedence:
        // the delay never runs when the app is otherwise blocked.
        assertFalse(EntryDelay.shouldDelay(facebook, enabled = true, blocked = true))
        assertFalse(EntryDelay.shouldDelay(youtube, enabled = true, blocked = true))
        assertFalse(EntryDelay.shouldDelay(whatsapp, enabled = true, blocked = false))
    }

    @Test
    fun countdownCountsDownAndFinishesAtZero() {
        val start = 100_000L
        // At the start the full 15 s remain.
        assertEquals(15_000L, EntryDelay.remainingMs(start, 15, start))
        assertEquals(15L, EntryDelay.remainingSeconds(start, 15, start))
        assertFalse(EntryDelay.isDone(start, 15, start))
        // 5 s in: 10 s remain.
        assertEquals(10_000L, EntryDelay.remainingMs(start, 15, start + 5_000L))
        assertEquals(10L, EntryDelay.remainingSeconds(start, 15, start + 5_000L))
        assertFalse(EntryDelay.isDone(start, 15, start + 5_000L))
        // 14.9 s in: not done yet — no entry before zero.
        assertFalse(EntryDelay.isDone(start, 15, start + 14_900L))
        assertEquals(1L, EntryDelay.remainingSeconds(start, 15, start + 14_900L))
        // At exactly 15 s the wait is done.
        assertTrue(EntryDelay.isDone(start, 15, start + 15_000L))
        assertEquals(0L, EntryDelay.remainingMs(start, 15, start + 15_000L))
        // Past the end it stays done, never negative.
        assertTrue(EntryDelay.isDone(start, 15, start + 60_000L))
        assertEquals(0L, EntryDelay.remainingMs(start, 15, start + 60_000L))
    }

    @Test
    fun durationsRespectChoice() {
        val start = 0L
        assertFalse(EntryDelay.isDone(start, 10, start + 9_999L))
        assertTrue(EntryDelay.isDone(start, 10, start + 10_000L))
        assertFalse(EntryDelay.isDone(start, 30, start + 15_000L))
        assertTrue(EntryDelay.isDone(start, 30, start + 30_000L))
    }

    @Test
    fun resetOnLeavingMeansFullWaitAgain() {
        // Leaving the overlay/app during the countdown RESETS the
        // timer: a fresh wait starts from the new foreground time,
        // so the full 15 s must be waited continuously.
        val firstStart = 100_000L
        // 10 s into the first wait, the user leaves.
        assertEquals(5_000L, EntryDelay.remainingMs(firstStart, 15, firstStart + 10_000L))
        // They come back later: a new wait starts (fresh start time).
        val secondStart = 200_000L
        assertEquals(15_000L, EntryDelay.remainingMs(secondStart, 15, secondStart))
        assertFalse(EntryDelay.isDone(secondStart, 15, secondStart + 10_000L))
        assertTrue(EntryDelay.isDone(secondStart, 15, secondStart + 15_000L))
    }
}

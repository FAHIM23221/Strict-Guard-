package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.3 Circular study countdown tests — pure logic, no Android framework.
 *
 * The circle counts the 15 fair minutes down (15:00 → 00:00),
 * pauses when the screen is off / a call / system UI is in front,
 * pauses when the attention prompt stays untapped for over 60
 * seconds (the honest idle definition — see StudyCountdown), and
 * hides when the app is left or the lock ends.
 */
class StudyCountdownTest {

    @Test
    fun remainingCountsDownFromFifteenMinutes() {
        assertEquals(15L * 60L * 1000L, StudyCountdown.remainingMs(0L))
        assertEquals(7L * 60L * 1000L + 30_000L, StudyCountdown.remainingMs(7L * 60L * 1000L + 30_000L))
        assertEquals(0L, StudyCountdown.remainingMs(15L * 60L * 1000L))
        assertEquals(0L, StudyCountdown.remainingMs(16L * 60L * 1000L))
    }

    @Test
    fun progressFractionFillsTheRing() {
        assertEquals(0f, StudyCountdown.progressFraction(0L), 0.001f)
        assertEquals(0.5f, StudyCountdown.progressFraction(7L * 60L * 1000L + 30_000L), 0.001f)
        assertEquals(1f, StudyCountdown.progressFraction(15L * 60L * 1000L), 0.001f)
        assertEquals(1f, StudyCountdown.progressFraction(20L * 60L * 1000L), 0.001f)
        assertEquals(450, StudyCountdown.progressSeconds(7L * 60L * 1000L + 30_000L))
        assertEquals(900, StudyCountdown.progressSeconds(15L * 60L * 1000L))
    }

    @Test
    fun displayTextIsMinutesSeconds() {
        assertEquals("15:00", StudyCountdown.displayText(15L * 60L * 1000L))
        assertEquals("07:30", StudyCountdown.displayText(7L * 60L * 1000L + 30_000L))
        assertEquals("01:00", StudyCountdown.displayText(60_000L))
        assertEquals("00:59", StudyCountdown.displayText(59_000L))
        assertEquals("00:01", StudyCountdown.displayText(1L))
        assertEquals("00:00", StudyCountdown.displayText(0L))
    }

    @Test
    fun runningWhileStudying() {
        val s = StudyCountdown.state(
            true, false, StudyLock.Mode.STUDYING, false
        )
        assertEquals(StudyCountdown.State.RUNNING, s)
    }

    @Test
    fun hiddenWithoutALockOrWithoutTheApp() {
        assertEquals(
            StudyCountdown.State.HIDDEN,
            StudyCountdown.state(false, false, StudyLock.Mode.STUDYING, false)
        )
        assertEquals(
            StudyCountdown.State.HIDDEN,
            StudyCountdown.state(true, true, StudyLock.Mode.STUDYING, false)
        )
        // Leaving the app hides the circle (the timer resets anyway).
        assertEquals(
            StudyCountdown.State.HIDDEN,
            StudyCountdown.state(true, false, StudyLock.Mode.LEFT, false)
        )
    }

    @Test
    fun pausedWhenScreenOffCallOrSystemUi() {
        assertEquals(
            StudyCountdown.State.PAUSED,
            StudyCountdown.state(true, false, StudyLock.Mode.PAUSED, false)
        )
    }

    @Test
    fun idlePauseOnlyAfterSixtySecondsUntapped() {
        val now = 1_700_000_000_000L
        // No prompt pending: not idle.
        assertFalse(StudyCountdown.isIdlePaused(0L, now))
        // Prompt shown 30 seconds ago: still running, not idle.
        assertFalse(StudyCountdown.isIdlePaused(now - 30_000L, now))
        // Prompt shown 60 seconds ago: exactly at the timeout, not yet idle.
        assertFalse(StudyCountdown.isIdlePaused(now - 60_000L, now))
        // Prompt shown 61 seconds ago: idle — countdown pauses.
        assertTrue(StudyCountdown.isIdlePaused(now - 61_000L, now))
        // Idle pauses the circle even while the study app is in front.
        assertEquals(
            StudyCountdown.State.PAUSED,
            StudyCountdown.state(true, false, StudyLock.Mode.STUDYING, true)
        )
        // …and the circle runs again once the prompt is tapped
        // (attention no longer overdue).
        assertEquals(
            StudyCountdown.State.RUNNING,
            StudyCountdown.state(true, false, StudyLock.Mode.STUDYING, false)
        )
    }
}

package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Self-block during Strict Mode (v6.1.0): Strict Guard's own
 * settings / dashboard activities must not open while Strict is on.
 * The launcher (home screen) and the block screen itself are exempt,
 * and Night Lock does NOT self-block.
 */
class SelfBlockTest {

    private val own = "app.strictguard"

    @Test
    fun ownSettingsActivitiesAreSelfBlocked() {
        assertTrue(BlockDecider.isOwnSettingsActivity(own, "$own.MainActivity", own))
        assertTrue(BlockDecider.isOwnSettingsActivity(own, "$own.StrictSetupActivity", own))
        assertTrue(BlockDecider.isOwnSettingsActivity(own, "$own.TamperLogActivity", own))
        assertTrue(BlockDecider.isOwnSettingsActivity(own, "$own.DiagnosticsActivity", own))
        assertTrue(BlockDecider.isOwnSettingsActivity(own, "$own.NightPickerActivity", own))
        assertTrue(BlockDecider.isOwnSettingsActivity(own, "$own.AppPickerActivity", own))
    }

    @Test
    fun launcherAndBlockScreenAreExempt() {
        assertFalse(BlockDecider.isOwnSettingsActivity(own, "$own.LauncherActivity", own))
        assertFalse(BlockDecider.isOwnSettingsActivity(own, "$own.BlockActivity", own))
    }

    @Test
    fun otherPackagesAndUnknownActivityAreNotSelfBlocked() {
        assertFalse(
            BlockDecider.isOwnSettingsActivity(
                "com.facebook.katana", "com.facebook.katana.MainActivity", own
            )
        )
        // Same simple class name, different app — not ours.
        assertFalse(
            BlockDecider.isOwnSettingsActivity(own, "com.other.MainActivity", own)
        )
        // No activity class known (UsageStats-only foreground): never
        // risk blocking the home screen on a guess.
        assertFalse(BlockDecider.isOwnSettingsActivity(own, null, own))
        assertFalse(BlockDecider.isOwnSettingsActivity("com.android.settings", null, own))
    }

    @Test
    fun tileTapDuringStrictIsSelfBlocked() {
        val decision = LauncherLogic.tapDecision(
            pkg = own, strict = true, night = false,
            nightAllowed = emptySet(), custom = emptySet(),
            limitReached = emptySet(), launcherPackages = emptySet(),
            ownPackage = own
        )
        assertEquals(BlockDecider.Kind.SELF_BLOCK, decision?.kind)
    }

    @Test
    fun tileTapOpensNormallyWhenStrictIsOff() {
        val decision = LauncherLogic.tapDecision(
            pkg = own, strict = false, night = false,
            nightAllowed = emptySet(), custom = emptySet(),
            limitReached = emptySet(), launcherPackages = emptySet(),
            ownPackage = own
        )
        assertNull(decision)
    }

    @Test
    fun nightLockAloneDoesNotSelfBlock() {
        // Night Lock keeps its old behaviour: the app stays openable
        // at night. Only Strict Mode self-blocks.
        val decision = LauncherLogic.tapDecision(
            pkg = own, strict = false, night = true,
            nightAllowed = emptySet(), custom = emptySet(),
            limitReached = emptySet(), launcherPackages = emptySet(),
            ownPackage = own
        )
        assertNull(decision)
    }

    @Test
    fun decideStillReturnsNullForOwnPackage() {
        // The guard service never relies on decide() for its own
        // package — it uses the separate isOwnSettingsActivity check
        // (activity-class level). decide() itself must stay null so
        // no other caller can accidentally block the launcher.
        val decision = BlockDecider.decide(
            pkg = own, strict = true, night = false,
            nightAllowed = emptySet(), custom = emptySet(),
            limitReached = emptySet(), isLauncher = false,
            ownPackage = own, foregroundActivity = "$own.MainActivity"
        )
        assertNull(decision)
    }

    @Test
    fun mainActivityForegroundDuringStrictIsCaught() {
        // The exact condition the guard service checks on every poll:
        // our own package in the foreground, on a settings activity,
        // while Strict is on.
        val strict = true
        val caught = strict && BlockDecider.isOwnSettingsActivity(
            own, "$own.MainActivity", own
        )
        assertTrue(caught)
        // Same screen, Strict off: not caught.
        assertFalse(
            false && BlockDecider.isOwnSettingsActivity(own, "$own.MainActivity", own)
        )
        // Launcher in the foreground, Strict on: not caught.
        assertFalse(
            strict && BlockDecider.isOwnSettingsActivity(
                own, "$own.LauncherActivity", own
            )
        )
    }
}

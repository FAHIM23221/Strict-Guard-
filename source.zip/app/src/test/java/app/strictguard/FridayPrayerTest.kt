package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v6.1.0 Friday prayer alarm tests — pure date / slot logic, no
 * Android framework.
 *
 * Friday ONLY, never daily. 09:00 alarm rings once; then only the
 * Jumu'ah countdown alerts for the 13:00 prayer: 10:00 (3h left),
 * 11:00 (2h), 12:00 (1h), 12:30 (30m), 13:00 (time for Jumu'ah) —
 * then STOP, no alerts after the prayer starts. The hourly
 * 10:00–19:00 plan was CANCELLED by Fahim.
 */
class FridayPrayerTest {

    /** Wall-clock instant in Asia/Dhaka. */
    private fun at(year: Int, month: Int, day: Int, hour: Int, min: Int = 0): Long =
        ZonedDateTime.of(year, month, day, hour, min, 0, 0, ZoneId.of("Asia/Dhaka"))
            .toInstant().toEpochMilli()

    // 13 November 2026 is a Friday; 14 November 2026 is a Saturday.
    private val friday = at(2026, 11, 13, 8, 0)
    private val saturday = at(2026, 11, 14, 8, 0)

    @Test
    fun fridayOnly() {
        assertTrue(FridayPrayer.isFriday(friday))
        assertFalse(FridayPrayer.isFriday(saturday))
        assertFalse(FridayPrayer.isFriday(at(2026, 11, 12, 8, 0))) // Thursday
        assertEquals("2026-11-13", FridayPrayer.dayKey(friday))
    }

    @Test
    fun nextFriday0900() {
        // Friday 08:00 → today 09:00.
        assertEquals(at(2026, 11, 13, 9, 0), FridayPrayer.nextFriday0900(friday))
        // Friday 10:00 → next Friday 09:00 (7 days later).
        assertEquals(at(2026, 11, 20, 9, 0), FridayPrayer.nextFriday0900(at(2026, 11, 13, 10, 0)))
        // Saturday → the following Friday.
        assertEquals(at(2026, 11, 20, 9, 0), FridayPrayer.nextFriday0900(saturday))
        // Sunday → the following Friday.
        assertEquals(at(2026, 11, 20, 9, 0), FridayPrayer.nextFriday0900(at(2026, 11, 15, 12, 0)))
    }

    @Test
    fun alarmRingsOnceOnFridayAtNine() {
        // Before 09:00: no.
        assertFalse(FridayPrayer.shouldRingAlarm(at(2026, 11, 13, 8, 59), true, ""))
        // At 09:00, not rung today: yes.
        assertTrue(FridayPrayer.shouldRingAlarm(at(2026, 11, 13, 9, 0), true, ""))
        // Already rung today: no (the AlarmManager path and the
        // guard-poll path share this day flag — never twice).
        assertFalse(
            FridayPrayer.shouldRingAlarm(at(2026, 11, 13, 9, 30), true, "2026-11-13")
        )
        // Saturday 09:00: never.
        assertFalse(FridayPrayer.shouldRingAlarm(at(2026, 11, 14, 9, 0), true, ""))
        // Toggle off: no.
        assertFalse(FridayPrayer.shouldRingAlarm(at(2026, 11, 13, 9, 0), false, ""))
    }

    @Test
    fun countdownAlertsFireInOrderThenStop() {
        // Before 10:00: nothing.
        assertNull(FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 9, 59), true, ""))
        // 10:00 → "10:00" (3 hours left).
        assertEquals("10:00", FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 10, 0), true, ""))
        // Once sent, it does not repeat.
        assertNull(
            FridayPrayer.dueCountdownAlert(
                at(2026, 11, 13, 10, 30), true, "2026-11-13|10:00"
            )
        )
        // 11:00 → "11:00" (2 hours left).
        assertEquals(
            "11:00",
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 11, 0), true, "2026-11-13|10:00")
        )
        // 12:00 → "12:00" (1 hour left).
        assertEquals(
            "12:00",
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 12, 0), true, "2026-11-13|11:00")
        )
        // 12:30 → "12:30" (30 minutes left).
        assertEquals(
            "12:30",
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 12, 30), true, "2026-11-13|12:00")
        )
        // 13:00 → "13:00" (time for Jumu'ah).
        assertEquals(
            "13:00",
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 13, 0), true, "2026-11-13|12:30")
        )
        // After 13:00: STOP — no more alerts, even hours later.
        assertNull(
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 14, 0), true, "2026-11-13|13:00")
        )
        assertNull(
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 19, 0), true, "2026-11-13|13:00")
        )
    }

    @Test
    fun noAlertsOnOtherDaysOrWhenDisabled() {
        assertNull(FridayPrayer.dueCountdownAlert(at(2026, 11, 14, 10, 0), true, ""))
        assertNull(FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 10, 0), false, ""))
    }

    @Test
    fun lateOpenFiresEarliestMissedSlotOnly() {
        // Phone off until 11:30: the earliest missed slot (10:00)
        // fires first; the next tick catches 11:00 up.
        assertEquals("10:00", FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 11, 30), true, ""))
    }

    @Test
    fun sentSlotsNeverRefire() {
        // Regression: only one "last sent" key is stored, so a slot
        // counts as sent when it is at or before the last sent
        // slot's time. At 12:00 with 11:00 already sent, the 10:00
        // alert must NOT fire again — 12:00 is due.
        assertEquals(
            "12:00",
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 12, 0), true, "2026-11-13|11:00")
        )
        // At 12:00 with only 10:00 sent, the missed 11:00 fires
        // first (catch-up, one per tick), not 12:00.
        assertEquals(
            "11:00",
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 12, 0), true, "2026-11-13|10:00")
        )
        // After 13:00 was sent, no slot fires again the same day.
        assertNull(
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 13, 30), true, "2026-11-13|13:00")
        )
        // A stale key from last Friday does not suppress today.
        assertEquals(
            "10:00",
            FridayPrayer.dueCountdownAlert(at(2026, 11, 13, 10, 30), true, "2026-11-06|13:00")
        )
    }

    @Test
    fun exactAlarmOnlyWhenPermitted() {
        assertTrue(FridayPrayer.useExactAlarm(true))
        assertFalse(FridayPrayer.useExactAlarm(false))
        assertEquals(9, FridayPrayer.ALARM_HOUR)
        assertEquals(13, FridayPrayer.PRAYER_HOUR)
        assertEquals(5, FridayPrayer.COUNTDOWN_SLOTS.size)
    }
}

package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.0.0 bypass hardening: the boot-gap decisions.
 *
 * Fahim's case: after power-off/power-on there is a window of a few
 * seconds before the guard starts, during which the app could be
 * uninstalled. These tests pin the three layers that close it:
 * direct-boot start from the device-protected mirror, normal-boot
 * start + launcher opening, and the Strict schedule surviving the
 * reboot (wall end recomputed into an elapsed end).
 */
class BootRestoreTest {

    private val nowWall = 1_792_000_000_000L // fixed "now" (Nov 2026)
    private val futureWall = nowWall + 4 * 60 * 60_000L // Strict ends in 4h
    private val pastWall = nowWall - 60_000L // Strict ended 1 minute ago

    // ---- Normal boot: start the guard when Strict is on or monitoring wanted ----

    @Test
    fun startGuardWhenStrictActive() {
        assertTrue(BootRestore.shouldStartGuard(strictActive = true, serviceWanted = false))
    }

    @Test
    fun startGuardWhenServiceWanted() {
        assertTrue(BootRestore.shouldStartGuard(strictActive = false, serviceWanted = true))
    }

    @Test
    fun noGuardStartWhenNothingWanted() {
        assertFalse(BootRestore.shouldStartGuard(strictActive = false, serviceWanted = false))
    }

    // ---- Direct boot (before unlock): the mirror decides ----

    @Test
    fun directBootStartsWhenStrictWallInFuture() {
        assertTrue(BootRestore.directBootGuardStart(futureWall, nowWall, serviceWanted = false))
    }

    @Test
    fun directBootDoesNotStartWhenStrictWallPassed() {
        assertFalse(BootRestore.directBootGuardStart(pastWall, nowWall, serviceWanted = false))
    }

    @Test
    fun directBootDoesNotStartWithNoMirror() {
        assertFalse(BootRestore.directBootGuardStart(0L, nowWall, serviceWanted = false))
    }

    @Test
    fun directBootStartsWhenServiceWantedEvenIfStrictEnded() {
        assertTrue(BootRestore.directBootGuardStart(pastWall, nowWall, serviceWanted = true))
    }

    // ---- Launcher opens immediately after boot ----

    @Test
    fun launcherOpensWhenStrictActive() {
        assertTrue(BootRestore.shouldOpenLauncher(strictActive = true, isDefaultHome = false))
    }

    @Test
    fun launcherOpensWhenDefaultHome() {
        assertTrue(BootRestore.shouldOpenLauncher(strictActive = false, isDefaultHome = true))
    }

    @Test
    fun launcherDoesNotOpenWhenStrictOffAndNotHome() {
        assertFalse(BootRestore.shouldOpenLauncher(strictActive = false, isDefaultHome = false))
    }

    // ---- Schedule survives reboot: wall end recomputed into elapsed end ----

    @Test
    fun recoveredEndIsFutureWhenWallEndInFuture() {
        val nowElapsed = 100_000L
        val recovered = Limits.recoveredElapsedEnd(nowElapsed, nowWall, futureWall)
        assertEquals(nowElapsed + (futureWall - nowWall), recovered)
        assertTrue(recovered > nowElapsed)
    }

    @Test
    fun recoveredEndIsZeroWhenWallEndPassed() {
        assertEquals(0L, Limits.recoveredElapsedEnd(100_000L, nowWall, pastWall))
    }

    @Test
    fun recoveredEndIsZeroWithNoWallEnd() {
        assertEquals(0L, Limits.recoveredElapsedEnd(100_000L, nowWall, 0L))
    }
}

package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.0 Break Cycle tests — pure cycle maths, no Android framework.
 *
 * Sessions: Facebook 40 min, YouTube 30 min, Chrome 45 min, AI 15 min.
 * Break: always 20 minutes. Daily limits unchanged
 * (Facebook 120, Chrome 90, YouTube 60, AI 30).
 */
class BreakCycleTest {

    private val now = 1_700_000_000_000L
    private val poll = Limits.POLL_MS

    @Test
    fun sessionQuotasMatchSpec() {
        assertEquals(40L * 60_000L, BreakCycle.sessionQuotaMs("facebook"))
        assertEquals(30L * 60_000L, BreakCycle.sessionQuotaMs("youtube"))
        assertEquals(45L * 60_000L, BreakCycle.sessionQuotaMs("chrome"))
        assertEquals(15L * 60_000L, BreakCycle.sessionQuotaMs("ai"))
        assertEquals(20L * 60_000L, BreakCycle.BREAK_MS)
    }

    @Test
    fun facebookSessionReachesQuotaAfter40Minutes() {
        // 40 minutes of ticks, daily total far below the 120 min limit.
        var session = 0L
        var outcome = BreakCycle.TickOutcome(0L, 0L, false)
        val ticks = (40L * 60_000L / poll).toInt()
        for (i in 1..ticks) {
            val daily = i * poll
            outcome = BreakCycle.onUseTick("facebook", session, poll, daily, Limits.FACEBOOK.limitMs, 0L, now)
            session = outcome.sessionUsedMs
            if (i < ticks) assertFalse(outcome.breakStarted)
        }
        assertTrue(outcome.breakStarted)
        assertEquals(now + BreakCycle.BREAK_MS, outcome.breakUntilMs)
        assertEquals(0L, outcome.sessionUsedMs)
    }

    @Test
    fun youtubeSessionReachesQuotaAfter30Minutes() {
        var session = 0L
        var outcome = BreakCycle.TickOutcome(0L, 0L, false)
        val ticks = (30L * 60_000L / poll).toInt()
        for (i in 1..ticks) {
            outcome = BreakCycle.onUseTick("youtube", session, poll, i * poll, Limits.YOUTUBE.limitMs, 0L, now)
            session = outcome.sessionUsedMs
        }
        assertTrue(outcome.breakStarted)
        assertEquals(now + BreakCycle.BREAK_MS, outcome.breakUntilMs)
    }

    @Test
    fun sessionCarriesOverAcrossAppOpens() {
        // 25 minutes used, app closed, reopened: session is NOT reset.
        val afterFirst = BreakCycle.onUseTick(
            "facebook", 25L * 60_000L, poll, 25L * 60_000L + poll,
            Limits.FACEBOOK.limitMs, 0L, now
        )
        assertFalse(afterFirst.breakStarted)
        assertEquals(25L * 60_000L + poll, afterFirst.sessionUsedMs)
        // 15 more minutes (25 + 15 = 40) reaches the quota.
        var session = afterFirst.sessionUsedMs
        var anyBreakStarted = false
        val ticks = (15L * 60_000L / poll).toInt()
        for (i in 1..ticks) {
            val outcome = BreakCycle.onUseTick(
                "facebook", session, poll, 40L * 60_000L,
                Limits.FACEBOOK.limitMs, 0L, now
            )
            session = outcome.sessionUsedMs
            if (outcome.breakStarted) anyBreakStarted = true
        }
        assertTrue(anyBreakStarted)
    }

    @Test
    fun inBreakNoUsageAccumulates() {
        val until = now + 10L * 60_000L
        val outcome = BreakCycle.onUseTick(
            "facebook", 0L, poll, 40L * 60_000L,
            Limits.FACEBOOK.limitMs, until, now
        )
        assertFalse(outcome.breakStarted)
        assertEquals(0L, outcome.sessionUsedMs)
        assertTrue(BreakCycle.isInBreak(until, now))
        assertFalse(BreakCycle.isInBreak(until, until))
        assertEquals(10L * 60_000L, BreakCycle.breakRemainingMs(until, now))
    }

    @Test
    fun dailyLimitWinsOverBreakAt120Minutes() {
        // Facebook's third session (40+40+40) reaches the daily 120 min
        // limit at the very same tick as the session quota: no break,
        // the app stays blocked for the rest of the day (LIMIT).
        val outcome = BreakCycle.onUseTick(
            "facebook", 40L * 60_000L - poll, poll, Limits.FACEBOOK.limitMs,
            Limits.FACEBOOK.limitMs, 0L, now
        )
        assertFalse(outcome.breakStarted)
        assertEquals(0L, outcome.breakUntilMs)
    }

    @Test
    fun deciderReturnsBreakWithCountdownDuringBreak() {
        val until = now + 12L * 60_000L
        val d = BlockDecider.decide(
            "com.facebook.katana", false, false, emptySet(), emptySet(),
            emptySet(), false, "app.strictguard", null,
            true, mapOf("facebook" to until), now
        )
        assertEquals(BlockDecider.Kind.BREAK, d?.kind)
        assertEquals("facebook", d?.groupId)
        assertEquals(until, d?.breakUntilMs)
    }

    @Test
    fun deciderReturnsLimitNotBreakWhenDailyLimitReached() {
        val until = now + 12L * 60_000L
        val d = BlockDecider.decide(
            "com.facebook.katana", false, false, emptySet(), emptySet(),
            setOf("facebook"), false, "app.strictguard", null,
            true, mapOf("facebook" to until), now
        )
        assertEquals(BlockDecider.Kind.LIMIT, d?.kind)
    }

    @Test
    fun deciderNoBreakWhenToggleOffOrBreakExpired() {
        // Toggle off: even a stored break end does not block.
        val until = now + 12L * 60_000L
        assertNull(
            BlockDecider.decide(
                "com.google.android.youtube", false, false, emptySet(), emptySet(),
                emptySet(), false, "app.strictguard", null,
                false, mapOf("youtube" to until), now
            )
        )
        // Break expired: the app may open again.
        assertNull(
            BlockDecider.decide(
                "com.google.android.youtube", false, false, emptySet(), emptySet(),
                emptySet(), false, "app.strictguard", null,
                true, mapOf("youtube" to until), until
            )
        )
    }

    @Test
    fun launcherTapEnforcesBreak() {
        val until = now + 20L * 60_000L
        val d = LauncherLogic.tapDecision(
            "com.google.android.youtube", false, false, emptySet(), emptySet(),
            emptySet(), emptySet(), "app.strictguard", null,
            true, mapOf("youtube" to until), now
        )
        assertEquals(BlockDecider.Kind.BREAK, d?.kind)
        assertEquals(until, d?.breakUntilMs)
    }

    @Test
    fun chromeAndAiCycles() {
        // Chrome: 45 min session, then break.
        var outcome = BreakCycle.onUseTick(
            "chrome", 45L * 60_000L - poll, poll, 45L * 60_000L,
            Limits.CHROME.limitMs, 0L, now
        )
        assertTrue(outcome.breakStarted)
        // AI: 15 min session, then break.
        outcome = BreakCycle.onUseTick(
            "ai", 15L * 60_000L - poll, poll, 15L * 60_000L,
            Limits.AI.limitMs, 0L, now
        )
        assertTrue(outcome.breakStarted)
    }
}

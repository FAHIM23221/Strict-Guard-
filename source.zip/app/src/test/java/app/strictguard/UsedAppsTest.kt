package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Hide Unused Apps (v6.1.0): used/unused classification, the 7-day
 * grace period for newly installed apps, Strict Guard always shown,
 * and the toggle being fully reversible (OFF restores the full list).
 */
class UsedAppsTest {

    private val dayMs = 24L * 60L * 60L * 1000L
    private val now = 1_800_000_000_000L
    private val own = "app.strictguard"

    private fun app(pkg: String) = LauncherLogic.AppEntry(pkg, pkg)

    @Test
    fun usedFiveDaysAgoIsShown() {
        assertTrue(
            UsedApps.isShown("com.example.bank", now - 5 * dayMs, now - 400 * dayMs, now, own)
        )
    }

    @Test
    fun unusedFortyDaysIsHidden() {
        assertFalse(
            UsedApps.isShown("com.example.old", now - 40 * dayMs, now - 400 * dayMs, now, own)
        )
    }

    @Test
    fun neverUsedIsHidden() {
        assertFalse(UsedApps.isShown("com.example.never", 0L, now - 400 * dayMs, now, own))
    }

    @Test
    fun installedTwoDaysAgoIsShown() {
        // 7-day grace period: shown until classified, even if never used.
        assertTrue(UsedApps.isShown("com.example.new", 0L, now - 2 * dayMs, now, own))
    }

    @Test
    fun installedTenDaysAgoNeverUsedIsHidden() {
        assertFalse(UsedApps.isShown("com.example.new", 0L, now - 10 * dayMs, now, own))
    }

    @Test
    fun strictGuardItselfAlwaysShown() {
        // Never used, installed long ago — still shown, pinned first.
        assertTrue(UsedApps.isShown(own, 0L, now - 400 * dayMs, now, own))
        assertTrue(UsedApps.isShown(own, 0L, 0L, now, own))
    }

    @Test
    fun boundaries() {
        // Used exactly 30 days ago: still shown (window inclusive).
        assertTrue(
            UsedApps.isShown("com.example.edge", now - 30 * dayMs, now - 400 * dayMs, now, own)
        )
        // Used 31 days ago: hidden.
        assertFalse(
            UsedApps.isShown("com.example.edge", now - 31 * dayMs, now - 400 * dayMs, now, own)
        )
        // Installed exactly 7 days ago: grace still applies.
        assertTrue(UsedApps.isShown("com.example.edge", 0L, now - 7 * dayMs, now, own))
        // Installed 8 days ago, never used: hidden.
        assertFalse(UsedApps.isShown("com.example.edge", 0L, now - 8 * dayMs, now, own))
    }

    @Test
    fun filterSplitsShownAndHidden() {
        val apps = listOf(
            app(own), app("com.used"), app("com.old"), app("com.never"), app("com.new")
        )
        val lastUsed = mapOf("com.used" to now - 5 * dayMs, "com.old" to now - 40 * dayMs)
        val installed = mapOf(
            own to now - 400 * dayMs,
            "com.used" to now - 400 * dayMs,
            "com.old" to now - 400 * dayMs,
            "com.never" to now - 400 * dayMs,
            "com.new" to now - 2 * dayMs
        )
        val (shown, hidden) = UsedApps.filterApps(apps, lastUsed, installed, now, own, true)
        assertEquals(listOf(own, "com.used", "com.new"), shown.map { it.pkg })
        assertEquals(listOf("com.old", "com.never"), hidden.map { it.pkg })
    }

    @Test
    fun toggleOffRestoresFullList() {
        // The clarification: turning the toggle OFF brings the full
        // grid back immediately — every app shown, none hidden, no
        // restart and no state to undo.
        val apps = listOf(
            app(own), app("com.used"), app("com.old"), app("com.never"), app("com.new")
        )
        val lastUsed = mapOf("com.used" to now - 5 * dayMs, "com.old" to now - 40 * dayMs)
        val installed = mapOf(
            own to now - 400 * dayMs,
            "com.used" to now - 400 * dayMs,
            "com.old" to now - 400 * dayMs,
            "com.never" to now - 400 * dayMs,
            "com.new" to now - 2 * dayMs
        )
        val (shown, hidden) = UsedApps.filterApps(apps, lastUsed, installed, now, own, false)
        assertEquals(apps.map { it.pkg }, shown.map { it.pkg })
        assertTrue(hidden.isEmpty())
        // And ON then OFF again restores the same full list.
        val (shownOn, _) = UsedApps.filterApps(apps, lastUsed, installed, now, own, true)
        assertEquals(3, shownOn.size)
        val (shownOff, hiddenOff) =
            UsedApps.filterApps(apps, lastUsed, installed, now, own, false)
        assertEquals(apps.map { it.pkg }, shownOff.map { it.pkg })
        assertTrue(hiddenOff.isEmpty())
    }

    @Test
    fun unknownInstallTimeGetsNoGrace() {
        assertFalse(UsedApps.isShown("com.example.unknown", 0L, 0L, now, own))
        // …but use still shows it.
        assertTrue(UsedApps.isShown("com.example.unknown", now - dayMs, 0L, now, own))
    }
}

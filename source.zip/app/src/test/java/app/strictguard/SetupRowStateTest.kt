package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * One-way setup permission buttons (v6.1.0): granted -> permanently
 * dead in the app; revoked outside the app -> re-enabled so the
 * guard can be repaired.
 */
class SetupRowStateTest {

    @Test
    fun grantedIsDead() {
        assertEquals(
            SetupRowState.State.GRANTED_DEAD,
            SetupRowState.state(done = true, wasGranted = true, strictLocked = false)
        )
        // Granted stays dead even during Strict (the app itself is
        // blocked during Strict anyway).
        assertEquals(
            SetupRowState.State.GRANTED_DEAD,
            SetupRowState.state(done = true, wasGranted = true, strictLocked = true)
        )
        // First sight of a granted permission is dead too.
        assertEquals(
            SetupRowState.State.GRANTED_DEAD,
            SetupRowState.state(done = true, wasGranted = false, strictLocked = false)
        )
    }

    @Test
    fun revokedReenables() {
        // Was granted before, now un-granted: the button must come
        // back so the permission can be granted again.
        assertEquals(
            SetupRowState.State.PENDING,
            SetupRowState.state(done = false, wasGranted = true, strictLocked = false)
        )
        assertTrue(SetupRowState.isRevocation(done = false, wasGranted = true))
    }

    @Test
    fun notGrantedAndNotRevoked() {
        assertEquals(
            SetupRowState.State.PENDING,
            SetupRowState.state(done = false, wasGranted = false, strictLocked = false)
        )
        assertFalse(SetupRowState.isRevocation(done = false, wasGranted = false))
        assertFalse(SetupRowState.isRevocation(done = true, wasGranted = true))
        assertFalse(SetupRowState.isRevocation(done = true, wasGranted = false))
    }

    @Test
    fun lockedDuringStrict() {
        assertEquals(
            SetupRowState.State.LOCKED,
            SetupRowState.state(done = false, wasGranted = false, strictLocked = true)
        )
        // A revoked button re-enables even during Strict in state
        // terms — but the app itself cannot be opened during Strict,
        // so the user only ever sees it after Strict ends.
        assertEquals(
            SetupRowState.State.PENDING,
            SetupRowState.state(done = false, wasGranted = true, strictLocked = true)
        )
    }

    @Test
    fun everySetupStepKeyCovered() {
        // The seven setup steps and their stable keys (MainActivity).
        val keys = listOf(
            "usage", "admin", "overlay", "launcher", "notif", "battery", "autostart"
        )
        assertEquals(7, keys.size)
        assertEquals(7, keys.toSet().size)
    }
}

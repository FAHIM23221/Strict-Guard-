package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

/** v5.2.0 tests: Strict schedule maths, sidebar packages.
 *  v5.2.1: the Shorts tests were replaced — the feature is removed
 *  (see the YouTube-normal tests below). */
class ScheduleTest {

    private val own = "app.strictguard"

    // ---- Strict schedule (Limits pure helpers) ----

    @Test
    fun wallEndForDaysAddsDays() {
        val now = 1_700_000_000_000L
        assertEquals(now + 7L * Limits.DAY_MS, Limits.wallEndForDays(now, 7))
        assertEquals(now + Limits.DAY_MS, Limits.wallEndForDays(now, 1))
        assertEquals(-1L, Limits.wallEndForDays(now, 0))
        // v6.1.0 cap: 1095 days (3 years). 365 is valid, 1095 is
        // valid, 1096 is rejected.
        assertEquals(now + 365L * Limits.DAY_MS, Limits.wallEndForDays(now, 365))
        assertEquals(now + 1095L * Limits.DAY_MS, Limits.wallEndForDays(now, 1095))
        assertEquals(-1L, Limits.wallEndForDays(now, 1096))
    }

    @Test
    fun validScheduleDaysRange() {
        assertFalse(Limits.validScheduleDays(0))
        assertTrue(Limits.validScheduleDays(1))
        assertTrue(Limits.validScheduleDays(365))
        // v6.1.0: cap raised from 365 to 1095 days (3 years).
        assertTrue(Limits.validScheduleDays(1095))
        assertFalse(Limits.validScheduleDays(1096))
        assertEquals(1095, Limits.MAX_STRICT_DAYS)
    }

    @Test
    fun wallEndForDateTimeMatchesCalendar() {
        val end = Limits.wallEndForDateTime(2027, Calendar.JANUARY, 15, 10, 30)
        val cal = Calendar.getInstance().apply {
            set(2027, Calendar.JANUARY, 15, 10, 30, 0)
            set(Calendar.MILLISECOND, 0)
        }
        assertEquals(cal.timeInMillis, end)
    }

    @Test
    fun validScheduleDateTimeWindow() {
        val now = System.currentTimeMillis()
        assertFalse(Limits.validScheduleDateTime(now, now)) // not in future
        assertFalse(Limits.validScheduleDateTime(now + 30_000L, now)) // < 1 min ahead
        assertTrue(Limits.validScheduleDateTime(now + 60_000L * 60L, now)) // 1 h ahead
        assertTrue(Limits.validScheduleDateTime(now + 365L * Limits.DAY_MS, now))
        // v6.1.0: chosen date up to 1095 days ahead is valid, beyond is not.
        assertTrue(Limits.validScheduleDateTime(now + 1095L * Limits.DAY_MS, now))
        assertFalse(Limits.validScheduleDateTime(now + 1096L * Limits.DAY_MS, now))
    }

    @Test
    fun strictWallActive() {
        assertTrue(Limits.strictWallActive(1000L, 5000L))
        assertFalse(Limits.strictWallActive(5000L, 5000L))
        assertFalse(Limits.strictWallActive(6000L, 5000L))
        assertFalse(Limits.strictWallActive(1000L, 0L))
    }

    @Test
    fun recoveredElapsedEndAfterReboot() {
        // Wall end 2 h ahead: elapsed end is now-elapsed + 2 h.
        assertEquals(
            10_000L + 2L * 60L * 60L * 1000L,
            Limits.recoveredElapsedEnd(10_000L, 1_000_000L, 1_000_000L + 2L * 60L * 60L * 1000L)
        )
        // Wall end already passed: Strict is over, elapsed end is 0.
        assertEquals(0L, Limits.recoveredElapsedEnd(10_000L, 2_000_000L, 1_000_000L))
    }

    // ---- v5.2.1: YouTube Shorts feature REMOVED ----
    // YouTube behaves exactly as in v5.1.0: usable when Strict is off,
    // Night Lock is off and its daily limit is not reached. There is
    // no Shorts toggle and no SHORTS decision kind any more.

    @Test
    fun shortsKindGone() {
        assertFalse(
            BlockDecider.Kind.values().any { it.name == "SHORTS" }
        )
    }

    @Test
    fun youtubeUsableWhenNothingActive() {
        assertNull(
            BlockDecider.decide(
                "com.google.android.youtube", false, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
        assertNull(
            BlockDecider.decide(
                "com.google.android.apps.youtube.music", false, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
    }

    @Test
    fun youtubeStillBlockedDuringStrictAsGroup() {
        assertEquals(
            BlockDecider.Kind.STRICT_GROUP,
            BlockDecider.decide(
                "com.google.android.youtube", true, false,
                emptySet(), emptySet(), emptySet(), false, own
            )?.kind
        )
    }

    // ---- Sidebar / Smart Panel packages ----

    @Test
    fun smartPanelBlockedDuringStrict() {
        assertEquals(
            BlockDecider.Kind.STRICT_BYPASS,
            BlockDecider.decide(
                "com.transsion.smartpanel", true, false,
                emptySet(), emptySet(), emptySet(), false, own
            )?.kind
        )
    }

    @Test
    fun xosLauncherBlockedDuringStrictWhenNotCurrentLauncher() {
        assertEquals(
            BlockDecider.Kind.STRICT_BYPASS,
            BlockDecider.decide(
                "com.transsion.XOSLauncher", true, false,
                emptySet(), emptySet(), emptySet(), false, own
            )?.kind
        )
    }

    @Test
    fun smartPanelNotBlockedWhenStrictOff() {
        assertNull(
            BlockDecider.decide(
                "com.transsion.smartpanel", false, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
    }
}

package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.2 — Study Lock deadlock regression tests.
 *
 * What Fahim saw on 2026-11-08 23:16 (screenshots): during an
 * active Study Lock, tapping eTestPaper showed the block screen
 * FOR eTestPaper itself ("Study Lock is on — only e test paper
 * … until the 15 minutes are done"), and the launcher showed a
 * lock badge on EVERY app including eTestPaper — so the 15 fair
 * minutes could never be completed and the lock could never end.
 *
 * Root cause: the lock recognised only the ORIGINAL Play Store
 * package com.nextive.eTestPaper. That listing was removed from
 * Google Play on 2026-07-08 and replaced by the live listing
 * "E-Test Paper : Smart Practice" (on Play since July 2026,
 * v2.4.4, updated 2026-11-05) whose package is
 * com.nextive.etestpaper — same letters, all lower-case.
 * Android package names are case-sensitive, so Fahim's installed
 * app was treated as "any other app" and blocked by its own lock.
 *
 * The fix: BOTH packages count as the study app
 * ([StudyLock.isStudyApp]), and [BlockDecider.decide] exempts
 * the study app FIRST, before every other rule, while a lock is
 * active — so no branch can ever re-decide it as blocked.
 */
class StudyLockDeadlockTest {

    private val own = "app.strictguard"
    private val oldPkg = "com.nextive.eTestPaper"
    private val livePkg = "com.nextive.etestpaper"
    private val otherApp = "com.facebook.katana"

    // ---- the study app is recognised, both packages ----

    @Test
    fun bothPackagesAreTheStudyApp() {
        assertTrue(StudyLock.isStudyApp(oldPkg))
        assertTrue(StudyLock.isStudyApp(livePkg))
        assertFalse(StudyLock.isStudyApp(otherApp))
        assertFalse(StudyLock.isStudyApp("com.android.chrome"))
        assertEquals(
            setOf(oldPkg, livePkg),
            StudyLock.STUDY_APP_PACKAGES
        )
    }

    // ---- decideStudy: the study app is never blocked by the lock ----

    @Test
    fun decideStudyAllowsBothStudyAppPackages() {
        assertNull(BlockDecider.decideStudy(livePkg, true, false, oldPkg, false))
        assertNull(BlockDecider.decideStudy(oldPkg, true, false, oldPkg, false))
        // …even when the study app is (wrongly) thought missing.
        assertNull(BlockDecider.decideStudy(livePkg, true, true, oldPkg, false))
    }

    @Test
    fun decideStudyStillBlocksOtherApps() {
        assertEquals(
            BlockDecider.Kind.STUDY,
            BlockDecider.decideStudy(otherApp, true, false, oldPkg, false)?.kind
        )
        assertEquals(
            BlockDecider.Kind.STUDY,
            BlockDecider.decideStudy("com.android.chrome", true, false, oldPkg, false)?.kind
        )
    }

    @Test
    fun decideStudyPhoneAppsStillExempt() {
        assertNull(BlockDecider.decideStudy("com.android.dialer", true, false, oldPkg, true))
    }

    // ---- decide(): defence in depth — no rule may block the study app during a lock ----

    @Test
    fun decideAllowsLivePackageDuringStudyLock() {
        // Plain lock, nothing else on.
        assertNull(
            BlockDecider.decide(
                livePkg, false, false, emptySet(), emptySet(), emptySet(),
                false, own, studyActive = true
            )
        )
    }

    @Test
    fun decideAllowsLivePackageEvenWithNightAndStrictOn() {
        // Night Lock on, Strict on, study app even on the custom
        // list: the lock's own app must still open. (Night hours
        // covering 21:00, or Strict running, must not re-block it.)
        assertNull(
            BlockDecider.decide(
                livePkg, true, true, emptySet(), setOf(livePkg), emptySet(),
                false, own, studyActive = true
            )
        )
        assertNull(
            BlockDecider.decide(
                oldPkg, true, true, emptySet(), setOf(oldPkg), emptySet(),
                false, own, studyActive = true
            )
        )
    }

    @Test
    fun decideStillBlocksOtherAppsDuringStudyLock() {
        assertEquals(
            BlockDecider.Kind.STUDY,
            BlockDecider.decide(
                otherApp, false, false, emptySet(), emptySet(), emptySet(),
                false, own, studyActive = true
            )?.kind
        )
        assertEquals(
            BlockDecider.Kind.STUDY,
            BlockDecider.decide(
                "com.android.chrome", true, true, emptySet(), emptySet(), emptySet(),
                false, own, studyActive = true
            )?.kind
        )
    }

    @Test
    fun decideDoesNotBlockStudyAppWhenNoLockIsActive() {
        // No lock: normal rules apply (here, nothing blocks it).
        assertNull(
            BlockDecider.decide(
                livePkg, false, false, emptySet(), emptySet(), emptySet(),
                false, own, studyActive = false
            )
        )
    }

    // ---- launcher: no lock badge on the study app during a lock ----

    @Test
    fun launcherTapAllowsStudyAppDuringLock() {
        // tapDecision == null means "may open": no lock badge, no
        // block screen. This is what the launcher grid shows.
        val tap = LauncherLogic.tapDecision(
            livePkg, false, false, emptySet(), emptySet(), emptySet(),
            emptySet(), own, studyActive = true, studyMissing = false
        )
        assertNull(tap)
        assertNull(
            LauncherLogic.tapDecision(
                oldPkg, false, false, emptySet(), emptySet(), emptySet(),
                emptySet(), own, studyActive = true, studyMissing = false
            )
        )
    }

    @Test
    fun launcherTapStillBlocksOtherAppsDuringLock() {
        val tap = LauncherLogic.tapDecision(
            otherApp, false, false, emptySet(), emptySet(), emptySet(),
            emptySet(), own, studyActive = true, studyMissing = false
        )
        assertEquals(BlockDecider.Kind.STUDY, tap?.kind)
    }
}

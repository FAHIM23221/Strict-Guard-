package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Auto theme by time (v6.1.0): Dark at 18:00, Light at 06:00,
 * Asia/Dhaka. Boundary cases + the manual-override rule (a manual
 * theme change holds until the next scheduled switch).
 */
class AutoThemeTest {

    private fun dhakaMs(day: Int, hour: Int, minute: Int): Long =
        ZonedDateTime.of(
            2026, 11, day, hour, minute, 0, 0, ZoneId.of(AutoTheme.ZONE_ID)
        ).toInstant().toEpochMilli()

    @Test
    fun desiredThemeBoundaries() {
        assertEquals("dark", AutoTheme.desiredTheme(0))
        assertEquals("dark", AutoTheme.desiredTheme(5))
        assertEquals("light", AutoTheme.desiredTheme(6))
        assertEquals("light", AutoTheme.desiredTheme(11))
        assertEquals("light", AutoTheme.desiredTheme(17))
        assertEquals("dark", AutoTheme.desiredTheme(18))
        assertEquals("dark", AutoTheme.desiredTheme(23))
    }

    @Test
    fun hourInDhakaAroundBothSwitches() {
        assertEquals(5, AutoTheme.hourInDhaka(dhakaMs(8, 5, 59)))
        assertEquals(6, AutoTheme.hourInDhaka(dhakaMs(8, 6, 0)))
        assertEquals(6, AutoTheme.hourInDhaka(dhakaMs(8, 6, 1)))
        assertEquals(17, AutoTheme.hourInDhaka(dhakaMs(8, 17, 59)))
        assertEquals(18, AutoTheme.hourInDhaka(dhakaMs(8, 18, 0)))
        assertEquals(0, AutoTheme.hourInDhaka(dhakaMs(9, 0, 0)))
        // 00:30 UTC is 06:30 in Dhaka (UTC+6, no DST).
        val utcHalfPastMidnight = ZonedDateTime.of(
            2026, 11, 8, 0, 30, 0, 0, ZoneId.of("UTC")
        ).toInstant().toEpochMilli()
        assertEquals(6, AutoTheme.hourInDhaka(utcHalfPastMidnight))
    }

    @Test
    fun themeToApplyOffMeansNever() {
        assertEquals(null, AutoTheme.themeToApply(false, dhakaMs(8, 10, 0), null))
        assertEquals(null, AutoTheme.themeToApply(false, dhakaMs(8, 19, 0), "light"))
    }

    @Test
    fun freshInstallAppliesCurrentPeriodTheme() {
        assertEquals("light", AutoTheme.themeToApply(true, dhakaMs(8, 10, 0), null))
        assertEquals("dark", AutoTheme.themeToApply(true, dhakaMs(8, 22, 0), null))
        assertEquals("dark", AutoTheme.themeToApply(true, dhakaMs(8, 5, 30), null))
    }

    @Test
    fun noReapplyWhenAlreadyApplied() {
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 10, 0), "light"))
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 22, 0), "dark"))
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 5, 30), "dark"))
    }

    @Test
    fun switchFiresExactlyAtBoundaries() {
        // Last applied light at 06:00; 17:59 is still light, 18:00 is dark.
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 17, 59), "light"))
        assertEquals("dark", AutoTheme.themeToApply(true, dhakaMs(8, 18, 0), "light"))
        // Last applied dark at 18:00; 05:59 is still dark, 06:00 is light.
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(9, 5, 59), "dark"))
        assertEquals("light", AutoTheme.themeToApply(true, dhakaMs(9, 6, 0), "dark"))
    }

    @Test
    fun manualOverrideHoldsUntilNextSwitch() {
        // 06:00 auto-applied light. The user manually picks dark at
        // 10:00 (lastApplied stays "light"). Nothing is forced back
        // at noon, but the 18:00 switch still fires.
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 12, 0), "light"))
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 17, 59), "light"))
        assertEquals("dark", AutoTheme.themeToApply(true, dhakaMs(8, 18, 0), "light"))
        // 18:00 auto-applied dark. The user manually picks light at
        // 20:00 (lastApplied stays "dark"). Nothing is forced back
        // at 23:00, but the next 06:00 switch still fires.
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 23, 0), "dark"))
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(9, 5, 59), "dark"))
        assertEquals("light", AutoTheme.themeToApply(true, dhakaMs(9, 6, 0), "dark"))
    }

    @Test
    fun fullDaySequence() {
        var lastApplied: String? = null
        // Before dawn: dark. 06:00: light. Rest of the day: nothing.
        assertEquals("dark", AutoTheme.themeToApply(true, dhakaMs(8, 5, 0), lastApplied))
        lastApplied = "dark"
        assertEquals("light", AutoTheme.themeToApply(true, dhakaMs(8, 6, 0), lastApplied))
        lastApplied = "light"
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 12, 0), lastApplied))
        assertEquals(null, AutoTheme.themeToApply(true, dhakaMs(8, 17, 59), lastApplied))
        // 18:00: dark again.
        assertEquals("dark", AutoTheme.themeToApply(true, dhakaMs(8, 18, 0), lastApplied))
    }
}

package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LauncherTest {

    private val own = "app.strictguard"
    private val launchers = setOf("com.transsion.XOSLauncher", "com.android.launcher3")

    // ---- Greetings (Bengali day parts; 17:05 is বিকেল, as in Fahim's screenshot) ----

    @Test
    fun greetingMorning() {
        assertEquals(LauncherLogic.Greeting.MORNING, LauncherLogic.greetingFor(5))
        assertEquals(LauncherLogic.Greeting.MORNING, LauncherLogic.greetingFor(11))
    }

    @Test
    fun greetingNoonAfternoonEveningNight() {
        assertEquals(LauncherLogic.Greeting.NOON, LauncherLogic.greetingFor(12))
        assertEquals(LauncherLogic.Greeting.NOON, LauncherLogic.greetingFor(15))
        assertEquals(LauncherLogic.Greeting.AFTERNOON, LauncherLogic.greetingFor(16))
        assertEquals(LauncherLogic.Greeting.AFTERNOON, LauncherLogic.greetingFor(17))
        assertEquals(LauncherLogic.Greeting.AFTERNOON, LauncherLogic.greetingFor(18))
        assertEquals(LauncherLogic.Greeting.EVENING, LauncherLogic.greetingFor(19))
        assertEquals(LauncherLogic.Greeting.EVENING, LauncherLogic.greetingFor(20))
        assertEquals(LauncherLogic.Greeting.NIGHT, LauncherLogic.greetingFor(21))
        assertEquals(LauncherLogic.Greeting.NIGHT, LauncherLogic.greetingFor(0))
        assertEquals(LauncherLogic.Greeting.NIGHT, LauncherLogic.greetingFor(4))
    }

    // ---- Short duration text, as on the usage bars ----

    @Test
    fun formatShortDurations() {
        assertEquals("0m", LauncherLogic.formatShort(0L, false))
        assertEquals("5m", LauncherLogic.formatShort(5 * 60_000L, false))
        assertEquals("1h", LauncherLogic.formatShort(60 * 60_000L, false))
        assertEquals("1h 46m", LauncherLogic.formatShort(106 * 60_000L, false))
        assertEquals("2h", LauncherLogic.formatShort(120 * 60_000L, false))
        assertEquals("30m", LauncherLogic.formatShort(30 * 60_000L, false))
    }

    @Test
    fun formatShortBengaliDigits() {
        assertEquals("১h ৪৬m", LauncherLogic.formatShort(106 * 60_000L, true))
        assertEquals("২h", LauncherLogic.formatShort(120 * 60_000L, true))
    }

    @Test
    fun usageTextUsedOverLimit() {
        assertEquals("1h 46m / 2h", LauncherLogic.usageText(106 * 60_000L, 120 * 60_000L, false))
        assertEquals("5m / 1h 30m", LauncherLogic.usageText(5 * 60_000L, 90 * 60_000L, false))
        assertEquals("1h / 1h", LauncherLogic.usageText(60 * 60_000L, 60 * 60_000L, false))
    }

    // ---- App grid sorting: Strict Guard pinned first, rest alphabetical ----

    @Test
    fun sortAppsPinsOwnFirst() {
        val apps = listOf(
            LauncherLogic.AppEntry("com.example.zebra", "Zebra"),
            LauncherLogic.AppEntry(own, "Strict Guard"),
            LauncherLogic.AppEntry("com.example.apple", "Apple")
        )
        val sorted = LauncherLogic.sortApps(apps, own)
        assertEquals(own, sorted[0].pkg)
        assertEquals("Apple", sorted[1].label)
        assertEquals("Zebra", sorted[2].label)
    }

    @Test
    fun sortAppsDedupes() {
        val apps = listOf(
            LauncherLogic.AppEntry("com.example.a", "A"),
            LauncherLogic.AppEntry("com.example.a", "A")
        )
        assertEquals(1, LauncherLogic.sortApps(apps, own).size)
    }

    // ---- Tap decisions: the launcher enforces the same rules as the guard ----

    private fun tap(
        pkg: String, strict: Boolean = false, night: Boolean = false,
        nightAllowed: Set<String> = emptySet(),
        custom: Set<String> = emptySet(),
        limitReached: Set<String> = emptySet()
    ) = LauncherLogic.tapDecision(
        pkg, strict, night, nightAllowed, custom, limitReached, launchers, own
    )

    // v6.1.0 self-block: tapping Strict Guard itself during Strict
    // Mode shows the block screen instead of opening the app; when
    // Strict is off (or only Night Lock is on) it still opens.
    @Test
    fun tapOwnAppSelfBlockedDuringStrict() {
        val d = tap(own, strict = true, night = true)
        assertEquals(BlockDecider.Kind.SELF_BLOCK, d?.kind)
    }

    @Test
    fun tapOwnAppOpensWhenStrictIsOff() {
        assertNull(tap(own, strict = false, night = false))
        assertNull(tap(own, strict = false, night = true))
    }

    @Test
    fun tapBlockedDuringStrict() {
        val d = tap("com.facebook.katana", strict = true)
        assertEquals(BlockDecider.Kind.STRICT_GROUP, d?.kind)
        assertEquals("facebook", d?.groupId)
    }

    @Test
    fun tapAllowedAppOpensWhenNotStrict() {
        assertNull(tap("com.example.game"))
        assertNull(tap("com.google.android.youtube"))
    }

    @Test
    fun tapLimitReachedBlocks() {
        val d = tap("com.google.android.youtube", limitReached = setOf("youtube"))
        assertEquals(BlockDecider.Kind.LIMIT, d?.kind)
    }

    @Test
    fun tapCustomBlockedDuringStrict() {
        val d = tap("com.example.game", strict = true, custom = setOf("com.example.game"))
        assertEquals(BlockDecider.Kind.CUSTOM, d?.kind)
    }

    @Test
    fun tapNightBlocksNonAllowed() {
        val d = tap("com.example.game", night = true, nightAllowed = setOf("com.android.dialer"))
        assertEquals(BlockDecider.Kind.NIGHT, d?.kind)
        assertNull(tap("com.android.dialer", night = true, nightAllowed = setOf("com.android.dialer")))
    }

    @Test
    fun tapOtherLauncherBlockedDuringStrict() {
        // Tapping the system launcher from our launcher during Strict
        // must not escape to the system home screen.
        val d = tap("com.transsion.XOSLauncher", strict = true)
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun tapOtherLauncherAllowedWhenNotStrict() {
        assertNull(tap("com.transsion.XOSLauncher"))
    }

    @Test
    fun tapSettingsBlockedDuringStrict() {
        val d = tap("com.android.settings", strict = true)
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun tapDecisionReturnsNonNullForBlocked() {
        assertNotNull(tap("com.facebook.katana", strict = true))
        assertTrue(tap("com.example.game", strict = false) == null)
    }
}

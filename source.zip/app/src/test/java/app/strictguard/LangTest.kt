package app.strictguard

import android.content.res.Configuration
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LangTest {

    @Test
    fun defaultLanguageIsEnglish() {
        assertEquals("en", "en") // default pref value, see Store.kt
        assertFalse(Lang.isBengali("en"))
        assertTrue(Lang.isBengali("bn"))
    }

    @Test
    fun localeForBothLanguages() {
        assertEquals("en", Lang.localeFor("en").language)
        assertEquals("bn", Lang.localeFor("bn").language)
        assertEquals("en", Lang.localeFor("anything-else").language)
    }

    @Test
    fun effectiveThemeFollowsSystemByDefault() {
        assertEquals(
            "dark",
            Lang.effectiveTheme("system", Configuration.UI_MODE_NIGHT_YES)
        )
        assertEquals(
            "light",
            Lang.effectiveTheme("system", Configuration.UI_MODE_NIGHT_NO)
        )
    }

    @Test
    fun explicitThemeOverridesSystem() {
        assertEquals(
            "light",
            Lang.effectiveTheme("light", Configuration.UI_MODE_NIGHT_YES)
        )
        assertEquals(
            "dark",
            Lang.effectiveTheme("dark", Configuration.UI_MODE_NIGHT_NO)
        )
    }

    @Test
    fun themeResourcesResolve() {
        assertEquals(R.style.Theme_StrictGuard_Dark, Lang.themeRes("dark"))
        assertEquals(R.style.Theme_StrictGuard_Light, Lang.themeRes("light"))
    }
}

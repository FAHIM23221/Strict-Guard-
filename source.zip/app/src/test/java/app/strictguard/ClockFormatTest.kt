package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Clock format toggle (v6.1.0): 24-hour is the default, 12-hour
 * shows a clear AM/PM marker (EN/BN).
 */
class ClockFormatTest {

    @Test
    fun requiredCasesTwelveHour() {
        // Midnight 00:05 -> 12:05 AM, noon 12:05 -> 12:05 PM,
        // 17:05 -> 5:05 PM, 23:59 -> 11:59 PM.
        assertEquals("12:05 AM", ClockFormat.format(0, 5, false, false))
        assertEquals("12:05 PM", ClockFormat.format(12, 5, false, false))
        assertEquals("5:05 PM", ClockFormat.format(17, 5, false, false))
        assertEquals("11:59 PM", ClockFormat.format(23, 59, false, false))
    }

    @Test
    fun twelveHourEdges() {
        assertEquals("12:00 AM", ClockFormat.format(0, 0, false, false))
        assertEquals("12:00 PM", ClockFormat.format(12, 0, false, false))
        assertEquals("1:30 AM", ClockFormat.format(1, 30, false, false))
        assertEquals("1:30 PM", ClockFormat.format(13, 30, false, false))
        assertEquals("11:59 AM", ClockFormat.format(11, 59, false, false))
    }

    @Test
    fun twentyFourHourUnchanged() {
        assertEquals("00:05", ClockFormat.format(0, 5, true, false))
        assertEquals("12:05", ClockFormat.format(12, 5, true, false))
        assertEquals("17:05", ClockFormat.format(17, 5, true, false))
        assertEquals("23:59", ClockFormat.format(23, 59, true, false))
    }

    @Test
    fun bengaliMarkers() {
        assertEquals("12:05 পূর্বাহ্ণ", ClockFormat.format(0, 5, false, true))
        assertEquals("5:05 অপরাহ্ণ", ClockFormat.format(17, 5, false, true))
        assertEquals("12:05 অপরাহ্ণ", ClockFormat.format(12, 5, false, true))
        assertEquals("11:59 অপরাহ্ণ", ClockFormat.format(23, 59, false, true))
        // 24-hour is the same in both languages.
        assertEquals("17:05", ClockFormat.format(17, 5, true, true))
    }
}

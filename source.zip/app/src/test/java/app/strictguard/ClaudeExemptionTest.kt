package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v6.1.0 Claude exemption tests — pure logic, no Android framework.
 *
 * v6.1.3: the exemption is now TOTAL (Fahim reversed his v6.1.0
 * decision on 2026-11-09). Claude is one of the six always-unlocked
 * apps in [AlwaysAllowed]: exempt from the AI daily limit (30 min)
 * and the AI break cycle AND from Strict Mode, Night Lock, Study
 * Lock, the entry delay and the custom list. It stays in the AI
 * group, so the group still resolves for the other AI apps
 * (ChatGPT, Gemini, Copilot, …), which stay limited.
 */
class ClaudeExemptionTest {

    private val now = 1_700_000_000_000L
    private val claude = "com.anthropic.claude"
    private val chatgpt = "com.openai.chatgpt"

    @Test
    fun claudePackageIsVerified() {
        // The exemption key is the exact package from the AI group
        // list, confirmed against Google Play (id=com.anthropic.claude).
        assertEquals("com.anthropic.claude", Limits.CLAUDE_PACKAGE)
        assertTrue(Limits.isLimitExempt(claude))
        assertFalse(Limits.isLimitExempt(chatgpt))
        assertFalse(Limits.isLimitExempt("com.google.android.apps.bard"))
    }

    @Test
    fun claudeStaysInAiGroup() {
        // The exemption is NOT a removal from the group: Strict and
        // Night blocking go through groupFor(), so Claude must still
        // resolve to the AI group.
        assertEquals("ai", Limits.groupFor(claude)?.id)
        assertEquals("ai", Limits.groupFor(chatgpt)?.id)
    }

    @Test
    fun claudeNotBlockedByUsedUpAiLimit() {
        // ChatGPT (or another AI app) used up the 30-minute AI limit.
        // Claude must still open.
        val d = BlockDecider.decide(
            claude, false, false, emptySet(), emptySet(),
            setOf("ai"), false, "app.strictguard", null
        )
        assertNull(d)
    }

    @Test
    fun otherAiAppsStillBlockedByAiLimit() {
        val d = BlockDecider.decide(
            chatgpt, false, false, emptySet(), emptySet(),
            setOf("ai"), false, "app.strictguard", null
        )
        assertEquals(BlockDecider.Kind.LIMIT, d?.kind)
    }

    @Test
    fun claudeNotBlockedByAiBreak() {
        // An AI break is active (e.g. ChatGPT's 15-minute session
        // ended). Claude must still open — it has no break.
        val until = now + 20L * 60_000L
        val d = BlockDecider.decide(
            claude, false, false, emptySet(), emptySet(),
            emptySet(), false, "app.strictguard", null,
            true, mapOf("ai" to until), now
        )
        assertNull(d)
    }

    @Test
    fun otherAiAppsStillBlockedByAiBreak() {
        val until = now + 20L * 60_000L
        val d = BlockDecider.decide(
            chatgpt, false, false, emptySet(), emptySet(),
            emptySet(), false, "app.strictguard", null,
            true, mapOf("ai" to until), now
        )
        assertEquals(BlockDecider.Kind.BREAK, d?.kind)
        assertEquals(until, d?.breakUntilMs)
    }

    @Test
    fun claudeNowAllowedDuringStrictMode() {
        // v6.1.3 reversal: Fahim now wants Claude fully exempt —
        // Strict Mode no longer blocks it, even though it is in
        // the AI group.
        val d = BlockDecider.decide(
            claude, true, false, emptySet(), emptySet(),
            emptySet(), false, "app.strictguard", null
        )
        assertNull(d)
    }

    @Test
    fun claudeNowAllowedDuringNightLock() {
        // v6.1.3 reversal: Night Lock no longer blocks Claude either.
        val d = BlockDecider.decide(
            claude, false, true, emptySet(), emptySet(),
            emptySet(), false, "app.strictguard", null
        )
        assertNull(d)
    }

    @Test
    fun claudeAllowedDuringNightLockIfNightAllowed() {
        // Night Lock's allowed-apps list still applies to Claude.
        val d = BlockDecider.decide(
            claude, false, true, setOf(claude), emptySet(),
            emptySet(), false, "app.strictguard", null
        )
        assertNull(d)
    }

    @Test
    fun launcherTapClaudeNotBlockedByAiLimitOrStrict() {
        val free = LauncherLogic.tapDecision(
            claude, false, false, emptySet(), emptySet(),
            setOf("ai"), emptySet(), "app.strictguard", null
        )
        assertNull(free)
        // v6.1.3: Strict Mode no longer blocks the launcher tile either.
        val strict = LauncherLogic.tapDecision(
            claude, true, false, emptySet(), emptySet(),
            emptySet(), emptySet(), "app.strictguard", null
        )
        assertNull(strict)
    }
}

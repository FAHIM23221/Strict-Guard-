package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * v6.1.0 Strict-state mirror tests — pure encode / decode / decide
 * logic, no Android framework.
 *
 * The device uses the Android Keystore ([KeystoreMirrorCrypto]);
 * here a JCE test crypto with a fixed in-memory key stands in for
 * it, exercising the same [MirrorCrypto] contract (AES/GCM + HMAC).
 */
class StrictMirrorTest {

    /** Test-only [MirrorCrypto]: AES/GCM + HMAC-SHA256, fixed keys. */
    private class TestCrypto : MirrorCrypto {
        private val encKey: SecretKey = run {
            val gen = KeyGenerator.getInstance("AES")
            gen.init(256)
            gen.generateKey()
        }
        private val macKey: SecretKey = SecretKeySpec(
            ByteArray(32) { (it * 7 + 3).toByte() }, "HmacSHA256"
        )

        override fun encrypt(plain: ByteArray): ByteArray {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, encKey)
            val body = cipher.iv + cipher.doFinal(plain)
            val mac = Mac.getInstance("HmacSHA256").apply { init(macKey) }.doFinal(body)
            return body + mac
        }

        override fun decrypt(data: ByteArray): ByteArray? {
            return try {
                if (data.size < 12 + 32 + 16) return null
                val body = data.copyOfRange(0, data.size - 32)
                val tag = data.copyOfRange(data.size - 32, data.size)
                val expected = Mac.getInstance("HmacSHA256").apply { init(macKey) }.doFinal(body)
                if (!tag.contentEquals(expected)) return null
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(
                    Cipher.DECRYPT_MODE, encKey,
                    GCMParameterSpec(128, body.copyOfRange(0, 12))
                )
                cipher.doFinal(body.copyOfRange(12, body.size))
            } catch (e: Exception) {
                null
            }
        }
    }

    private val crypto = TestCrypto()
    private val now = 1_700_000_000_000L

    @Test
    fun roundTripKeepsEndTimeAndSchedule() {
        val end = now + 30L * Limits.DAY_MS
        val state = StrictMirror.MirrorState(end, now)
        val decoded = StrictMirror.decode(StrictMirror.encode(state, crypto), crypto)
        assertNotNull(decoded)
        assertEquals(end, decoded!!.strictEndWallMs)
        assertEquals(now, decoded.createdWallMs)
    }

    @Test
    fun roundTripHandlesThreeYearEndTime() {
        // The 1095-day cap: a mirror written for the maximum
        // Strict duration must round-trip exactly (epoch millis —
        // no extra work, verified here).
        val end = now + 1095L * Limits.DAY_MS
        val state = StrictMirror.MirrorState(end, now)
        val decoded = StrictMirror.decode(StrictMirror.encode(state, crypto), crypto)
        assertNotNull(decoded)
        assertEquals(end, decoded!!.strictEndWallMs)
    }

    @Test
    fun tamperedMirrorIsDetected() {
        val end = now + 30L * Limits.DAY_MS
        val bytes = StrictMirror.encode(StrictMirror.MirrorState(end, now), crypto)
        // Flip a byte in the middle of the ciphertext.
        val tampered = bytes.copyOf()
        tampered[tampered.size / 2] = (tampered[tampered.size / 2].toInt() xor 0x01).toByte()
        assertNull(StrictMirror.decode(tampered, crypto))
        // And the decision is Tampered (never trusted to shorten Strict).
        val decision = StrictMirror.decideRestore(tampered, 0L, false, now, crypto)
        assertTrue(decision is StrictMirror.Restore.Tampered)
    }

    @Test
    fun decideRestoreCases() {
        val end = now + 30L * Limits.DAY_MS
        val bytes = StrictMirror.encode(StrictMirror.MirrorState(end, now), crypto)
        // No mirror file: nothing to do.
        assertTrue(StrictMirror.decideRestore(null, 0L, false, now, crypto)
            is StrictMirror.Restore.NoMirror)
        // Store already has Strict: mirror is redundant.
        assertTrue(StrictMirror.decideRestore(bytes, end, true, now, crypto)
            is StrictMirror.Restore.AlreadyActive)
        // Fresh Store + valid mirror with a future end: restore it.
        val restored = StrictMirror.decideRestore(bytes, 0L, false, now, crypto)
        assertTrue(restored is StrictMirror.Restore.Restored)
        assertEquals(end, (restored as StrictMirror.Restore.Restored).state.strictEndWallMs)
        // Mirror whose end has passed: expired (delete it).
        val past = StrictMirror.encode(
            StrictMirror.MirrorState(now - Limits.DAY_MS, now - 2L * Limits.DAY_MS), crypto
        )
        assertTrue(StrictMirror.decideRestore(past, 0L, false, now, crypto)
            is StrictMirror.Restore.Expired)
    }

    @Test
    fun tamperFallbackIsMaximumDuration() {
        // A tampered mirror never shortens Strict: the fallback is
        // the maximum allowed duration from now (1095 days).
        assertEquals(
            now + 1095L * Limits.DAY_MS,
            StrictMirror.tamperFallbackEndMs(now)
        )
    }

    @Test
    fun forceStopGapDetection() {
        // Strict on, last tick 20 min ago, not from boot: force-stop.
        assertTrue(StrictMirror.shouldLogForceStopGap(true, now - 20L * 60_000L, now, false))
        // 10 min ago: normal poll jitter, not a gap.
        assertFalse(StrictMirror.shouldLogForceStopGap(true, now - 10L * 60_000L, now, false))
        // From boot/unlock: a reboot explains the gap.
        assertFalse(StrictMirror.shouldLogForceStopGap(true, now - 20L * 60_000L, now, true))
        // Strict off: no gap to log.
        assertFalse(StrictMirror.shouldLogForceStopGap(false, now - 20L * 60_000L, now, false))
        // No tick ever recorded: cannot tell.
        assertFalse(StrictMirror.shouldLogForceStopGap(true, 0L, now, false))
    }

    @Test
    fun payloadVersionAndParsing() {
        val state = StrictMirror.MirrorState(now + Limits.DAY_MS, now)
        val payload = StrictMirror.buildPayload(state)
        assertEquals(state, StrictMirror.parsePayload(payload))
        assertNull(StrictMirror.parsePayload("garbage".toByteArray(Charsets.UTF_8)))
        assertNull(StrictMirror.parsePayload("v99\n1\n2\n".toByteArray(Charsets.UTF_8)))
    }
}

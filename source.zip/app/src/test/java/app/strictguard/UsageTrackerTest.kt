package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Proves the v4 bug is fixed: usage must accumulate on EVERY poll for the
 * currently-foreground app, NOT only when the foreground app changes.
 * Continuous use in one app must reach its limit mid-session.
 */
class UsageTrackerTest {

    @Test
    fun continuousUseInOneAppReachesLimit() {
        val tracker = UsageTracker(pollMs = 500L)
        // AI limit is 30 min = 30*60*1000 ms = 3600 polls of 500 ms.
        var reached: String? = null
        var ticks = 0
        while (reached == null && ticks < 4000) {
            reached = tracker.tick("ai", "2026-11-07")
            ticks++
        }
        assertEquals("ai", reached)
        assertEquals(3600, ticks)
        assertEquals(30L * 60L * 1000L, tracker.used("ai", "2026-11-07"))
    }

    @Test
    fun limitNotReachedOneTickEarly() {
        val tracker = UsageTracker(pollMs = 500L)
        var reached: String? = null
        repeat(3599) { reached = tracker.tick("ai", "2026-11-07") }
        assertNull(reached)
        assertTrue(tracker.used("ai", "2026-11-07") < Limits.AI.limitMs)
    }

    /** v6.1.7 — a raised limit, passed in by the caller, governs the tick. */
    @Test
    fun limitOverrideRaisesTheTriggerPoint() {
        val tracker = UsageTracker(pollMs = 500L)
        // AI's default is 30 min (3600 ticks of 500 ms); raised to
        // 120 min (14400 ticks) via the override, it must NOT fire
        // at the old 30-minute mark.
        var reached: String? = null
        repeat(3600) {
            reached = tracker.tick("ai", "2026-11-07", limitMsOverride = 120L * 60L * 1000L)
        }
        assertNull(reached)
        // ...but does fire once the raised 120-minute mark is reached.
        repeat(14400 - 3600) {
            reached = tracker.tick("ai", "2026-11-07", limitMsOverride = 120L * 60L * 1000L)
        }
        assertEquals("ai", reached)
    }

    @Test
    fun switchingAppsKeepsEachGroupsUsage() {
        val tracker = UsageTracker(pollMs = 500L)
        repeat(100) { tracker.tick("facebook", "2026-11-07") }
        repeat(50) { tracker.tick("youtube", "2026-11-07") }
        repeat(100) { tracker.tick("facebook", "2026-11-07") }
        assertEquals(200L * 500L, tracker.used("facebook", "2026-11-07"))
        assertEquals(50L * 500L, tracker.used("youtube", "2026-11-07"))
    }

    @Test
    fun nullForegroundAccumulatesNothing() {
        val tracker = UsageTracker(pollMs = 500L)
        repeat(1000) { tracker.tick(null, "2026-11-07") }
        assertEquals(0L, tracker.used("facebook", "2026-11-07"))
        assertEquals(0L, tracker.used("ai", "2026-11-07"))
    }

    @Test
    fun newDayResetsUsage() {
        val tracker = UsageTracker(pollMs = 500L)
        repeat(100) { tracker.tick("facebook", "2026-11-07") }
        assertEquals(100L * 500L, tracker.used("facebook", "2026-11-07"))
        tracker.tick("facebook", "2026-11-08")
        assertEquals(500L, tracker.used("facebook", "2026-11-08"))
        assertEquals(0L, tracker.used("facebook", "2026-11-07"))
    }

    @Test
    fun restoreKeepsPersistedUsage() {
        val tracker = UsageTracker(pollMs = 500L)
        tracker.restore("2026-11-07", mapOf("youtube" to 59L * 60L * 1000L))
        // One more minute of YouTube (120 polls) must hit the 60-min limit.
        var reached: String? = null
        repeat(120) { reached = tracker.tick("youtube", "2026-11-07") }
        assertEquals("youtube", reached)
    }
}

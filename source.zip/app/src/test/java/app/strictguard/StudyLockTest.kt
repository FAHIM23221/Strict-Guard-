package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v6.1.0 Nightly Study Lock tests — pure timer / trigger logic,
 * no Android framework.
 *
 * The link is permanent: com.nextive.eTestPaper ("E-Test Paper for
 * SSC & HSC", StudyPlex / Nextive Solution LLC). Default time 21:00,
 * 15 continuous fair minutes, one attention check at 7.5 minutes
 * (60-second tap window), once per night.
 */
class StudyLockTest {

    private val poll = Limits.POLL_MS
    private val studyApp = StudyLock.STUDY_APP_PACKAGE
    private val otherApp = "com.facebook.katana"
    private val phoneApp = "com.android.incallui"

    /** Wall-clock instant in Asia/Dhaka. */
    private fun at(day: Int, hour: Int, min: Int = 0, sec: Int = 0): Long =
        ZonedDateTime.of(2026, 11, day, hour, min, sec, 0, ZoneId.of("Asia/Dhaka"))
            .toInstant().toEpochMilli()

    /** Run [n] STUDYING ticks from [state], tapping the attention prompt when it appears. */
    private fun studyTicks(
        state: StudyLock.TickState,
        n: Int,
        startNow: Long
    ): StudyLock.TickResult {
        var s = state
        var now = startNow
        var result = StudyLock.onTick(s, StudyLock.Mode.STUDYING, now, poll)
        for (i in 2..n) {
            now += poll
            if (result.attentionDue && !result.state.attentionDone) {
                // Tap "আমি পড়ছি" as soon as it appears.
                s = result.state.copy(attentionDone = true, attentionSinceMs = 0L)
            } else {
                s = result.state
            }
            result = StudyLock.onTick(s, StudyLock.Mode.STUDYING, now, poll)
        }
        return result
    }

    @Test
    fun constantsMatchSpec() {
        assertEquals("com.nextive.eTestPaper", studyApp)
        assertEquals(15L * 60_000L, StudyLock.DURATION_MS)
        assertEquals(7L * 60_000L + 30_000L, StudyLock.ATTENTION_AT_MS)
        assertEquals(60_000L, StudyLock.ATTENTION_TIMEOUT_MS)
        assertEquals(21 * 60, StudyLock.DEFAULT_TIME_MIN)
    }

    @Test
    fun fifteenContinuousMinutesCompletesTheLock() {
        val start = at(8, 21, 0)
        val ticks = (StudyLock.DURATION_MS / poll).toInt()
        val result = studyTicks(StudyLock.TickState(0L, false, 0L), ticks, start)
        assertTrue(result.completed)
        assertEquals(StudyLock.DURATION_MS, result.state.accumulatedMs)
        assertFalse(result.didReset)
    }

    @Test
    fun screenOffPausesButKeepsMinutes() {
        val start = at(8, 21, 0)
        var state = StudyLock.TickState(0L, false, 0L)
        var now = start
        // 5 fair minutes of studying.
        repeat((5L * 60_000L / poll).toInt()) {
            state = StudyLock.onTick(state, StudyLock.Mode.STUDYING, now, poll).state
            now += poll
        }
        assertEquals(5L * 60_000L, state.accumulatedMs)
        // 2 minutes with the screen off: nothing counts, nothing lost.
        repeat((2L * 60_000L / poll).toInt()) {
            val r = StudyLock.onTick(state, StudyLock.Mode.PAUSED, now, poll)
            state = r.state
            now += poll
            assertFalse(r.completed)
            assertFalse(r.didReset)
        }
        assertEquals(5L * 60_000L, state.accumulatedMs)
        // Studying again resumes from 5 minutes.
        val r = StudyLock.onTick(state, StudyLock.Mode.STUDYING, now, poll)
        assertEquals(5L * 60_000L + poll, r.state.accumulatedMs)
    }

    @Test
    fun leavingTheAppResetsToZero() {
        val start = at(8, 21, 0)
        var state = StudyLock.TickState(0L, false, 0L)
        var now = start
        // 10 fair minutes, tapping the attention prompt when it appears.
        var result = StudyLock.onTick(state, StudyLock.Mode.STUDYING, now, poll)
        repeat((10L * 60_000L / poll).toInt() - 1) {
            now += poll
            if (result.attentionDue && !result.state.attentionDone) {
                state = result.state.copy(attentionDone = true, attentionSinceMs = 0L)
            } else {
                state = result.state
            }
            result = StudyLock.onTick(state, StudyLock.Mode.STUDYING, now, poll)
        }
        state = result.state
        assertEquals(10L * 60_000L, state.accumulatedMs)
        val r = StudyLock.onTick(state, StudyLock.Mode.LEFT, now, poll)
        assertTrue(r.didReset)
        assertEquals(0L, r.state.accumulatedMs)
        assertFalse(r.state.attentionDone)
        assertEquals(0L, r.state.attentionSinceMs)
        assertFalse(r.completed)
    }

    @Test
    fun attentionCheckFiresAtSevenAndAHalfMinutes() {
        val start = at(8, 21, 0)
        var state = StudyLock.TickState(0L, false, 0L)
        var now = start
        var result = StudyLock.onTick(state, StudyLock.Mode.STUDYING, now, poll)
        // 7 minutes: no prompt yet.
        repeat((7L * 60_000L / poll).toInt() - 1) {
            now += poll
            result = StudyLock.onTick(result.state, StudyLock.Mode.STUDYING, now, poll)
        }
        assertFalse(result.attentionDue)
        // Cross 7:30 — the prompt appears.
        repeat((30_000L / poll).toInt()) {
            now += poll
            result = StudyLock.onTick(result.state, StudyLock.Mode.STUDYING, now, poll)
        }
        assertTrue(result.attentionDue)
        assertTrue(result.state.attentionSinceMs > 0L)
        state = result.state
        // Tapping it clears the prompt and counting resumes.
        val tapped = state.copy(attentionDone = true, attentionSinceMs = 0L)
        val after = StudyLock.onTick(tapped, StudyLock.Mode.STUDYING, now + poll, poll)
        assertFalse(after.attentionDue)
        assertEquals(state.accumulatedMs + poll, after.state.accumulatedMs)
    }

    @Test
    fun untappedAttentionPausesAfterSixtySeconds() {
        val start = at(8, 21, 0)
        var state = StudyLock.TickState(0L, false, 0L)
        var now = start
        var result = StudyLock.onTick(state, StudyLock.Mode.STUDYING, now, poll)
        repeat((StudyLock.ATTENTION_AT_MS / poll).toInt() - 1) {
            now += poll
            result = StudyLock.onTick(result.state, StudyLock.Mode.STUDYING, now, poll)
        }
        assertTrue(result.attentionDue)
        val frozen = result.state.accumulatedMs
        // The 60-second grace still counts (he is still studying,
        // he just has not tapped yet); after it, the timer pauses.
        repeat((61_000L / poll).toInt()) {
            now += poll
            result = StudyLock.onTick(result.state, StudyLock.Mode.STUDYING, now, poll)
            assertTrue(result.attentionDue)
        }
        assertEquals(frozen + 60_000L, result.state.accumulatedMs)
        // A further 30 seconds without tapping: still paused.
        repeat((30_000L / poll).toInt()) {
            now += poll
            result = StudyLock.onTick(result.state, StudyLock.Mode.STUDYING, now, poll)
            assertTrue(result.attentionDue)
        }
        assertEquals(frozen + 60_000L, result.state.accumulatedMs)
    }

    @Test
    fun triggerOnlyAtNightAndOnlyOnce() {
        // Before 21:00 — no trigger.
        assertFalse(
            StudyLock.shouldTrigger(at(8, 20, 59), 21 * 60, "", "", false)
        )
        // At 21:00 — triggers.
        assertTrue(
            StudyLock.shouldTrigger(at(8, 21, 0), 21 * 60, "", "", false)
        )
        // Already triggered tonight — does not trigger again.
        assertFalse(
            StudyLock.shouldTrigger(at(8, 21, 30), 21 * 60, "2026-11-08", "", false)
        )
        // Already completed tonight — does not trigger again.
        assertFalse(
            StudyLock.shouldTrigger(at(8, 22, 0), 21 * 60, "", "2026-11-08", false)
        )
        // A lock already active — does not re-trigger.
        assertFalse(
            StudyLock.shouldTrigger(at(8, 21, 5), 21 * 60, "", "", true)
        )
        // Next night — triggers again.
        assertTrue(
            StudyLock.shouldTrigger(at(9, 21, 0), 21 * 60, "2026-11-08", "2026-11-08", false)
        )
    }

    /** v6.1.7 — the feature's own on/off switch ([Store.studyLockEnabled]). */
    @Test
    fun disabledFeatureNeverTriggers() {
        // At the trigger time, feature OFF — does not trigger.
        assertFalse(
            StudyLock.shouldTrigger(
                at(8, 21, 0), 21 * 60, "", "", active = false, enabled = false
            )
        )
        // Same moment, feature ON (explicit) — triggers, unchanged from before.
        assertTrue(
            StudyLock.shouldTrigger(
                at(8, 21, 0), 21 * 60, "", "", active = false, enabled = true
            )
        )
        // Omitting the parameter defaults to ON — every pre-v6.1.7 call site
        // (and every pre-v6.1.7 test above) keeps behaving exactly as before.
        assertTrue(
            StudyLock.shouldTrigger(at(8, 21, 0), 21 * 60, "", "", false)
        )
    }

    @Test
    fun leftoverLockExpiresAtSixInTheMorning() {
        // Same night, after midnight — still active.
        assertFalse(StudyLock.shouldExpire(at(9, 0, 30), "2026-11-08", true))
        // Next morning before 06:00 — still active.
        assertFalse(StudyLock.shouldExpire(at(9, 5, 59), "2026-11-08", true))
        // 06:00 next morning — expired.
        assertTrue(StudyLock.shouldExpire(at(9, 6, 0), "2026-11-08", true))
        // Not active — never expires.
        assertFalse(StudyLock.shouldExpire(at(9, 6, 0), "2026-11-08", false))
    }

    @Test
    fun rebootKeepsMinutesOnlyIfSessionWasContinuous() {
        assertEquals(
            10L * 60_000L,
            StudyLock.resumeAccumulated(10L * 60_000L, lastStudying = true)
        )
        assertEquals(
            0L,
            StudyLock.resumeAccumulated(10L * 60_000L, lastStudying = false)
        )
        assertEquals(0L, StudyLock.resumeAccumulated(0L, lastStudying = true))
    }

    @Test
    fun missingAppBlocksEverythingExceptPlayStoreAndCalls() {
        // Other apps blocked while waiting for the study app.
        val blocked = BlockDecider.decideStudy(
            otherApp, studyActive = true, studyMissing = true, studyApp, isPhoneApp = false
        )
        assertEquals(BlockDecider.Kind.STUDY, blocked?.kind)
        // The Play Store is allowed, so the app can be installed.
        assertNull(
            BlockDecider.decideStudy(
                "com.android.vending", studyActive = true, studyMissing = true,
                studyApp, isPhoneApp = false
            )
        )
        // Phone calls are allowed.
        assertNull(
            BlockDecider.decideStudy(
                phoneApp, studyActive = true, studyMissing = true, studyApp, isPhoneApp = true
            )
        )
        // The study app itself is never blocked by the lock.
        assertNull(
            BlockDecider.decideStudy(
                studyApp, studyActive = true, studyMissing = false, studyApp, isPhoneApp = false
            )
        )
        // No lock — nothing blocked.
        assertNull(
            BlockDecider.decideStudy(
                otherApp, studyActive = false, studyMissing = false, studyApp, isPhoneApp = false
            )
        )
    }

    @Test
    fun studyLockBlocksOtherAppsButNotStudyAppOrCalls() {
        // Via the shared decide(): Facebook is blocked during a lock.
        val fb = BlockDecider.decide(
            otherApp, strict = false, night = false,
            nightAllowed = emptySet(), custom = emptySet(),
            limitReached = emptySet(), isLauncher = false,
            ownPackage = "app.strictguard",
            studyActive = true, studyMissing = false,
            studyApp = studyApp, isPhoneApp = false
        )
        assertEquals(BlockDecider.Kind.STUDY, fb?.kind)
        // The study app opens normally during a lock.
        assertNull(
            BlockDecider.decide(
                studyApp, strict = false, night = false,
                nightAllowed = emptySet(), custom = emptySet(),
                limitReached = emptySet(), isLauncher = false,
                ownPackage = "app.strictguard",
                studyActive = true, studyMissing = false,
                studyApp = studyApp, isPhoneApp = false
            )
        )
        // A phone call is not blocked during a lock.
        assertNull(
            BlockDecider.decide(
                phoneApp, strict = false, night = false,
                nightAllowed = emptySet(), custom = emptySet(),
                limitReached = emptySet(), isLauncher = false,
                ownPackage = "app.strictguard",
                studyActive = true, studyMissing = false,
                studyApp = studyApp, isPhoneApp = true
            )
        )
        // Night Lock hours covering 21:00 must NOT block the study
        // app during a lock — otherwise the lock could never complete.
        assertNull(
            BlockDecider.decide(
                studyApp, strict = false, night = true,
                nightAllowed = emptySet(), custom = emptySet(),
                limitReached = emptySet(), isLauncher = false,
                ownPackage = "app.strictguard",
                studyActive = true, studyMissing = false,
                studyApp = studyApp, isPhoneApp = false
            )
        )
        // ...but Night Lock still blocks other apps during a lock.
        assertEquals(
            BlockDecider.Kind.STUDY,
            BlockDecider.decide(
                otherApp, strict = false, night = true,
                nightAllowed = emptySet(), custom = emptySet(),
                limitReached = emptySet(), isLauncher = false,
                ownPackage = "app.strictguard",
                studyActive = true, studyMissing = false,
                studyApp = studyApp, isPhoneApp = false
            )?.kind
        )
    }

    @Test
    fun launcherTapDuringStudyLock() {
        // Tapping another app from the launcher is blocked.
        val blocked = LauncherLogic.tapDecision(
            otherApp, strict = false, night = false,
            nightAllowed = emptySet(), custom = emptySet(),
            limitReached = emptySet(), launcherPackages = emptySet(),
            ownPackage = "app.strictguard",
            studyActive = true, studyMissing = false, isPhoneApp = false
        )
        assertEquals(BlockDecider.Kind.STUDY, blocked?.kind)
        // Tapping the study app opens it.
        assertNull(
            LauncherLogic.tapDecision(
                studyApp, strict = false, night = false,
                nightAllowed = emptySet(), custom = emptySet(),
                limitReached = emptySet(), launcherPackages = emptySet(),
                ownPackage = "app.strictguard",
                studyActive = true, studyMissing = false, isPhoneApp = false
            )
        )
        // Tapping Strict Guard's own tile during a lock is blocked too.
        val self = LauncherLogic.tapDecision(
            "app.strictguard", strict = false, night = false,
            nightAllowed = emptySet(), custom = emptySet(),
            limitReached = emptySet(), launcherPackages = emptySet(),
            ownPackage = "app.strictguard",
            studyActive = true, studyMissing = false, isPhoneApp = false
        )
        assertEquals(BlockDecider.Kind.STUDY, self?.kind)
        // No lock — the tile opens normally.
        assertNull(
            LauncherLogic.tapDecision(
                "app.strictguard", strict = false, night = false,
                nightAllowed = emptySet(), custom = emptySet(),
                limitReached = emptySet(), launcherPackages = emptySet(),
                ownPackage = "app.strictguard",
                studyActive = false, studyMissing = false, isPhoneApp = false
            )
        )
    }
}

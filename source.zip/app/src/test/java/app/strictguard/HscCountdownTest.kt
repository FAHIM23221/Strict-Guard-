package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v6.1.0 HSC countdown tests — pure date / time logic, no Android
 * framework.
 *
 * Target: HSC 2027 first exam, 6 June 2027, 10:00 AM Asia/Dhaka.
 * The main page ticks days/hours/minutes/seconds every second; the
 * launcher shows full calendar months + remaining days
 * ("৬ মাস ২৯ দিন"), changing only at midnight. The daily
 * "one day less" alert and the 08:00 reminder still quote days.
 */
class HscCountdownTest {

    /** Wall-clock instant in Asia/Dhaka. */
    private fun at(year: Int, month: Int, day: Int, hour: Int = 10, min: Int = 0): Long =
        ZonedDateTime.of(year, month, day, hour, min, 0, 0, ZoneId.of("Asia/Dhaka"))
            .toInstant().toEpochMilli()

    private val exam = HscCountdown.DEFAULT_EXAM_MS // 6 June 2027 10:00 Dhaka

    @Test
    fun defaultExamIs6June2027At10Dhaka() {
        assertEquals(at(2027, 6, 6, 10, 0), exam)
        // End of the exam period: after 13 July is over.
        assertEquals(at(2027, 7, 14, 0, 0), HscCountdown.EXAM_END_MS)
    }

    @Test
    fun decomposeSplitsDaysHoursMinutesSeconds() {
        val parts = HscCountdown.decompose(
            (209L * 86_400L + 14L * 3600L + 32L * 60L + 10L) * 1000L
        )
        assertEquals(209L, parts.days)
        assertEquals(14, parts.hours)
        assertEquals(32, parts.minutes)
        assertEquals(10, parts.seconds)
        // Never negative.
        val zero = HscCountdown.decompose(-5_000L)
        assertEquals(0L, zero.days)
        assertEquals(0, zero.seconds)
    }

    @Test
    fun daysRemainingFrom8November2026() {
        // 8 Nov 2026 10:00 → 6 June 2027 10:00 is exactly 210 days.
        assertEquals(210L, HscCountdown.daysRemaining(at(2026, 11, 8, 10, 0), exam))
    }

    @Test
    fun monthsAndDaysFrom8November2026() {
        // Launcher format: 8 Nov 2026 → 6 June 2027 is 6 full
        // calendar months (8 Nov + 6 months = 8 May 2027) + 29 days
        // (8 May → 6 June).
        val md = HscCountdown.monthsAndDays(at(2026, 11, 8, 10, 0), exam)
        assertEquals(6L, md.months)
        assertEquals(29L, md.days)
    }

    @Test
    fun monthsAndDaysBoundaries() {
        // Exactly one month out: 6 May 2027 → 6 June 2027.
        val oneMonth = HscCountdown.monthsAndDays(at(2027, 5, 6, 10, 0), exam)
        assertEquals(1L, oneMonth.months)
        assertEquals(0L, oneMonth.days)
        // One day out: 5 June 2027 → 6 June 2027.
        val oneDay = HscCountdown.monthsAndDays(at(2027, 6, 5, 10, 0), exam)
        assertEquals(0L, oneDay.months)
        assertEquals(1L, oneDay.days)
        // Exam day itself (before 10:00): 0 months 0 days.
        val examDay = HscCountdown.monthsAndDays(at(2027, 6, 6, 9, 0), exam)
        assertEquals(0L, examDay.months)
        assertEquals(0L, examDay.days)
        // After the exam: 0 months 0 days (state handles Started/Ended).
        val after = HscCountdown.monthsAndDays(at(2027, 6, 7, 10, 0), exam)
        assertEquals(0L, after.months)
        assertEquals(0L, after.days)
        // Month-end: 31 Jan → 28 Feb is not a whole calendar
        // month in JDK month math (0 months, 28 days), while
        // 28 Feb → 28 Mar is exactly one month.
        val jan31 = HscCountdown.monthsAndDays(
            at(2027, 1, 31, 10, 0), at(2027, 2, 28, 10, 0)
        )
        assertEquals(0L, jan31.months)
        assertEquals(28L, jan31.days)
        val feb28 = HscCountdown.monthsAndDays(
            at(2027, 2, 28, 10, 0), at(2027, 3, 28, 10, 0)
        )
        assertEquals(1L, feb28.months)
        assertEquals(0L, feb28.days)
    }

    @Test
    fun stateTransitions() {
        assertTrue(HscCountdown.state(at(2026, 11, 8, 10, 0), exam)
            is HscCountdown.State.Counting)
        // At the exam instant the exam has started.
        assertEquals(HscCountdown.State.Started, HscCountdown.state(exam, exam))
        // During the exam period it stays Started.
        assertEquals(
            HscCountdown.State.Started,
            HscCountdown.state(at(2027, 6, 20, 10, 0), exam)
        )
        // After 13 July is over the exam has ended.
        assertEquals(
            HscCountdown.State.Ended,
            HscCountdown.state(at(2027, 7, 14, 0, 0), exam)
        )
        assertEquals(
            HscCountdown.State.Ended,
            HscCountdown.state(at(2027, 8, 1, 10, 0), exam)
        )
    }

    @Test
    fun dhakaTimezoneHandling() {
        // 6 June 2027 09:59 Dhaka is still Counting (1 minute left);
        // the same UTC instant would be a different Dhaka time.
        val before = HscCountdown.state(at(2027, 6, 6, 9, 59), exam)
        assertTrue(before is HscCountdown.State.Counting)
        assertEquals(0L, (before as HscCountdown.State.Counting).parts.days)
        assertEquals(1, before.parts.minutes)
        // dayKey is a Dhaka calendar day, not UTC.
        assertEquals("2027-06-06", HscCountdown.dayKey(at(2027, 6, 6, 1, 0)))
    }

    @Test
    fun reminderFiresOncePerMorningAtEight() {
        val day = "2026-11-08"
        // Before 08:00: no.
        assertFalse(HscCountdown.shouldSendReminder(at(2026, 11, 8, 7, 59), exam, true, ""))
        // At 08:00, not sent today: yes.
        assertTrue(HscCountdown.shouldSendReminder(at(2026, 11, 8, 8, 0), exam, true, ""))
        // Already sent today: no.
        assertFalse(
            HscCountdown.shouldSendReminder(at(2026, 11, 8, 9, 0), exam, true, day)
        )
        // Reminder toggle off: no.
        assertFalse(HscCountdown.shouldSendReminder(at(2026, 11, 8, 8, 0), exam, false, ""))
        // After the exam: no reminder.
        assertFalse(
            HscCountdown.shouldSendReminder(at(2027, 6, 7, 8, 0), exam, true, "")
        )
    }

    @Test
    fun dayLessPopupAndDrop() {
        assertTrue(HscCountdown.dayDropped(210L, 209L))
        assertFalse(HscCountdown.dayDropped(209L, 209L))
        assertFalse(HscCountdown.dayDropped(209L, 210L))
        // Pending + not shown today: show. Shown already: don't.
        assertTrue(HscCountdown.shouldShowDayLessPopup(true, false))
        assertFalse(HscCountdown.shouldShowDayLessPopup(true, true))
        assertFalse(HscCountdown.shouldShowDayLessPopup(false, false))
    }

    @Test
    fun dayLessAlertSequenceOncePerDayAndSurvivesReboot() {
        // First observation only seeds the count — no alert.
        assertFalse(HscCountdown.dayDropped(-1L, 210L))
        var lastSeen = 210L
        // Midnight passes: days drop 210 → 209 → alert fires once.
        assertTrue(HscCountdown.dayDropped(lastSeen, 209L))
        lastSeen = 209L
        // Popup shows once (pending + not shown today) …
        assertTrue(HscCountdown.shouldShowDayLessPopup(true, false))
        // … and after showing, it does not show again the same day.
        assertFalse(HscCountdown.shouldShowDayLessPopup(false, true))
        // Same-day polls: no second drop, no second alert.
        assertFalse(HscCountdown.dayDropped(lastSeen, 209L))
        // Reboot survival: the phone is off at midnight, days drop
        // 209 → 208 while off. After reboot the persisted last-seen
        // count (209) is still there, so the drop is detected and
        // the alert fires for the new day.
        assertTrue(HscCountdown.dayDropped(209L, 208L))
        // … and once fired for that day, it does not repeat.
        assertFalse(HscCountdown.dayDropped(208L, 208L))
    }

    @Test
    fun dayLessMessagesMentionDaysLeft() {
        // Bank: 10 variants per language (tone refinement).
        assertEquals(10, HscCountdown.DAY_LESS_MESSAGES_BN.size)
        assertEquals(10, HscCountdown.DAY_LESS_MESSAGES_EN.size)
        // Every template carries the days-left number.
        for (template in HscCountdown.DAY_LESS_MESSAGES_BN +
            HscCountdown.DAY_LESS_MESSAGES_EN
        ) {
            assertTrue(template.contains("%1\$d"))
        }
        // Every formatted message states the days left, in both
        // languages — Bengali digits in Bengali, ASCII in English.
        for (days in listOf(208L, 100L, 1L)) {
            val bn = HscCountdown.dayLessMessage(days, true)
            val en = HscCountdown.dayLessMessage(days, false)
            assertTrue(bn.contains(Limits.toBengaliDigits(days.toString())))
            assertTrue(en.contains(days.toString()))
            assertTrue(bn.contains("দিন"))
            assertTrue(en.contains("days"))
        }
        // Rotation: days 0–9 cover all 10 variants (index = days % 10).
        val seenBn = (0L..9L).map { HscCountdown.dayLessMessage(it, true) }.toSet()
        val seenEn = (0L..9L).map { HscCountdown.dayLessMessage(it, false) }.toSet()
        assertEquals(10, seenBn.size)
        assertEquals(10, seenEn.size)
        // Rotation repeats every 10 days: days 208 and 198 use the
        // same template (index 8) — only the days number differs.
        val stripDigits = { s: String -> s.replace(Regex("[0-9০-৯]"), "") }
        assertEquals(
            stripDigits(HscCountdown.dayLessMessage(208L, true)),
            stripDigits(HscCountdown.dayLessMessage(198L, true))
        )
        assertEquals(
            stripDigits(HscCountdown.dayLessMessage(208L, false)),
            stripDigits(HscCountdown.dayLessMessage(198L, false))
        )
    }

    @Test
    fun examDatePickerRoundTrip() {
        // A picked date (6 June 2027) is 10:00 Dhaka.
        assertEquals(exam, HscCountdown.examMsForDate(2027, 5, 6))
        // A revised date is honoured.
        val revised = HscCountdown.examMsForDate(2027, 5, 13)
        assertEquals(at(2027, 6, 13, 10, 0), revised)
        assertTrue(HscCountdown.daysRemaining(at(2026, 11, 8, 10, 0), revised) > 210L)
    }
}

package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BlockDeciderTest {

    private val own = "app.strictguard"

    @Test
    fun ownAppAndLauncherNeverBlocked() {
        assertNull(BlockDecider.decide(own, true, true, emptySet(), emptySet(), emptySet(), false, own))
        assertNull(BlockDecider.decide("com.android.launcher", true, true, emptySet(), emptySet(), emptySet(), true, own))
    }

    @Test
    fun limitReachedBlocksAllDay() {
        val d = BlockDecider.decide(
            "com.google.android.youtube", false, false,
            emptySet(), emptySet(), setOf("youtube"), false, own
        )
        assertEquals(BlockDecider.Kind.LIMIT, d?.kind)
        assertEquals("youtube", d?.groupId)
    }

    @Test
    fun limitNotReachedDoesNotBlock() {
        assertNull(
            BlockDecider.decide(
                "com.google.android.youtube", false, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
    }

    @Test
    fun bypassAppsBlockedDuringStrict() {
        val d = BlockDecider.decide(
            "com.android.settings", true, false,
            emptySet(), emptySet(), emptySet(), false, own
        )
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun bypassAppsNotBlockedWhenStrictOff() {
        assertNull(
            BlockDecider.decide(
                "com.android.settings", false, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
    }

    @Test
    fun customBlockAppliesDuringStrictOnly() {
        val custom = setOf("com.example.game")
        assertEquals(
            BlockDecider.Kind.CUSTOM,
            BlockDecider.decide("com.example.game", true, false, emptySet(), custom, emptySet(), false, own)?.kind
        )
        assertNull(
            BlockDecider.decide("com.example.game", false, false, emptySet(), custom, emptySet(), false, own)
        )
    }

    @Test
    fun nightBlocksEverythingExceptAllowed() {
        val allowed = setOf("com.android.dialer")
        assertEquals(
            BlockDecider.Kind.NIGHT,
            BlockDecider.decide("com.example.game", false, true, allowed, emptySet(), emptySet(), false, own)?.kind
        )
        assertNull(
            BlockDecider.decide("com.android.dialer", false, true, allowed, emptySet(), emptySet(), false, own)
        )
    }

    // ---- v5.1.0: Strict Mode itself blocks all four limit groups ----
    @Test
    fun strictBlocksFacebookGroup() {
        val d = BlockDecider.decide(
            "com.facebook.katana", true, false,
            emptySet(), emptySet(), emptySet(), false, own
        )
        assertEquals(BlockDecider.Kind.STRICT_GROUP, d?.kind)
        assertEquals("facebook", d?.groupId)
    }

    @Test
    fun strictBlocksChromeYoutubeAndAiGroups() {
        for ((pkg, group) in listOf(
            "com.android.chrome" to "chrome",
            "com.google.android.youtube" to "youtube",
            "com.openai.chatgpt" to "ai"
        )) {
            val d = BlockDecider.decide(
                pkg, true, false, emptySet(), emptySet(), emptySet(), false, own
            )
            assertEquals(group, d?.groupId)
            assertEquals(BlockDecider.Kind.STRICT_GROUP, d?.kind)
        }
    }

    @Test
    fun strictGroupBeatsNightAllowed() {
        // Even if YouTube were night-allowed, Strict still blocks it.
        val d = BlockDecider.decide(
            "com.google.android.youtube", true, true,
            setOf("com.google.android.youtube"), emptySet(), emptySet(), false, own
        )
        assertEquals(BlockDecider.Kind.STRICT_GROUP, d?.kind)
    }

    @Test
    fun nonGroupAppNotBlockedByStrictAlone() {
        assertNull(
            BlockDecider.decide(
                "com.example.game", true, false,
                emptySet(), emptySet(), emptySet(), false, own
            )
        )
    }

    @Test
    fun settingsAppStillBlockedDuringStrict() {
        val d = BlockDecider.decide(
            "com.android.settings", true, false,
            emptySet(), emptySet(), emptySet(), false, own
        )
        assertEquals(BlockDecider.Kind.STRICT_BYPASS, d?.kind)
    }

    @Test
    fun cloneAppsAreBuiltinStrict() {
        assertEquals(
            BlockDecider.Kind.STRICT_BYPASS,
            BlockDecider.decide("com.lbe.parallel.intl", true, false, emptySet(), emptySet(), emptySet(), false, own)?.kind
        )
    }
}

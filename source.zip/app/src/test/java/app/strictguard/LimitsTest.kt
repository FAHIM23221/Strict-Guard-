package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class LimitsTest {

    @Test
    fun groupsHaveCorrectLimits() {
        assertEquals(120, Limits.FACEBOOK.limitMinutes)
        assertEquals(90, Limits.CHROME.limitMinutes)
        assertEquals(60, Limits.YOUTUBE.limitMinutes)
        assertEquals(30, Limits.AI.limitMinutes)
    }

    /** v6.1.7 — raising a group's limit, capped at 2 hours, never below default. */
    @Test
    fun effectiveLimitMinutesRaisesAndCaps() {
        // No override (0) — stays at default.
        assertEquals(90, Limits.effectiveLimitMinutes(90, 0))
        // Override at or below default — stays at default (no lowering).
        assertEquals(90, Limits.effectiveLimitMinutes(90, 90))
        assertEquals(90, Limits.effectiveLimitMinutes(90, 50))
        // Override above default, within the cap — takes effect.
        assertEquals(120, Limits.effectiveLimitMinutes(90, 120))
        assertEquals(100, Limits.effectiveLimitMinutes(90, 100))
        // Override past the 120-minute cap — clamped to the cap.
        assertEquals(120, Limits.effectiveLimitMinutes(90, 999))
        // Facebook's default IS the cap — no room, whatever is asked.
        assertEquals(120, Limits.effectiveLimitMinutes(120, 999))
    }

    @Test
    fun groupForKnownPackages() {
        assertEquals("facebook", Limits.groupFor("com.facebook.katana")?.id)
        assertEquals("chrome", Limits.groupFor("com.android.chrome")?.id)
        assertEquals("youtube", Limits.groupFor("com.google.android.youtube")?.id)
        assertEquals("ai", Limits.groupFor("com.openai.chatgpt")?.id)
        assertEquals(null, Limits.groupFor("com.example.unknown"))
    }

    @Test
    fun nightWindowDefault() {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 2)
        cal.set(Calendar.MINUTE, 30)
        assertTrue(Limits.nightActive(cal, 0, 360))
        cal.set(Calendar.HOUR_OF_DAY, 12)
        assertFalse(Limits.nightActive(cal, 0, 360))
        cal.set(Calendar.HOUR_OF_DAY, 6)
        cal.set(Calendar.MINUTE, 0)
        assertFalse(Limits.nightActive(cal, 0, 360))
    }

    @Test
    fun nightWindowWrappingMidnight() {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 23)
        assertTrue(Limits.nightActive(cal, 22 * 60, 6 * 60))
        cal.set(Calendar.HOUR_OF_DAY, 5)
        assertTrue(Limits.nightActive(cal, 22 * 60, 6 * 60))
        cal.set(Calendar.HOUR_OF_DAY, 12)
        assertFalse(Limits.nightActive(cal, 22 * 60, 6 * 60))
    }

    @Test
    fun strictActiveUsesElapsedTime() {
        assertTrue(Limits.strictActive(1000L, 5000L))
        assertFalse(Limits.strictActive(5000L, 5000L))
        assertFalse(Limits.strictActive(6000L, 5000L))
        assertFalse(Limits.strictActive(1000L, 0L))
    }

    @Test
    fun formatDurationBengaliDigits() {
        assertEquals("২ ঘণ্টা ৩০ মিনিট", Limits.formatDuration(150L * 60L * 1000L, true))
        assertEquals("45 min", Limits.formatDuration(45L * 60L * 1000L, false))
        assertEquals("০ মিনিট", Limits.formatDuration(0L, true))
    }

    @Test
    fun percentClamped() {
        assertEquals(50, Limits.percent(30L * 60L * 1000L, 60L * 60L * 1000L))
        assertEquals(100, Limits.percent(120L * 60L * 1000L, 60L * 60L * 1000L))
        assertEquals(0, Limits.percent(0L, 60L * 60L * 1000L))
    }
}

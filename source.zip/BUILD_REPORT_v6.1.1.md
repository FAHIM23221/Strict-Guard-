# BUILD REPORT — Strict Guard v6.1.1 (crash-fix release)

Date: 2026-11-08. Built for Fahim (Infinix X6886, Android 16).
Base: v6.1.0 source in this same directory (SHA-256
`b46854780d0a047130eca80946c09a1dadc9f3713d67c30da3f86405bd63dc1a`).
No APK was decompiled; built from the v5/v6 source only, manual kotlinc + aapt2 + d8
route (Gradle cannot run in this sandbox).

## Result: SUCCEEDED

- **APK:** `~/workspace/your_files/Strict-Guard-v6.1.1.apk` — 859,141 bytes
- **SHA-256:** `f8dc209a4de9a9c56713032cc64bb8ace9327d7822eabc70a4491fe4970a7553`
- **Source zip:** `~/workspace/your_files/Strict-Guard-v6.1.1-source.zip`
- **Signature:** apksigner verifies, 1 signer (same fresh debug keystore as
  v5/v5.1/v5.2/v5.2.1/v6.0.0/v6.1.0, CN=Strict Guard, O=Self-built, C=BD).
  Signing scheme **v3 only** (v1/v2 false) — same apksigner 35.0.0 quirk as before;
  v3 covers Android 9+ and minSdk is 29.
- **Unit tests: 200/200 pass** (JUnit 4.13.2) — v6.1.0's 190 + 10 new in
  `StartupCrashTest.kt` (see below).
- **No Accessibility:** 0 "accessibility" strings in the dex, no
  AccessibilityService / BIND_ACCESSIBILITY in the manifest.
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no
  http(s) URL strings in the dex.
- **StartupGuard markers confirmed in the built APK's dex:** `StartupGuard`.
- **HOME intent filter confirmed in the built APK** (aapt2 xmltree):
  `LauncherActivity` declares MAIN + HOME + DEFAULT, exported, singleTask.
- **NOT tested on a real device.** Fahim must uninstall v6.1.0 first
  (different signing key) before installing v6.1.1, then pick Strict Guard
  as the default home launcher and redo the 7 setup steps.

## The crash (what Fahim saw)

Fahim installed v6.1.0 and tapped the icon at 21:54 Dhaka on 2026-11-08.
Android showed "Strict Guard keeps stopping" over his normal XOS home
screen (screenshot `~/workspace/user/files/93074_0_0skf.jpg`) — the app
died before he ever saw inside it, before setting it as launcher.
He confirmed: the crash happened on the very first open attempt, right
after install.

## Root cause — the one that crashed first launch

**`app/src/main/java/app/strictguard/BaseActivity.kt:57` (v6.1.0):**

```kotlin
registerReceiver(themeReceiver, IntentFilter(AutoTheme.ACTION_THEME_CHANGED))
```

called from `BaseActivity.onResume()`, with **no export flag**. The
action is our own custom action (`"app.strictguard.THEME_CHANGED"`),
NOT a system broadcast, so the Android 14 system-broadcast exception
does not apply. Apps with `targetSdkVersion` 34+ **must** pass
`RECEIVER_EXPORTED` or `RECEIVER_NOT_EXPORTED` when registering a
receiver (Android 14 behaviour change, still enforced on Android 15
and 16); without it the system throws:

```
SecurityException: One of RECEIVER_EXPORTED or RECEIVER_NOT_EXPORTED
should be specified when a receiver isn't being registered exclusively
for system broadcasts.
```

`onResume()` had no try/catch, so the exception killed the process on
the **first resume of the first activity (MainActivity)** — the instant
Fahim tapped the icon. This was verified against the official Android
14 behaviour-change documentation (developer.android.com, "Runtime-
registered broadcasts receivers must specify export behavior").

Why v6.0.0 opened fine and v6.1.0 crashed immediately: the receiver
was added in v6.1.0 for the auto-theme switch. v6.0.0's `BaseActivity`
(checked in `Strict-Guard-v6.0.0-source.zip`) has **no**
`registerReceiver` call at all. Grep confirms v6.1.0 had exactly one
`registerReceiver` call in the whole app — this one.

## Other first-launch risks checked (and why they were NOT the crash)

Checked first, before concluding, because a fresh install has no
permissions granted and no prior data:

- **GuardService foreground service (suspect a):** `GuardService.kt`
  calls `startForeground(..., FOREGROUND_SERVICE_TYPE_SPECIAL_USE)` and
  the manifest declares `foregroundServiceType="specialUse"` plus the
  `FOREGROUND_SERVICE_SPECIAL_USE` permission — type and manifest
  match, so this was not the first-launch crash. It *can* still throw
  (`ForegroundServiceStartNotAllowedException`) when the service is
  started from the background on Android 12+, so it is now guarded
  (see Fixes).
- **Exact alarms (suspect b):** `PrayerAlarmScheduler.scheduleNext()`
  already checks `canScheduleExactAlarms()` and falls back to
  `setAndAllowWhileIdle()` (inexact) when denied, inside try/catch —
  and it is not called on first launch at all (only from boot/unlock
  receivers and the Friday toggle). Not the crash. Unchanged.
- **Mirror / Keystore (suspect c):** `MirrorStore.checkAndRestore()`
  and `KeystoreMirrorCrypto` are already fully try/catch-guarded and
  return soft failures. Not the crash. Unchanged.
- **Layouts/resources (suspect d):** all view IDs used by
  `MainActivity`/`LauncherActivity` exist in the layouts, all custom
  `?attr/` colours are defined in both themes, all drawables exist,
  and the manual build (aapt2 link) would have failed on a missing
  resource. The APK's dex contains all classes and the manifest
  badges correctly. Not the crash.
- **HSC countdown / StudyLock / EntryDelay init:** pure logic or
  already-guarded; none runs unguarded on the first launch path.

## Fixes in v6.1.1 (all in `app/src/main/java/app/strictguard/`)

New file **`StartupGuard.kt`** — the crash-fix + defensive-startup
helper, with pure testable logic:

- `receiverFlagForSdk(sdk)` / `useFlagOverload(sdk)`: the 3-arg
  `registerReceiver` overload only exists from API 33 — calling it on
  older devices would be a `NoSuchMethodError`, so the SDK is checked
  first. Returns `RECEIVER_NOT_EXPORTED` on API 33+ (our receiver only
  ever hears our own app's broadcast), null below.
- `registerPrivateReceiver(...)`: registers with
  `RECEIVER_NOT_EXPORTED` on API 33+, old 2-arg call below, wrapped
  in try/catch — never throws. On failure the theme-change broadcast
  is simply not received while the activity is open (the guard poll
  still applies the auto theme; onResume re-evaluates it).
- `runSafe(block)` / `runSafeOr(block, fallback)`: one startup step
  that can never kill the launch.
- `startGuardService(context)` / `startGuardServiceFromBoot(context)`:
  `startForegroundService()` wrapped — a refused background start is
  a missed start, never a crash.

**`BaseActivity.kt`** — the actual crash site:
- `onResume()` (was line 57): uses
  `StartupGuard.registerPrivateReceiver(...)` instead of the bare
  `registerReceiver(...)`. **This is the fix for the reported crash.**
- `attachBaseContext()` (was line 25-28): `Store(newBase)` wrapped in
  try/catch — before unlock the credential-encrypted prefs may be
  unreadable; falls back to the un-wrapped base (English).
- `onCreate()` (was line 30-35): Store read + `setTheme()` wrapped;
  if the Store cannot be read yet the activity still opens (default
  theme) and `onResume` guards every use of `store`.
- New helper `isStoreReady()` (`::store.isInitialized` — the backing
  field of an inherited lateinit var is not accessible from a subclass
  in kotlinc, so subclasses use this).

**`MainActivity.kt`** — first-launch path hardened, behaviour unchanged:
- `onResume()`: every step guarded separately via `runSafe` —
  `recoverStrictAfterBoot()`, `MirrorStore.checkAndRestore()`, guard
  self-heal restart (now via `StartupGuard.startGuardService()`),
  `refresh()`, HSC ticker start, day-less popup. One failing
  subsystem is skipped; the rest still run.
- `onCreate()`: the POST_NOTIFICATIONS permission request wrapped.
- `startGuardService()` now delegates to `StartupGuard`.

**`LauncherActivity.kt`** — same treatment in `onResume()` (boot
recovery, mirror restore, guard restart, refresh, HSC months ticker,
day-less popup all guarded; guard restart via `StartupGuard`).

**`GuardService.kt`**:
- `onStartCommand()`: the `startForeground(...)` call is wrapped in
  try/catch — on a refused start the service stops itself cleanly
  (`stopSelf()`, `START_NOT_STICKY`) instead of crashing the process.
- `onCreate()`: `createChannel()` wrapped (it reads resources).

**`BootReceiver.kt` / `SystemEventsReceiver.kt`**: the whole
`onReceive()` is wrapped in try/catch (a throwing receiver crashes the
process; `PACKAGE_ADDED` fires at install time, before any setup),
and their `startForegroundService()` calls now go through
`StartupGuard.startGuardServiceFromBoot()`.

**`StrictSetupActivity.kt`**: its `startForegroundService()` call now
goes through `StartupGuard.startGuardService()`.

**`AutoTheme.kt`**: the theme-change broadcast is now addressed at
our own package (`.setPackage(...)`), so it is explicit rather than
implicit (Android 14 restricts implicit intents to internal
components). The receiver is `RECEIVER_NOT_EXPORTED`, so only our app
can hear it either way.

No v6.1.0 feature or behaviour was changed otherwise: break cycle,
Claude exemption, Warm Sand theme + auto theme, self-block, 24h/12h
clock, one-way setup buttons, hide-unused-apps, Nightly Study Lock
(eTestPaper, 21:00, 15 fair minutes), entry delay, force-stop /
Clear-Data mirror, 3-year Strict cap, HSC countdown (launcher months
format "৬ মাস ২৯ দিন"), daily "one day less" alert, Friday Jumu'ah
system — all unchanged.

## Tests

**200/200 pass** (was 190/190 in v6.1.0). New `StartupCrashTest.kt`
(10 tests):

- Flag-overload rule: used on API 33+ only (29/32 → old call, 33–36
  → flagged call).
- Receiver flag is `RECEIVER_NOT_EXPORTED` on API 33–36, null below
  (the 3-arg overload does not exist below API 33); receiver is
  private, never `RECEIVER_EXPORTED`.
- `runSafe` swallows the exact Android 14 `registerReceiver`
  `SecurityException` message, plus `RuntimeException`,
  `IllegalStateException`, `NullPointerException`.
- `runSafeOr` returns the fallback (`"en"`) when the step throws.
- First-launch init model: six guarded steps (boot recovery, mirror,
  guard start, refresh, ticker, alert) — a throw in the 1st, 2nd,
  3rd and 5th still lets all six steps run; all-throwing still does
  not propagate.
- Exact-alarm fallback: `useExactAlarm(false)` → inexact,
  `useExactAlarm(true)` → exact (already covered in
  `FridayPrayerTest`, restated here for the crash-fix path).

## Install (for Fahim)

1. **Uninstall v6.1.0 first** (same signing-key rule as every
   version since v4 — a different key from v3.7 and from each other
   in the debug-keystore line; Android will refuse to install over
   v6.1.0 otherwise).
2. Install `Strict-Guard-v6.1.1.apk`.
3. Open it — this is the step that crashed in v6.1.0; it should now
   open straight onto the main page.
4. Set Strict Guard as the default home launcher and redo the 7
   setup steps (Usage Access, Device Admin, Overlay, Launcher,
   Notification Access, Battery, Autostart).

## Honest limits (unchanged)

- No on-device test was possible (no Android emulator/adb on this
  Linux VM). The crash cause is established by code inspection +
  the official Android 14 behaviour-change documentation, and the
  fix removes the exact throwing call — but the real proof is Fahim
  opening v6.1.1 on his Infinix. If it still crashes, the next step
  is the exact crash text from Android's "App info → …" / a
  logcat, which will name the throwing line.
- Safe Mode / ADB / a second profile can still bypass any app-level
  guard, as before.

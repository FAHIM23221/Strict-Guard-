#!/usr/bin/env python3
"""Assemble the APK: copy the aapt2-linked base APK and add the dex file(s).

Usage: assemble.py <linked.apk> <dex-dir> <out.apk>
The .arsc and res/ entries come from the linked APK; classes*.dex from d8.
"""
import sys
import zipfile
import shutil
import os

linked, dex_dir, out = sys.argv[1], sys.argv[2], sys.argv[3]

tmp = out + ".tmp"
shutil.copyfile(linked, tmp)
with zipfile.ZipFile(tmp, "a", zipfile.ZIP_DEFLATED) as z:
    for name in sorted(os.listdir(dex_dir)):
        if name.endswith(".dex"):
            z.write(os.path.join(dex_dir, name), name)
os.replace(tmp, out)
print("assembled", out)

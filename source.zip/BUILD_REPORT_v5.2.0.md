# BUILD REPORT — Strict Guard v5.2.0

Date: 2026-11-07. Built for Olivia (Infinix X6886, Android 16).
Base: v5.1.0 source in this same directory (verified byte-identical to
~/workspace/your_files/Strict-Guard-v5.1.0-source.zip before editing).
Package: `app.strictguard`, versionName 5.2.0, versionCode 32, minSdk 29, targetSdk 34.
No APK was decompiled; built from the v5 source only, manual kotlinc + aapt2 + d8
route (Gradle cannot run in this sandbox).

## Result: SUCCEEDED

- **APK:** `~/workspace/your_files/Strict-Guard-v5.2.0.apk` — 763,975 bytes
- **SHA-256:** `f90d2e8386d70a3aa4b9eee8617b95d96cfecb099edf4bcf940a8e1415dce327`
- **Signature:** apksigner verifies, 1 signer (same fresh debug keystore as v5/v5.1,
  CN=Strict Guard, O=Self-built, C=BD). Signing scheme **v3 only** (v1/v2 false)
  — same apksigner 35.0.0 quirk as before; v3 covers Android 9+ and minSdk is 29.
- **Unit tests: 44/44 pass** (JUnit 4.13.2) — v5.1's 31 + 13 new v5.2.0 tests
  (ScheduleTest: schedule maths, Shorts toggle, Smart Panel packages).
- **No Accessibility:** no AccessibilityService / BIND_ACCESSIBILITY / any
  "accessibility" string in the dex or manifest.
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no http(s)
  strings in the dex.
- **NOT tested on a real device.** Olivia must uninstall v3.7, v4.0.0, v5.0.0
  and v5.1.0 first (different signing key) before installing v5.2.0.

## What changed in v5.2.0

1. **Strict Mode schedule (Olivia's request 1).**
   - StrictSetupActivity now offers three choices: until midnight tonight
     (as before), for a number of days (1–365, typed in), or until a chosen
     date + time (DatePicker + TimePicker). Test mode (1 minute) still exists.
   - The end is stored as wall-clock epoch millis (`strict_end_wall`) AND
     as an elapsedRealtime end derived from it. While the phone runs, the
     elapsed end governs, so changing the wall clock cannot end Strict early.
     After a reboot, `Store.recoverStrictAfterBoot()` (called from
     BootReceiver, GuardService.onCreate and MainActivity.onResume)
     recomputes the elapsed end from the wall end — so a multi-day Strict
     survives a reboot. If the wall end has passed, Strict ends cleanly.
   - The schedule cannot be shortened, cancelled or changed while Strict
     is on: the setup screen refuses to open during Strict, and Store
     setters refuse writes (the v5.1.0 lock). MainActivity now shows the
     full end date + time ("7 Nov 2026, 18:00"), not just the time.
   - Pure schedule maths lives in `Limits` (`wallEndForDays`,
     `wallEndForDateTime`, `validScheduleDateTime`, `recoveredElapsedEnd`)
     and is unit-tested.

2. **Device Admin protection (Olivia's request 2) — best-effort, honest.**
   - Settings (`com.android.settings`) was already in BUILTIN_STRICT, so
     the Device Admin settings screen cannot be reached while Strict is
     on — kept, and verified by the existing test.
   - GuardService now checks Device Admin on EVERY 500 ms poll. On loss it
     writes a Tamper Log entry (`ADMIN_LOST device-admin turned off in
     Settings`), shows a high-importance notification that opens the app
     so admin can be turned back on, and keeps blocking via UsageStats
     anyway (blocking never depended on admin). `GuardAdminReceiver`
     still logs enable/disable events.
   - The UI does NOT claim deactivation is impossible: the setup step now
     reads "Admin is monitored: turning it off in Settings is logged, not
     impossible" (English + Bengali). Android genuinely lets the user
     deactivate admin in Settings — no app can change that.

3. **Sidebar / Smart Panel floating block (Olivia's request 3).**
   - `com.transsion.smartpanel` (the XOS Smart Panel — verified in the XDA
     Infinix debloat list and the Infinix bloatware registry) and
     `com.transsion.XOSLauncher` added to BUILTIN_STRICT, so the panel
     itself is locked during Strict/Night.
   - The real block was already mode-agnostic: UsageStats
     MOVE_TO_FOREGROUND fires for a package in every window mode, so a
     blocked app opened from the sidebar as a floating window, in
     split-screen or PiP is still caught by the 500 ms poll.
   - Strengthened the overlay: full-screen TYPE_APPLICATION_OVERLAY, now
     clickable, so touches land on the block overlay instead of passing
     through to the floating window beneath it.

4. **YouTube Shorts (Olivia's request 4).**
   - New "Block YouTube Shorts" toggle on the main screen (switch + row,
     locked during Strict like every other setting, persisted).
   - Without Accessibility the app cannot tell Shorts apart from normal
     YouTube inside the YouTube app, so the toggle blocks the WHOLE
     YouTube app (`com.google.android.youtube` + YouTube Music) at all
     times while it is on — new `BlockDecider.Kind.SHORTS`. The feature
     description says exactly that in one line, in English and Bengali.
   - YouTube inside a browser cannot be told apart from other browsing
     without Accessibility either; browsers are covered by the existing
     Strict / daily-limit rules (browsers are blocked during Strict and
     after their own 90-minute limit).

## Kept unchanged (verified by tests)

- LOCK DURING STRICT (v5.1.0): all settings locked until Strict ends.
- Strict Mode blocks Facebook / Chrome / YouTube / AI groups itself.
- Usage accumulated on EVERY 500 ms poll; floating / split-screen / PiP
  blocking; Night Lock + allowed-apps; custom blocklist; Tamper Log;
  Diagnostics (now also shows Shorts toggle, admin monitoring and the
  Strict wall-clock end); boot receiver; calm muted sage-green UI;
  one-tap Bangla/English switch (persisted); Dark + Light modes (persisted).

## Honest limits

- Up to ~500 ms visibility of a blocked app before the block screen.
- Device Admin CAN still be deactivated in Android Settings when Strict
  is off (and the Settings block only works while GuardService runs with
  Usage Access). Deactivation is now logged + notified, not prevented.
- A wall-clock schedule has one trade-off: if the user changes the wall
  clock AND reboots, the recomputed end follows the (changed) clock.
  Clock changes are logged to the Tamper Log.
- Shorts = whole YouTube app; there is no way to block only Shorts
  without Accessibility, which Olivia forbade (it stops by itself on
  her Infinix).
- Force-stop from Settings stops the guard until the app is opened again
  or the phone reboots. Safe Mode / ADB / second profile can bypass.
- No on-device testing in this sandbox.

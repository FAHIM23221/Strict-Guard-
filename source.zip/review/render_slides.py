#!/usr/bin/env python3
"""Render the Strict Guard v6.0.0 review walkthrough slides.

Reconstructions drawn from the app's REAL layouts/strings
(activity_launcher.xml, MainActivity dashboard, BlockActivity,
BootReceiver flow) — NOT screenshots of a running app, because no
Android emulator or device exists in this sandbox. Every slide is
labelled as a walkthrough reconstruction in the video itself.

Font rule (learned from the first render): Noto Sans Bengali has no
Latin glyphs, so Latin-only strings use DejaVu and Bengali-only
strings use Noto Sans Bengali; mixed strings are drawn in parts.
"""
import os
from PIL import Image, ImageDraw, ImageFont

OUT = "/tmp/sg6/slides"
os.makedirs(OUT, exist_ok=True)

W, H = 720, 1280
BG = (244, 246, 242)
CARD = (255, 255, 255)
SAGE = (71, 107, 91)
SAGE_DARK = (58, 90, 76)
SAGE_TRACK = (122, 152, 137)
TEXT = (30, 42, 36)
TEXT2 = (90, 107, 96)
LIGHT = (217, 228, 220)
WHITE = (255, 255, 255)
BORDER = (220, 226, 220)

BN = "/usr/share/fonts/truetype/noto/NotoSansBengali-Regular.ttf"
BNB = "/usr/share/fonts/truetype/noto/NotoSansBengali-Bold.ttf"
EN = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
ENB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def f(path, size):
    return ImageFont.truetype(path, size, layout_engine=ImageFont.Layout.RAQM)


def canvas(bg=BG):
    return Image.new("RGB", (W, H), bg)


def rrect(d, box, r, fill):
    d.rounded_rectangle(box, radius=r, fill=fill)


def text(d, xy, s, font, fill, anchor="la"):
    d.text(xy, s, font=font, fill=fill, anchor=anchor)


def text_w(d, s, font):
    return d.textlength(s, font=font)


def is_ascii(s):
    return all(ord(c) < 128 for c in s)


def auto_font(s, size, bold=False):
    """DejaVu for Latin-only, Noto Sans Bengali otherwise."""
    if is_ascii(s):
        return f(ENB if bold else EN, size)
    return f(BNB if bold else BN, size)


def mixed_center(d, cx, y, parts, fill):
    """Draw parts [(text, font), ...] centred at cx. Returns end y."""
    total = sum(text_w(d, s, fo) for s, fo in parts)
    x = cx - total / 2
    for s, fo in parts:
        d.text((x, y), s, font=fo, fill=fill)
        x += text_w(d, s, fo)


def lock(d, cx, cy, s, color):
    w = s
    d.arc([cx - w * 0.32, cy - w * 0.55, cx + w * 0.32, cy + w * 0.15],
          start=180, end=0, fill=color, width=max(3, s // 10))
    d.rounded_rectangle([cx - w * 0.42, cy - w * 0.1, cx + w * 0.42, cy + w * 0.55],
                        radius=s // 8, fill=color)
    d.ellipse([cx - s * 0.06, cy + s * 0.12, cx + s * 0.06, cy + s * 0.24],
              fill=WHITE)


def check(d, x, y, s, color):
    d.line([(x, y + s * 0.55), (x + s * 0.35, y + s * 0.85),
            (x + s, y + s * 0.1)], fill=color, width=max(4, s // 8))


def cross(d, x, y, s, color):
    w = max(4, s // 8)
    d.line([(x, y), (x + s, y + s)], fill=color, width=w)
    d.line([(x + s, y), (x, y + s)], fill=color, width=w)


def header(d, label):
    text(d, (40, 44), label, f(ENB, 22), SAGE, anchor="la")
    d.line([(40, 82), (680, 82)], fill=BORDER, width=2)


def caption(d, s):
    text(d, (360, 1224), s, f(BN, 24), TEXT2, anchor="ma")


def usage_row(d, x, y, w, name, value, pct):
    text(d, (x, y), name, f(BN, 28), WHITE)
    text(d, (x + w, y + 2), value, f(EN, 24), LIGHT, anchor="ra")
    d.rounded_rectangle([x, y + 44, x + w, y + 54], radius=5, fill=SAGE_TRACK)
    fw = max(8, int(w * pct))
    d.rounded_rectangle([x, y + 44, x + fw, y + 54], radius=5, fill=WHITE)


# ---------------- Slide 1: title ----------------
im = canvas(SAGE)
d = ImageDraw.Draw(im)
text(d, (360, 380), "Strict Guard", f(ENB, 66), WHITE, anchor="ma")
text(d, (360, 470), "v6.0.0", f(EN, 44), LIGHT, anchor="ma")
text(d, (360, 580), "পর্যালোচনা", f(BNB, 52), WHITE, anchor="ma")
text(d, (360, 680), "নতুন লঞ্চার, বুটের ফাঁক বন্ধ", f(BN, 30), LIGHT, anchor="ma")
text(d, (360, 730), "কী কাজ করে, আর কী পরীক্ষা হয়নি", f(BN, 30), LIGHT, anchor="ma")
d.line([(180, 830), (540, 830)], fill=LIGHT, width=2)
text(d, (360, 870), "Walkthrough reconstruction —", f(EN, 24), LIGHT, anchor="ma")
text(d, (360, 905), "not a screen recording.", f(EN, 24), LIGHT, anchor="ma")
text(d, (360, 950), "এখানে ইমুলেটর বা ডিভাইস নেই।", f(BN, 24), LIGHT, anchor="ma")
im.save(f"{OUT}/01_title.png")

# ---------------- Slide 2: the new launcher ----------------
im = canvas()
d = ImageDraw.Draw(im)
header(d, "STRICT GUARD v6.0.0  —  LAUNCHER")
text(d, (40, 116), "শুভ বিকেল", f(BN, 40), TEXT2)
text(d, (40, 168), "17:05", f(ENB, 132), TEXT)
text(d, (40, 318), "রবিবার, ৮ নভেম্বর ২০২৬", f(BN, 34), TEXT2)
rrect(d, [40, 392, 680, 872], 36, SAGE)
text(d, (76, 424), "স্ট্রিক্ট মোড অন", f(BNB, 38), WHITE)
text(d, (76, 478), "Remaining: 4h 43m", f(EN, 30), LIGHT)
text(d, (76, 546), "আজকের ব্যবহার", f(BNB, 30), WHITE)
rows = [
    ("ফেসবুক", "1h 46m / 2h", 0.88),
    ("ক্রোম", "5m / 1h 30m", 0.06),
    ("ইউটিউব", "1h / 1h", 1.0),
    ("এআই চ্যাট", "30m / 30m", 1.0),
]
y = 592
for name, val, pct in rows:
    usage_row(d, 76, y, 568, name, val, pct)
    y += 70
text(d, (40, 906), "অ্যাপসমূহ", f(BNB, 36), TEXT)
apps = [
    ("SG", SAGE, "Strict Guard", True, False, "পিন করা"),
    ("f", (70, 100, 140), "Facebook", False, True, None),
    ("▶", (150, 70, 70), "YouTube", False, True, None),
    ("C", (90, 130, 110), "Chrome", False, False, None),
    ("S", (120, 125, 120), "Settings", False, True, None),
    ("P", (70, 110, 90), "Phone", False, False, None),
    ("A", (100, 100, 110), "Camera", False, False, None),
    ("F", (130, 120, 90), "Files", False, False, None),
]
y0, row_gap = 948, 150
for i, (ch, col, label, pinned, blocked, badge) in enumerate(apps):
    cx = 40 + (i % 4) * 165
    cy = y0 + (i // 4) * row_gap
    rrect(d, [cx + 31, cy, cx + 119, cy + 88], 22, col)
    text(d, (cx + 75, cy + 44), ch, f(ENB, 36), WHITE, anchor="mm")
    text(d, (cx + 75, cy + 94), label, f(EN, 19), TEXT, anchor="ma")
    if blocked:
        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        od = ImageDraw.Draw(ov)
        od.rounded_rectangle([cx + 31, cy, cx + 119, cy + 88], radius=22,
                             fill=(244, 246, 242, 150))
        im.paste(Image.alpha_composite(im.convert("RGBA"), ov).convert("RGB"), (0, 0))
        d = ImageDraw.Draw(im)
        lock(d, cx + 75, cy + 44, 40, (60, 60, 60))
    if badge:
        # Small sage text under the label (a pill here would overlap it).
        text(d, (cx + 75, cy + 118), badge, f(BN, 16), SAGE, anchor="ma")
caption(d, "লঞ্চার — শুভেচ্ছা, ঘড়ি, স্ট্রিক্ট কার্ড, ব্যবহারের বার, অ্যাপ গ্রিড")
im.save(f"{OUT}/02_launcher.png")

# ---------------- Slide 3: dashboard ----------------
im = canvas()
d = ImageDraw.Draw(im)
header(d, "STRICT GUARD v6.0.0  —  DASHBOARD")
text(d, (40, 116), "ড্যাশবোর্ড", f(BNB, 46), TEXT)
rrect(d, [40, 192, 680, 330], 32, SAGE)
text(d, (76, 220), "স্ট্রিক্ট মোড অন", f(BNB, 36), WHITE)
text(d, (76, 272), "Remaining: 4h 43m", f(EN, 28), LIGHT)
rows3 = [
    ("স্ট্রিক্ট সময়সূচি", "আজ রাত ১২টা পর্যন্ত"),
    ("নাইট লক", "00:00 – 06:00"),
    ("কাস্টম ব্লকলিস্ট", "৩টি অ্যাপ"),
    ("ট্যাম্পার লগ", "১২টি ঘটনা"),
    ("ডায়াগনস্টিকস", "সব ঠিক আছে"),
    ("হোম লঞ্চার", "সেট করা আছে"),
]
y = 366
rrect(d, [40, y, 680, y + 66 * len(rows3) + 28], 32, CARD)
for i, (k, v) in enumerate(rows3):
    yy = y + 16 + i * 66
    text(d, (76, yy), k, auto_font(k, 30), TEXT)
    text(d, (644, yy + 2), v, auto_font(v, 26), TEXT2, anchor="ra")
    if i < len(rows3) - 1:
        d.line([(76, yy + 48), (644, yy + 48)], fill=BORDER, width=2)
caption(d, "ড্যাশবোর্ড — v5.2.1-এর সব ফিচার অপরিবর্তিত")
im.save(f"{OUT}/03_dashboard.png")

# ---------------- Slide 4: block screen ----------------
im = canvas(SAGE_DARK)
d = ImageDraw.Draw(im)
lock(d, 360, 380, 190, WHITE)
text(d, (360, 520), "এই অ্যাপটি এখন বন্ধ আছে", f(BNB, 44), WHITE, anchor="ma")
text(d, (360, 600), "Facebook", f(ENB, 38), LIGHT, anchor="ma")
mixed_center(d, 360, 670, [
    ("স্ট্রিক্ট মোড চলছে — ", f(BN, 30)),
    ("4h 43m", f(EN, 30)),
    (" বাকি", f(BN, 30)),
], LIGHT)
text(d, (360, 730), "এই চেষ্টা ট্যাম্পার লগে লেখা হয়েছে", f(BN, 26), LIGHT, anchor="ma")
d.line([(180, 820), (540, 820)], fill=LIGHT, width=2)
text(d, (360, 860), "বন্ধ অ্যাপ: আবছা ও তালার চিহ্ন", f(BN, 26), LIGHT, anchor="ma")
text(d, (360, 900), "ট্যাপ করলেও অ্যাপ খোলে না", f(BN, 26), LIGHT, anchor="ma")
caption(d, "ব্লক স্ক্রিন — বন্ধ অ্যাপ খোলে না, চেষ্টা লগ হয়")
im.save(f"{OUT}/04_block.png")

# ---------------- Slide 5: boot gap timeline ----------------
im = canvas()
d = ImageDraw.Draw(im)
header(d, "STRICT GUARD v6.0.0  —  BOOT GAP")
text(d, (40, 116), "বুটের ফাঁক — কীভাবে বন্ধ হলো", f(BNB, 40), TEXT)
steps = [
    ("পাওয়ার অন", "ফোন চালু"),
    ("LOCKED_BOOT_COMPLETED", "আনলকের আগেই গার্ড চালু"),
    ("USER_UNLOCKED", "গার্ড আসল অবস্থা আবার পড়ে"),
    ("BOOT_COMPLETED", "লঞ্চার সাথে সাথে খোলে"),
]
x_line = 96
y = 260
d.line([(x_line, y + 20), (x_line, y + 20 + 3 * 170)], fill=SAGE, width=6)
for i, (t, sub) in enumerate(steps):
    cy = y + 20 + i * 170
    d.ellipse([x_line - 22, cy - 22, x_line + 22, cy + 22], fill=SAGE)
    d.ellipse([x_line - 9, cy - 9, x_line + 9, cy + 9], fill=WHITE)
    text(d, (150, cy - 34), t, auto_font(t, 30, bold=True), TEXT)
    text(d, (150, cy + 6), sub, f(BN, 28), TEXT2)
rrect(d, [40, 1000, 680, 1100], 28, SAGE)
text(d, (360, 1050), "স্ট্রিক্ট রিবুটের পরেও অন থাকে — কোনো ফাঁক নেই", f(BN, 28), WHITE, anchor="mm")
caption(d, "তিন স্তর — আনলকের আগে, বুটে, আনলকে")
im.save(f"{OUT}/05_boot.png")

# ---------------- Slide 6: honest limits ----------------
im = canvas()
d = ImageDraw.Draw(im)
header(d, "STRICT GUARD v6.0.0  —  HONEST REVIEW")
text(d, (40, 116), "সৎ পর্যালোচনা", f(BNB, 46), TEXT)
rrect(d, [40, 192, 680, 560], 32, SAGE)
check(d, 76, 226, 30, WHITE)
text(d, (122, 220), "যাচাই হয়েছে", f(BNB, 36), WHITE)
ok = ["৮৭টি ইউনিট টেস্ট পাস", "ম্যানিফেস্ট ও ডেক্স পরীক্ষা করা",
      "কোনো অ্যাক্সেসিবিলিটি নেই", "কোনো ইন্টারনেট নেই", "হোম ইনটেন্ট আছে"]
yy = 282
for s in ok:
    text(d, (76, yy), s, f(BN, 30), WHITE)
    yy += 54
rrect(d, [40, 592, 680, 960], 32, CARD)
cross(d, 76, 626, 30, TEXT)
text(d, (122, 620), "যাচাই হয়নি, সীমা", f(BNB, 36), TEXT)
no = ["আসল ফোনে ইনস্টল হয়নি", "এখানে ইমুলেটর বা ডিভাইস নেই",
      "সেফ মোড, এডিবি বাইপাস করে",
      "স্ট্রিক্ট বন্ধ থাকলে ডিভাইস অ্যাডমিন বন্ধ করা যায়"]
yy = 682
for s in no:
    text(d, (76, yy), s, f(BN, 30), TEXT)
    yy += 54
text(d, (360, 1010), "আসল পরীক্ষা ফাহিমের ইনফিনিক্সে করতে হবে", f(BN, 28), TEXT2, anchor="ma")
caption(d, "যা যাচাই হয়েছে — আর যা হয়নি")
im.save(f"{OUT}/06_limits.png")

print("slides done:", sorted(os.listdir(OUT)))

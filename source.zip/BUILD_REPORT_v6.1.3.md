# BUILD REPORT — Strict Guard v6.1.3

Date: 2026-11-09 (early morning). Built for Fahim (Infinix X6886, Android 16).
Base: v6.1.2 source in this same directory (SHA-256
`d0e597daf1f32f0b088d0d6eedce312c518582ddc49796e4afbeecfece089b6c`).
No APK was decompiled; built from the v5/v6 source only, manual kotlinc + aapt2 + d8
route (Gradle cannot run in this sandbox).

## Result: SUCCEEDED

- **APK:** `~/workspace/your_files/Strict-Guard-v6.1.3.apk` — 867,656 bytes
- **SHA-256:** `2dcf4789af7dc66749b99df5995c65ae6d3d1f613496e738572ec1bf514cebb1`
- **Source zip:** `~/workspace/your_files/Strict-Guard-v6.1.3-source.zip`
- **Signature:** apksigner verifies, 1 signer (same fresh debug keystore as
  v5/v5.1/v5.2/v5.2.1/v6.0.0/v6.1.0/v6.1.1/v6.1.2, CN=Strict Guard, O=Self-built, C=BD).
  Signing scheme **v3 only** (v1/v2 false) — same apksigner 35.0.0 quirk as before;
  v3 covers Android 9+ and minSdk is 29.
- **Unit tests: 239/239 pass** (JUnit 4.13.2) — v6.1.2's 221 + 11 new in
  `AlwaysAllowedTest.kt` + 7 new in `StudyCountdownTest.kt`; the 3
  ClaudeExemptionTest cases that asserted Claude was blocked in
  Strict/Night were updated to the new rule (see Feature 1).
- **No Accessibility:** 0 "accessibility" strings in the dex, no
  AccessibilityService / BIND_ACCESSIBILITY in the manifest.
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no
  http(s) URL strings in the dex.
- **New-code markers confirmed in the built APK's dex:** `AlwaysAllowed`,
  `isAlwaysAllowed`, `defaultNightAllowed`, `StudyCountdown`,
  `studyCountdownRing`. The countdown layout
  (`res/layout/overlay_study_countdown.xml`) and its ring drawables
  (`bg_study_ring`, `bg_study_ring_track`, `bg_study_countdown`) are
  in the built APK. HOME intent confirmed.
- **NOT tested on a real device.** Fahim must uninstall v6.1.2 first
  (different signing key) before installing v6.1.3, then pick Strict Guard
  as the default home launcher and redo the 7 setup steps.
- **Scope, per Fahim's instruction:** ONLY the two features below (plus
  the Night Lock default he added by voice) are in this version. The
  MCQ time-earning feature and the tiered Strict double-confirm /
  cancel windows are explicitly NOT in v6.1.3 — they stay for later,
  when he says so.

## Feature 1 — Always-unlocked apps: Brilliant, bKash, Nagad, Claude, WhatsApp, Messenger

Fahim (2026-11-09 ~00:03, text): "কিছু অ্যাপের জন্য কোন নিয়ম থাকবে
না এগুলো সব সময়ই আনলক থাকবে" — Brilliant, bKash, Nagad, Claude,
WhatsApp, Messenger. NO rules apply to them, ever: exempt from Strict
Mode, Night Lock, daily limits, break cycle, entry delay, Study Lock
and the custom blocklist. The launcher never shows a lock badge on
them, and their usage is never counted.

**This reverses the v6.1.0 rule** that Claude stayed blocked during
Strict Mode and Night Lock (Fahim confirmed that on 2026-11-08) — he
now wants Claude fully exempt too. WhatsApp was already excluded from
the entry delay only; it is now exempt from everything, as is Messenger.

### Verified package names (checked 2026-11-09, never guessed)

| App | Package | Verified against |
|---|---|---|
| Brilliant | `org.brilliant.android` | Google Play (id=org.brilliant.android), AppBrain, APKFab |
| bKash | `com.bKash.customerapp` | Uptodown, APKMirror, Play URL — NOTE the capital K; package names are case-sensitive (same lesson as the eTestPaper deadlock) |
| Nagad | `com.konasl.nagad` | AppBrain (appbrain.com/app/nagad/com.konasl.nagad), andro.io |
| Claude | `com.anthropic.claude` | Already in Limits.CLAUDE_PACKAGE (Play-verified in v6.1.0) |
| WhatsApp | `com.whatsapp` | Uptodown / APKFab / Play |
| Messenger | `com.facebook.orca` | Already in the FACEBOOK group list in Limits.kt; package-name reference + Threads Play link |

Not included on purpose: bKash merchant / business variants
(`com.bKash.merchantapp`, `com.bkash.businessapp`) and Nagad agent /
DSO variants (`com.konasl.nagad.agent`, `com.konasl.nagad.dso`) —
only the customer apps Fahim named. All six were verified; nothing
was left unverified, so nothing is missing from the set.

### How it is enforced (new `AlwaysAllowed.kt`)

- `AlwaysAllowed.PACKAGES` — the six, hard-coded like the study-app
  link (no UI to change it, so it cannot be weakened in a moment of
  temptation). `isAlwaysAllowed(pkg)` is the single check.
- `BlockDecider.decide()` — checked FIRST, right after the
  own-package/launcher return, before limit / break / Study / Strict
  / Night / custom. Same defence-in-depth pattern as the study-app
  exemption (v6.1.2). `decideStudy()` also returns null for the six.
- `LauncherLogic.tapDecision()` — checked before the launcher-bypass
  branch and before decide(), so the launcher tile never shows a
  lock badge on them.
- `EntryDelay.shouldDelay()` — always-unlocked apps never get the
  delay (none of the six is a delay app anyway; this is the second
  layer).
- `GuardService.tick()` usage counting — the six are never counted.
  This matters for Messenger: it is in the FACEBOOK group, so without
  this its use would count toward Facebook's 120-minute limit. Claude
  was already skipped via `Limits.isLimitExempt`; the new check covers
  all six before any counting happens.
- Main page settings row (was "Claude — unlimited") now reads
  "Always unlocked apps" / "সবসময় আনলক অ্যাপ" and names all six
  (EN + BN strings updated).

## Feature 2 — Circular study countdown overlay

Fahim (2026-11-09 ~00:03, text): while using eTestPaper for the 15
fair minutes, a small circular countdown runs at the top of the screen
until 15m ends; if the app screen stays still / idle, the countdown
PAUSES.

### What was built

- New `StudyCountdown.kt` (pure state machine, unit-tested) +
  `overlay_study_countdown.xml` + ring drawables (Warm Sand dusty
  rose `#C9A189` on a translucent cream track, dim dark pill
  background, calm and non-distracting).
- `GuardService.syncStudyCountdownOverlay()` drives it on every
  500 ms tick while a lock runs: the ring fills 0 → 900 s as minutes
  accumulate, the text shows the time left ("15:00" → "00:00").
- Non-modal by construction: a small (~92 dp) WRAP_CONTENT overlay
  at the top centre, `FLAG_NOT_TOUCH_MODAL` — touches outside the
  circle pass straight through to eTestPaper, so the countdown can
  never block studying. Only taps ON the circle itself reach it.
- Pauses (dimmed circle + pause mark) when: the screen turns off,
  the keyguard locks, a phone call is in front, system UI is in
  front — and when idle (see below). Hides when he leaves eTestPaper
  for any other app (the timer resets then anyway) and disappears
  when the 15 minutes complete or the lock ends. If the overlay
  permission is missing, the circle simply cannot be shown — the
  timer itself still runs correctly, and the add is retried when the
  permission comes back (setup step: Overlay).

### The honest idle limit — read this before promising more

WITHOUT an Accessibility Service the guard CANNOT observe touches,
scrolls or taps inside another app (eTestPaper). There is no Android
API that tells us the eTestPaper screen "stays still". So "idle" is
defined through the attention check that already exists: midway
(~7:30) an "আমি পড়ছি" prompt appears and must be tapped within
60 seconds. The countdown circle itself is tappable — tapping the
circle IS that confirmation and resumes an idle-paused countdown.
If the prompt stays untapped for over 60 seconds, the countdown is
idle-paused and stays paused until the circle (or the attention
prompt's own button) is tapped. That is the closest honest
approximation of "screen still" without Accessibility. This build
does NOT claim true touch detection inside eTestPaper — neither in
the code comments nor here. True per-touch idle detection would
need the Accessibility Service Fahim forbade (it breaks the app on
his Infinix).

## Feature 3 — Night Lock default allowed-apps list (voice add-on)

Fahim (2026-11-09 ~00:04, voice): during Night Lock, when the
launcher shows only certain allowed apps, the six always-unlocked
apps must ALREADY be in that list by default — he must not have to
add them separately. He can still add more apps later.

- `Store.nightAllowed` now returns `AlwaysAllowed.PACKAGES` when no
  list has ever been saved (detected with `prefs.contains`, not with
  an empty set — an explicitly saved empty list is his choice and
  stays empty). Once he saves a list in the Night Lock picker, that
  saved list is used exactly as saved, including if he removed some
  of the six or added others.
- The picker (`AppPickerActivity`) reads the same getter, so the six
  show pre-checked the first time he opens it. The Night Lock
  description (EN + BN) now says the six are already included.
- The guard and launcher already enforce `nightAllowed` through
  `BlockDecider.decide()` / `tapDecision()`; with the six also in
  `AlwaysAllowed`, they open during Night Lock even before any list
  is saved — two layers, same result.

## Tests

- **239/239 pass** (221 in v6.1.2 + 18 new/changed).
- `AlwaysAllowedTest.kt` (11 new): all six packages in the set;
  case-sensitivity (lower-case `com.bkash.customerapp` is NOT
  exempt); other apps not exempt; each of the six allowed under
  Strict, Night Lock, Study Lock, after the Facebook/AI limit is
  used up, during a break, and while in the custom list; launcher
  tap never blocked; entry delay never applies; Night Lock default
  is the six until a list is saved, and a saved list wins exactly.
- `StudyCountdownTest.kt` (7 new): remaining time, ring fill,
  "mm:ss" text, RUNNING while studying, HIDDEN without a lock /
  without the app / when leaving, PAUSED on screen-off/call, and
  idle-pause only after 60 s untapped (30 s and exactly 60 s are
  NOT idle; 61 s is).
- `ClaudeExemptionTest.kt` (updated): the 3 cases that asserted
  Claude was blocked in Strict/Night now assert it is allowed;
  the limit/break/group cases are unchanged.

## Install

1. **Uninstall v6.1.2 first** (same signing-key rule — Android
   refuses to install over it otherwise).
2. Install v6.1.3.
3. Open it, set Strict Guard as default home launcher, redo the
   7 setup steps (Usage Access, Device Admin, Overlay, Launcher,
   Notification Access, Battery, Autostart) — the Overlay step
   matters for the countdown circle: with it granted the circle
   shows at the top of eTestPaper; without it the timer still
   runs, just without the visible circle.
4. Test: Brilliant / bKash / Nagad / Claude / WhatsApp / Messenger
   must open with no wait, no badge, even with Strict on or at
   night; Facebook must still block under Strict. At 21:00 the
   Study Lock must pull him into eTestPaper with the small
   circular countdown at the top counting 15:00 down; leaving the
   app hides it, and the attention prompt at ~7:30 must be
   tappable on the circle itself. Night Lock picker must show
   the six pre-checked the first time it is opened.

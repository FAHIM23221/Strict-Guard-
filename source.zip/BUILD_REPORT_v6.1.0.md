# BUILD REPORT — Strict Guard v6.1.0

Date: 2026-11-08. Built for Fahim (Infinix X6886, Android 16).
Base: v6.0.0 source in this same directory (verified matching the
~/workspace/your_files/Strict-Guard-v6.0.0-source.zip contents before
editing — same app/ tree, plus the older build reports / Gradle files
that live only in the working tree).
Package: `app.strictguard`, versionName 6.1.0, versionCode 35, minSdk 29, targetSdk 34.
No APK was decompiled; built from the v5/v6 source only, manual kotlinc + aapt2 + d8
route (Gradle cannot run in this sandbox).

## Result: SUCCEEDED

- **APK:** `~/workspace/your_files/Strict-Guard-v6.1.0.apk` — 855,045 bytes
- **SHA-256:** `b46854780d0a047130eca80946c09a1dadc9f3713d67c30da3f86405bd63dc1a`
  (rebuilt 2026-11-08 ~18:52 +06 with the day-less message-bank
  expansion below — 10 variants per language, Bengali digits; same
  version 6.1.0 / code 35, so the APK hash changed from the previous
  v6.1.0 build `ac6cc699…`)
- **Source zip:** `~/workspace/your_files/Strict-Guard-v6.1.0-source.zip`
- **Signature:** apksigner verifies, 1 signer (same fresh debug keystore as
  v5/v5.1/v5.2/v5.2.1/v6.0.0, CN=Strict Guard, O=Self-built, C=BD). Signing scheme
  **v3 only** (v1/v2 false) — same apksigner 35.0.0 quirk as before; v3 covers
  Android 9+ and minSdk is 29.
- **Unit tests: 190/190 pass** (JUnit 4.13.2) — v6.0.0's 87 + 11 new in
  `BreakCycleTest.kt` (session quotas, carry-over across opens, break
  timing, daily-limit priority, BlockDecider BREAK, launcher tap) +
  10 new in `ClaudeExemptionTest.kt` (package verification, limit/break
  exemption, Strict/Night still blocking, launcher tap) + 8 new in
  `AutoThemeTest.kt` (06:00/18:00 boundaries, Dhaka hour, manual
  override holding until the next switch, full-day sequence) + 8 new
  in `SelfBlockTest.kt` (own settings activities, launcher/block-screen
  exemption, tile tap during Strict, Night Lock not self-blocking,
  MainActivity-foreground catch) + 1 net in `LauncherTest.kt` (the old
  "own app never blocked" test was replaced by the self-block tests) +
  4 new in `ClockFormatTest.kt` (00:05 → 12:05 AM, 12:05 → 12:05 PM,
  17:05 → 5:05 PM, 23:59 → 11:59 PM, 24-hour unchanged, Bengali
  markers) + 5 new in `SetupRowStateTest.kt` (granted → dead, revoked
  → re-enabled, locked during Strict, all seven step keys) + 10 new
  in `UsedAppsTest.kt` (used 5 days ago → shown, unused 40 days →
  hidden, never used → hidden, installed 2 days ago → shown, installed
  10 days ago → hidden, Strict Guard always shown, 30-day/7-day
  boundaries, toggle OFF restores the full list) + 12 new in
  `StudyLockTest.kt` (constants, 15 continuous minutes completing the
  lock, pause on screen-off keeping minutes, reset on leaving the app,
  attention check at 7:30 and pause after 60 s untapped, trigger only
  at night and only once, leftover-lock expiry at 06:00, reboot resume
  keeping minutes only if the session was continuous, missing-app
  blocking with Play Store + calls exempt, shared decide() STUDY,
  launcher tap during a lock) + 8 new in `EntryDelayTest.kt`
  (defaults/choices, social list, WhatsApp excluded, precedence of
  Strict/limit blocks, countdown to zero, reset on leaving) + 7 new
  in `StrictMirrorTest.kt` (encode/decode round-trip incl. the 1095-day
  end time, HMAC tamper detection, restore/expired/already-active
  decisions, tamper fallback = maximum duration, force-stop gap
  detection, payload parsing) + 10 new in `HscCountdownTest.kt`
  (decomposition, 210 days from 8 Nov 2026, launcher months format 6
  months 29 days + boundary cases, state transitions, Dhaka timezone,
  08:00 reminder once per day, day-less drop/popup, rotating messages
  stating the days left, date-picker round-trip) + 8 new in
  `FridayPrayerTest.kt` (Friday only, next Friday 09:00, alarm rings
  once, countdown slots in order then stop, no alerts on other
  days/disabled, late-open catch-up, sent slots never re-fire) +
  boundary updates in `ScheduleTest.kt` (365 valid, 1095 valid, 1096
  rejected; chosen date 1095 days ahead valid, beyond rejected) + 1
  new in `HscCountdownTest.kt` (day-less alert sequence: first
  observation seeds, midnight drop fires once, popup shows once per
  day, same-day polls do not repeat, reboot survival — a drop while
  the phone was off is detected after reboot from the persisted
  last-seen count) and the message tests strengthened (bank size 10,
  every template carries %1$d, Bengali-digit rendering, rotation
  covers all 10 variants and repeats every 10 days).
  Total: 87 + 103 = 190.
- **No Accessibility:** 0 "accessibility" strings in the dex, no
  AccessibilityService / BIND_ACCESSIBILITY in the manifest.
- **No INTERNET:** no `android.permission.INTERNET` in the manifest, no
  http(s) URL strings in the dex.
- **Auto-theme + self-block markers confirmed in the built APK's dex:**
  `AutoTheme`, `auto_theme`, `SELF_BLOCK`. The Warm Sand palette is in
  the light theme resources; new strings `blocked_self`, `f_auto_theme`,
  `f_auto_theme_desc` are in the built APK.
- **Clock + one-way-setup markers confirmed in the built APK's dex:**
  `ClockFormat`, `SetupRowState`, `PERMISSION_REVOKED`,
  `setup_granted`, `clock_24h`. New strings `f_clock`,
  `clock_desc_24`, `clock_desc_12`, `setup_allowed`, `revoked_title`,
  `revoked_text`, `settings_title`, `menu_title`, `status_card_on`,
  `status_card_off`, `f_lang`, `f_theme`, `row_desc_current` are in
  the built APK.
- **Hide-Unused-Apps markers confirmed in the built APK's dex:**
  `UsedApps`, `show_only_used`. New strings `f_show_used`,
  `f_show_used_desc`, `hidden_apps`, `all_apps` are in the built APK.
- **Study Lock markers confirmed in the built APK's dex:**
  `StudyLock`, `STUDY_APP_PACKAGE`, `STUDY_LOCK_DONE`,
  `STUDY_APP_MISSING`, `STUDY_RESET`. New strings `f_study`,
  `f_study_desc`, `study_title`, `study_time`, `study_time_desc`,
  `study_start_title`, `study_start_text`, `study_missing_title`,
  `study_missing_text`, `study_install_button`,
  `study_attention_text`, `study_attention_button`, `blocked_study`
  are in the built APK.
- **HOME intent filter confirmed in the built APK** (aapt2 xmltree):
  `LauncherActivity` declares MAIN + HOME + DEFAULT, exported, singleTask.
- **NOT tested on a real device.** Fahim must uninstall v3.7, v4.0.0,
  v5.0.0, v5.1.0, v5.2.0, v5.2.1 and v6.0.0 first (different signing key)
  before installing v6.1.0.

## New in v6.1.0 — Break Cycle (বিরতি সাইকেল)

Fahim's request: daily limits stay exactly as they are and are NOT
changeable, but after a fixed amount of use the app must kick him out
for a forced 20-minute break, then let him use again — a repeating
cycle. Facebook: 40 min use, 20 min break, repeating. YouTube: 30 min
use, 20 min break, then the remaining 30 min.

### Exact numbers per group

Daily limits are UNCHANGED (Facebook 120, Chrome 90, YouTube 60,
AI chat 30 minutes). Session quota = one session of use, then a
forced 20-minute break, repeating until the daily total is used up:

| Group    | Daily limit | Session | Break | Cycle pattern            |
|----------|-------------|---------|-------|--------------------------|
| Facebook | 120 min     | 40 min  | 20 min| 40 / 20 / 40 / 20 / 40   |
| YouTube  | 60 min      | 30 min  | 20 min| 30 / 20 / 30             |
| Chrome   | 90 min      | 45 min  | 20 min| 45 / 20 / 45             |
| AI chat  | 30 min      | 15 min  | 20 min| 15 / 20 / 15             |

Chrome and AI were NOT specified by Fahim — they generalise his
numbers with the rule "session = half the daily limit, break always
20 minutes". This is stated in the UI (dashboard toggle description,
EN + BN) and here so he can correct it if he wants different numbers.

### Rules, as built

- **Session usage carries over across app opens.** Session usage is
  persisted per group per day (`break_session_<group>` in Store), so
  closing Facebook after 25 minutes and reopening it later leaves
  15 minutes of that session — it does NOT reset.
- **Auto kick-out.** The moment a session quota is reached, the app
  is blocked immediately with the same block screen as other blocks,
  and a `BREAK_START` entry is written to the Tamper Log.
- **The break cannot be skipped.** The break end is a persisted
  wall-clock epoch (`break_until_<group>`), checked on every 500 ms
  poll. Reopening the app during the break shows the block screen
  again. The break survives a reboot (persisted state; after reboot
  the guard re-reads it — note: during direct boot before unlock the
  credential-encrypted prefs are unreadable, so a break is enforced
  from the moment the user unlocks, like the rest of the guard state).
- **Break time does NOT count toward the daily limit.** While in a
  break, no usage is accumulated for that group.
- **Daily limit wins.** When the daily limit is reached — including
  at the exact tick a session quota is also reached (Facebook's third
  40-minute session ends at 120 minutes) — the app stays blocked for
  the rest of the day (LIMIT), with no break started.
- **Strict Mode / Night Lock still block regardless** of the break
  cycle, as before.
- **Distinct block reason.** The block screen shows the break reason
  with a live countdown ("বিরতি শেষ হতে বাকি ১৭ মিনিট" / "Break ends
  in 17 min"), distinct from "Today's limit is used up". The overlay
  shows the same countdown. The dashboard usage row also shows the
  remaining break time while a group is in a break.
- **Launcher tap path enforces the break** with the same BlockDecider
  rules: a group in a break shows dimmed with a lock mark on the
  launcher grid, and tapping it opens the break block screen.
- **Toggle.** A "বিরতি সাইকেল / Break Cycle" row with a switch sits
  on the dashboard (default ON, locked during Strict like every other
  setting), with a one-line EN/BN explanation of the cycle. Turning
  it off returns to v6.0.0 behaviour (daily limits only).
- **Tamper Log.** Break start (`BREAK_START <group> session done,
  20 min break`) and break end (`BREAK_END <group> break over`) are
  logged.

### Where it lives in the code

- `Limits.kt` — new pure `BreakCycle` object: session quotas,
  `BREAK_MS`, `isInBreak`, `breakRemainingMs`, `onUseTick`
  (session/break state machine, daily-limit priority).
- `Store.kt` — persisted break state per group per day
  (`breakCycleEnabled`, `sessionUsedFor`, `breakUntilFor`,
  `breakUntilMap`, `addSessionUsage`, `startBreak`), with day rollover.
- `BlockDecider.kt` — new `Kind.BREAK`; `decide()` takes the break
  map + wall clock and returns BREAK (with `breakUntilMs`) when a
  group is in a break. LIMIT is checked first, so it wins.
- `GuardService.kt` — the tick applies the cycle: no usage during a
  break, session accumulation + break start on quota, break-end
  logging, BREAK decision passed to the block screen/overlay.
- `BlockActivity.kt` / `LauncherActivity.kt` / `LauncherLogic.kt` —
  BREAK reason + countdown on the block screen, break enforcement on
  launcher taps.
- `MainActivity.kt` — Break Cycle toggle row + break countdown on
  usage rows.
- `values/strings.xml`, `values-bn/strings.xml` — `f_break`,
  `f_break_desc`, `blocked_break`, `break_remaining` (EN + BN).
- `app/src/test/.../BreakCycleTest.kt` — 11 new tests.
- `app/src/test/.../ClaudeExemptionTest.kt` — 10 new tests (see below).

## Added to the same v6.1.0 build — Warm Sand launcher theme + auto theme by time (Fahim, 2026-11-08)

### Design 3 "Warm Sand" as the light theme

Fahim picked Design 3 (`~/workspace/your_files/launcher-designs/design-3-sand.png`):
warm cream background, warm dusty-rose/brown text, large clock on top,
Strict card in a deeper warm brown with cream usage bars, rounded app
tiles. Applied as the launcher's light theme — the light theme palette
in `colors.xml` is now Warm Sand (the dark theme keeps its existing
dark palette, unchanged):

| Element | Warm Sand (light theme) |
|---|---|
| Background | warm cream `#F4EBDD` |
| Cards | lighter cream `#FBF6EC` |
| Text | warm brown `#6E4A38` |
| Secondary text | dusty rose-brown `#9A6F57` |
| Strict card / buttons (accent) | deep warm brown `#8A6A52` |
| Usage bars on the card | cream fill `#F5E9D3` on translucent track |
| Badges / app tiles | sand `#EFE3D0` |

Layout is unchanged (greeting, big clock, date, Strict card, usage
bars, app grid) and the calm non-addictive rule is kept. Because the
light theme is shared, the dashboard's light theme is Warm Sand too —
the status card and buttons are warm brown in light mode as well.
The dark theme is untouched.

### Auto theme by time — "অটো থিম"

- **Toggle on the dashboard** (features list, default ON), with a
  one-line EN/BN explanation: "Dark at 6 PM, Light at 6 AM (Dhaka
  time) — automatic. A manual theme change holds until the next
  switch; the automatic switch still applies during Strict Mode."
  / "সন্ধ্যা ৬টায় অন্ধকার, সকাল ৬টায় আলো (ঢাকা সময়) — স্বয়ংক্রিয়।
  হাতে থিম বদলালে পরের বদলের সময় পর্যন্ত থাকে; Strict Mode চলাকালেও
  স্বয়ংক্রিয় বদল হয়।"
- **Switch times:** Dark turns on automatically at **18:00** every
  evening, Light at **06:00** every morning, Asia/Dhaka local time.
  Boundaries are exact: 05:59 is dark, 06:00 is light; 17:59 is
  light, 18:00 is dark (unit-tested).
- **Evaluated on resume and on the GuardService poll** (every 500 ms),
  so the switch applies even if the app was closed at the switch time.
  When the guard flips the theme while an activity is open, it
  broadcasts `app.strictguard.THEME_CHANGED` and the open activity
  recreates with the new theme.
- **Survives reboot:** the toggle (`auto_theme`) and the last-applied
  state (`auto_theme_applied`) are persisted in `Store`; the guard
  re-evaluates on its poll after boot/unlock.
- **Manual override:** the automatic switch only fires when the
  desired theme differs from the last theme *it* applied. If Fahim
  manually picks Dark at 10:00, nothing forces it back — his choice
  holds until the next scheduled switch (18:00), when the automatic
  switch fires again.
- **Strict Mode:** the toggle itself is locked during Strict like
  every other setting (it cannot be turned on/off while Strict is on),
  but the scheduled automatic switch itself still applies during
  Strict — it is automatic, not a manual change, so it bypasses the
  lock-during-Strict guard (`Store.setThemeAuto()`). Stated in the UI
  note above and here.
- **Code:** new pure `AutoTheme` object (`desiredTheme`, `hourInDhaka`,
  `themeToApply`, `maybeApplyAutoTheme`); `Store.autoTheme`,
  `Store.autoThemeApplied`, `Store.setThemeAuto()`; `BaseActivity`
  evaluates on resume + listens for the switch broadcast;
  `GuardService.tick()` evaluates on every poll.

## Added to the same v6.1.0 build — Strict Guard self-block during Strict Mode (Fahim, 2026-11-08)

During Strict Mode, the Strict Guard app ITSELF must not open at all.

- **Tile tap:** tapping the Strict Guard tile in the launcher grid
  during Strict shows the block screen ("Strict Guard is locked
  during Strict Mode — it opens again when Strict ends" /
  "Strict Mode চলাকালে Strict Guard বন্ধ থাকে — Strict শেষ হলে আবার
  খুলবে") instead of opening the app. The tile is dimmed with a lock
  mark while Strict is on. When Strict is off, the tile opens the
  settings dashboard as before.
- **"Open Strict Guard" button** on the launcher is blocked the same
  way during Strict (it is another path into the app).
- **GuardService catch:** the guard also catches the app's own
  MainActivity (or any other settings/dashboard activity) coming to
  the foreground during Strict — activity-class level, the same
  approach as the v5.2.1 Settings fix — and sends it back to the
  launcher with the block screen. This covers the paths the tile
  cannot: the app icon on another launcher, Recents, a notification
  tap, and the app already being open when Strict started (so after
  starting Strict, the dashboard closes itself to the launcher within
  ~500 ms).
- **Launcher still works:** `LauncherActivity` (the home screen) and
  `BlockActivity` (the block screen) are exempt from the self-block —
  Home keeps working, and the block screen is what the self-block
  shows.
- **Tamper Log:** every self-block attempt is logged (`BLOCKED Strict
  Guard (app.strictguard) SELF_BLOCK` from the guard, `SELF_BLOCK …`
  / `LAUNCHER_BLOCKED … SELF_BLOCK` from the launcher).
- **Strict ends only by its schedule**, so the app becomes openable
  again when Strict ends.
- **Night Lock does NOT self-block:** Night Lock behaviour is kept as
  it was — the app's settings stay openable at night.
- **Code:** `BlockDecider.Kind.SELF_BLOCK` + pure
  `BlockDecider.isOwnSettingsActivity()` (own package + activity
  class, excluding LauncherActivity/BlockActivity; null activity class
  never blocks, so the home screen is never blocked on a guess);
  `LauncherLogic.tapDecision()` returns SELF_BLOCK for the own package
  during Strict; `GuardService.tick()` checks it before the normal
  decision (`decide()` itself still returns null for the own package,
  so no other caller can accidentally block the launcher);
  `BlockActivity` + guard overlay show the `blocked_self` reason.

## Added to the same v6.1.0 build — Hide Unused Apps in the launcher (Fahim, 2026-11-08)

- **Toggle on the main page** (Settings section): "শুধু ব্যবহৃত অ্যাপ
  দেখাও" / "Show only used apps", **default OFF**, with a one-line
  EN/BN explanation. Locked during Strict Mode like other settings.
- **When ON**, the launcher grid shows only apps with foreground use
  in the **last 30 days** (from UsageStats — Strict Guard already has
  Usage Access), plus Strict Guard itself pinned first. Apps with no
  foreground use in the last 30 days, or never used, are hidden from
  the grid. **Newly installed apps get a 7-day grace period** (shown
  until classified, even if never used). Usage is **re-checked every
  time the launcher resumes** (the grid rebuilds on every refresh, so
  the list is always current).
- **Nothing becomes unreachable:** a **"লুকানো অ্যাপ (n)" / "Hidden
  apps (n)"** row at the bottom of the grid opens the **full list**
  (shown + hidden) as a tappable dialog ("সব অ্যাপ" / "All apps"), so
  a rarely-used app — a banking app, for example — can still be
  opened without turning the toggle off. Tapping an app there goes
  through the **same BlockDecider rules** as a grid tap (a hidden app
  is not blocked by being hidden, but Strict / Night / limit / break
  rules still apply).
- **Fully reversible:** hiding is only a launcher display filter —
  never an uninstall or a block. Turning the toggle OFF restores the
  full grid immediately, with all apps visible and no restart needed:
  the filter is applied fresh on every launcher resume, so there is
  no hidden-state to undo (unit-tested: ON-then-OFF returns the exact
  full list, hidden list empty).
- **Fail-open:** if Usage Access is off, usage cannot be read, so the
  launcher shows everything rather than hiding the whole grid on a
  guess.
- **Code:** new pure `UsedApps` object (`isShown`, `filterApps`,
  30-day window, 7-day grace); `Store.showOnlyUsedApps`;
  `LauncherActivity.buildGrid()` filtering + `queryLastUsed()` /
  `queryInstalled()` (UsageStats + firstInstallTime) + the hidden row
  + `showAllAppsDialog()`; `MainActivity` Settings toggle row.

## Added to the same v6.1.0 build — clock format toggle 24h/12h (Fahim, 2026-11-08)

- **Toggle on the main page** (Settings section): "ঘড়ি: ২৪ ঘণ্টা /
  ১২ ঘণ্টা" / "Clock: 24-hour / 12-hour". Tapping the row switches
  24-hour ↔ 12-hour and applies immediately, no restart; the row's
  description shows the current format with a live example
  ("Current: 12-hour — 5:05 PM. Tap to switch to 24-hour.").
- **Launcher clock too:** the launcher clock (which showed 24-hour
  "17:05") reads the same setting, so it follows the toggle.
- **Default: 24-hour** (current behaviour, unchanged).
- **12-hour format:** e.g. 5:05 PM, with a clear AM/PM marker — "AM" /
  "PM" in English, "পূর্বাহ্ণ" / "অপরাহ্ণ" in Bengali (the standard
  Bengali locale markers). Verified: 00:05 → 12:05 AM, 12:05 → 12:05
  PM, 17:05 → 5:05 PM, 23:59 → 11:59 PM (unit-tested, plus the 24-hour
  and Bengali-marker cases).
- **Persisted** (`clock_24h` in Store), and **locked during Strict**
  like every other setting (Store setter guard + the row is disabled
  during Strict; the app itself is blocked during Strict anyway).
- **Code:** new pure `ClockFormat` object; `Store.clock24h`;
  `LauncherActivity` clock binding; `MainActivity` Settings row.

## Added to the same v6.1.0 build — Design 1 "Warm Sand" main page (Fahim, 2026-11-08)

Fahim picked Design 1 (`~/workspace/your_files/main-ui-designs/design-1-warm-sand.png`).
The main page now matches it, in the same Warm Sand palette as the
launcher (warm cream background, warm dusty-rose/brown text, deep
warm-brown Strict card with cream usage bars) — the whole app is one
consistent Warm Sand look in light mode; the dark theme keeps its
existing dark palette. No behaviour changed, only the main-page
colours/layout:

- **Header:** centred "Strict Guard" title with a gear button on the
  right that jumps to the Settings section. Language and theme are no
  longer header buttons — they are Settings rows (same one-tap
  behaviour, same persistence, same lock during Strict). The header
  date line is gone (the launcher still shows greeting + clock +
  date).
- **Strict Mode card:** "Strict Mode: ON" / "Remaining: 4h 43m" /
  the schedule ("Strict until 9 Nov 2026, 00:00"), with **today's
  usage bars inside the card** (cream bars, as in the mockup) and the
  "Claude — সীমাহীন" note right-aligned under the AI bar.
- **Break-cycle status line** under the card, shown only while a group
  is in a forced break: "⏸ বিরতি সাইকেল: Facebook — বিরতি ১৪ মিনিট
  বাকি" / "⏸ Break Cycle: Facebook — Break ends in 14 min".
- **Settings section ("সেটিংস"):** Night Lock (toggle), Night Lock
  allowed-apps (kept — it is a real feature the mockup does not show,
  still reachable), বিরতি সাইকেল (toggle), অটো থিম (toggle), ঘড়ি
  ২৪ ঘণ্টা / ১২ ঘণ্টা (tap to switch), ভাষা বাংলা / English (tap to
  switch), থিম Dark / Light (tap to switch), Claude exemption note.
- **Menu section ("মেনু"):** কাস্টম ব্লকলিস্ট, home launcher, Tamper
  Log, Diagnostics.
- **Setup checklist kept below** (the mockup shows the top of the
  page; the permissions are still needed), with the setup progress
  ("Setup: 5 / 7 steps done") as its header. Strict button, monitoring
  button, lock banner, guard warning and footer are unchanged.

## Added to the same v6.1.0 build — one-way setup permission buttons (Fahim, 2026-11-08)

- **Once granted, dead:** in the setup checklist, a granted
  permission's row becomes permanently dead in the app — greyed out
  (dimmed, chevron hidden), badge showing "অ্যালাউ করা হয়েছে ✓" /
  "Allowed ✓", and tapping it does NOTHING (it does not open Settings
  again and offers no way to turn the permission off). Applies to all
  seven setup rows: Device Admin, Usage Access, Overlay, Notification
  Access, Battery optimisation, XOS Autostart, Default Home Launcher.
- **Re-checked on every resume** (after returning from the system
  permission screen) and **persisted**: which steps were granted
  before is stored in the Store (`setup_granted`), so the dead state
  survives restarts.
- **One necessary exception:** if Android reports a permission was
  later revoked from outside the app (via system Settings), the button
  re-enables so the guard can be repaired — otherwise a revoked
  permission could never be re-granted. The revocation is logged to
  the Tamper Log (`PERMISSION_REVOKED <key> <title>`) and shown as a
  high-importance notification that opens the app, as the existing
  Device Admin monitoring does. (The guard service already watches
  Device Admin, Usage Access and Overlay on every 500 ms poll and
  logs + notifies on loss; this is the same rule for the setup
  checklist itself.)
- **Code:** new pure `SetupRowState` object (GRANTED_DEAD / PENDING /
  LOCKED, `isRevocation`); `Store.setupGrantedKeys()` /
  `markSetupGranted()` / `unmarkSetupGranted()`; `MainActivity`
  revocation check in `refresh()` + `showRevokedNotification()`.

### Honest Android limit (stated plainly, as Fahim asked)

The in-app button is dead, and Settings is blocked during Strict, but
**when Strict is OFF, Android still lets the user revoke a permission
from system Settings by hand — no app can prevent that.** What the
guard does instead: it detects the revocation (guard-service poll for
Admin/Usage/Overlay, setup re-check on resume for all seven), logs it
to the Tamper Log, shows a notification, and re-enables the button so
the permission can be granted again. During Strict, Settings itself is
blocked, so the revocation cannot happen while Strict is on.

## Added to the same v6.1.0 build — Claude exemption (Fahim, 2026-11-08)

Fahim wants to use Claude unlimited: the AI chat group's 30-minute
daily limit and the break cycle must NOT apply to Claude.

- **Verified package:** `com.anthropic.claude` — it is in the AI
  group list in `Limits.kt`, and Google Play
  (`play.google.com/store/apps/details?id=com.anthropic.claude`) and
  APK listings confirm that is the official Claude by Anthropic app.
- **What is exempt:** Claude's usage is never counted (no daily
  usage, no session usage, no break). Even when ChatGPT/Gemini use up
  the 30-minute AI limit, or an AI break is active, Claude still
  opens. All other AI apps (ChatGPT, Gemini, Copilot, Perplexity,
  Character.AI) stay under the 30-minute daily limit and the
  15-min-use / 20-min-break cycle.
- **What is NOT exempt (confirmed by Fahim):** Claude STAYS in the AI
  group, so during Strict Mode it is blocked like every other AI app
  (`STRICT_GROUP`), and during Night Lock it is blocked too (`NIGHT`,
  unless it is on the Night Lock allowed-apps list). The exemption
  applies ONLY to the daily limit and the break cycle.
- **UI:** the AI usage row on the dashboard and on the launcher shows
  "Claude — সীমাহীন" / "Claude — unlimited" next to the 30-minute
  limit, and a dashboard feature row says in one line (EN + BN):
  "Claude is exempt from the AI daily limit and break cycle —
  unlimited use. It is still blocked during Strict Mode and Night
  Lock."
- **Code:** `Limits.CLAUDE_PACKAGE` + `Limits.isLimitExempt()`;
  `BlockDecider.decide()` skips LIMIT and BREAK for Claude only;
  `GuardService.tick()` skips all usage/session counting for Claude
  (Strict/Night decisions still run through the same `decide()`).

## Added to the same v6.1.0 build — Nightly Study Lock (Fahim, 2026-11-08)

- **The app — researched, not guessed.** "E-Test Paper for SSC &
  HSC" by StudyPlex / Nextive Solution LLC — board questions, model
  tests and HSC final model test for SSC/HSC students in Bangladesh.
  **Package: `com.nextive.eTestPaper`**, verified on two independent
  APK listings (APKPure, with SHA-256, and AppBrain). A screenshot
  Fahim sent 2026-11-08 shows the app installed on his launcher
  under the label "eTestPaper", which matches. **Fahim should still
  confirm it:** if the installed app's package differs, the lock will
  report it missing instead of working. One caveat from the research:
  AppBrain says the app was removed from Google Play on 2026-07-08,
  while the developer's Facebook page (Oct 2026) still advertises
  Play Store badges and a newer "E-Test Paper : Smart Practice"
  listing was updated 2026-11-07 — so the Play Store "Install"
  button may fail if the listing is gone; the overlay still explains
  what to install.
- **Permanent link, no off switch.** `StudyLock.STUDY_APP_PACKAGE =
  "com.nextive.eTestPaper"` is a hard-coded named constant. There is
  NO UI to change or remove the app and NO toggle to disable the
  feature. Only the TIME may be changed (see below).
- **Behaviour.** Every night at 21:00 (9 PM, Asia/Dhaka — default)
  the guard interrupts whatever Fahim is doing: a full-screen overlay
  ("পড়ার সময় 📚 / Study time") appears and the e test paper app is
  launched automatically. A 15-minute study lock then starts. During
  those 15 minutes every other app is blocked (same block screen as
  Strict Mode, reason `STUDY` — "Study Lock is on — only e test
  paper (and phone calls) until the 15 minutes are done"). He cannot
  use anything else except the e test paper app and receiving phone
  calls. The app's own settings/dashboard activities are blocked
  during a lock too (launcher tile tap shows the block screen; the
  guard catches MainActivity coming to the foreground the same way);
  the launcher home screen itself keeps working, and the block screen
  is exempt. After 15 continuous fair minutes the lock releases, the
  Tamper Log records `STUDY_LOCK_DONE`, and he returns to normal use.
  The lock runs once per night; after completion it does not trigger
  again until the next night.
- **Fairness — the 15 minutes must be continuous.**
  - Only time with the e test paper app in the foreground AND the
    screen on (and the keyguard not locked) counts.
  - Screen off / keyguard / phone call / system UI (Recents, shade)
    PAUSES the timer: minutes are kept, just not counted.
  - Leaving the app for any other app RESETS the accumulated time to
    zero — a fresh continuous 15 minutes is required. (Logged as
    `STUDY_RESET`.) This includes going Home or opening Strict
    Guard's own settings.
  - One attention check midway, at 7 minutes 30 seconds: a small
    "আমি পড়ছি — I'm studying" prompt appears over the study app.
    It must be tapped within 60 seconds; the 60-second grace still
    counts, but after that the timer pauses until it is tapped.
    (Logged as `STUDY_ATTENTION_OK`.)
  - A 3-second launch grace after the lock starts, so the study app
    can come up without the guard blocking the app the lock
    interrupted or racing its own launch. During the grace neither
    the timer nor the block decision runs.
- **Time setting.** One main-page row, no switch — "Study Lock /
  স্টাডি লক", description names the app and the nightly time
  ("e test paper — every night at 21:00, 15 minutes of study. Only
  the time can be changed; the app cannot be changed or removed.").
  Tapping it opens a time picker (same pattern as the Night Lock
  hours picker). The time is locked during Strict like every other
  setting. Default 21:00.
- **Missing app.** If the e test paper app is NOT installed when the
  lock triggers, the overlay explains it must be installed, with a
  button opening its Play Store page (`market://details?id=
  com.nextive.eTestPaper`, https fallback), other apps stay blocked,
  and the Tamper Log records `STUDY_APP_MISSING` — the night is
  never silently skipped. The Play Store itself is exempt while the
  app is missing, so the install button can be used. If the app is
  installed while the lock is waiting, the guard notices on the next
  poll, logs `STUDY_APP_INSTALLED`, hides the overlay and launches
  the study app.
- **Reboot.** The lock state is persisted (active, day, done day,
  accumulated ms, attention state, missing flag, last-studying
  flag). If the phone reboots mid-lock, the lock resumes. **Choice
  made (stated as asked): completed minutes are kept ONLY if the
  session was continuous at the last tick before the reboot** — i.e.
  the last recorded tick had the study app in the foreground with
  the screen on. If the session was already paused then (screen off,
  call, …), the minutes reset to zero with the attention check.
  Rationale: "continuous" means one unbroken block of studying.
  One sub-second race remains: if he left the app less than one
  poll (500 ms) before the reboot, that tick never ran, so up to
  500 ms of credit can be kept — negligible. A 60-second resume
  grace also applies after a service (re)start with an active lock:
  leaving the app pauses instead of resetting, because after a
  reboot the foreground is the launcher, not the study app, and
  that must not instantly wipe earned minutes. Other apps stay
  blocked during the grace, so it cannot be used for anything else.
  A leftover lock from a previous night expires at 06:00 the next
  morning (logged `STUDY_LOCK_EXPIRED`); if the phone is off all
  night, that night is skipped and the next trigger is the
  following 21:00.
- **Interaction with Strict / Night Lock.** The STUDY decision is
  checked after LIMIT/BREAK (they keep their own reasons) and
  before Strict/Night. The study app is in no limit group, so
  Strict Mode ON at 21:00 still lets it open (Strict blocks the AI
  group, not the study app). Night Lock hours overlapping 21:00
  would have blocked the study app itself — fixed explicitly: while
  a Study Lock is active, the study app is exempt from the NIGHT
  decision too, so the lock can always complete. The default Night
  Lock 00:00–06:00 does not overlap 21:00 anyway.
- **Code.** New pure `StudyLock.kt` (constants, `dayKey`,
  `triggerTimeToday`, `shouldTrigger`, `shouldExpire`, `onTick`,
  `resumeAccumulated`) + `StudyLockTest.kt` (12 tests, see Result).
  `Store.kt` holds the study state (time, active, day, done day,
  accum, attention, missing, last-studying). `BlockDecider` gains
  `Kind.STUDY` + `decideStudy()` and study params on `decide()`;
  `LauncherLogic.tapDecision()` passes them through;
  `GuardService.tick()` runs trigger/expiry before foreground
  resolution, the timer after it, the 3 s launch grace, and the
  study overlays (start / missing / attention, TYPE_APPLICATION_
  OVERLAY); `BlockActivity` shows the STUDY reason;
  `StudyTimeActivity` + `activity_study_time.xml` + manifest entry;
  main-page Study Lock row; `Util.isPhoneApp()` (default dialer via
  TelecomManager + incallui/telecom) and `Util.isAppInstalled()`.

## Added to the same v6.1.0 build — Entry Delay for social apps (Fahim, 2026-11-08)

Whenever a social-feed app is opened, a full-screen popup appears
FIRST with a countdown timer; the app can only be entered after the
full wait — never before. Default wait **15 seconds** (Fahim said 10
or 15 — 15 is used), with a duration choice of **10 / 15 / 30
seconds** in settings (tap the row to cycle). Toggle
"সোশ্যাল অ্যাপে ঢোকার আগে অপেক্ষা" (default ON), locked during
Strict like other settings.

Social apps covered (`EntryDelay.SOCIAL_PACKAGES`): Facebook (+ Lite),
Instagram (+ Lite), TikTok (+ Lite), X (Twitter), Snapchat, LinkedIn,
Reddit, Pinterest, Threads, Tumblr, VK, BeReal, Likee, Quora,
Discord, **and YouTube + YouTube Music** (added at Fahim's
correction — YouTube keeps its daily limit + break cycle as well; the
delay is on top). **WhatsApp is EXCLUDED** (messaging, not a social
feed), as are Messenger, Telegram, Signal, Viber and IMO.

Behaviour: every time a social app comes to the foreground (launcher,
recents, or another app), the guard shows the delay overlay with a
live countdown ("১৫ সেকেন্ড অপেক্ষা করো — সত্যিই ঢুকতে চাও?") and
the app stays blocked behind it. Leaving the overlay / the app during
the countdown RESETS the timer — the full wait must be done
continuously. After the countdown ends the overlay dismisses and the
app opens. The delay applies on EVERY open, not once per day. Strict
Mode / Night Lock / daily limit / break-cycle / Study Lock blocks
take precedence — the delay never grants access when the app is
otherwise blocked. Usage is NOT counted while the delay overlay
covers the app (the wait is not use). Delay state is in-memory in
GuardService: a service restart resets the wait (the safe direction).
Code: `EntryDelay.kt` (pure), `overlay_entry_delay.xml`,
`GuardService` delay phase A/B + `resetDelay()`, `BlockDecider`
unchanged (delay runs only when it returns null). Tests: 8 in
`EntryDelayTest.kt`.

## Added to the same v6.1.0 build — force-stop / Clear Data protection during Strict (Fahim, 2026-11-08)

Safe Mode and ADB/computer bypass are EXPLICITLY out of scope — left
alone, as Fahim said.

### Force Stop — Device Admin is now required to start Strict
An app that is an ACTIVE Device Admin has its Force Stop button
greyed out by Android's Settings app itself — and the Disable button
too. So Strict Mode now REQUIRES active Device Admin: if admin is
not active when he tries to start Strict, `StrictSetupActivity`
refuses and shows a prompt ("ডিভাইস অ্যাডমিন লাগবে") with a button
to enable it. Since the Settings app is already blocked during
Strict, the "deactivate admin" toggle cannot be reached while Strict
is on. **Force-stop protection holds ONLY while Device Admin is
active** — if admin is off, Strict cannot start at all. If admin is
lost mid-Strict (e.g. after a mirror restore), the guard re-prompts
for it. Tests: admin gate in `ScheduleTest`/`AdminFixTest` area
(`StrictSetupActivity` gate); the button-state reasoning (admin
active ⇒ Force Stop + Disable greyed out by Android itself) is
documented here and in `StrictMirror.kt`.

### Clear Data — state survival via an encrypted, HMAC-protected mirror
Android offers NO API to grey out or disable the "Clear Data /
Clear Storage" button — the button will still be tappable. The
defence is therefore STATE SURVIVAL, not button removal: the Strict
state (strict-on + wall-clock end time) is mirrored to an encrypted,
HMAC-protected file OUTSIDE the app's private data. Private internal
storage and app-specific external storage are both wiped by Clear
Data, so the mirror lives in shared storage — **MediaStore
Downloads, relative path `Download/StrictGuard`, file
`strict_guard_state.bin`** — a shared/public location that survives
Clear Data on Android 16, needing no new storage permission on API
29+ for the app's own MediaStore entries. On the next app launch /
boot receiver / launcher start, if the mirror says Strict is still
on, Strict is restored immediately (even with a fresh empty Store),
Device Admin is re-prompted if it was lost, and a Tamper Log entry
`DATA_CLEARED_DURING_STRICT` is written. The mirror is
AES/GCM-encrypted (Android Keystore, hardware-backed where supported;
Keystore keys survive Clear Data — they live in the keystore daemon,
keyed by UID, deleted only on uninstall) plus an explicit
HMAC-SHA256: editing it to shorten Strict is detected and logged
(`MIRROR_TAMPERED`), and a tampered mirror NEVER shortens Strict —
it restores Strict to the **maximum duration (1095 days from
detection)** instead. When Strict ends NORMALLY (schedule expiry) the
mirror is deleted, so clearing data afterwards is a clean slate and
fully allowed again; same when Strict is off (no mirror, no
interference). Test-mode end also deletes it. "Clear cache" is
harmless — no state lives in the cache. Force-stop gap detection:
the guard writes its last tick timestamp every poll; on the next
service start, if Strict is on and the last tick is stale (over 15
minutes) and the start did NOT come from boot/unlock, the gap is
logged as `FORCE_STOP_DETECTED` (a reboot explains the gap, so boot
starts are excluded; if he force-stops and then reboots instead of
launching the app, the gap is genuinely indistinguishable and is not
logged). Single package only — no second app, no watcher app.
Code: `StrictMirror.kt` (pure decide/encode/decode),
`MirrorCrypto.kt` (Keystore AES/GCM + HMAC interface),
`MirrorStore.kt` (MediaStore file I/O + restore glue), `Store`
writes the mirror on Strict start and deletes it on normal/test end,
`GuardService.onStartCommand` (restore + gap check),
`BootReceiver` / `SystemEventsReceiver` (restore on boot/unlock).
Tests: 7 in `StrictMirrorTest.kt` (incl. a JCE test crypto standing
in for the Keystore, and a 3-year mirror round-trip).

### Honest limits (stated plainly)
(a) The Clear Data button itself cannot be hidden/disabled by any
app — the protection is that clearing data no longer resets Strict.
(b) A user who finds and deletes the mirror file with a file manager
can still defeat the Clear Data defence — the remaining hole. What
deleting it does NOT do is shorten Strict: the mirror is only a
backup; if the Store still has Strict, Strict stays on.
(c) Protection depends on Device Admin staying active.
(d) Safe Mode / ADB remain out of scope per Fahim.

## Added to the same v6.1.0 build — Strict duration cap raised to 1095 days (Fahim, 2026-11-08)

Fahim remembers the old v3.7 cap as 30 days max and wants Strict
longer. That 30-day cap was v3.7's; the v6 base already allowed 365
days. This build raises the cap to **1095 days (3 years)** for both
the N-days option and the chosen-date option
(`Limits.MAX_STRICT_DAYS` 365 → 1095). Minimum unchanged (1 day /
1 minute ahead). The N-days input is already an EditText
(`StrictSetupActivity` `etDays`), so 1095 is typeable without tedious
tapping — no input change was needed. All EN + BN strings/labels
mentioning the 365-day limit were updated. The Strict-state mirror
stores the end time as epoch millis — a 3-year end time needs no
extra work; verified by a mirror round-trip test at the 1095-day
end. Tests: boundary updates in `ScheduleTest.kt` (365 valid, 1095
valid, 1096 rejected; chosen date 1095 days ahead valid, beyond
rejected).

## Added to the same v6.1.0 build — HSC 2027 live countdown + reminders (Fahim, 2026-11-08)

Target: HSC 2027 first exam, **6 June 2027, 10:00 AM Asia/Dhaka**
(Bangla 1st Paper; theory ends 13 July 2027, practicals by 18 July)
— verified from the Education Minister's 14 May 2026 announcement.
A live countdown ticking every second is shown in TWO places, as the
VERY FIRST element at the top of both screens, HIGHLIGHTED (deep
warm-brown card, large bold cream numbers, strongest contrast),
pinned above the scroll area so it never scrolls away:

- **Main page:** full countdown with label — "HSC পরীক্ষার বাকি
  ২০৯ দিন ১৪ ঘণ্টা ৩২ মিনিট ১০ সেকেন্ড" / EN equivalent, ticking
  every second while the dashboard is visible.
- **Launcher:** numbers ONLY — no "HSC পরীক্ষার বাকি" title, no
  exam-date line, nothing saying what it counts down to — and in
  MONTHS, not days (Fahim, 2026-11-08 ~18:36: "২০৯ দিন" feels like
  too much): full calendar months + remaining days, e.g. "৬ মাস
  ২৯ দিন" (8 Nov 2026 → 6 June 2027 = 6 months + 29 days; 8 Nov + 6
  months = 8 May 2027, 8 May → 6 June = 29 days). Calendar months,
  not 30-day chunks, so the number matches a wall calendar. The value
  only changes at midnight — no h/m/s ticking on the launcher (the
  ticker still runs but rewrites the text only when it changes).
  The main page is UNCHANGED (full d/h/m/s ticking with label).

Ticking: once per second ONLY while the launcher/dashboard is visible
(`BaseActivity` ticker, started in onResume, stopped in onPause). No
background per-second wakeups — no battery drain when the screen is
off or another app is in front. Reminder: a once-daily notification
each morning at **08:00 Dhaka** stating the days remaining,
toggleable in settings, default ON. Exam date changeable: a settings
row with a date picker (time stays 10:00 Dhaka), default 6 June 2027
10:00, because the board has said dates may be revised; locked
during Strict like every other setting. End states: at zero —
"HSC পরীক্ষা শুরু হয়েছে"; after the exam period ends (13 July
2027) — "HSC পরীক্ষা শেষ হয়েছে". Never negative.

Daily "ONE DAY LESS" alert (Fahim, 2026-11-08 ~18:22): every
midnight when the days-remaining number drops by one, a full-screen
popup (shown on next unlock, dismiss with "বুঝেছি", once per day)
AND a high-priority notification, with rotating calm Bengali
messages. Tone: MOTIVATIONAL and urgent — push him to
change/improve himself, always stating one more day is gone, how
many days are left, and that there is not much time in hand, firm
but never shaming (e.g. "আরো একদিন কমে গেল — হাতে আছে মাত্র ২০৮
দিন, বেশি সময় নেই", "একটা দিন চলে গেল, আর ফিরবে না — বাকি ২০৭
দিন। আজ থেকেই বদলাও"). Toggleable (default ON), survives reboot
via persisted last-alerted day. The alerts still quote DAYS (the
months format is launcher-display only). Code: `HscCountdown.kt`
(pure — decompose, monthsAndDays, state, reminder/day-less logic,
rotating messages), `DayLessAlertActivity` + layout,
`BaseActivity` ticker + popup helper, `activity_main.xml` /
`activity_launcher.xml` restructured (root ScrollView →
LinearLayout with the countdown card pinned above the ScrollView),
`MainActivity` settings rows (date picker, reminder toggle,
day-less toggle), `GuardService.hscTick` (reminder + day-less
detection on the existing 500 ms poll). Tests: 10 in
`HscCountdownTest.kt`.

## Added to the same v6.1.0 build — Friday prayer alarm (Fahim, 2026-11-08)

Friday ONLY — never daily. Every Friday at **09:00** an alarm preset
in the backend rings ONCE automatically (alarm sound + vibration +
full-screen dismiss). The earlier hourly 10:00–19:00 "নামাজের সময়
হয়ে গেছে" plan was CANCELLED by Fahim (2026-11-08 ~18:28) — the
09:00 alarm is RETAINED. Instead, ONLY countdown alerts for the
**13:00 (1 PM) Jumu'ah prayer** in addition to the 09:00 alarm:
10:00 "আর ৩ ঘণ্টা বাকি", 11:00 "আর ২ ঘণ্টা বাকি", 12:00 "আর ১ ঘণ্টা
বাকি", 12:30 "আর ৩০ মিনিট বাকি", 13:00 "জুম্মার নামাজের সময় হয়ে
গেছে" — then STOP, no alerts after the prayer starts. Toggleable
(default ON), locked during Strict, survives reboot (alarm
re-scheduled on boot; alert state persisted). Exact-alarm permission
(`SCHEDULE_EXACT_ALARM`) with inexact fallback, plus the guard poll
as a second fallback for the 09:00 alarm — a single persisted "last
rung day" / "last alert key" is shared by both paths, so nothing
rings twice. One alert per poll tick; a late open (phone off until
11:30) fires the earliest missed slot first and catches up one per
tick. Code: `FridayPrayer.kt` (pure), `PrayerAlarmScheduler.kt`
(AlarmManager exact when permitted, else inexact; re-scheduled on
boot and after firing; cancelled when the toggle is off),
`PrayerAlarmReceiver.kt` (marks the day rung, shows the alarm via a
high-priority notification with full-screen intent),
`PrayerAlarmActivity.kt` + layout (shows over the lock screen, loops
the system alarm ringtone + vibrates until dismissed),
`GuardService.fridayTick` (09:00 fallback + countdown alerts),
manifest entries + permissions (`SCHEDULE_EXACT_ALARM`,
`USE_FULL_SCREEN_INTENT`, `VIBRATE`). Bug found and fixed during
this run by the new tests: the countdown function only stored ONE
"last sent" key, so after the 11:00 alert was sent, the 12:00 check
re-fired the 10:00 slot (and after 13:00 it would have looped back
and broken the "then STOP" guarantee). Fixed: a slot counts as sent
when it is at or before the last sent slot's time on the same day —
slots always fire in order, so the earliest passed slot after the
last sent one is due. Tests: 8 in `FridayPrayerTest.kt`, incl. a
regression test for the re-fire.

## Added to the same v6.1.0 build — day-less message bank expanded to 10 variants (Fahim's tone refinement, 2026-11-08)

The daily "one day less" messages were 4 variants per language;
they are now **10 per language** (BN + EN), all motivational and
urgent — the kind of words that push him to change/improve himself.
Every message states that one more day is gone, how many days are
left (%1$d, always present), and that there is not much time in
hand. Firm but never shaming, never mocking. Examples (new ones from
Fahim's brief, plus the earlier four kept): "সময় কমছে — বাকি ২০৬
দিন। নিজেকে বদলানোর সময় এখনই।", "আরো একদিন শেষ — হাতে সময় কম,
পড়াটা আজই শেষ করো। বাকি ২০৫ দিন।" (the brief's example had no
number; the number was added because the rule is that it must always
be in the message), "২০৫ দিন বাকি — প্রতিটা দিন গুনে গুনে যাচ্ছে,
কাজে লাগাও।" Rotation is by days-remaining % 10, so the message
changes every day and repeats every 10 days. Small fix with it:
`dayLessMessage` now renders the days number in **Bengali digits**
in Bengali mode (২০৮, not 208) — previously `String.format` left
ASCII digits inside the Bengali text, in both the popup and the
notification. Code: `HscCountdown.DAY_LESS_MESSAGES_BN/EN` +
`dayLessMessage` (uses `Limits.toBengaliDigits`).

## Verified against Fahim's repeated briefs (2026-11-08, voice) — no code change needed, all already built

Fahim re-sent the placement, day-less alert, Friday and months
briefs as follow-ups; each was checked against the actual code in
this build (not assumed from the summary):

- **Placement:** verified in `activity_main.xml` /
  `activity_launcher.xml` — the countdown card is the FIRST element
  at the top of both screens (above greeting + clock on the launcher,
  above title/Strict card on the main page), deep warm-brown card
  (`bg_status_card`, strongest contrast in the Warm Sand palette),
  21sp bold cream numbers, larger and bolder than surrounding text,
  and it sits OUTSIDE the ScrollView (root LinearLayout with the card
  pinned above the ScrollView), so it never scrolls away.
- **Daily "one day less" alert:** verified end to end — midnight
  rollover detected on the guard poll (`GuardService.hscTick`:
  `dayDropped` on the persisted last-seen days count); high-priority
  notification on the HSC channel (IMPORTANCE_HIGH, stays until
  dismissed) + full-screen popup on next unlock
  (`DayLessAlertActivity`, "বুঝেছি" dismiss, same Warm Sand card
  style); once per day only — the pending flag is cleared and the day
  recorded when the popup opens, and the notification fires once
  because the last-seen count is updated on the same tick; reboot
  survival via persisted `hscLastSeenDays` / `hscDayLessDay` /
  `hscDayLessPending` in Store (a drop while the phone was off is
  detected on the first poll after reboot); toggle
  (`f_hsc_dayless`, default ON, locked during Strict) is separate
  from the 08:00 morning reminder — both stay.
- **Friday:** verified — Friday ONLY, 09:00 alarm once (AlarmManager
  exact when permitted, inexact + guard-poll fallback; survives
  reboot via re-schedule on BOOT_COMPLETED / USER_UNLOCKED), then
  ONLY the Jumu'ah countdown alerts 10:00 (3h) / 11:00 (2h) / 12:00
  (1h) / 12:30 (30m) / 13:00 ("সময় হয়ে গেছে"), then STOP. The
  string "10:00–19:00" appears only in comments stating that hourly
  plan was cancelled — no hourly code remains.
- **Launcher months format:** verified — `HscCountdown.monthsAndDays`
  (real calendar months + leftover days; 8 Nov 2026 → 6 June 2027 =
  6 months 29 days), launcher ticker in `monthsOnly` mode (numbers
  only, no label, rewritten only when the value changes at midnight,
  no h/m/s ticking); main page keeps full d/h/m/s ticking with the
  label; day-less alerts still quote days.

## Kept unchanged (verified by tests)

Custom home launcher (HOME intent, greeting + clock + date, Strict
card, scrollable app grid, tap blocking), Strict schedule (until
midnight / N days / date+time, survives reboot, cannot be shortened
during Strict), LOCK DURING STRICT, Strict blocks Facebook / Chrome /
YouTube / AI groups itself, usage accumulated on EVERY 500 ms poll,
floating / split-screen / PiP blocking, Sidebar / Smart Panel
blocking, Night Lock + allowed-apps, custom blocklist, Tamper Log,
Diagnostics, boot receiver, direct-boot guard start, launcher on
reboot, calm non-addictive UI, one-tap Bangla/English switch
(persisted), Dark + Light modes (persisted) — the Light mode is now
the Warm Sand palette (Design 3), the Dark mode is unchanged. The
YouTube Shorts feature stays removed (v5.2.1).

## Build notes

- One build failure was fixed during this run: the first build.sh run
  produced an APK badged 6.0.0/code 34 even though build.sh passed
  `--version-code 35 --version-name 6.1.0` to aapt2 link — aapt2 kept
  the manifest's own version attributes. Fixed by updating
  `AndroidManifest.xml` itself to 35/6.1.0 and rebuilding; the
  delivered APK badging now reads 6.1.0/code 35.
- One test failure was fixed during this run: it was a bug in the new
  test loop (the break fires on the 1799th tick, so checking the
  flag only after the 1800th tick saw it cleared). The test now
  records whether a break started at any tick; the production code
  was not changed for it.
- Warm Sand / auto theme / self-block run: three small build fixes —
  a dangling comment block left by an edit in `LauncherLogic.kt`
  (removed; the KDoc above it already documents the rule), the new
  `AutoTheme.kt` referencing `Store` in the unit-test compile (fixed
  by adding `Store.kt` to the test-compile list in `build.sh` — it
  only depends on `Limits` + the Android framework), and the existing
  `LauncherTest.tapOwnAppNeverBlocked` test, which asserted the old
  behaviour — it was replaced by the new self-block tests (tile tap
  self-blocked during Strict, opens normally when Strict is off,
  Night Lock alone does not self-block). No production logic was
  changed for any of these; the last one is the intended behaviour
  change of the self-block feature itself.
- Clock / Design 1 / one-way-setup run: one compile fix — enum
  entries in the subject-less `when` in `SetupRowState.state()` needed
  the `State.` qualifier. No production logic changed for it.
- Five-feature run (Entry Delay / mirror / cap 1095 / HSC / Friday):
  three fixes. (1) The unit-test compile failed twice at first:
  `Store.kt` references `MirrorStore`, and `MirrorStore.kt`
  references `Util`/`GuardService`/`MainActivity` — fixed by
  compiling ALL main sources for the test step in `build.sh`
  (`@build/main-sources.txt`), instead of a hand-picked list.
  (2) One test failure exposed a REAL bug in `FridayPrayer` (see the
  Friday section above): the countdown re-fired older slots after a
  newer one was sent, which would have broken the "then STOP"
  guarantee. Fixed in production code (a slot counts as sent when at
  or before the last sent slot's time) plus a regression test; no
  other production logic changed for it. (3) A stale comment in
  `GuardService.hscTick` still said "Friday prayer hourly reminders
  (Fridays 10:00–19:00)" — corrected to the five Jumu'ah slots; the
  implementation already had only those five. The misleading
  `PRAYER_HOURLY_NOTIF_ID` constant was renamed
  `PRAYER_COUNTDOWN_NOTIF_ID`. The launcher months format (Fahim
  2026-11-08 ~18:36) was added during this run: `HscCountdown.
  monthsAndDays` (calendar-month math, verified against JDK
  `ChronoUnit.MONTHS` behaviour — 31 Jan → 28 Feb is 0 months,
  28 days) + a `monthsOnly` mode in the `BaseActivity` ticker; the
  main page keeps full d/h/m/s ticking.
- Message-bank run: the day-less bank was expanded 4 → 10 variants
  per language with Bengali-digit rendering. One test failure was
  fixed during this run: the new rotation test asserted that the
  messages for days 208 and 198 are equal (same template index) —
  but the days number inside differs, so they are not equal. The
  test now compares the messages with digits stripped. No production
  logic was changed for it. The repeated placement / day-less /
  Friday / months briefs were verified against the actual code (see
  the section above) — no code change was needed for any of them.

## Honest limits

- Up to ~500 ms visibility of a blocked app before the block screen.
- Device Admin CAN still be deactivated in Android Settings when
  Strict is OFF — Android genuinely lets the user do that, and no app
  can change it. During Strict, Settings is blocked by package +
  activity with a sticky foreground check, the in-app admin control is
  locked, the guard self-heals if killed, and any loss is logged +
  notified.
- The launcher only takes effect after Fahim picks it as the default
  home. Until then the system launcher is still reachable from Home.
- A wall-clock schedule has one trade-off: if the user changes the
  wall clock AND reboots, the recomputed end follows the (changed)
  clock. Clock changes are logged to the Tamper Log. The same applies
  to a break end, which is also wall-clock based.
- Force-stop from Settings stops the guard until the app is opened
  again (MainActivity/LauncherActivity then restarts it) or the phone
  reboots. Safe Mode / ADB / second profile can bypass, as before.
- No on-device testing in this sandbox. Fahim should test: use
  Facebook for 40 minutes and confirm the block screen appears with
  a 20-minute countdown; reopen Facebook during the break and confirm
  it is still blocked; after the break, confirm 40 more minutes work;
  use YouTube for 30 minutes and confirm the same 20-minute break.
- Self-block, on-device: turn Strict on, then tap the Strict Guard
  tile and confirm the block screen appears instead of the app;
  confirm the launcher itself still works as Home; turn Strict off
  (wait for the schedule) and confirm the app opens again. Note the
  self-block only works while the guard service is running — if the
  guard was force-stopped and the launcher was never opened since,
  opening the app from another launcher could briefly show the
  dashboard until the guard restarts (MainActivity/LauncherActivity
  restart it on resume, and the guard then blocks it within ~500 ms).
  A notification tap during Strict can likewise flash the dashboard
  for up to ~500 ms before the guard sends it back.
- Auto theme, on-device: with the toggle ON (default), confirm the
  theme is Light at 07:00 and Dark at 19:00, and that a manual theme
  change at noon is not forced back until 18:00. The switch is
  evaluated on resume and on the guard poll, so it should apply
  within ~500 ms of 06:00/18:00 even with the app closed — but only
  while the guard service is running; if the guard is stopped, the
  switch applies on the next app resume instead.
- Clock toggle, on-device: tap the "ঘড়ি ২৪ ঘণ্টা / ১২ ঘণ্টা" row and
  confirm the launcher clock changes immediately (e.g. 17:05 → 5:05
  PM) with no restart, and that the choice survives closing and
  reopening the app.
- Hide Unused Apps, on-device: turn the toggle ON and confirm only
  apps used in the last 30 days (plus Strict Guard) show in the grid,
  a "লুকানো অ্যাপ (n)" row appears at the bottom, and tapping it opens
  the full list where a hidden app (e.g. banking) can be opened. Turn
  the toggle OFF again and confirm the full grid comes back
  immediately, no restart. Newly installed apps should stay visible
  for their first 7 days even if never opened.
- One-way setup buttons, on-device: grant a permission and confirm
  its row goes grey with "অ্যালাউ করা হয়েছে ✓" and tapping it does
  nothing (no Settings screen opens). Then revoke that permission
  from system Settings (while Strict is OFF) and reopen the app —
  confirm the row is tappable again, the Tamper Log has a
  PERMISSION_REVOKED entry, and a notification was shown. Note: this
  test itself proves the honest limit above — Android lets the user
  revoke from system Settings by hand; the app can only detect, log
  and offer re-granting, never prevent it.
- Study Lock, on-device: set the study time to 2 minutes from now
  (main page → Study Lock row → time picker), confirm the overlay
  appears at that time and e test paper opens by itself. Study for
  the full 15 minutes (tap "আমি পড়ছি" when it appears at ~7:30)
  and confirm the lock releases and the Tamper Log has
  STUDY_LOCK_DONE. Then: open another app mid-lock and confirm the
  block screen appears and the 15 minutes restart from zero;
  turn the screen off for a minute and confirm the timer pauses
  (minutes kept). Uninstall e test paper, set the time again, and
  confirm the missing-app overlay appears with the Install button
  and other apps stay blocked. Reboot mid-lock and confirm the lock
  resumes (minutes kept only if you were studying when it
  rebooted).
- Entry Delay, on-device: open Facebook and confirm the 15-second
  countdown popup appears first and Facebook cannot be entered
  before zero; leave mid-countdown and confirm the timer resets to
  a full 15 s; open WhatsApp and confirm NO popup appears; open
  YouTube and confirm the popup appears on top of its limit/break
  rules; turn Strict on and confirm the app is blocked outright
  (no delay popup grants access). Note: the app can be visible for
  up to ~500 ms before the delay overlay covers it.
- Mirror / force-stop, on-device: turn Device Admin OFF and try to
  start Strict — confirm it refuses and prompts to enable admin.
  With Strict on, open Settings → Apps → Strict Guard and confirm
  Force Stop and Disable are greyed out. Then (Strict still on) tap
  Clear Data, reopen the app, and confirm Strict is restored with
  the original end time and the Tamper Log has
  DATA_CLEARED_DURING_STRICT. When Strict ends normally, confirm
  clearing data afterwards is a clean slate. Honest limits: the
  Clear Data button itself cannot be hidden; a user who finds and
  deletes the mirror file (`Download/StrictGuard/
  strict_guard_state.bin`) with a file manager can still defeat
  it; protection depends on Device Admin staying active.
- Strict cap, on-device: open the Strict setup and confirm 1095
  days (and a date 1095 days ahead) are accepted and 1096 is
  rejected.
- HSC countdown, on-device: confirm the main page shows the live
  d/h/m/s countdown ticking every second with the "HSC পরীক্ষার
  বাকি" label, and the launcher shows ONLY numbers in months
  ("৬ মাস ২৯ দিন" on 8 Nov 2026), changing only at midnight.
  Change the exam date in settings and confirm both update; set
  the date back. The 08:00 reminder and the midnight "one day
  less" popup + notification can only be checked overnight — confirm
  the popup appears on the next unlock after a midnight drop and
  dismisses with "বুঝেছি".
- Friday alarm, on-device: the 09:00 Friday alarm can only be
  checked on a Friday — confirm it rings once with sound + vibration
  + full-screen dismiss, and the Jumu'ah alerts arrive at 10:00 /
  11:00 / 12:00 / 12:30 / 13:00 and then stop. On any other day
  confirm nothing rings. Note: if exact-alarm permission is revoked,
  the alarm falls back to an inexact AlarmManager alarm plus the
  guard poll, so it may ring a few minutes late — it still rings
  once per Friday.

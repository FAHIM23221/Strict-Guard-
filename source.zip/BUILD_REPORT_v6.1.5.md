# Strict Guard v6.1.5 — Build Report

**Date:** 2026-11-09 ~03:45 Asia/Dhaka
**Base:** v6.1.4 (SHA-256 `8b6665b0c5364efb7b51943894d3f770f03458f627c07af7d4987a2e17997851`)
**Version:** versionCode 40, versionName 6.1.5, package `app.strictguard`
**Build route:** same manual kotlinc 1.9.22 + aapt2 + d8 route as v6.1.4. No decompile. No Gradle.
**Requested by:** Fahim, voice 2026-11-09 ~03:30 — he proved the boot-gap bypass on his own phone and this is the fix.

## What happened (Fahim's own test, v6.1.4, Infinix X6886 Android 16)

He restarted the phone, and DURING the boot loading — while the system was still booting up — he opened Settings and turned OFF Device Admin access. So the v6.1.4 "faster boot guard" was NOT fast enough: there was a window after the system became usable and before the guard was enforcing, long enough to open Settings, navigate to Device Admin, and deactivate it. Once admin is off, Strict Guard can be force-stopped / uninstalled, so this breaks the whole Strict Mode promise. This release exists only to close that window as far as Android allows a third-party app. **No other feature changes.**

## The gap, found in code order (v6.1.4)

The boot path, traced through the code:

1. **Manifest receivers — already correct.** `BootReceiver` is `directBootAware` and listens for `LOCKED_BOOT_COMPLETED` (fires before first unlock) and `BOOT_COMPLETED`; `SystemEventsReceiver` listens for `USER_UNLOCKED`. The receivers were not the problem.
2. **`LOCKED_BOOT_COMPLETED` → `BootReceiver`** reads the cheap device-protected mirror and calls `startForegroundService`. That part was fast — but it only STARTED the service.
3. **`GuardService.onStartCommand`** — the Store (credential-encrypted prefs) is unreadable before unlock, so `initStore()` failed and `onStartCommand` returned `START_STICKY` with **NO `startForeground` and NO poll loop**. The service was alive and enforcing NOTHING. Worse, a service started via `startForegroundService` that never calls `startForeground` within the system timeout is killed by Android — so the direct-boot service was most likely dead by unlock time, and enforcement had to cold-start after unlock.
4. **`USER_UNLOCKED` → `SystemEventsReceiver`** → `startForegroundService`. `USER_UNLOCKED` is NOT in Android's documented foreground-service background-start exemption list (`BOOT_COMPLETED` and `LOCKED_BOOT_COMPLETED` are; `USER_UNLOCKED` is not), so that start can be refused — the exception was swallowed and nothing retried until `BOOT_COMPLETED`, which on XOS can arrive seconds after the user is already interacting.
5. **Even when the start succeeded**, `onStartCommand` ran `MirrorStore.checkAndRestore` — a MediaStore query plus a Keystore key load + HMAC + AES-GCM decrypt, cold after boot (~0.5–3 s) — BEFORE `startForeground` and the first poll post. v6.1.4 moved that work out of the *receiver*; it still sat in the *service* before the first enforcement tick.
6. **Only then** did the first tick run and the Settings fast path block anything. A human opening Settings and navigating to Device Admin takes ~5–10 s; the guard needed longer than that to become enforcing, so Fahim won.

## What changed

### 1. Direct-boot enforcement mode — the service enforces from the mirror alone

New file `BootEnforce.kt` (pure logic) + `GuardService` boot mode:

- `onStartCommand` no longer returns `START_STICKY` with an idle service when the Store is unreadable. It enters **boot mode** (`startBootMode()`): the device-protected boot mirror (Strict wall end + service-wanted, via the existing `Store.bootMirrorState` / `BootRestore.directBootGuardStart`) decides whether to enforce. If nothing is wanted, the service stops promptly — a service that neither foregrounds nor stops within the system timeout is killed by Android, so it must not linger.
- If enforcement is wanted, the service calls **`startForeground` IMMEDIATELY** with a minimal notification (its channel is now created alone in `onCreate` as `createGuardChannel()`, so a failure creating the other channels can never cost the guard its foreground notification) and starts a **100 ms boot poll** (`BootEnforce.BOOT_POLL_MS` — faster than the 250 ms Strict-on poll, because boot mode lasts seconds and the first post-unlock tick is what closes the gap).
- The **boot tick** (`bootTick()`) does ONLY what enforcement needs: resolve the foreground (the same sticky resolver as the normal fast path — fresh event, else last-known package, else most-recently-used from UsageStats, so Settings already open before the first tick is still caught), check admin, and fast-block Settings / Phone Master / our own settings via the existing `BlockDecider.fastBlockDecision` with `strict = true` from the mirror. No usage accounting, no alarms, no mirror work, no study lock. Boot blocks are remembered and flushed into the Tamper Log when boot mode ends (`exitBootMode()`); admin loss seen in boot mode is remembered the same way.
- The moment the Store becomes readable (a boot tick calls `initStore()` and it succeeds), the service **graduates to the normal path** (`startNormalMode(null, fromBoot = true)`), flushing boot mode first. The `USER_UNLOCKED` start is kept as a retry — but enforcement no longer depends on it, because the service is already warm and polling by unlock time.

### 2. Enforce first on the normal path too

`startNormalMode()` (extracted from the old `onStartCommand` body) now runs **`startForeground` + first poll BEFORE the slow work**. The Keystore mirror restore (`MirrorStore.checkAndRestore`) and the force-stop-gap check moved to a background thread right after the poll is posted — they only matter when the Store lost Strict (Clear Data), and the boot receiver and the app launches already restore it too. This was the remaining seconds of the gap even on a successful start.

### 3. Admin loss: persistent alert + mirror re-assert + independent detection

New file `AdminLoss.kt`:

- While Strict is on, the admin-lost notification is now **ongoing (not swipe-dismissible)** and is cancelled only when admin comes back (`cancelAdminLostNotification` on the restore path). Before, it was auto-cancel/dismissible.
- When admin loss is found on the poll during Strict, Strict is **re-asserted from the surviving mirror** on a background thread (`MirrorStore.checkAndRestore`) — losing admin cannot also silently lose the Strict state.
- **`GuardAdminReceiver.onDisabled` now delegates to `AdminLoss.handleDisabled`** instead of only logging. This callback fires even when the guard service is dead, so it is the independent second detection path next to the poll. It logs the loss, posts the persistent alert when Strict is on (reading Strict from the boot mirror in direct boot, where the Store throws), and re-asserts Strict from the mirror. It never throws.
- **The backstop, documented:** even if the app is uninstalled and reinstalled after admin is lost, the mirror (MediaStore Downloads, outside the app's private data) still says Strict is on — the next app launch re-checks it (`MainActivity`/`LauncherActivity` already call `MirrorStore.checkAndRestore`) and Strict comes back. The remaining hole is the same as before: code cannot run until the user opens the app or the phone reboots after a reinstall.

### 4. No other changes

No limits, themes, launcher, study lock, entry delay, HSC countdown, or Friday changes. The only other edits are the version bump (40 / 6.1.5) and the new test class in `build.sh`.

## The honest remaining limit — read this before testing

**The gap is NOT literally zero, and this release does not claim it is.** No third-party app code can run before Android itself finishes booting up to `LOCKED_BOOT_COMPLETED` — that part of boot is untouchable, and the user cannot interact with anything then anyway. What v6.1.5 does is make the window after that point as small as Android allows:

- **Estimated window, from code inspection** (no on-device measurement is possible from here): receiver fires → BootReceiver reads the device-protected prefs (milliseconds) → `startForegroundService` → cold process start (typically ~100–500 ms) → `onCreate` (Store init attempt fails fast) → `onStartCommand` → boot mode → `startForeground` → first boot tick at 100 ms → foreground resolved (one UsageEvents query, milliseconds) → Settings blocked. **First block lands well under a second after the system is usable** — normally ~0.3–0.6 s after `LOCKED_BOOT_COMPLETED`, and ~1 s worst case if Android cold-starts the process at unlock instead. A human needs ~5–10 s to open Settings, navigate to Security → Device admin apps, and tap the toggle — so the guard now wins that race by an order of magnitude.
- **What still cannot be prevented:** (a) if the OEM lets Settings open from the lock-screen shade without unlocking, no app can block that pre-unlock surface (overlays cannot cover the keyguard); (b) Android itself can always turn admin off — `onDisabled` fires after the fact and can only warn, never veto — so if the guard is somehow not running at all (force-stopped AND not restarted), the toggle is reachable; the persistent alert + mirror backstop are the answer to that, not a prevention; (c) Safe Mode / ADB remain out of scope, as before.

## Tests

- **287 / 287 pass** (272 in v6.1.4 + 15 new).
- New `BootGapTest.kt` (15): boot enforces from the mirror alone (Strict wall end in the future; service wanted; nothing wanted → no enforce; Strict already ended → no enforce); boot Strict active exactly while the mirror wall end is in the future; boot poll 100 ms < 250 ms Strict-on < 500 ms normal; Settings blocked by the fast path from the first boot tick (package and activity class); the Device Admin screen IS Settings (package `com.android.settings`), so blocking the package blocks the toggle; Phone Master blocked from the first boot tick; fast path silent when Strict is off; admin loss alerts only when Strict is on and persists while Strict is on; mirror re-assert restores Strict after admin loss (and does not resurrect it after it ended) via the real `StrictMirror.decideRestore` with a test crypto.

## Verification

- **aapt2 badging:** `package: name='app.strictguard' versionCode='40' versionName='6.1.5'`, minSdk 29, targetSdk 34.
- **apksigner:** Verifies, v3 scheme only (v1/v2/v4 false, 1 signer) — same as v6.1.4.
- **Accessibility:** 0 accessibility strings in the DEX, none in the manifest.
- **Permissions:** no INTERNET (same 13 permissions as v6.1.4).
- **Signing key:** same as v6.1.3/v6.1.4 — signer certificate SHA-256 `0367b410108019d6c2e18a26609b7a619cbd75ad19a60bf3a4a9280f47ef6304` on both APKs, verified — so **v6.1.5 installs OVER v6.1.4, no uninstall needed**.
- **New code in the APK:** `BootEnforce` and `AdminLoss` classes present in `classes.dex`.
- **APK SHA-256:** `d005ead1f18d68352ba989a4994659d77fd2317149057cade8d50e4158893147`
- **APK size:** 871,752 bytes

## Files changed

- New: `app/src/main/java/app/strictguard/BootEnforce.kt`, `app/src/main/java/app/strictguard/AdminLoss.kt`
- New tests: `BootGapTest.kt`
- Modified: `GuardService.kt` (boot mode, enforce-first normal start, channel split, persistent admin alert + mirror re-assert), `GuardAdminReceiver.kt` (delegates to `AdminLoss.handleDisabled`), `AndroidManifest.xml` (40 / 6.1.5), `build.sh` (40 / 6.1.5, new test class).

## Install

**FIRST — Device Admin is currently OFF on Fahim's phone** (he turned it off in the 03:30 boot test). Strict has no protection until he turns it back on. Before testing the boot gap: open Strict Guard → setup → turn Device Admin back ON. (Strict itself may still be on from before — if it expired in the meantime, start a fresh Strict first, otherwise the boot test proves nothing.)

1. Install v6.1.5 **over** v6.1.4 — same signing key, so no uninstall is needed. If the phone refuses the install for any reason, uninstall v6.1.4 first and install fresh.
2. Set Strict Guard as the default launcher (if it asks again).
3. Redo the 7 setup steps (Overlay step matters for the study countdown circle).

(Only v3.7 and older need a forced uninstall first — different signing key.)

## On-device test (Fahim, Infinix)

The test that matters — repeat of the 03:30 test, with Strict ON and Device Admin ON:

1. Restart the phone. The moment the system is usable, try to open Settings. **Expected:** the block screen appears within about a second of the home screen becoming usable — before Settings can be navigated anywhere, let alone to Device Admin.
2. Try again after unlock, immediately: open Settings as fast as possible. **Expected:** blocked on the first attempt.
3. Check the Tamper Log afterwards: it should contain a `BOOT_BLOCKED com.android.settings …` entry (flushed when boot mode ended) if a block landed during boot.
4. If Device Admin is somehow turned off anyway (e.g. the guard was force-stopped first): **expected** — a persistent notification that cannot be swiped away, a Tamper Log `ADMIN_LOST` entry, and Strict still on (mirror re-assert). Turning admin back on clears the notification.

## Still owed / not tested on-device

- No on-device testing (no Android emulator / adb on this Linux computer). The window above is estimated from code inspection, not measured on the phone — Fahim's repeat of the boot test is the real verification.
- The v6.1.3 on-device checks are still open: whether his Brilliant stays unlocked (Brilliant.org vs Brilliant Connect), the six always-unlocked apps, the circular countdown at the 21:00 Study Lock.
- The v6.1.4 on-device checks are still open: Phone Master invisible in the launcher during Strict and back when Strict ends, Settings block in ~250 ms, reboot guard.

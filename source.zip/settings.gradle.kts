rootProject.name = "strict-guard-v5"
include(":app")

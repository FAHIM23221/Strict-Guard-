# Strict Guard v6.1.6 — Build Report

**Date:** 2026-11-09 (Dhaka, ~22:02)
**Version:** 6.1.6 (versionCode **41** — see the note below), package `app.strictguard`
**Built from:** `~/workspace/strict-guard-v5/` (v6.1.5 source + this fix only)
**No other feature changes.**

## The hole (Fahim, 2026-11-09 ~03:51, Infinix X6886, Android 16)

After a restart, while the phone was still loading and the home
screen had appeared, Fahim pulled down the Quick Settings shade
("shutter") from the top and tapped the Settings gear icon —
**Settings opened, even though Strict Mode was on** and v6.1.5
claimed the boot gap was closed. Screenshot:
`~/workspace/user/files/93132_0_qgmj.jpg`.

## Exact cause (file + logic)

The guard's only enforcement point is *"Settings reaches the
foreground AND the guard service is running AND the block is
visible"*. The shade path breaks all three, and v6.1.5 had three
code-verifiable weaknesses stacked exactly there:

1. **The boot block was invisible when its activity start was
   refused — `GuardService.kt`, `blockBoot()`.** Unlike the
   normal-path `block()`, `blockBoot()` never showed the
   full-screen `TYPE_APPLICATION_OVERLAY`. Before any activity of
   ours is visible (lock screen, home still loading), Android can
   refuse a service's activity start under its background-activity
   rules — the only exemption this app holds is the overlay
   permission. A refused/delayed `BlockActivity` left **nothing**
   covering Settings. The gear tap happens exactly in that window.

2. **The launcher/main self-heal ran after slow work —
   `LauncherActivity.kt` / `MainActivity.kt`, `onResume()`.**
   Both ran `MirrorStore.checkAndRestore` (MediaStore query +
   Keystore load + HMAC + AES-GCM, ~0.5–3 s cold) on the main
   thread **before** the guard-restart check. If the boot service
   never started (e.g. the app was force-stopped, which suppresses
   all boot broadcasts until a manual launch), the guard restarted
   only after that slow work — while the shade was already usable
   and Settings was one gear-tap away.

3. **Boot blocks lived only in memory — `GuardService.kt`,
   `bootBlockedEvents`.** They were flushed into the Tamper Log
   only when boot mode ended normally. If the service process died
   before graduating, the evidence that Settings was opened during
   Strict at boot died with it.

Also verified during diagnosis (these were **not** the cause, so
they were not changed): the boot receiver **does** listen for
`LOCKED_BOOT_COMPLETED` and the app **is** direct-boot aware
(manifest `android:directBootAware`, device-protected prefs for the
boot mirror); the 100 ms boot poll **is** in the built code and
active before unlock; Settings **is** in the blocked set at that
moment — enforcement reads the boot mirror, not the
credential-encrypted prefs that are unreadable before unlock. The
shade path failed at the three points above, not at detection.

## The fix

1. **`blockBoot()` now shows the full-screen overlay too**
   (`GuardService.kt`). A window add needs no activity-start
   exemption, so the overlay covers Settings the moment the block
   lands, even if the `BlockActivity` start is refused. `reasonText()`
   was made store-safe for this: in boot mode the Store is
   unreadable, so the overlay reason falls back to the plain
   resource strings (system locale) instead of the persisted
   language — losing the language choice on one overlay is
   acceptable, crashing the boot block is not.
   Boot-mode block retry is now **500 ms** instead of 2000 ms
   (`BootEnforce.bootBlockRetryMs()`), so a refused start is
   retried half a second later, with the overlay covering the
   screen in the meantime. The normal path keeps 2000 ms.
2. **Guard restart is FIRST in `LauncherActivity.onResume()` and
   `MainActivity.onResume()`**, and the mirror restore moved to a
   background thread in both. The launcher also starts the guard
   at the top of `onCreate()`, before the layout inflates — after
   a reboot the home screen is what the user sees first, and the
   shade is usable from it while the grid is still loading.
3. **Boot events are written to device-protected prefs the moment
   they happen** — new `BootEventLog.kt` (`boot_events` prefs,
   `BOOT_BLOCKED <pkg>/<class> (<kind>)`, capped at 50). The
   Tamper Log itself lives in credential-encrypted prefs,
   unreadable before unlock — but device-protected prefs **are**
   writable before unlock. On graduation, `exitBootMode()` drains
   the DE log into the Tamper Log (deduplicated against the
   in-memory list). If the process dies before graduating, the
   events survive in the DE prefs and are drained on the next
   graduation. A boot-time admin loss is recorded the same way
   (`BOOT_ADMIN_LOST …`).
   The recording happens inside `blockBoot()` after its throttle
   passes — not per 100 ms tick — so one block is one log entry.
4. **No change to what is blocked.** Settings, Phone Master and
   the app's own settings screens are blocked from the first boot
   tick by the same fast path, from the mirror alone, regardless
   of launch source (launcher, shade gear, notification, shortcut).
   New pure helpers in `BootEnforce.kt` (`bootBlockRetryMs`,
   `shouldShowBootOverlay`) with the shade analysis in the header.

## Honest residual limit — what still cannot be closed

- **The shade itself can never be suppressed by an app.** It is
  SystemUI, above every app window including
  `TYPE_APPLICATION_OVERLAY`, and intercepting the gear tap would
  need Accessibility (forbidden on this phone) or device-owner.
  The closable point is Settings reaching the foreground, and that
  is what this version closes.
- **Cold process start under boot load cannot be shortened by the
  app** (typically 1–3 s after `LOCKED_BOOT_COMPLETED`). The gear
  can be tapped in that window — but the moment the service is up,
  the next 100 ms boot tick covers Settings with the overlay, and
  the block is retried every 500 ms while Settings stays in the
  foreground. No code runs before `LOCKED_BOOT_COMPLETED`.
- **Not literally zero.** Estimated first block well under 1 s
  after the system is usable (~0.3–0.6 s normally, ~1 s worst
  case), same as v6.1.5; v6.1.6 closes the *visible* gap once the
  service is up.
- If the boot mirror has no Strict wall end (Strict started before
  the mirror existed, or the write failed), boot mode starts the
  service when wanted but the fast block stays off until the Store
  reads after unlock. The mirror is written on every Strict
  start/end, so this only bites for a Strict that predates the
  mirror.

## Tests

**305 / 305 pass** (v6.1.5: 287; +18 new in `BootShadeTest.kt`):

- Shade gear launch resolves to Settings, not SystemUI
  (`ForegroundResolver` prefers the fresh event).
- SystemUI itself is never fast-blocked (only what the shade
  launches is blocked).
- Settings blocked by the fast path with **no activity class**
  (a shade launch may surface the package before any class).
- Phone Master from the shade is blocked too.
- Fast path stays silent when Strict is off.
- Boot block shows the overlay when the permission exists, none
  without it.
- Boot block retry 500 ms < normal 2000 ms; boot poll 100 ms <
  strict poll 250 ms.
- Boot event format names the package + reason; tolerates an
  unknown activity class; admin-lost event is a fixed string;
  DE log caps at 50 entries.
- Boot Strict is off when the mirror wall end is missing
  (documents the limit above), on while it is in the future.
- Self-heal gate: restarts when not running + Usage Access
  granted; not when already running; not without Usage Access.

Full suite run by `build.sh` step 5 (`JUnitCore`, all 30 test
classes). No other test changed.

## Verification

- `aapt2 dump badging`: package `app.strictguard`,
  versionCode `41`, versionName `6.1.6`, minSdk 29, targetSdk 34.
- `apksigner verify`: **Verifies, v3-only** (v1/v2/v3.1/v4 false),
  1 signer.
- **Same signing key as v6.1.3 / v6.1.4 / v6.1.5** — signer
  certificate SHA-256 digest identical for v6.1.5 and v6.1.6:
  `0367b410108019d6c2e18a26609b7a619cbd75ad19a60bf3a4a9280f47ef6304`
  (DN `CN=Strict Guard, O=Self-built, C=BD`).
- **0 Accessibility strings in code** — no
  `AccessibilityService`, no `BIND_ACCESSIBILITY_SERVICE` in
  source or manifest (the only "accessibility" matches are doc
  comments saying the app has none). No `INTERNET` permission in
  the manifest or the APK badging.
- Permissions (unchanged from v6.1.5): RECEIVE_BOOT_COMPLETED,
  FOREGROUND_SERVICE, FOREGROUND_SERVICE_SPECIAL_USE,
  REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, POST_NOTIFICATIONS,
  SYSTEM_ALERT_WINDOW, PACKAGE_USAGE_STATS, QUERY_ALL_PACKAGES,
  BIND_NOTIFICATION_LISTENER_SERVICE, BIND_DEVICE_ADMIN,
  SCHEDULE_EXACT_ALARM, USE_FULL_SCREEN_INTENT, VIBRATE.

## Deliverables

- APK: `~/workspace/your_files/Strict-Guard-v6.1.6.apk`
  - SHA-256: `936f30e7d354dd51a47c636f91425e1bc957b003b1fab0e7f90ca54801af51a4`
  - Size: 875,848 bytes
- Source: `~/workspace/your_files/Strict-Guard-v6.1.6-source.zip`
  (project tree + all build reports, 161 files; SHA-256 recorded
  in the delivery message, since a zip cannot contain its own hash)

## ⚠️ Version-code note — read before installing

**The task for this build said "versionCode 40", but v6.1.5 is
already versionCode 40** (manifest `android:versionCode="40"`).
This build uses **versionCode 41** instead (versionName 6.1.6).
Equal-code over-install is allowed by Android's downgrade check
in principle, but it is fragile and confusing — a higher code is
the only reliably verifiable over-install path, and the
35→36→37→38→39→40 sequence made 41 the next code. Nothing else
about the build depends on the number.

## Install (over v6.1.5 — no uninstall needed)

Same signing key + higher versionCode (41 > 40), so v6.1.6
**installs OVER v6.1.5**. If the phone refuses, uninstall v6.1.5
first and install fresh (same key, so the data is not the issue —
the installer is just being strict).

1. Make sure Device Admin is ON (Fahim turned it off in his
   03:30 test; v6.1.5's install steps already said to turn it
   back on).
2. Install `Strict-Guard-v6.1.6.apk` over v6.1.5.
3. Set Strict Guard as the default home launcher (if it asks
   again), and redo the 7 setup steps if any shows as missing —
   the **Overlay** step matters most for this fix: without it the
   boot block has no overlay cover, only the block screen.
4. Re-test the bypass: restart the phone, and while it is still
   loading, pull the shade down and tap the gear. Settings should
   now be covered by the full-screen block overlay the moment it
   opens. Check the Tamper Log afterwards — it should show a
   `BOOT_BLOCKED com.android.settings/... (STRICT_BYPASS)` entry
   from the boot.

No on-device testing was possible here (no Android environment
on this Linux computer), as with all previous versions.

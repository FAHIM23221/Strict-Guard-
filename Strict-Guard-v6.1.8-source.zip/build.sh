#!/usr/bin/env bash
# Strict Guard v6.1.8 — manual APK build (no Gradle; Gradle cannot run here).
# Tools: JDK 17, Android SDK 35, kotlinc 1.9.22, build-tools 35.0.0.
set -euo pipefail
cd "$(dirname "$0")"

JAVA_HOME=~/workspace/jdk17
SDK=~/workspace/.android-sdk
BT=$SDK/build-tools/35.0.0
ANDROID_JAR=$SDK/platforms/android-35/android.jar
KOTLINC=~/workspace/kotlinc-1.9.22/kotlinc/bin/kotlinc
STDLIB=~/workspace/kotlinc-1.9.22/kotlinc/lib/kotlin-stdlib.jar
JUNIT=~/workspace/.sdk-tmp/junit-4.13.2.jar
HAMCREST=~/workspace/.sdk-tmp/hamcrest-1.3.jar
export JAVA_HOME PATH=$JAVA_HOME/bin:$PATH
export JAVA_OPTS="-Xmx1024m -XX:+UseSerialGC -XX:MaxMetaspaceSize=192m"

mkdir -p build/gen build/r-classes build/classes build/dex build/test-classes output

echo "== 1. aapt2 compile resources =="
"$BT/aapt2" compile --dir app/src/main/res -o build/res.zip

echo "== 2. aapt2 link =="
"$BT/aapt2" link -o build/app-res.apk \
  --manifest app/src/main/AndroidManifest.xml \
  -I "$ANDROID_JAR" \
  --java build/gen \
  --auto-add-overlay \
  --min-sdk-version 29 --target-sdk-version 34 \
  --version-code 43 --version-name 6.1.8 \
  build/res.zip

echo "== 3. javac R.java =="
find build/gen -name "*.java" > build/r-sources.txt
javac -encoding UTF-8 -cp "$ANDROID_JAR" -d build/r-classes @build/r-sources.txt

echo "== 4. kotlinc main sources =="
find app/src/main/java -name "*.kt" > build/main-sources.txt
"$KOTLINC" -jvm-target 17 -language-version 1.9 \
  -cp "$ANDROID_JAR:$STDLIB:build/r-classes" \
  -d build/classes @build/main-sources.txt

echo "== 5. unit tests =="
# Compile ALL main sources (Store references MirrorStore, which
# references Util/GuardService/MainActivity) plus the tests.
"$KOTLINC" -jvm-target 17 -language-version 1.9 \
  -cp "$ANDROID_JAR:$STDLIB:$JUNIT:$HAMCREST:build/r-classes" \
  -d build/test-classes \
  @build/main-sources.txt \
  app/src/test/java/app/strictguard/*.kt
java -cp "build/test-classes:$STDLIB:$JUNIT:$HAMCREST" \
  org.junit.runner.JUnitCore \
  app.strictguard.UsageTrackerTest \
  app.strictguard.LimitsTest \
  app.strictguard.BlockDeciderTest \
  app.strictguard.ScheduleTest \
  app.strictguard.AdminFixTest \
  app.strictguard.LauncherTest \
  app.strictguard.BootRestoreTest \
  app.strictguard.LangTest \
  app.strictguard.BreakCycleTest \
  app.strictguard.ClaudeExemptionTest \
  app.strictguard.AutoThemeTest \
  app.strictguard.SelfBlockTest \
  app.strictguard.ClockFormatTest \
  app.strictguard.SetupRowStateTest \
  app.strictguard.UsedAppsTest \
  app.strictguard.StudyLockTest \
  app.strictguard.EntryDelayTest \
  app.strictguard.StrictMirrorTest \
  app.strictguard.HscCountdownTest \
  app.strictguard.FridayPrayerTest \
  app.strictguard.StartupCrashTest \
  app.strictguard.StudyLockDeadlockTest \
  app.strictguard.EntryDelayFixTest \
  app.strictguard.AlwaysAllowedTest \
  app.strictguard.StudyCountdownTest \
  app.strictguard.PhoneMasterTest \
  app.strictguard.FastBlockTest \
  app.strictguard.BootSpeedTest \
  app.strictguard.BootGapTest \
  app.strictguard.BootShadeTest 2>&1 | tee build/test-output.txt

echo "== 6. d8 dex =="
find build/classes build/r-classes -name "*.class" > build/dex-inputs.txt
"$BT/d8" --min-api 29 --output build/dex @build/dex-inputs.txt "$STDLIB"

echo "== 7. assemble APK =="
python3 assemble.py build/app-res.apk build/dex output/Strict-Guard-v6.1.8.apk

echo "== 8. zipalign + sign =="
if [ ! -f build/debug.keystore ]; then
  keytool -genkeypair -v -keystore build/debug.keystore -storepass android \
    -alias strictguard -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Strict Guard, O=Self-built, C=BD"
fi
"$BT/zipalign" -f 4 output/Strict-Guard-v6.1.8.apk output/Strict-Guard-v6.1.8-aligned.apk
mv output/Strict-Guard-v6.1.8-aligned.apk output/Strict-Guard-v6.1.8.apk
"$BT/apksigner" sign --ks build/debug.keystore --ks-pass pass:android \
  --key-pass pass:android --out output/Strict-Guard-v6.1.8-signed.apk \
  output/Strict-Guard-v6.1.8.apk
mv output/Strict-Guard-v6.1.8-signed.apk output/Strict-Guard-v6.1.8.apk

echo "== 9. verify =="
"$BT/aapt2" dump badging output/Strict-Guard-v6.1.8.apk | head -20
"$BT/apksigner" verify -v output/Strict-Guard-v6.1.8.apk
ls -l output/Strict-Guard-v6.1.8.apk
sha256sum output/Strict-Guard-v6.1.8.apk
echo "BUILD OK"

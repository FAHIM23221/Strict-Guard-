package app.strictguard

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Calendar

class ScreenTimeChartTest {

    @Test
    fun dayLabelsMapSundayThroughSaturday() {
        assertEquals("Sun", ScreenTimeChart.dayLabel(Calendar.SUNDAY, bn = false))
        assertEquals("Sat", ScreenTimeChart.dayLabel(Calendar.SATURDAY, bn = false))
        assertEquals("রবি", ScreenTimeChart.dayLabel(Calendar.SUNDAY, bn = true))
        assertEquals("শনি", ScreenTimeChart.dayLabel(Calendar.SATURDAY, bn = true))
        assertEquals("সোম", ScreenTimeChart.dayLabel(Calendar.MONDAY, bn = true))
    }

    @Test
    fun barHeightScalesAgainstTheTallestDay() {
        // The tallest day fills the max height exactly.
        assertEquals(100, ScreenTimeChart.barHeightPx(120, 120, 100, 4))
        // Half the tallest day is roughly half the height.
        assertEquals(50, ScreenTimeChart.barHeightPx(60, 120, 100, 4))
        // A day with 0 minutes still shows the minimum sliver, not nothing.
        assertEquals(4, ScreenTimeChart.barHeightPx(0, 120, 100, 4))
    }

    @Test
    fun barHeightWithNoDataAtAllStaysAtMinimum() {
        // Every one of the 7 days is 0 — nothing to scale against —
        // every bar must still draw the minimum sliver, not crash
        // on a division by zero.
        assertEquals(4, ScreenTimeChart.barHeightPx(0, 0, 100, 4))
    }

    @Test
    fun averageMinutesOfSevenDays() {
        assertEquals(60, ScreenTimeChart.averageMinutes(listOf(60, 60, 60, 60, 60, 60, 60)))
        assertEquals(30, ScreenTimeChart.averageMinutes(listOf(0, 0, 0, 0, 0, 0, 210)))
        assertEquals(0, ScreenTimeChart.averageMinutes(emptyList()))
    }
}

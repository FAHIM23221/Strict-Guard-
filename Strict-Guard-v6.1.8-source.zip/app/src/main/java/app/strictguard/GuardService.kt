package app.strictguard

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.util.Calendar

/**
 * Foreground guard service. Polls UsageStats every 500 ms.
 *
 * Why this blocks floating windows / split-screen / PiP without any
 * Accessibility Service: UsageStats MOVE_TO_FOREGROUND fires for a package
 * in EVERY window mode. A blocked app opened from the XOS sidebar as a
 * floating window, in split-screen, or in PiP is still the foreground
 * package, so the poll sees it and blocks it. The service never needs to
 * know the window mode — only the foreground package. v5.2.0 adds two
 * more layers: the XOS Smart Panel itself (com.transsion.smartpanel)
 * is in the builtin-strict list, and the block overlay is full-screen
 * TYPE_APPLICATION_OVERLAY and clickable, so it covers a floating
 * window instead of letting touches pass through to it.
 *
 * v5.2.1 FIXES THE ADMIN BYPASS Olivia found on-device: the guard
 * only looked at UsageEvents from the last 3 seconds. If the user was
 * already inside Settings when Strict was turned on, or navigated
 * *inside* Settings (Settings -> Security -> Device admin apps is the
 * same package, so no new MOVE_TO_FOREGROUND event fires), then after
 * 3 seconds the query returned null, tick() returned early, and the
 * guard went blind — Settings stayed open and Device Admin could be
 * turned off. The foreground package is now STICKY (last-known package
 * is reused when no new event arrives, with UsageStats' most-recently-
 * used package as a second fallback), and the permission/admin checks
 * run on every tick even when no foreground package can be resolved.
 * Settings is also checked by activity class, not just by package.
 * Honest limit: a blocked app may be visible for up to one poll interval
 * (~500 ms) before the block screen appears.
 */
class GuardService : Service() {

    companion object {
        const val NOTIF_ID = 1001
        const val ADMIN_NOTIF_ID = 1002
        const val HSC_REMINDER_NOTIF_ID = 1004
        const val HSC_DAYLESS_NOTIF_ID = 1005
        const val PRAYER_COUNTDOWN_NOTIF_ID = 1006
        const val CHANNEL_ID = "guard"
        const val ADMIN_CHANNEL_ID = "admin-alert"
        /** High-importance channel for the HSC "one day less" alert. */
        const val HSC_CHANNEL_ID = "hsc-alert"
        /** High-importance channel for Friday prayer reminders. */
        const val PRAYER_CHANNEL_ID = "prayer"
        const val ACTION_START = "app.strictguard.START"
        const val ACTION_STOP = "app.strictguard.STOP"
        /** Intent extra: this start came from boot / unlock (a reboot explains a guard gap). */
        const val EXTRA_FROM_BOOT = "app.strictguard.FROM_BOOT"
        private const val OVERLAY_HIDE_MS = 6000L
        /** Launch grace after a lock starts (see the fields below). */
        private const val STUDY_LAUNCH_GRACE_MS = 3000L
        /** Resume grace after a service (re)start with an active lock. */
        private const val STUDY_RESUME_GRACE_MS = 60_000L

        /** True while the service process is alive. MainActivity reads
         *  this to warn when blocking is not actually running. */
        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private lateinit var store: Store
    private val tracker = UsageTracker()
    private val handler = Handler(Looper.getMainLooper())
    private var lastForegroundPkg: String? = null
    private var lastForegroundActivity: String? = null
    private var lastBlockedPkg: String? = null
    private var lastBlockedAt: Long = 0L
    private var overlayView: View? = null
    private var lastUsageOk = true
    private var lastOverlayOk = true
    private var lastAdminOk = true
    // v6.1.7 hardening — ADB off and "we are the default launcher"
    // both start true (assumed ok) so a genuine change is what logs,
    // exactly like lastUsageOk/lastOverlayOk/lastAdminOk above.
    private var lastAdbOk = true
    private var lastLauncherOk = true
    /** Safe Mode is logged once per service run, the moment it can be. */
    private var safeModeLogged = false
    /** Groups currently in a forced break, so the break end is logged once. */
    private val breakActiveSeen = HashSet<String>()

    // ---- Nightly Study Lock (v6.1.0) ----
    /** Overlay views for the lock (start notice, missing-app, attention). */
    private var studyStartView: View? = null
    private var studyMissingView: View? = null
    private var studyAttentionView: View? = null
    /**
     * v6.1.3 circular countdown overlay: a small circle at the top
     * of the screen while the 15 fair minutes run, + its live ring
     * / time / pause views. Null when not showing.
     */
    private var studyCountdownView: View? = null
    private var studyCountdownRing: android.widget.ProgressBar? = null
    private var studyCountdownText: TextView? = null
    private var studyCountdownPaused: TextView? = null
    /** The overlay add failed (no overlay permission): do not
     *  retry the add on every tick; retried when the permission
     *  comes back (see checkPermissions). */
    private var studyCountdownAddFailed: Boolean = false
    /** Start overlay shown once per service run per lock (it auto-hides). */
    private var studyStartShown = false
    /**
     * Launch grace (elapsed-realtime deadline): for 3 seconds after
     * the lock starts, the timer and the block decision are skipped
     * so the study app can come up without the guard blocking the
     * app the lock interrupted, or racing its own launch.
     */
    private var studyLaunchGraceUntil: Long = 0L
    /**
     * Resume grace (elapsed-realtime deadline): for 60 seconds after
     * the service (re)starts with a lock already active (reboot,
     * system kill, unlock after direct boot), leaving the app pauses
     * the timer instead of resetting it — after a reboot the
     * foreground is the launcher, not the study app, and that must
     * not instantly wipe earned minutes. Other apps stay blocked
     * during the grace, so it cannot be used for anything else.
     */
    private var studyResumeGraceUntil: Long = 0L
    /** The resume rule + grace are applied once per service run. */
    private var studyResumeGraceArmed: Boolean = false

    // ---- Direct-boot enforcement mode (v6.1.5) ----
    /**
     * True while the service enforces from the device-protected
     * boot mirror alone: the Store (credential-encrypted prefs)
     * is unreadable before unlock, so until it reads, the service
     * knows only the mirror's Strict wall end + service-wanted.
     * See [BootEnforce] for why v6.1.4's "return START_STICKY and
     * enforce nothing" left the boot gap Fahim proved on-device.
     */
    private var bootMode: Boolean = false
    /** Strict counts as ON in boot mode (mirror wall end in the future). */
    private var bootStrict: Boolean = false
    /**
     * Admin was found off while in boot mode. The Tamper Log lives
     * in CE prefs, so the loss is remembered here and logged +
     * alerted the moment boot mode ends.
     */
    private var bootAdminLostSeen: Boolean = false
    /**
     * Blocks that landed in boot mode ("BOOT_BLOCKED ..."), flushed
     * into the Tamper Log when boot mode ends — the log itself is
     * unreadable before unlock.
     */
    private val bootBlockedEvents = ArrayList<String>()

    // ---- Entry Delay for social apps (v6.1.0) ----
    /** Package currently being delayed (its countdown is running). */
    private var delayPkg: String? = null
    /** ElapsedRealtime when the current wait started. */
    private var delayStartElapsed: Long = 0L
    /** Package whose countdown finished and is still in the foreground (granted). */
    private var delayDonePkg: String? = null
    /** The delay overlay view + its live countdown text. */
    private var delayOverlayView: View? = null
    private var delayCountdownView: TextView? = null
    /**
     * v6.1.2 — package the full-screen [DelayActivity] fallback
     * was launched for, if it is showing. Null when the overlay
     * path is in use (or no wait is running).
     */
    private var delayActivityPkg: String? = null

    private val pollRunnable = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (e: Exception) {
                // Never let the guard die on one bad poll.
            }
            handler.postDelayed(this, currentPollIntervalMs())
        }
    }

    /**
     * v6.1.4 — the poll interval for the NEXT tick: 250 ms while
     * Strict is on (the Settings block must land fast), 500 ms
     * otherwise. Never throws — a failure falls back to 500 ms.
     * v6.1.5 — boot mode polls at 100 ms ([BootEnforce.BOOT_POLL_MS]):
     * the whole point is the shortest possible window between
     * unlock and the first block, and boot mode lasts seconds.
     */
    private fun currentPollIntervalMs(): Long {
        return try {
            if (bootMode) return BootEnforce.BOOT_POLL_MS
            if (::store.isInitialized) Limits.pollIntervalMs(store.isStrictActive())
            else Limits.POLL_MS
        } catch (e: Exception) {
            Limits.POLL_MS
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        // v6.0.0 direct boot: Store() can throw before the user unlocks
        // (credential-encrypted prefs unavailable). Never crash the
        // guard on boot — start the poll anyway and retry init on
        // every tick until unlock.
        initStore()
        // v6.1.1: channel creation reads resources — it must never
        // crash the service start on a fresh install.
        // v6.1.5: the guard channel is created here (boot mode needs
        // it before the first enforcement tick); the other channels
        // are created by startNormalMode once the Store is readable.
        StartupGuard.runSafe { createGuardChannel() }
    }

    /** Try to (re)initialise the Store + usage tracker. Returns true on success. */
    private fun initStore(): Boolean {
        if (::store.isInitialized) return true
        return try {
            store = Store(this)
            store.recoverStrictAfterBoot()
            tracker.restore(store.todayKey(), store.usageSnapshot())
            // v6.1.7 hardening — Safe Mode disables this app entirely,
            // so it can only ever be logged AFTER the fact, once the
            // guard is running again. Once per service run.
            if (!safeModeLogged) {
                safeModeLogged = true
                if (Util.isSafeMode(this)) {
                    store.logTamper("SAFE_MODE guard was unavailable in Safe Mode")
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Re-read persisted state (schedule recovery + usage). Called on
     * every start so a direct-boot start that ran with empty state is
     * corrected the moment the user unlocks (USER_UNLOCKED restarts us).
     */
    private fun refreshState() {
        if (!::store.isInitialized) {
            initStore()
            return
        }
        try {
            store.recoverStrictAfterBoot()
            tracker.restore(store.todayKey(), store.usageSnapshot())
        } catch (e: Exception) {
            // Retry on the next tick.
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!::store.isInitialized && !initStore()) {
            // v6.1.5 — direct-boot enforcement mode. The old code
            // returned START_STICKY here (alive, enforcing nothing)
            // — the boot gap Fahim proved on-device. See
            // [startBootMode] and [BootEnforce].
            return startBootMode()
        }
        if (intent?.action == ACTION_STOP) {
            store.serviceWanted = false
            bootMode = false
            stopSelf()
            return START_NOT_STICKY
        }
        startNormalMode(intent)
        return START_STICKY
    }

    /**
     * v6.1.5 — direct-boot enforcement mode. The Store is
     * unreadable before unlock, but the guard must already be
     * enforcing by the time the user CAN touch Settings — i.e.
     * from LOCKED_BOOT_COMPLETED, not from USER_UNLOCKED or
     * BOOT_COMPLETED. The device-protected boot mirror (Strict
     * wall end + service-wanted) is all this needs: if it says
     * enforce, the service foregrounds IMMEDIATELY with a
     * minimal notification and starts the 100 ms boot poll
     * ([bootTick]). If it says nothing is wanted, the service
     * stops promptly — a service started via
     * startForegroundService that neither foregrounds nor stops
     * within the system timeout is killed by Android, so this
     * must not linger. The boot poll graduates to the normal
     * path the moment the Store reads (see [tick]).
     */
    private fun startBootMode(): Int {
        val (wallEnd, wanted) = StartupGuard.runSafeOr(
            { Store.bootMirrorState(this) }, Pair(0L, false)
        )
        val now = System.currentTimeMillis()
        if (!BootEnforce.shouldBootEnforce(wallEnd, now, wanted)) {
            stopSelf()
            return START_NOT_STICKY
        }
        bootMode = true
        bootStrict = BootEnforce.bootStrictActive(wallEnd, now)
        // Foreground NOW: the startForegroundService timeout kills
        // a service that never foregrounds, and the whole point of
        // boot mode is to be alive and polling before unlock.
        try {
            startForeground(
                NOTIF_ID, buildBootNotification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        handler.removeCallbacks(pollRunnable)
        handler.post(pollRunnable)
        return START_STICKY
    }

    /**
     * Minimal notification for boot mode. Resources work in direct
     * boot, but if anything throws, a bare notification with
     * literal text is used instead — losing the notification text
     * is acceptable, losing enforcement is not.
     */
    private fun buildBootNotification(): Notification {
        return try {
            buildNotification()
        } catch (e: Exception) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Strict Guard is on")
                .setContentText("Blocked apps are being watched")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setOngoing(true)
                .build()
        }
    }

    /**
     * Leave boot mode: flush what boot mode saw into the real
     * Store. Must only be called after initStore() succeeded.
     * Boot blocks go into the Tamper Log; an admin loss seen in
     * boot mode fires its log + persistent alert NOW — the moment
     * admin is found off, as far as the locked CE prefs allowed.
     * v6.1.6 — boot events were ALSO written to device-protected
     * prefs the moment they happened ([BootEventLog]), so drain
     * those too: if the process died before graduating, the
     * in-memory list is empty but the DE log still has the events.
     * Deduplicated — an event recorded in both places is logged once.
     */
    private fun exitBootMode() {
        if (!bootMode) return
        bootMode = false
        val seen = LinkedHashSet<String>()
        for (event in BootEventLog.drain(this)) {
            if (seen.add(event)) {
                StartupGuard.runSafe { store.logTamper(event) }
            }
        }
        for (event in bootBlockedEvents) {
            if (seen.add(event)) {
                StartupGuard.runSafe { store.logTamper(event) }
            }
        }
        bootBlockedEvents.clear()
        if (bootAdminLostSeen) {
            bootAdminLostSeen = false
            StartupGuard.runSafe {
                store.logTamper("ADMIN_LOST device-admin turned off in Settings")
            }
            lastAdminOk = false
            AdminLoss.postAdminLostNotification(
                this, persistent = store.isStrictActive()
            )
            Thread {
                StartupGuard.runSafe { MirrorStore.checkAndRestore(this, store) }
            }.start()
        }
    }

    /**
     * v6.1.5 — the normal start path, with enforcement FIRST.
     * The [fromBoot] flag marks starts that came from boot /
     * unlock (a reboot explains a guard gap; a force-stop does
     * not) — it defaults from the intent, and the boot-mode
     * graduation passes true explicitly.
     */
    private fun startNormalMode(
        intent: Intent?,
        fromBoot: Boolean = intent?.getBooleanExtra(EXTRA_FROM_BOOT, false) == true
    ) {
        // Leaving boot mode (a USER_UNLOCKED restart, or a boot
        // tick that just read the Store): flush boot mode first.
        exitBootMode()
        store.serviceWanted = true
        // v6.1.5: the remaining channels (admin alert, HSC, prayer)
        // are created here, on the normal path — the guard channel
        // was already created in onCreate for boot mode.
        StartupGuard.runSafe { createChannels() }
        refreshState()
        // v6.1.0 Study Lock: a lock already active when the service
        // (re)starts (reboot, system kill, unlock after direct boot)
        // resumes under the reboot rule — minutes kept only if the
        // session was continuous — plus a 60-second resume grace.
        if (store.studyActive) resumeStudyLockAfterRestart()
        // v6.1.5 — enforce FIRST: startForeground + first poll
        // BEFORE the slow work. The Keystore mirror decrypt
        // (MediaStore query + key loads, cold after boot) used to
        // sit between the service start and the first tick — that
        // was the remaining seconds of the boot gap Fahim proved.
        // The restore still runs, on a background thread, right
        // after the poll is posted; it only matters when the Store
        // lost Strict (Clear Data), and the boot receiver and the
        // app launches already restore it too. The force-stop gap
        // check moves with it — it is a log line, not enforcement.
        try {
            startForeground(NOTIF_ID, buildNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } catch (e: Exception) {
            stopSelf()
            return
        }
        handler.removeCallbacks(pollRunnable)
        handler.post(pollRunnable)
        Thread {
            try {
                // v6.1.0 Clear Data defence: if the Store lost Strict
                // (Clear Data was tapped) but the mirror outside the
                // app's private data still says Strict is on,
                // restore it immediately.
                MirrorStore.checkAndRestore(this, store)
            } catch (e: Exception) {
            }
            try {
                // v6.1.0 force-stop gap: Strict is on, the last guard
                // tick is stale, and this start did NOT come from
                // boot/unlock (a reboot explains the gap; a
                // force-stop does not).
                if (StrictMirror.shouldLogForceStopGap(
                        store.isStrictActive(), store.lastGuardTickMs,
                        System.currentTimeMillis(), fromBoot
                    )
                ) {
                    store.logTamper("FORCE_STOP_DETECTED last tick ${store.lastGuardTickMs}")
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    override fun onDestroy() {
        isRunning = false
        bootMode = false
        handler.removeCallbacks(pollRunnable)
        hideOverlay()
        hideStudyOverlays()
        hideDelayOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * v6.1.5 — the guard notification channel ONLY. The foreground
     * notification is the first thing boot mode needs (before the
     * first enforcement tick), so its channel is created by itself
     * and guarded on its own: if creating the other channels ever
     * throws, the guard channel — and with it enforcement — must
     * not be lost. The other channels are created by
     * [createChannels] once the service reaches the normal path.
     */
    private fun createGuardChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID, getString(R.string.service_notif_title),
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(ch)
        }
    }

    private fun createChannels() {
        createGuardChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            // v5.2.0: high-importance channel for the Device Admin alert.
            val adminCh = NotificationChannel(
                ADMIN_CHANNEL_ID, getString(R.string.admin_lost_title),
                NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(adminCh)
            // v6.1.0: high-importance channel for the HSC "one day
            // less" alert (and the Friday prayer alarm path).
            val hscCh = NotificationChannel(
                HSC_CHANNEL_ID, getString(R.string.hsc_dayless_title),
                NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(hscCh)
            val prayerCh = NotificationChannel(
                PRAYER_CHANNEL_ID, getString(R.string.friday_alarm_title),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                enableVibration(true)
            }
            nm.createNotificationChannel(prayerCh)
        }
    }

    private fun buildNotification(): Notification {
        val open = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.service_notif_title))
            .setContentText(getString(R.string.service_notif_text))
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
        return b.build()
    }

    /** One poll tick. Public for clarity; the real work is in [tick]. */
    fun tick() {
        // v6.1.5 — boot mode: the Store is unreadable before
        // unlock, so the normal tick's Store reads would all fail.
        // Tick the boot path until the Store reads, then graduate
        // to the normal path (flushing boot mode first).
        if (bootMode) {
            if (initStore()) {
                startNormalMode(null, fromBoot = true)
                return
            }
            bootTick()
            return
        }
        // v6.0.0: in direct boot the Store may not have initialised
        // yet (credential-encrypted prefs unavailable before unlock).
        // Retry on every poll until it succeeds; never run a tick
        // without state.
        if (!::store.isInitialized) {
            if (!initStore()) return
            // First successful init in this run (e.g. unlock after a
            // direct-boot start): a lock active here is a resumed one.
            if (store.studyActive) resumeStudyLockAfterRestart()
        }
        val now = System.currentTimeMillis()

        // v6.1.0 force-stop gap signal: the guard writes its last
        // tick every poll, so a later start can see how long the
        // guard was dead.
        store.lastGuardTickMs = now

        // v6.1.0: Strict's schedule expired while running — clear
        // the state and DELETE the mirror, so clearing data
        // afterwards is a clean slate.
        store.checkStrictEnded()

        // v6.1.4 FAST PATH — why the Settings block was slow:
        // the foreground was only resolved AFTER the HSC reminders,
        // the auto-theme check, the permission watch and the study
        // trigger, and every tick paid for a UsageStats
        // most-recent query even when the sticky package was known.
        // Now the foreground is resolved FIRST and the bypass
        // routes (Settings, our own settings, Phone Master) are
        // blocked immediately, before any of that work. The
        // resolved package is reused below, so the tick pays for
        // one foreground query instead of two. The study launch
        // grace still applies: for 3 s after a lock starts, nothing
        // is blocked (the study app is coming up).
        // The interval for THIS tick's accounting: 250 ms while
        // Strict is on, 500 ms otherwise — threaded through every
        // usage add below so fast ticks never over-count.
        val tickMs = currentPollIntervalMs()
        val fgPkg = currentForeground(now)
        // v6.1.8 — total screen time for the launcher's "last 7
        // days" chart: ANY foreground app except StrictGuard's own
        // screens. The home/launcher screen isn't "usage" any more
        // than a stock launcher's home screen counts in Android's
        // own Digital Wellbeing — so excluding our own package here
        // is the same rule, not a special case.
        if (fgPkg != null && fgPkg != packageName) {
            store.addScreenTime(tickMs)
        }
        if (fgPkg != null) {
            val inStudyGrace = store.studyActive &&
                SystemClock.elapsedRealtime() < studyLaunchGraceUntil
            if (!inStudyGrace) {
                val fast = BlockDecider.fastBlockDecision(
                    fgPkg, lastForegroundActivity, packageName,
                    store.isStrictActive()
                )
                if (fast != null) {
                    block(fgPkg, fast)
                    return
                }
            }
        }

        // v6.1.0 HSC reminders (from the guard poll — no extra
        // wakeups; if the guard is stopped they wait for its next run).
        hscTick(now)

        // v6.1.0 auto theme: evaluate the 06:00/18:00 switch on every
        // poll, so it applies even if the app was closed at the switch
        // time. Only writes + broadcasts when a switch is actually due.
        AutoTheme.maybeApplyAutoTheme(this, store)

        // 2) Permission-loss watch runs on EVERY tick, even when no
        //    foreground package can be resolved (v5.2.0 returned early
        //    before this when the event query came back empty).
        checkPermissions()

        // v6.1.0 Study Lock — trigger / expiry, before foreground
        // resolution: the lock must start at 21:00 even if no
        // foreground package resolves on that tick.
        if (store.studyActive) {
            if (StudyLock.shouldExpire(now, store.studyDay, true)) {
                endStudyLock(expired = true)
            }
        } else if (StudyLock.shouldTrigger(
                now, store.studyTimeMin, store.studyDay, store.studyDoneDay, false,
                store.studyLockEnabled
            )
        ) {
            startStudyLock(now)
        }

        // v6.1.4 — the foreground was already resolved at the top
        // of the tick (fast path); reuse it instead of querying
        // UsageStats a second time on the same tick.
        val pkg = fgPkg ?: return

        // v6.1.0 Study Lock — the fair timer runs on every tick while
        // the lock is active. The lock may have ended inside
        // startStudyLock / the timer itself (completed), so re-read.
        if (store.studyActive) {
            studyTick(pkg, now, tickMs)
        }

        // v6.1.0 Entry Delay — phase A: update the wait's state
        // from the foreground + screen. Returns true while the
        // delay overlay covers the app (the wait is not use, so
        // usage is not counted for those ticks). The block decision
        // below still runs and takes precedence: a blocked app never
        // gets its delay.
        // v6.1.2: while the full-screen DelayActivity fallback is
        // showing, the foreground package is Strict Guard itself —
        // the wait still belongs to the social app underneath, so
        // the delay step watches that package, not ours.
        val delayFgPkg = EntryDelay.effectiveDelayPkg(
            pkg, lastForegroundActivity, packageName, delayPkg
        )
        val delayCovering = entryDelayStep(delayFgPkg)

        // 1) Accumulate usage on EVERY poll for the foreground group.
        //    This is the v4 bug fix: continuous use in one app must count.
        //    v6.1.0 Break Cycle: when the cycle is on, a group in a
        //    forced break accumulates NO usage (break time never counts
        //    toward the daily limit), and when a session quota is
        //    reached a 20-minute break starts immediately. Session
        //    usage carries over across app opens — it is persisted,
        //    so closing the app early does not reset the session.
        //    v6.1.0 Entry Delay: while the delay overlay covers the
        //    app, the wait is not use — no usage, no session, no break
        //    progress for those ticks.
        val group = Limits.groupFor(pkg)
        // v6.1.3 always-unlocked apps: their usage is never counted
        // — Messenger is in the Facebook group, so without this its
        // use would count toward Facebook's 120-minute limit. (Claude
        // was already skipped by isLimitExempt below; this covers all
        // six the same way, before any counting happens.)
        if (group != null && (delayCovering || AlwaysAllowed.isAlwaysAllowed(pkg))) {
            tracker.tick(null, store.todayKey())
        } else if (group != null) {
            // v6.1.0 Claude exemption, extended in v6.1.3 to all six
            // always-unlocked apps (checked above, before any
            // counting): their usage is never counted — no daily
            // usage, no session, no break. They are also never
            // blocked by Strict/Night (AlwaysAllowed is checked
            // first in BlockDecider.decide), which is decided
            // separately from counting.
            if (Limits.isLimitExempt(pkg)) {
                tracker.tick(null, store.todayKey())
            } else if (store.breakCycleEnabled) {
                val breakUntil = store.breakUntilFor(group.id)
                if (BreakCycle.isInBreak(breakUntil, now)) {
                    breakActiveSeen.add(group.id)
                    tracker.tick(null, store.todayKey())
                } else {
                    if (breakActiveSeen.remove(group.id)) {
                        store.logTamper("BREAK_END ${group.id} break over")
                    }
                    store.addUsage(group.id, tickMs)
                    // v6.1.7: the EFFECTIVE limit (raised, if the user
                    // raised it) governs both the tracker and the
                    // break cycle — group.limitMs alone is only the
                    // group's unraised default from here on.
                    val effLimitMs = store.effectiveLimitMs(group)
                    val reached = tracker.tick(group.id, store.todayKey(), tickMs, effLimitMs)
                    if (reached != null) {
                        store.logTamper("LIMIT ${group.id} ${Limits.formatDuration(effLimitMs, Lang.isBengali(store.lang))}")
                    }
                    val outcome = BreakCycle.onUseTick(
                        group.id,
                        store.sessionUsedFor(group.id),
                        tickMs,
                        store.usageFor(group.id),
                        effLimitMs,
                        store.breakUntilFor(group.id),
                        now
                    )
                    if (outcome.breakStarted) {
                        store.startBreak(group.id, outcome.breakUntilMs)
                        breakActiveSeen.add(group.id)
                        store.logTamper(
                            "BREAK_START ${group.id} session done, 20 min break"
                        )
                    } else {
                        store.addSessionUsage(group.id, tickMs)
                    }
                }
            } else {
                store.addUsage(group.id, tickMs)
                val effLimitMs = store.effectiveLimitMs(group) // v6.1.7
                val reached = tracker.tick(group.id, store.todayKey(), tickMs, effLimitMs)
                if (reached != null) {
                    store.logTamper("LIMIT ${group.id} ${Limits.formatDuration(effLimitMs, Lang.isBengali(store.lang))}")
                }
            }
        } else {
            tracker.tick(null, store.todayKey())
        }

        // 3) Decide + block. During the 3-second launch grace after
        // a lock starts, block nothing: the study app is coming up
        // and the interrupted app must not get a block screen over
        // its launch. (When no lock is active the grace deadline is
        // 0, so this never skips.) The delay timer is reset here too,
        // so a wait cannot start early during the grace.
        if (store.studyActive &&
            SystemClock.elapsedRealtime() < studyLaunchGraceUntil
        ) {
            resetDelay()
            return
        }
        val strict = store.isStrictActive()
        val night = store.nightEnabled && Limits.nightActive(
            Calendar.getInstance(), store.nightStartMin, store.nightEndMin
        )
        // v6.1.0 self-block: during Strict Mode, Strict Guard's own
        // settings / dashboard activities must not open — this is
        // the catch for every path the launcher tile cannot cover:
        // the app icon on another launcher, Recents, a notification
        // tap, or the app already being open when Strict started.
        // The launcher (home screen) and the block screen itself are
        // exempt, and Night Lock does NOT self-block. [BlockDecider]
        // returns null for our own package, so this is a separate
        // check, before the normal decision. block() logs the
        // attempt to the Tamper Log.
        if (strict && BlockDecider.isOwnSettingsActivity(
                pkg, lastForegroundActivity, packageName
            )
        ) {
            block(pkg, BlockDecider.Decision(BlockDecider.Kind.SELF_BLOCK))
            return
        }
        // v6.1.0 Study Lock: the app's own settings / dashboard
        // activities are "anything else" during a lock, so they are
        // blocked too — with the STUDY reason, not SELF_BLOCK.
        // (The launcher tap path blocks the tile as well, in
        // LauncherLogic; this is the catch for Recents, notification
        // taps, or the app already being open when the lock started.)
        if (store.studyActive && BlockDecider.isOwnSettingsActivity(
                pkg, lastForegroundActivity, packageName
            )
        ) {
            block(pkg, BlockDecider.Decision(BlockDecider.Kind.STUDY))
            return
        }
        val limitReached = Limits.GROUPS
            .filter { store.usageFor(it.id) >= store.effectiveLimitMs(it) } // v6.1.7
            .map { it.id }.toSet()
        val decision = BlockDecider.decide(
            pkg, strict, night, store.nightAllowed, store.customBlock,
            limitReached, Util.launcherPackages(this).contains(pkg), packageName,
            lastForegroundActivity,
            store.breakCycleEnabled, store.breakUntilMap(), now,
            store.studyActive, store.studyMissing, StudyLock.STUDY_APP_PACKAGE,
            Util.isPhoneApp(this, pkg)
        )
        if (decision != null) {
            block(pkg, decision)
            return
        }

        // 4) Entry Delay — phase B: the app is otherwise allowed,
        // so show / update the countdown overlay while the wait
        // runs, and hide it when the wait is done or not running.
        entryDelaySyncOverlay()
    }

    /**
     * v6.1.5 — the direct-boot tick. Runs at 100 ms while the
     * Store is unreadable, and does ONLY what enforcement needs:
     * read the foreground (UsageEvents sticky resolver first,
     * UsageStats fallback), check admin, and fast-block Settings
     * / Phone Master / our own settings. No usage accounting, no
     * alarms, no mirror, no study lock, no notifications other
     * than the persistent admin alert — all of that is deferred
     * to the moment the Store reads. Strictness comes from the
     * boot mirror ([bootStrict]), so the fast block runs from the
     * very first tick. Boot blocks are remembered, not logged —
     * the Tamper Log lives in CE prefs — and flushed by
     * [exitBootMode]. Admin loss seen here is remembered the
     * same way ([bootAdminLostSeen]); the independent
     * [GuardAdminReceiver.onDisabled] path covers it too. Never
     * throws, never stops the poll: a failed boot tick is one
     * missed 100 ms tick, not a dead guard.
     */
    private fun bootTick() {
        try {
            if (!bootStrict) return
            val now = System.currentTimeMillis()
            // Sticky foreground resolver (same as the normal fast
            // path): a fresh event, else the last-known package, else
            // the most-recently-used package from UsageStats — so
            // Settings already open before the first tick is still
            // caught. The activity class follows the same stickiness.
            val pkg = currentForeground(now) ?: return
            val cls = lastForegroundActivity
            val adminOk = Util.isAdminActive(this)
            if (!adminOk && !bootAdminLostSeen) {
                bootAdminLostSeen = true
                // v6.1.6 — record immediately to device-protected
                // prefs, not just memory: if the process dies
                // before graduating, the loss is still on record.
                StartupGuard.runSafe {
                    BootEventLog.record(this, BootEventLog.formatAdminLostEvent())
                }
            }
            // Same fast-block rule as the normal path, from the
            // mirror state alone: Settings (package or activity),
            // Phone Master, our own settings screens. The block
            // itself (and its log entry) happens inside blockBoot,
            // after its retry throttle — recording here would log
            // the same block on every 100 ms tick.
            val fast = BlockDecider.fastBlockDecision(pkg, cls, packageName, strict = true)
            if (fast != null) {
                blockBoot(pkg, fast)
            }
        } catch (e: Exception) {
        }
    }

    /**
     * v6.1.5 — boot-mode block: no Store, so no Tamper Log and no
     * localised reason. The block screen (a plain activity that
     * tolerates a missing Store) does not need it. Identical in
     * spirit to [block]: open BlockActivity full-screen, kill the
     * blocked app's process (never our own), and send the user
     * home.
     *
     * v6.1.6 — THE QUICK SETTINGS SHADE FIX. The old boot block
     * did ONLY the activity start. Before any activity of ours is
     * visible (lock screen, home still loading), Android can
     * refuse a service's activity start — the only exemption the
     * app holds is the overlay permission. A refused/delayed
     * BlockActivity left NOTHING covering Settings, which is
     * exactly how Fahim opened it from the shade gear. The boot
     * block now ALSO shows the full-screen overlay (a window add
     * needs no activity-start exemption), so Settings is covered
     * the moment the block lands, even if the activity start is
     * refused. The block is retried every 500 ms while Settings
     * stays in the foreground (normal path keeps 2 s).
     */
    private fun blockBoot(pkg: String, decision: BlockDecider.Decision) {
        val now = SystemClock.elapsedRealtime()
        if (pkg == lastBlockedPkg && now - lastBlockedAt < BootEnforce.bootBlockRetryMs(true)) return
        lastBlockedPkg = pkg
        lastBlockedAt = now
        // The block fired (not throttled): record it NOW, both in
        // memory and in device-protected prefs — the Tamper Log is
        // unreadable before unlock and the in-memory list dies with
        // the process, so a boot-time Settings open is on record the
        // moment it happens, whatever happens to the service next.
        val reason = BootEventLog.formatBlockEvent(
            pkg, lastForegroundActivity, decision.kind
        )
        bootBlockedEvents.add(reason)
        StartupGuard.runSafe { BootEventLog.record(this, reason) }
        val label = StartupGuard.runSafeOr({ Util.appLabel(this, pkg) }, pkg)
        if (BootEnforce.shouldShowBootOverlay(Util.hasOverlay(this))) {
            StartupGuard.runSafe { showOverlay(label, decision) }
        }
        try {
            val i = Intent(this, BlockActivity::class.java).apply {
                putExtra(BlockActivity.EXTRA_PKG, pkg)
                putExtra(BlockActivity.EXTRA_KIND, decision.kind.name)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            startActivity(i)
        } catch (e: Exception) {
            // v6.1.6 — a refused start is covered by the overlay
            // above and retried on the next boot tick (500 ms).
        }
        try {
            if (pkg != packageName) {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                am.killBackgroundProcesses(pkg)
            }
        } catch (e: Exception) {
        }
        try {
            Util.goHome(this)
        } catch (e: Exception) {
        }
    }

    /**
     * v5.2.1 — the foreground package, resolved stickily. The UsageEvents
     * query only covers the last 3 seconds, so it goes empty as soon as
     * the user sits inside one app (or one package, like Settings) for
     * more than 3 seconds — and a package that was in the foreground
     * does not stop being in the foreground just because no new event
     * fired. Resolution order: fresh event > last-known package >
     * most-recently-used package from UsageStats. The activity class
     * follows the same stickiness, so a Settings screen reached by
     * in-app navigation is still recognised as Settings.
     */
    private fun currentForeground(now: Long): String? {
        // v6.1.4 — the UsageStats most-recent query is the most
        // expensive call in the tick and it ran on EVERY poll. It
        // is only needed when there is no fresh event AND no sticky
        // package (e.g. right after a service restart) — skip it
        // otherwise, so the Settings fast path at the top of tick()
        // is not delayed behind it. ForegroundResolver.resolve()
        // is null-safe, so passing null here is "no info".
        val event = foregroundEvent(now)
        if (event.first != null) lastForegroundPkg = event.first
        if (event.second != null) lastForegroundActivity = event.second
        val statsPkg =
            if (event.first == null && lastForegroundPkg == null) statsMostRecent(now)
            else null
        val pkg = ForegroundResolver.resolve(
            event.first, lastForegroundPkg, statsPkg
        )
        lastForegroundActivity =
            ForegroundResolver.resolveActivity(event.second, lastForegroundActivity)
        return pkg
    }

    private fun checkPermissions() {
        val usageOk = Util.hasUsageAccess(this)
        if (usageOk != lastUsageOk) {
            lastUsageOk = usageOk
            if (!usageOk) store.logTamper("PERMISSION_LOST usage-access")
        }
        val overlayOk = Util.hasOverlay(this)
        if (overlayOk != lastOverlayOk) {
            lastOverlayOk = overlayOk
            if (!overlayOk) store.logTamper("PERMISSION_LOST overlay")
            // v6.1.3: the countdown overlay add is retried once the
            // overlay permission comes back.
            if (overlayOk) studyCountdownAddFailed = false
        }
        // v5.2.0 — Device Admin is checked on EVERY poll. Android lets
        // the user turn admin off in Settings; the app cannot make that
        // impossible, and the UI must never claim it can. What it does
        // instead: log the loss, show a persistent alert notification
        // that opens the app so admin can be turned back on, and keep
        // blocking via UsageStats anyway (blocking never depends on
        // admin). Settings itself is already blocked during Strict, so
        // the admin screen cannot be reached while Strict is on.
        // v6.1.5 — the loss during Strict is now a PERSISTENT alert
        // (ongoing, not swipe-dismissible) while Strict is on, the
        // Strict state is re-asserted from the surviving mirror on
        // a background thread (so losing admin cannot also silently
        // lose Strict), and the alert is cancelled the moment admin
        // comes back. See [AdminLoss]. The guard poll is one
        // detection path; [GuardAdminReceiver.onDisabled] is the
        // other — it fires even when the guard service is dead.
        val adminOk = Util.isAdminActive(this)
        if (adminOk != lastAdminOk) {
            lastAdminOk = adminOk
            if (!adminOk) {
                store.logTamper("ADMIN_LOST device-admin turned off in Settings")
                if (store.isStrictActive()) {
                    AdminLoss.postAdminLostNotification(
                        this, persistent = true
                    )
                    Thread {
                        try {
                            MirrorStore.checkAndRestore(this, store)
                        } catch (e: Exception) {
                        }
                    }.start()
                }
            } else {
                store.logTamper("ADMIN_RESTORED device-admin")
                AdminLoss.cancelAdminLostNotification(this)
            }
        }
        // v6.1.7 hardening — USB debugging (adb) turned on: a classic
        // bypass route. Logged on the edge, same pattern as above.
        val adbOk = !Util.isAdbEnabled(this)
        if (adbOk != lastAdbOk) {
            lastAdbOk = adbOk
            if (!adbOk) store.logTamper("ADB_ENABLED usb debugging turned on")
        }
        // v6.1.7 hardening — StrictGuard stopped being the default
        // home app while Strict / Night was active. This cannot be
        // blocked — only the OS decides the default launcher — so
        // it is logged, not prevented; the real block (UsageStats
        // polling) does not depend on which launcher is in front.
        val night = store.nightEnabled && Limits.nightActive(
            Calendar.getInstance(), store.nightStartMin, store.nightEndMin
        )
        if (store.isStrictActive() || night) {
            val launcherOk = Util.isDefaultLauncher(this)
            if (launcherOk != lastLauncherOk) {
                lastLauncherOk = launcherOk
                if (!launcherOk) {
                    store.logTamper("LAUNCHER_CHANGED no longer the default home app")
                }
            }
        } else {
            // Outside Strict/Night a launcher change is not tamper —
            // don't let a stale false linger and fire a false edge
            // the next time Strict/Night starts.
            lastLauncherOk = true
        }
    }

    // ================= Nightly Study Lock (v6.1.0) =================
    //
    // The linked app is PERMANENT (StudyLock.STUDY_APP_PACKAGE) —
    // hard-coded, no UI to change it, no toggle to disable it.
    // Only the TIME may be changed, in settings (locked during
    // Strict). The lock runs once per night: 15 continuous fair
    // minutes in the study app, screen on. Everything else is
    // blocked except receiving phone calls.

    /** Start tonight's lock: state, overlay, launch the study app. */
    private fun startStudyLock(now: Long) {
        val today = StudyLock.dayKey(now)
        store.studyActive = true
        store.studyDay = today
        store.studyAccumMs = 0L
        store.studyAttentionDone = false
        store.studyAttentionSinceMs = 0L
        store.studyLastStudying = false
        store.studyMissing = !isStudyAppInstalled()
        studyStartShown = false
        studyLaunchGraceUntil = SystemClock.elapsedRealtime() + STUDY_LAUNCH_GRACE_MS
        if (store.studyMissing) {
            store.logTamper("STUDY_APP_MISSING")
            store.logTamper("STUDY_LOCK_START missing app")
            showStudyMissingOverlay()
        } else {
            store.logTamper("STUDY_LOCK_START $today")
            launchStudyApp()
            showStudyStartOverlay()
        }
    }

    /**
     * End the lock. [done] = the 15 fair minutes are complete;
     * [expired] = a leftover lock from a previous night hit 06:00.
     * A completed night is recorded so it does not trigger again
     * until the next night; an expired night is not, so the next
     * night's 21:00 still triggers.
     */
    private fun endStudyLock(done: Boolean = false, expired: Boolean = false) {
        val today = StudyLock.dayKey(System.currentTimeMillis())
        store.studyActive = false
        store.studyMissing = false
        store.studyAccumMs = 0L
        store.studyAttentionDone = false
        store.studyAttentionSinceMs = 0L
        store.studyLastStudying = false
        studyLaunchGraceUntil = 0L
        studyResumeGraceUntil = 0L
        hideStudyOverlays()
        if (done) {
            store.studyDoneDay = today
            store.logTamper("STUDY_LOCK_DONE $today")
        } else if (expired) {
            store.logTamper("STUDY_LOCK_EXPIRED ${store.studyDay}")
        }
    }

    /**
     * Called when the service (re)starts with a lock already active
     * (reboot, system kill, unlock after direct boot). Applies the
     * reboot rule once per run: minutes are kept only if the last
     * tick before the restart had the study app in the foreground
     * with the screen on; otherwise they reset to zero, with the
     * attention check. Also arms a 60-second resume grace in which
     * leaving the app pauses instead of resetting — after a reboot
     * the foreground is the launcher, and that must not instantly
     * wipe earned minutes. Other apps stay blocked during the grace,
     * so it cannot be used for anything else.
     */
    private fun resumeStudyLockAfterRestart() {
        if (studyResumeGraceArmed) return
        studyResumeGraceArmed = true
        val kept = StudyLock.resumeAccumulated(store.studyAccumMs, store.studyLastStudying)
        if (kept != store.studyAccumMs) {
            store.studyAccumMs = kept
            store.studyAttentionDone = false
            store.studyAttentionSinceMs = 0L
            store.logTamper("STUDY_RESUME reset (session was paused)")
        }
        studyResumeGraceUntil = SystemClock.elapsedRealtime() + STUDY_RESUME_GRACE_MS
    }

    /** One timer step while a lock is active. */
    private fun studyTick(pkg: String, now: Long, tickMs: Long) {
        // If the app was installed while the lock was waiting on it,
        // notice it now: stop waiting, launch the study app.
        if (store.studyMissing && isStudyAppInstalled()) {
            store.studyMissing = false
            store.logTamper("STUDY_APP_INSTALLED")
            hideStudyMissingOverlay()
            launchStudyApp()
            studyLaunchGraceUntil = SystemClock.elapsedRealtime() + STUDY_LAUNCH_GRACE_MS
            showStudyStartOverlay()
        }

        // Overlays for a resumed lock: after a reboot the views are
        // gone, so re-show the right one (once per run for the start
        // notice; the missing overlay stays until the lock ends).
        if (store.studyMissing) {
            showStudyMissingOverlay()
        } else if (!studyStartShown) {
            showStudyStartOverlay()
        }

        // Launch grace: the study app is still coming up; neither
        // count nor reset on these ticks.
        if (SystemClock.elapsedRealtime() < studyLaunchGraceUntil) return

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val screenOn = pm.isInteractive
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val keyguardLocked = km.isKeyguardLocked

        // What the foreground means for the timer. System UI (recents
        // / shade) and a phone call pause — he has not switched apps.
        // The Play Store pauses only while the study app is missing
        // (installing it). Everything else — including the launcher
        // and this app's own settings — means he left: reset to zero.
        // During the resume grace after a restart, leaving pauses
        // instead of resetting (see resumeStudyLockAfterRestart).
        val rawMode = when {
            StudyLock.isStudyApp(pkg) ->
                if (screenOn && !keyguardLocked) StudyLock.Mode.STUDYING
                else StudyLock.Mode.PAUSED
            Util.isPhoneApp(this, pkg) -> StudyLock.Mode.PAUSED
            pkg == "com.android.systemui" -> StudyLock.Mode.PAUSED
            store.studyMissing && pkg == StudyLock.PLAY_STORE_PKG -> StudyLock.Mode.PAUSED
            else -> StudyLock.Mode.LEFT
        }
        val mode = if (rawMode == StudyLock.Mode.LEFT &&
            SystemClock.elapsedRealtime() < studyResumeGraceUntil
        ) StudyLock.Mode.PAUSED else rawMode
        if (mode == StudyLock.Mode.STUDYING) studyResumeGraceUntil = 0L

        store.studyLastStudying = (mode == StudyLock.Mode.STUDYING)
        val state = StudyLock.TickState(
            store.studyAccumMs, store.studyAttentionDone, store.studyAttentionSinceMs
        )
        val result = StudyLock.onTick(state, mode, now, tickMs)
        store.studyAccumMs = result.state.accumulatedMs
        store.studyAttentionDone = result.state.attentionDone
        store.studyAttentionSinceMs = result.state.attentionSinceMs
        if (result.didReset) {
            store.logTamper("STUDY_RESET left the app")
        }
        if (result.attentionDue) showStudyAttentionOverlay()
        else hideStudyAttentionOverlay()
        if (result.completed) {
            endStudyLock(done = true)
        } else {
            // v6.1.3 circular countdown: shown / updated on every
            // tick while the lock runs; hidden when it completes
            // (endStudyLock hides it) or the app is left.
            syncStudyCountdownOverlay(mode, now)
        }
    }

    /**
     * v6.1.2 — true when EITHER study-app package is installed.
     * The live Play Store listing is com.nextive.etestpaper; the
     * original listing was com.nextive.eTestPaper. Checking only
     * one of them reported the app missing (and blocked it) when
     * Fahim had the other one installed.
     */
    private fun isStudyAppInstalled(): Boolean =
        StudyLock.STUDY_APP_PACKAGES.any { Util.isAppInstalled(this, it) }

    /** Launch the study app — whichever of its two packages is installed (or do nothing if it vanished). */
    private fun launchStudyApp() {
        val launch = StudyLock.STUDY_APP_PACKAGES.firstNotNullOfOrNull {
            packageManager.getLaunchIntentForPackage(it)
        } ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(launch)
        } catch (e: Exception) {
        }
    }

    /** Open the study app's Play Store page (market://, https fallback).
     * v6.1.2: opens the LIVE listing (com.nextive.etestpaper) — the
     * original listing (com.nextive.eTestPaper) was removed from
     * Google Play on 2026-07-08, so its page no longer installs. */
    private fun openStudyAppInPlayStore() {
        val id = StudyLock.STUDY_APP_PACKAGE_ALT
        val market = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=$id")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(market)
        } catch (e: Exception) {
            val web = Intent(
                Intent.ACTION_VIEW,
                android.net.Uri.parse("https://play.google.com/store/apps/details?id=$id")
            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            try {
                startActivity(web)
            } catch (e2: Exception) {
            }
        }
    }

    /** Add a study overlay view to the window (clickable, like the block overlay). */
    private fun addStudyOverlay(view: View): Boolean {
        if (!Util.hasOverlay(this)) return false
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        return try {
            wm.addView(view, params)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun removeStudyView(view: View?) {
        if (view == null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeView(view)
        } catch (e: Exception) {
        }
    }

    /** "Study time" notice, shown once per lock / service run, auto-hides. */
    private fun showStudyStartOverlay() {
        if (studyStartView != null || studyStartShown) return
        studyStartShown = true
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_study_start, null)
        view.isClickable = true
        if (addStudyOverlay(view)) {
            studyStartView = view
            handler.postDelayed({ hideStudyStartOverlay() }, OVERLAY_HIDE_MS)
        }
    }

    private fun hideStudyStartOverlay() {
        removeStudyView(studyStartView)
        studyStartView = null
    }

    /** Missing-app overlay: stays until the lock ends or the app is installed. */
    private fun showStudyMissingOverlay() {
        if (studyMissingView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_study_missing, null)
        view.isClickable = true
        view.findViewById<android.widget.Button>(R.id.btnInstallStudyApp).setOnClickListener {
            openStudyAppInPlayStore()
        }
        if (addStudyOverlay(view)) studyMissingView = view
    }

    private fun hideStudyMissingOverlay() {
        removeStudyView(studyMissingView)
        studyMissingView = null
    }

    /** Midway "আমি পড়ছি" attention prompt. */
    private fun showStudyAttentionOverlay() {
        if (studyAttentionView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_study_attention, null)
        view.isClickable = true
        view.findViewById<android.widget.Button>(R.id.btnStudying).setOnClickListener {
            store.studyAttentionDone = true
            store.studyAttentionSinceMs = 0L
            store.logTamper("STUDY_ATTENTION_OK")
            hideStudyAttentionOverlay()
        }
        if (addStudyOverlay(view)) studyAttentionView = view
    }

    private fun hideStudyAttentionOverlay() {
        removeStudyView(studyAttentionView)
        studyAttentionView = null
    }

    private fun hideStudyOverlays() {
        hideStudyStartOverlay()
        hideStudyMissingOverlay()
        hideStudyAttentionOverlay()
        hideStudyCountdownOverlay()
    }

    /**
     * v6.1.3 — circular study countdown overlay (Fahim, 2026-11-09).
     * A small circle at the top of the screen while the 15 fair
     * minutes run in eTestPaper: the ring fills as minutes
     * accumulate, the text shows the time left. Shown while the
     * lock runs and the study app is in front (or paused: screen
     * off / call / idle), hidden when he leaves the app (the
     * timer resets then anyway) or the lock ends. Driven by
     * [StudyCountdown]'s pure state machine, so the rules are
     * unit-tested; this is only the window + the live values.
     * Without the overlay permission the circle simply cannot be
     * shown — the timer itself still runs correctly, and the add
     * is retried when the permission comes back.
     */
    private fun syncStudyCountdownOverlay(mode: StudyLock.Mode, now: Long) {
        val attentionOverdue =
            StudyCountdown.isIdlePaused(store.studyAttentionSinceMs, now)
        val state = StudyCountdown.state(
            store.studyActive, store.studyMissing, mode, attentionOverdue
        )
        if (state == StudyCountdown.State.HIDDEN) {
            hideStudyCountdownOverlay()
            return
        }
        if (studyCountdownView == null) {
            if (studyCountdownAddFailed) return
            val view = LayoutInflater.from(this)
                .inflate(R.layout.overlay_study_countdown, null)
            view.isClickable = true
            view.setOnClickListener { onStudyCountdownTap() }
            if (!addCountdownOverlay(view)) {
                studyCountdownAddFailed = true
                return
            }
            studyCountdownView = view
            studyCountdownRing = view.findViewById(R.id.studyCountdownRing)
            studyCountdownText = view.findViewById(R.id.studyCountdownText)
            studyCountdownPaused = view.findViewById(R.id.studyCountdownPaused)
        }
        val accumulated = store.studyAccumMs
        studyCountdownRing?.progress = StudyCountdown.progressSeconds(accumulated)
        studyCountdownText?.text =
            StudyCountdown.displayText(StudyCountdown.remainingMs(accumulated))
        val paused = state == StudyCountdown.State.PAUSED
        studyCountdownPaused?.visibility = if (paused) View.VISIBLE else View.GONE
        studyCountdownView?.alpha = if (paused) 0.55f else 1f
    }

    /**
     * Small top-centre overlay: WRAP_CONTENT, FLAG_NOT_TOUCH_MODAL —
     * touches outside the circle pass straight through to
     * eTestPaper, so the countdown can never block studying.
     * Only taps ON the circle itself reach it (the activity tap).
     */
    private fun addCountdownOverlay(view: View): Boolean {
        if (!Util.hasOverlay(this)) return false
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dp = resources.displayMetrics.density
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity =
            android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
        params.y = (56 * dp).toInt()
        return try {
            wm.addView(view, params)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun hideStudyCountdownOverlay() {
        removeStudyView(studyCountdownView)
        studyCountdownView = null
        studyCountdownRing = null
        studyCountdownText = null
        studyCountdownPaused = null
    }

    /**
     * Tapping the countdown circle counts as activity: it confirms
     * the "আমি পড়ছি" attention check when one is due (and resumes
     * an idle-paused countdown), exactly like tapping the attention
     * prompt's own button. Tapping at any other time does nothing —
     * the circle is a display, not a control.
     */
    private fun onStudyCountdownTap() {
        if (store.studyAttentionSinceMs != 0L) {
            store.studyAttentionDone = true
            store.studyAttentionSinceMs = 0L
            store.logTamper("STUDY_ATTENTION_OK")
            hideStudyAttentionOverlay()
        }
    }

    // ================= End Study Lock =================

    // ================= Entry Delay for social apps (v6.1.0) =================
    //
    // Phase A (called before usage counting): update the wait's
    // state from the foreground + screen. Returns true while the
    // delay overlay covers the app. Phase B (called after the block
    // decision, only when the app is otherwise allowed) shows or
    // updates the overlay. A block decision anywhere resets the wait.

    /** Update the wait's state. True while the overlay covers the app. */
    private fun entryDelayStep(pkg: String): Boolean {
        // The grant only lasts while the same app stays in the foreground.
        if (delayDonePkg != null && delayDonePkg != pkg) delayDonePkg = null
        if (delayDonePkg == pkg) return false // granted — normal use
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val screenOn = pm.isInteractive
        // Not a delay situation (toggle off, not a social app, or the
        // screen is off): any running wait resets — the full wait
        // must be done continuously, with the screen on.
        if (!store.entryDelayEnabled || !EntryDelay.isDelayApp(pkg) || !screenOn) {
            if (delayPkg != null) resetDelay()
            return false
        }
        val nowElapsed = SystemClock.elapsedRealtime()
        if (delayPkg == pkg) {
            // Continuing the wait.
            if (EntryDelay.isDone(delayStartElapsed, store.entryDelaySeconds, nowElapsed)) {
                delayDonePkg = pkg
                delayPkg = null
                hideDelayOverlay()
                hideDelayActivity()
                return false
            }
            return true
        }
        // Fresh open — start the wait.
        delayPkg = pkg
        delayStartElapsed = nowElapsed
        delayDonePkg = null
        return true
    }

    /** Show / update the countdown overlay (phase B). */
    private fun entryDelaySyncOverlay() {
        val pkg = delayPkg ?: run {
            hideDelayOverlay()
            hideDelayActivity()
            return
        }
        val remaining = EntryDelay.remainingSeconds(
            delayStartElapsed, store.entryDelaySeconds, SystemClock.elapsedRealtime()
        )
        // v6.1.2 — the overlay is the normal popup, but it is NOT
        // the only one: if the overlay permission is missing, or
        // the overlay view could not be added, the countdown MUST
        // still appear — as the full-screen DelayActivity. A wait
        // with no visible popup is a wait the user can walk straight
        // through, which is exactly the bug Fahim reported (social
        // apps opening directly, no 15-second popup at all).
        if (delayOverlayView == null && !Util.hasOverlay(this)) {
            showDelayActivity(pkg)
            return
        }
        if (delayOverlayView == null) {
            val view = LayoutInflater.from(this).inflate(R.layout.overlay_entry_delay, null)
            view.isClickable = true
            view.findViewById<TextView>(R.id.delayTitle).text =
                getString(R.string.delay_title, Util.appLabel(this, pkg))
            view.findViewById<TextView>(R.id.delayText).text =
                getString(R.string.delay_text, store.entryDelaySeconds)
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            try {
                wm.addView(view, params)
                delayOverlayView = view
                delayCountdownView = view.findViewById(R.id.delayCountdown)
            } catch (e: Exception) {
                delayOverlayView = null
                delayCountdownView = null
                // The overlay could not be added even though the
                // permission reads as granted — fall back to the
                // full-screen activity rather than a silent skip.
                showDelayActivity(pkg)
                return
            }
        }
        val bn = Lang.isBengali(store.lang)
        delayCountdownView?.text = if (bn) {
            Limits.toBengaliDigits(remaining.toString())
        } else {
            remaining.toString()
        }
    }

    /**
     * v6.1.2 — show the countdown as the full-screen [DelayActivity]
     * (once per wait). The wait's deadline is the same one the
     * overlay would have counted down from. If even the activity
     * cannot be started (background-activity rules), log it to the
     * Tamper Log — the failure is then visible in Diagnostics
     * instead of silent, and the overlay setup step is the fix.
     */
    private fun showDelayActivity(pkg: String) {
        if (delayActivityPkg == pkg && DelayActivity.isShowing(pkg)) return
        val deadline = delayStartElapsed + store.entryDelaySeconds * 1000L
        val ok = DelayActivity.launch(this, pkg, store.entryDelaySeconds, deadline)
        if (ok) {
            delayActivityPkg = pkg
        } else {
            delayActivityPkg = null
            StartupGuard.runSafe {
                store.logTamper("DELAY_NO_POPUP $pkg (no overlay, activity start failed)")
            }
        }
    }

    /** Finish the fallback countdown screen, if it is showing. */
    private fun hideDelayActivity() {
        val pkg = delayActivityPkg ?: return
        delayActivityPkg = null
        DelayActivity.finishIfShowing(pkg)
    }

    /** Reset the wait and hide its overlay. */
    private fun resetDelay() {
        val pkg = delayPkg
        delayPkg = null
        delayStartElapsed = 0L
        hideDelayOverlay()
        if (pkg != null) {
            delayActivityPkg = null
            DelayActivity.finishIfShowing(pkg)
        } else {
            hideDelayActivity()
        }
    }

    private fun hideDelayOverlay() {
        val view = delayOverlayView ?: return
        delayOverlayView = null
        delayCountdownView = null
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeView(view)
        } catch (e: Exception) {
        }
    }

    // ================= HSC countdown + reminders (v6.1.0) =================
    //
    // From the guard poll (no extra wakeups): the 08:00 daily
    // reminder and the midnight "one day less" detection. The live
    // per-second countdown itself only ticks in the activities while
    // they are visible.

    private fun hscTick(now: Long) {
        // 08:00 daily reminder (once per day, days remaining).
        if (HscCountdown.shouldSendReminder(
                now, store.hscExamMs, store.hscReminderEnabled, store.hscReminderDay
            )
        ) {
            store.hscReminderDay = HscCountdown.dayKey(now)
            postHscReminderNotification(now)
        }
        // "One day less": the days-remaining number dropped since
        // the guard last saw it. Post the high-priority notification
        // now; the popup shows on next unlock (the activities check
        // the pending flag). The first observation only seeds the
        // count — no alert for it.
        if (store.hscDayLessEnabled) {
            val state = HscCountdown.state(now, store.hscExamMs)
            if (state is HscCountdown.State.Counting) {
                val days = state.parts.days
                if (HscCountdown.dayDropped(store.hscLastSeenDays, days)) {
                    store.hscLastSeenDays = days
                    store.hscDayLessDay = HscCountdown.dayKey(now)
                    store.hscDayLessPending = true
                    postHscDayLessNotification(days)
                } else if (store.hscLastSeenDays != days) {
                    store.hscLastSeenDays = days
                }
            }
        }
        // Friday prayer: the 09:00 alarm fallback + the Jumu'ah
        // countdown alerts (10:00 / 11:00 / 12:00 / 12:30 / 13:00).
        // The earlier hourly 10:00–19:00 plan was cancelled by
        // Fahim — only these five, then stop.
        fridayTick(now)
    }

    private fun postHscReminderNotification(now: Long) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val days = HscCountdown.daysRemaining(now, store.hscExamMs)
            val bn = Lang.isBengali(store.lang)
            val text = getString(
                R.string.hsc_reminder_text,
                if (bn) Limits.toBengaliDigits(days.toString()) else days.toString()
            )
            val open = Intent(this, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.hsc_reminder_title))
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(HSC_REMINDER_NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }

    private fun postHscDayLessNotification(daysLeft: Long) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val bn = Lang.isBengali(store.lang)
            val text = HscCountdown.dayLessMessage(daysLeft, bn)
            val open = Intent(this, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, HSC_CHANNEL_ID)
                .setContentTitle(getString(R.string.hsc_dayless_title))
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(HSC_DAYLESS_NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }

    // ================= Friday prayer (v6.1.0) =================
    //
    // From the guard poll: the 09:00 alarm fallback (the AlarmManager
    // path is primary) and the Jumu'ah countdown alerts. Friday only.

    private fun fridayTick(now: Long) {
        if (!store.fridayAlarmEnabled) return
        // 09:00 alarm fallback: if the exact alarm did not fire (no
        // permission, guard was stopped), the poll rings it. The
        // shared "last rung day" flag means the two paths can never
        // double-ring.
        if (FridayPrayer.shouldRingAlarm(now, true, store.fridayLastRungDay)) {
            store.fridayLastRungDay = FridayPrayer.dayKey(now)
            PrayerAlarmReceiver().showAlarm(this)
            PrayerAlarmScheduler.scheduleNext(this)
        }
        // Jumu'ah countdown alerts: 10:00, 11:00, 12:00, 12:30, 13:00.
        // Then STOP — no alerts after the prayer starts.
        val due = FridayPrayer.dueCountdownAlert(now, true, store.fridayLastAlertKey)
        if (due != null) {
            store.fridayLastAlertKey = "${FridayPrayer.dayKey(now)}|$due"
            postFridayCountdownNotification(due)
        }
    }

    private fun postFridayCountdownNotification(slotKey: String) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val textRes = when (slotKey) {
                "10:00" -> R.string.friday_countdown_3h
                "11:00" -> R.string.friday_countdown_2h
                "12:00" -> R.string.friday_countdown_1h
                "12:30" -> R.string.friday_countdown_30m
                else -> R.string.friday_countdown_now
            }
            val open = Intent(this, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, PRAYER_CHANNEL_ID)
                .setContentTitle(getString(R.string.friday_alarm_title))
                .setContentText(getString(textRes))
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(PRAYER_COUNTDOWN_NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }

    // ================= End HSC / Entry Delay =================

    private fun block(pkg: String, decision: BlockDecider.Decision) {
        // v6.1.0 Entry Delay: a blocked app never gets its delay —
        // reset any running wait and hide its overlay.
        resetDelay()
        // Throttle: one block action per package per 2 seconds.
        val now = SystemClock.elapsedRealtime()
        if (pkg == lastBlockedPkg && now - lastBlockedAt < 2000L) return
        lastBlockedPkg = pkg
        lastBlockedAt = now

        val label = Util.appLabel(this, pkg)
        store.logTamper("BLOCKED $label ($pkg) ${decision.kind}")

        showOverlay(label, decision)
        val i = Intent(this, BlockActivity::class.java).apply {
            putExtra(BlockActivity.EXTRA_PKG, pkg)
            putExtra(BlockActivity.EXTRA_KIND, decision.kind.name)
            putExtra(BlockActivity.EXTRA_GROUP, decision.groupId)
            putExtra(BlockActivity.EXTRA_BREAK_UNTIL, decision.breakUntilMs)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        startActivity(i)
        Util.goHome(this)
    }

    private fun showOverlay(label: String, decision: BlockDecider.Decision) {
        if (!Util.hasOverlay(this)) return
        hideOverlay()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_block, null)
        // v5.2.0: the overlay must actually cover a floating window, not
        // just sit on top of it — make it clickable so touches land on
        // the overlay instead of passing through to the app beneath.
        view.isClickable = true
        view.findViewById<TextView>(R.id.overlayReason).text =
            reasonText(decision) + " — " + label
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(view, params)
            overlayView = view
            handler.postDelayed({ hideOverlay() }, OVERLAY_HIDE_MS)
        } catch (e: Exception) {
            overlayView = null
        }
    }

    private fun hideOverlay() {
        val view = overlayView ?: return
        overlayView = null
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeView(view)
        } catch (e: Exception) {
        }
    }

    /**
     * v6.1.6 — store-safe: [showOverlay] is now also called from
     * boot mode ([blockBoot]), where the Store (credential-encrypted
     * prefs) is unreadable and `store` is not initialised. The
     * reason then falls back to the plain resource strings (system
     * locale) instead of the persisted language — losing the
     * language choice on one overlay is acceptable, crashing the
     * boot block is not.
     */
    private fun reasonText(d: BlockDecider.Decision): String {
        val bn = try {
            if (::store.isInitialized) Lang.isBengali(store.lang) else false
        } catch (e: Exception) {
            false
        }
        return when (d.kind) {
        BlockDecider.Kind.LIMIT -> getString(R.string.blocked_limit)
        BlockDecider.Kind.STRICT_BYPASS -> getString(R.string.blocked_bypass)
        BlockDecider.Kind.STRICT_GROUP -> getString(R.string.blocked_strict)
        BlockDecider.Kind.CUSTOM -> getString(R.string.blocked_custom)
        BlockDecider.Kind.NIGHT -> getString(R.string.blocked_night)
        // v6.1.0: a break block shows its live countdown, so the
        // reason is unmistakable on the overlay too.
        BlockDecider.Kind.BREAK -> getString(R.string.blocked_break) + " — " +
            getString(
                R.string.break_remaining,
                Limits.formatDuration(
                    BreakCycle.breakRemainingMs(d.breakUntilMs, System.currentTimeMillis()),
                    bn
                )
            )
        // v6.1.0 self-block: the app itself, during Strict Mode.
        BlockDecider.Kind.SELF_BLOCK -> getString(R.string.blocked_self)
        // v6.1.0 Study Lock: everything else is blocked while studying.
        BlockDecider.Kind.STUDY -> getString(R.string.blocked_study)
        }
    }

    /** Last MOVE_TO_FOREGROUND event in the last 3 seconds, as
     *  (package, activity class). Either half may be null when no
     *  event fired in the window — the caller resolves stickily. */
    private fun foregroundEvent(now: Long): Pair<String?, String?> {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(now - 3000L, now) ?: return Pair(null, null)
        var lastPkg: String? = null
        var lastCls: String? = null
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                lastPkg = e.packageName
                lastCls = e.className
            }
        }
        return Pair(lastPkg, lastCls)
    }

    /**
     * Most-recently-used package from UsageStats (last 2 minutes).
     * Second fallback when there is no fresh event and no sticky
     * package — this is what catches Settings when it was already
     * in the foreground before Strict was turned on.
     */
    private fun statsMostRecent(now: Long): String? {
        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, now - 120_000L, now
            ) ?: return null
            var bestPkg: String? = null
            var bestTime = 0L
            for (s in stats) {
                if (s.lastTimeUsed > bestTime) {
                    bestTime = s.lastTimeUsed
                    bestPkg = s.packageName
                }
            }
            bestPkg
        } catch (e: Exception) {
            null
        }
    }
}

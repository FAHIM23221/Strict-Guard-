package app.strictguard

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * All persisted state lives in SharedPreferences named "strictguard_store"
 * — the same name v3.7 used, so v3.7 settings can carry over.
 *
 * Strict Mode end is stored in SystemClock.elapsedRealtime() so changing
 * the wall clock cannot end Strict early. The wall-clock end is stored
 * only for display.
 */
class Store(context: Context) {

    private val appContext: Context = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    companion object {
        const val PREFS = "strictguard_store"
        // Device-protected mirror of the two boot decisions, readable
        // during direct boot before the user unlocks (v6.0.0).
        private const val BOOT_PREFS = "strictguard_boot"
        private const val K_BOOT_STRICT_END_WALL = "boot_strict_end_wall"
        private const val K_BOOT_SERVICE_WANTED = "boot_service_wanted"
        private const val K_STRICT_END_ELAPSED = "strict_end_elapsed"
        private const val K_STRICT_TEST = "strict_test"
        private const val K_STRICT_END_WALL = "strict_end_wall"
        private const val K_NIGHT_ENABLED = "night_enabled"
        private const val K_NIGHT_START = "night_start_min"
        private const val K_NIGHT_END = "night_end_min"
        private const val K_USAGE_DAY = "usage_day"
        private const val K_CUSTOM_BLOCK = "custom_block"
        private const val K_NIGHT_ALLOWED = "night_allowed"
        private const val K_TAMPER = "tamper_log"
        private const val K_LANG = "lang"
        private const val K_THEME = "theme"
        // v6.1.0 auto theme by time: toggle + last auto-applied theme.
        private const val K_AUTO_THEME = "auto_theme"
        private const val K_AUTO_THEME_APPLIED = "auto_theme_applied"
        // v6.1.0 clock format (24h default) + one-way setup buttons
        // (which setup steps were granted before).
        private const val K_CLOCK_24H = "clock_24h"
        private const val K_SETUP_GRANTED = "setup_granted"
        // v6.1.0 Hide Unused Apps: launcher shows only used apps.
        private const val K_SHOW_ONLY_USED = "show_only_used"
        // v6.1.0 Nightly Study Lock: time + persisted lock state.
        private const val K_STUDY_TIME_MIN = "study_time_min"
        private const val K_STUDY_ACTIVE = "study_active"
        private const val K_STUDY_DAY = "study_day"
        private const val K_STUDY_DONE_DAY = "study_done_day"
        private const val K_STUDY_ACCUM_MS = "study_accum_ms"
        private const val K_STUDY_ATT_DONE = "study_att_done"
        private const val K_STUDY_ATT_SINCE = "study_att_since"
        private const val K_STUDY_MISSING = "study_missing"
        private const val K_STUDY_LAST_STUDYING = "study_last_studying"
        private const val K_STUDY_ENABLED = "study_enabled"
        // v6.1.0 Entry Delay for social apps.
        private const val K_ENTRY_DELAY_ENABLED = "entry_delay_enabled"
        private const val K_ENTRY_DELAY_SECONDS = "entry_delay_seconds"
        // v6.1.0 Force-stop gap detection: last guard tick.
        private const val K_LAST_GUARD_TICK = "last_guard_tick"
        // v6.1.0 HSC 2027 countdown + reminders.
        private const val K_HSC_EXAM_MS = "hsc_exam_ms"
        private const val K_HSC_REMINDER_ENABLED = "hsc_reminder_enabled"
        private const val K_HSC_REMINDER_DAY = "hsc_reminder_day"
        private const val K_HSC_DAYLESS_ENABLED = "hsc_dayless_enabled"
        private const val K_HSC_LAST_SEEN_DAYS = "hsc_last_seen_days"
        private const val K_HSC_DAYLESS_DAY = "hsc_dayless_day"
        private const val K_HSC_DAYLESS_PENDING = "hsc_dayless_pending"
        private const val K_HSC_DAYLESS_POPUP_DAY = "hsc_dayless_popup_day"
        // v6.1.0 Friday prayer alarm + Jumu'ah countdown.
        private const val K_FRIDAY_ALARM_ENABLED = "friday_alarm_enabled"
        private const val K_FRIDAY_LAST_RUNG_DAY = "friday_last_rung_day"
        private const val K_FRIDAY_LAST_ALERT_KEY = "friday_last_alert_key"
        private const val K_SERVICE_WANTED = "service_wanted"
        private const val K_AUTOSTART_CONFIRMED = "autostart_confirmed"
        // v6.1.0 Break Cycle state (per group, per day).
        private const val K_BREAK_ENABLED = "break_enabled"
        private const val K_BREAK_DAY = "break_day"
        const val MAX_TAMPER = 200

        /** Read the device-protected boot mirror (usable before unlock).
         *  Returns (Strict wall-clock end, service wanted). Never throws. */
        fun bootMirrorState(context: Context): Pair<Long, Boolean> {
            return try {
                val p = context.applicationContext
                    .createDeviceProtectedStorageContext()
                    .getSharedPreferences(BOOT_PREFS, Context.MODE_PRIVATE)
                Pair(
                    p.getLong(K_BOOT_STRICT_END_WALL, 0L),
                    p.getBoolean(K_BOOT_SERVICE_WANTED, false)
                )
            } catch (e: Exception) {
                Pair(0L, false)
            }
        }
    }

    /**
     * Mirror the two boot decisions (Strict wall end + service wanted)
     * into device-protected storage, which is readable during direct
     * boot before the user unlocks. The normal prefs are
     * credential-encrypted and may be unreadable then. Called
     * whenever Strict starts/ends or service-wanted changes.
     */
    fun mirrorBootState() {
        try {
            appContext.createDeviceProtectedStorageContext()
                .getSharedPreferences(BOOT_PREFS, Context.MODE_PRIVATE)
                .edit()
                .putLong(K_BOOT_STRICT_END_WALL, strictEndWall())
                .putBoolean(K_BOOT_SERVICE_WANTED, serviceWanted)
                .apply()
        } catch (e: Exception) {
            // Device-protected storage is always available on API 24+;
            // if it ever fails, normal boot still works via BOOT_COMPLETED.
        }
    }

    // ---- v5.1.0 lock during Strict ----
    // Once Strict Mode is on, every setting already set is locked until
    // Strict ends (elapsedRealtime). The UI disables the controls too;
    // these setter guards are the second layer, so a setting cannot be
    // changed even if a settings screen is somehow opened during Strict.
    // Usage counting, tamper logging and the guard service itself are
    // NOT locked — only user settings.
    // v5.2.1: the rule lives in Limits (pure, unit-tested) — the
    // in-app Device Admin control is locked by this same rule.
    fun settingsLocked(): Boolean = !Limits.settingsChangeAllowed(isStrictActive())

    // ---- language & theme (persisted, one-tap toggles) ----
    // Language default is English; "বাংলা" is one tap away on the main
    // screen. Theme default is "system" (follow the device); the toggle
    // stores an explicit "light"/"dark" override.
    var lang: String
        get() = prefs.getString(K_LANG, "en") ?: "en"
        set(v) { if (!settingsLocked()) prefs.edit().putString(K_LANG, v).apply() }

    var theme: String // "system" | "light" | "dark"
        get() = prefs.getString(K_THEME, "system") ?: "system"
        set(v) { if (!settingsLocked()) prefs.edit().putString(K_THEME, v).apply() }

    // ---- auto theme by time (v6.1.0, "অটো থিম") ----
    // Default ON: Dark at 18:00, Light at 06:00, Asia/Dhaka.
    // The toggle itself is a user setting, so it is locked during
    // Strict like every other setting (setter guard above).
    var autoTheme: Boolean
        get() = prefs.getBoolean(K_AUTO_THEME, true)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_AUTO_THEME, v).apply() }

    // Last theme the AUTOMATIC switch applied ("light" / "dark" /
    // null before the first switch). System state, not a user
    // setting — written by the automatic switch itself, so it is
    // never blocked by the lock-during-Strict guard.
    var autoThemeApplied: String?
        get() = prefs.getString(K_AUTO_THEME_APPLIED, null)
        set(v) { prefs.edit().putString(K_AUTO_THEME_APPLIED, v).apply() }

    /**
     * Apply a theme change made by the AUTOMATIC time switch. This
     * deliberately bypasses the lock-during-Strict guard: the switch
     * is automatic, not a manual settings change, so it still applies
     * while Strict is on (Fahim's rule). Manual changes must keep
     * using [theme], which stays locked during Strict.
     */
    fun setThemeAuto(v: String) {
        prefs.edit().putString(K_THEME, v).apply()
    }

    // ---- clock format (v6.1.0) ----
    // 24-hour by default (the launcher clock showed 24-hour before);
    // 12-hour shows e.g. "5:05 PM". Locked during Strict like every
    // other setting (the setter guard above).
    var clock24h: Boolean
        get() = prefs.getBoolean(K_CLOCK_24H, true)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_CLOCK_24H, v).apply() }

    // ---- one-way setup buttons (v6.1.0) ----
    // The set of setup-step keys that were granted before, persisted
    // so the dead-button state survives restarts. A step is added
    // the first time its live check reports granted; it is removed
    // only when the live check later reports it un-granted, i.e. it
    // was revoked from outside the app — that is the one case where
    // the button re-enables, so the guard can be repaired.
    fun setupGrantedKeys(): Set<String> =
        prefs.getStringSet(K_SETUP_GRANTED, emptySet())?.toSet() ?: emptySet()

    fun markSetupGranted(key: String) {
        val s = setupGrantedKeys().toMutableSet()
        if (s.add(key)) prefs.edit().putStringSet(K_SETUP_GRANTED, s).apply()
    }

    fun unmarkSetupGranted(key: String) {
        val s = setupGrantedKeys().toMutableSet()
        if (s.remove(key)) prefs.edit().putStringSet(K_SETUP_GRANTED, s).apply()
    }

    // ---- Hide Unused Apps (v6.1.0) ----
    // Default OFF: the launcher shows every app. When ON, the grid
    // shows only apps used in the last 30 days (plus Strict Guard
    // itself); hiding is only a display filter, never a block.
    // Locked during Strict like every other setting.
    var showOnlyUsedApps: Boolean
        get() = prefs.getBoolean(K_SHOW_ONLY_USED, false)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_SHOW_ONLY_USED, v).apply() }

    // ---- Nightly Study Lock (v6.1.0; on/off toggle added v6.1.7) ----
    // The LINKED APP is still PERMANENT (StudyLock.STUDY_APP_PACKAGE)
    // — no UI changes it. The feature itself may now be turned off
    // entirely ([studyLockEnabled], default ON, matching every
    // release through v6.1.6 where it could not be disabled at all).
    // Both the toggle and the TIME are locked during Strict like
    // every other setting — so it cannot be switched off in the
    // middle of a Strict session to dodge tonight's lock. Turning
    // it off only prevents FUTURE triggers; a lock already running
    // finishes normally. Everything else here is lock state, written
    // by the guard itself, never by the user.
    var studyLockEnabled: Boolean
        get() = prefs.getBoolean(K_STUDY_ENABLED, true)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_STUDY_ENABLED, v).apply() }

    var studyTimeMin: Int // minutes since midnight, default 21:00
        get() = prefs.getInt(K_STUDY_TIME_MIN, StudyLock.DEFAULT_TIME_MIN)
        set(v) { if (!settingsLocked()) prefs.edit().putInt(K_STUDY_TIME_MIN, v).apply() }

    var studyActive: Boolean
        get() = prefs.getBoolean(K_STUDY_ACTIVE, false)
        set(v) { prefs.edit().putBoolean(K_STUDY_ACTIVE, v).apply() }

    /** Calendar day ("yyyy-MM-dd") the current lock was triggered. */
    var studyDay: String
        get() = prefs.getString(K_STUDY_DAY, "") ?: ""
        set(v) { prefs.edit().putString(K_STUDY_DAY, v).apply() }

    /** Calendar day a lock was completed (once per night). */
    var studyDoneDay: String
        get() = prefs.getString(K_STUDY_DONE_DAY, "") ?: ""
        set(v) { prefs.edit().putString(K_STUDY_DONE_DAY, v).apply() }

    /** Fair continuous minutes accumulated in this lock session. */
    var studyAccumMs: Long
        get() = prefs.getLong(K_STUDY_ACCUM_MS, 0L)
        set(v) { prefs.edit().putLong(K_STUDY_ACCUM_MS, v).apply() }

    /** The midway attention check was tapped. */
    var studyAttentionDone: Boolean
        get() = prefs.getBoolean(K_STUDY_ATT_DONE, false)
        set(v) { prefs.edit().putBoolean(K_STUDY_ATT_DONE, v).apply() }

    /** Wall-clock when the attention prompt appeared, 0 = not pending. */
    var studyAttentionSinceMs: Long
        get() = prefs.getLong(K_STUDY_ATT_SINCE, 0L)
        set(v) { prefs.edit().putLong(K_STUDY_ATT_SINCE, v).apply() }

    /** The study app was NOT installed when the lock triggered. */
    var studyMissing: Boolean
        get() = prefs.getBoolean(K_STUDY_MISSING, false)
        set(v) { prefs.edit().putBoolean(K_STUDY_MISSING, v).apply() }

    /** The last guard tick had the study app in the foreground with
     *  the screen on — decides whether minutes survive a reboot. */
    var studyLastStudying: Boolean
        get() = prefs.getBoolean(K_STUDY_LAST_STUDYING, false)
        set(v) { prefs.edit().putBoolean(K_STUDY_LAST_STUDYING, v).apply() }

    // ---- Entry Delay for social apps (v6.1.0) ----
    // Toggle default ON, duration 10/15/30 s (default 15). Both
    // locked during Strict like every other setting.
    var entryDelayEnabled: Boolean
        get() = prefs.getBoolean(K_ENTRY_DELAY_ENABLED, true)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_ENTRY_DELAY_ENABLED, v).apply() }

    var entryDelaySeconds: Int
        get() = EntryDelay.validDuration(prefs.getInt(K_ENTRY_DELAY_SECONDS, EntryDelay.DEFAULT_SECONDS))
        set(v) { if (!settingsLocked()) prefs.edit().putInt(K_ENTRY_DELAY_SECONDS, EntryDelay.validDuration(v)).apply() }

    /** Last guard poll (wall-clock ms), written by GuardService every tick — the force-stop gap signal. */
    var lastGuardTickMs: Long
        get() = prefs.getLong(K_LAST_GUARD_TICK, 0L)
        set(v) { prefs.edit().putLong(K_LAST_GUARD_TICK, v).apply() }

    // ---- HSC 2027 countdown + reminders (v6.1.0) ----
    // Exam date/time (default 6 June 2027 10:00 Dhaka), changeable
    // in settings, locked during Strict. Reminder + day-less alert
    // toggles default ON, locked during Strict too.
    var hscExamMs: Long
        get() = prefs.getLong(K_HSC_EXAM_MS, HscCountdown.DEFAULT_EXAM_MS)
        set(v) { if (!settingsLocked()) prefs.edit().putLong(K_HSC_EXAM_MS, v).apply() }

    var hscReminderEnabled: Boolean
        get() = prefs.getBoolean(K_HSC_REMINDER_ENABLED, true)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_HSC_REMINDER_ENABLED, v).apply() }

    /** Calendar day ("yyyy-MM-dd") the 08:00 reminder was last sent. */
    var hscReminderDay: String
        get() = prefs.getString(K_HSC_REMINDER_DAY, "") ?: ""
        set(v) { prefs.edit().putString(K_HSC_REMINDER_DAY, v).apply() }

    var hscDayLessEnabled: Boolean
        get() = prefs.getBoolean(K_HSC_DAYLESS_ENABLED, true)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_HSC_DAYLESS_ENABLED, v).apply() }

    /** Days remaining as last observed by the guard (-1 = never). */
    var hscLastSeenDays: Long
        get() = prefs.getLong(K_HSC_LAST_SEEN_DAYS, -1L)
        set(v) { prefs.edit().putLong(K_HSC_LAST_SEEN_DAYS, v).apply() }

    /** Calendar day of the last "one day less" event. */
    var hscDayLessDay: String
        get() = prefs.getString(K_HSC_DAYLESS_DAY, "") ?: ""
        set(v) { prefs.edit().putString(K_HSC_DAYLESS_DAY, v).apply() }

    /** A day-less popup is waiting to be shown on next unlock. */
    var hscDayLessPending: Boolean
        get() = prefs.getBoolean(K_HSC_DAYLESS_PENDING, false)
        set(v) { prefs.edit().putBoolean(K_HSC_DAYLESS_PENDING, v).apply() }

    /** Calendar day the day-less popup was last shown. */
    var hscDayLessPopupDay: String
        get() = prefs.getString(K_HSC_DAYLESS_POPUP_DAY, "") ?: ""
        set(v) { prefs.edit().putString(K_HSC_DAYLESS_POPUP_DAY, v).apply() }

    // ---- Friday prayer alarm + Jumu'ah countdown (v6.1.0) ----
    // Toggle default ON, locked during Strict. The last-rung day and
    // last-alert key are shared by the AlarmManager path and the
    // guard-poll fallback, so nothing rings twice.
    var fridayAlarmEnabled: Boolean
        get() = prefs.getBoolean(K_FRIDAY_ALARM_ENABLED, true)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_FRIDAY_ALARM_ENABLED, v).apply() }

    /** Calendar day ("yyyy-MM-dd") the 09:00 Friday alarm last rang. */
    var fridayLastRungDay: String
        get() = prefs.getString(K_FRIDAY_LAST_RUNG_DAY, "") ?: ""
        set(v) { prefs.edit().putString(K_FRIDAY_LAST_RUNG_DAY, v).apply() }

    /** "yyyy-MM-dd|HH:mm" of the last Jumu'ah countdown alert sent. */
    var fridayLastAlertKey: String
        get() = prefs.getString(K_FRIDAY_LAST_ALERT_KEY, "") ?: ""
        set(v) { prefs.edit().putString(K_FRIDAY_LAST_ALERT_KEY, v).apply() }

    // ---- Strict Mode ----
    // v5.2.0: the end is stored as WALL-CLOCK epoch millis
    // (K_STRICT_END_WALL) so a schedule survives a reboot, AND as an
    // elapsedRealtime end derived from it, which governs while the
    // phone is running so changing the wall clock cannot end Strict
    // early. The schedule itself can never be shortened or changed
    // while Strict is on: StrictSetupActivity only opens when Strict
    // is off, and every setting setter below refuses writes while
    // settingsLocked() is true.
    fun startStrict(testMode: Boolean, msUntilMidnight: Long) {
        val duration = if (testMode) 60_000L else msUntilMidnight
        startStrictUntil(System.currentTimeMillis() + duration, testMode)
    }

    /** Start Strict until a chosen wall-clock time (must be in the future). */
    fun startStrictUntil(wallEndMs: Long, testMode: Boolean) {
        val nowWall = System.currentTimeMillis()
        val duration = if (testMode) 60_000L else (wallEndMs - nowWall).coerceAtLeast(0L)
        val wallEnd = if (testMode) nowWall + 60_000L else wallEndMs
        prefs.edit()
            .putLong(K_STRICT_END_ELAPSED, SystemClock.elapsedRealtime() + duration)
            .putBoolean(K_STRICT_TEST, testMode)
            .putLong(K_STRICT_END_WALL, wallEnd)
            .apply()
        // v6.0.0: mirror for direct boot, so the guard can start
        // before the user unlocks even after a reboot.
        mirrorBootState()
        // v6.1.0: mirror the Strict state outside the app's private
        // data (MediaStore Downloads) so Clear Data during Strict
        // cannot reset it. Best-effort — never throws.
        MirrorStore.writeStrictMirror(appContext, this)
    }

    /**
     * v6.1.0 — called on every guard tick: if Strict's schedule has
     * expired (the elapsed end has passed while the phone is
     * running), clear the state and DELETE the mirror, so clearing
     * data afterwards is a clean slate. Also handles the
     * post-reboot case where recoverStrictAfterBoot already cleared
     * the elapsed end but the wall end is still in the past.
     * The elapsed end governs while running, so changing the wall
     * clock alone cannot end Strict early: the wall-based branch
     * only fires when the elapsed end is already 0 (i.e. after a
     * reboot recovery). Returns true if Strict ended here.
     */
    fun checkStrictEnded(): Boolean {
        val elapsedEnd = strictEndElapsed()
        val wallEnd = strictEndWall()
        val nowElapsed = SystemClock.elapsedRealtime()
        val nowWall = System.currentTimeMillis()
        val expired = (elapsedEnd > 0L && nowElapsed >= elapsedEnd) ||
            (elapsedEnd == 0L && wallEnd > 0L && nowWall >= wallEnd)
        if (!expired) return false
        prefs.edit()
            .putLong(K_STRICT_END_ELAPSED, 0L)
            .putLong(K_STRICT_END_WALL, 0L)
            .putBoolean(K_STRICT_TEST, false)
            .apply()
        mirrorBootState()
        MirrorStore.deleteMirror(appContext)
        logTamper("STRICT_ENDED")
        return true
    }

    /**
     * After a reboot elapsedRealtime restarts from ~0, so the stored
     * elapsed end is stale. Recompute it from the wall-clock end; if
     * the wall end has already passed, clear Strict so it ends cleanly.
     * Called from BootReceiver, GuardService.onCreate and MainActivity.
     * Idempotent: only rewrites when the stored value is stale.
     */
    fun recoverStrictAfterBoot() {
        val wallEnd = strictEndWall()
        if (wallEnd <= 0L) return
        val nowWall = System.currentTimeMillis()
        val nowElapsed = SystemClock.elapsedRealtime()
        val expected = Limits.recoveredElapsedEnd(nowElapsed, nowWall, wallEnd)
        val stored = strictEndElapsed()
        if (expected == 0L) {
            if (stored != 0L) {
                prefs.edit().putLong(K_STRICT_END_ELAPSED, 0L).apply()
            }
            return
        }
        if (stored == 0L || kotlin.math.abs(stored - expected) > 60_000L) {
            prefs.edit().putLong(K_STRICT_END_ELAPSED, expected).apply()
            logTamper("STRICT_RECOVERED after-boot")
        }
    }

    /** Test mode is the only way Strict can end early. */
    fun endTestMode() {
        if (isTestMode()) {
            prefs.edit()
                .putLong(K_STRICT_END_ELAPSED, 0L)
                .putBoolean(K_STRICT_TEST, false)
                .apply()
            mirrorBootState()
            // v6.1.0: test end is a normal end — delete the mirror.
            MirrorStore.deleteMirror(appContext)
        }
    }

    fun isStrictActive(): Boolean =
        Limits.strictActive(SystemClock.elapsedRealtime(), strictEndElapsed())

    fun strictEndElapsed(): Long = prefs.getLong(K_STRICT_END_ELAPSED, 0L)
    fun isTestMode(): Boolean = prefs.getBoolean(K_STRICT_TEST, false)
    fun strictEndWall(): Long = prefs.getLong(K_STRICT_END_WALL, 0L)

    // ---- Night Lock ----
    var nightEnabled: Boolean
        get() = prefs.getBoolean(K_NIGHT_ENABLED, false)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_NIGHT_ENABLED, v).apply() }

    var nightStartMin: Int
        get() = prefs.getInt(K_NIGHT_START, Limits.NIGHT_DEFAULT_START_MIN)
        set(v) { if (!settingsLocked()) prefs.edit().putInt(K_NIGHT_START, v).apply() }

    var nightEndMin: Int
        get() = prefs.getInt(K_NIGHT_END, Limits.NIGHT_DEFAULT_END_MIN)
        set(v) { if (!settingsLocked()) prefs.edit().putInt(K_NIGHT_END, v).apply() }

    // ---- Daily usage ----
    fun todayKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun usageKey(groupId: String) = "usage_$groupId"

    fun usageFor(groupId: String): Long {
        if (prefs.getString(K_USAGE_DAY, "") != todayKey()) return 0L
        return prefs.getLong(usageKey(groupId), 0L)
    }

    fun usageSnapshot(): Map<String, Long> {
        val day = todayKey()
        if (prefs.getString(K_USAGE_DAY, "") != day) return emptyMap()
        return Limits.GROUPS.associate { it.id to prefs.getLong(usageKey(it.id), 0L) }
    }

    // ---- v6.1.7 Daily limit raise (max 2 hours per group) ----
    // 0 stored means "no override — use the group's own default".
    // Facebook has no override UI (its default already IS the cap).
    private fun limitOverrideKey(groupId: String) = "limit_override_min_$groupId"

    fun limitOverrideMinFor(groupId: String): Int = prefs.getInt(limitOverrideKey(groupId), 0)

    /**
     * Raises (or clears) a group's limit. [minutes] <= the group's
     * own default clears the override back to that default; anything
     * above is clamped to [Limits.MAX_LIMIT_MINUTES] before being
     * stored. Locked during Strict like every other setting, so the
     * cap cannot be raised mid-session to dodge tonight's block.
     */
    fun setLimitOverrideMinFor(groupId: String, minutes: Int) {
        if (settingsLocked()) return
        val group = Limits.GROUPS.firstOrNull { it.id == groupId } ?: return
        val clamped = Limits.effectiveLimitMinutes(group.limitMinutes, minutes)
        val toStore = if (clamped <= group.limitMinutes) 0 else clamped
        prefs.edit().putInt(limitOverrideKey(groupId), toStore).apply()
    }

    /** The limit actually enforced for [group] today: its default, raised if overridden. */
    fun effectiveLimitMs(group: Limits.Group): Long =
        Limits.effectiveLimitMinutes(group.limitMinutes, limitOverrideMinFor(group.id)) *
            60L * 1000L

    fun addUsage(groupId: String, ms: Long) {
        val day = todayKey()
        val e = prefs.edit()
        if (prefs.getString(K_USAGE_DAY, "") != day) {
            e.putString(K_USAGE_DAY, day)
            for (g in Limits.GROUPS) e.putLong(usageKey(g.id), 0L)
        }
        val cur = if (prefs.getString(K_USAGE_DAY, "") == day) {
            prefs.getLong(usageKey(groupId), 0L)
        } else 0L
        e.putLong(usageKey(groupId), cur + ms)
        e.apply()
    }

    // ---- v6.1.8 Screen time history (last 7 days, launcher chart) ----
    // Separate from the 4-group daily usage above: this is TOTAL
    // foreground time across every app except StrictGuard itself —
    // "screen time" in the ordinary sense, not just the limited
    // groups. addUsage() above resets to 0 at midnight with nothing
    // kept; this keeps the last 14 days (self-pruning) so a 7-day
    // chart always has a real history to read, not just "today".
    private fun screenTimeKey(date: String) = "screentime_ms_$date"
    private const val K_SCREEN_TIME_DATES = "screentime_dates" // CSV, oldest first
    private const val SCREEN_TIME_KEEP_DAYS = 14

    fun screenTimeMsFor(date: String): Long = prefs.getLong(screenTimeKey(date), 0L)

    /** Adds [ms] to TODAY's running total; prunes anything past [SCREEN_TIME_KEEP_DAYS]. */
    fun addScreenTime(ms: Long) {
        val day = todayKey()
        val datesCsv = prefs.getString(K_SCREEN_TIME_DATES, "") ?: ""
        val dates = if (datesCsv.isEmpty()) mutableListOf() else datesCsv.split(",").toMutableList()
        val e = prefs.edit()
        if (day !in dates) {
            dates.add(day)
            while (dates.size > SCREEN_TIME_KEEP_DAYS) {
                e.remove(screenTimeKey(dates.removeAt(0)))
            }
            e.putString(K_SCREEN_TIME_DATES, dates.joinToString(","))
        }
        e.putLong(screenTimeKey(day), screenTimeMsFor(day) + ms)
        e.apply()
    }

    /**
     * The last 7 CALENDAR days (today + 6 before, oldest first) as
     * (date, milliseconds) pairs. A day with no record (app not
     * used that day, or not yet 14 days old) reads as 0 ms — never
     * null, so the chart never has to guess at a missing day.
     */
    fun last7DaysScreenTimeMs(): List<Pair<String, Long>> {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val base = Calendar.getInstance()
        return (6 downTo 0).map { daysAgo ->
            val c = base.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -daysAgo)
            val key = fmt.format(c.time)
            key to screenTimeMsFor(key)
        }
    }

    // ---- v6.1.0 Break Cycle ----
    // Daily limits are fixed and NOT changeable; the break cycle is a
    // toggle on top of them (default ON, locked during Strict like
    // every other setting). Session usage and the break end are
    // persisted per group per day, so closing/reopening the app does
    // NOT reset a session, and a break survives a reboot (breakUntil
    // is a wall-clock epoch). Break time never counts toward the
    // daily limit. On a new day all break state resets.
    var breakCycleEnabled: Boolean
        get() = prefs.getBoolean(K_BREAK_ENABLED, true)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_BREAK_ENABLED, v).apply() }

    private fun breakSessionKey(groupId: String) = "break_session_$groupId"
    private fun breakUntilKey(groupId: String) = "break_until_$groupId"

    /** Reset all break state when the day rolls over. */
    private fun ensureBreakDay(e: android.content.SharedPreferences.Editor? = null) {
        val day = todayKey()
        if (prefs.getString(K_BREAK_DAY, "") == day) return
        val ed = e ?: prefs.edit()
        ed.putString(K_BREAK_DAY, day)
        for (g in Limits.GROUPS) {
            ed.putLong(breakSessionKey(g.id), 0L)
            ed.putLong(breakUntilKey(g.id), 0L)
        }
        if (e == null) ed.apply()
    }

    /** Session usage so far today for this group (0 on a new day). */
    fun sessionUsedFor(groupId: String): Long {
        if (prefs.getString(K_BREAK_DAY, "") != todayKey()) return 0L
        return prefs.getLong(breakSessionKey(groupId), 0L)
    }

    /** Wall-clock end of the current forced break, 0 when not in a break. */
    fun breakUntilFor(groupId: String): Long {
        if (prefs.getString(K_BREAK_DAY, "") != todayKey()) return 0L
        return prefs.getLong(breakUntilKey(groupId), 0L)
    }

    /** Break end for every group (0 = not in a break). Used by BlockDecider. */
    fun breakUntilMap(): Map<String, Long> =
        Limits.GROUPS.associate { it.id to breakUntilFor(it.id) }

    fun addSessionUsage(groupId: String, ms: Long) {
        val e = prefs.edit()
        ensureBreakDay(e)
        e.putLong(breakSessionKey(groupId), sessionUsedFor(groupId) + ms)
        e.apply()
    }

    /** Start a forced break: session resets, break ends at [untilWallMs]. */
    fun startBreak(groupId: String, untilWallMs: Long) {
        val e = prefs.edit()
        ensureBreakDay(e)
        e.putLong(breakSessionKey(groupId), 0L)
        e.putLong(breakUntilKey(groupId), untilWallMs)
        e.apply()
    }

    // ---- Block lists ----
    var customBlock: Set<String>
        get() = prefs.getStringSet(K_CUSTOM_BLOCK, emptySet()) ?: emptySet()
        set(v) { if (!settingsLocked()) prefs.edit().putStringSet(K_CUSTOM_BLOCK, HashSet(v)).apply() }

    /**
     * v6.1.3 Night Lock default (Fahim, voice 2026-11-09): the six
     * always-unlocked apps (Brilliant, bKash, Nagad, Claude,
     * WhatsApp, Messenger) are PRE-SET in the allowed-apps list.
     * Until Fahim saves a list in the Night Lock picker, the
     * getter returns [AlwaysAllowed.PACKAGES] — so during Night
     * Lock those six are already there in the launcher, no
     * separate adding needed. Once he saves a list, that saved
     * list is used exactly as saved (he may add more apps, or
     * remove some of the six). The "never saved" case is detected
     * with prefs.contains, not with an empty set: an explicitly
     * saved empty list is his choice and stays empty.
     */
    var nightAllowed: Set<String>
        get() = AlwaysAllowed.defaultNightAllowed(
            prefs.contains(K_NIGHT_ALLOWED),
            prefs.getStringSet(K_NIGHT_ALLOWED, emptySet())
        )
        set(v) { if (!settingsLocked()) prefs.edit().putStringSet(K_NIGHT_ALLOWED, HashSet(v)).apply() }

    // ---- Tamper log ----
    fun logTamper(event: String) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val line = "$stamp  $event"
        val old = prefs.getString(K_TAMPER, "") ?: ""
        val lines = (old.split("\n").filter { it.isNotBlank() } + line)
            .takeLast(MAX_TAMPER)
        prefs.edit().putString(K_TAMPER, lines.joinToString("\n")).apply()
    }

    fun tamperLog(): String = prefs.getString(K_TAMPER, "") ?: ""

    fun clearTamper() { if (!settingsLocked()) prefs.edit().putString(K_TAMPER, "").apply() }

    var serviceWanted: Boolean
        get() = prefs.getBoolean(K_SERVICE_WANTED, false)
        set(v) {
            prefs.edit().putBoolean(K_SERVICE_WANTED, v).apply()
            mirrorBootState()
        }

    /** XOS Autostart cannot be read back from the system, so this step is a
     *  manual confirmation: set when the user opens the app settings from
     *  the setup row and confirms it there. */
    var autostartConfirmed: Boolean
        get() = prefs.getBoolean(K_AUTOSTART_CONFIRMED, false)
        set(v) { if (!settingsLocked()) prefs.edit().putBoolean(K_AUTOSTART_CONFIRMED, v).apply() }
}

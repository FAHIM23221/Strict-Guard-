package app.strictguard

import android.app.AlertDialog
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Custom home launcher (v6.0.0). Design (Fahim's design freedom):
 * NOT a copy of the v3.7 screenshot — a cleaner layout of our own:
 * the greeting sits directly on the calm background (no card), the
 * Strict Mode card is the one warm-brown anchor with cream usage
 * rows inside it (Warm Sand, Design 3, v6.1.0), then the scrollable
 * app grid with Strict Guard pinned first.
 *
 * This activity is declared as a HOME activity in the manifest, so it
 * can be set as the default home launcher (setup step 4, RoleManager).
 * Pressing Home therefore returns here, not to the system launcher.
 *
 * Tapping an app goes through [LauncherLogic.tapDecision] — the same
 * blocking rules as the guard service. A blocked tap opens the block
 * screen instead of the app; a blocked app is shown dimmed with a
 * lock mark. Strict Guard itself opens the settings dashboard
 * ([MainActivity]) — except during Strict Mode, when the app itself
 * is self-blocked (v6.1.0) and the tile shows the block screen.
 *
 * v6.1.0 Hide Unused Apps: when the "Show only used apps" toggle is
 * ON, the grid shows only apps used in the last 30 days (UsageStats;
 * new apps get a 7-day grace period), plus Strict Guard pinned first.
 * Hiding is only a display filter — a "Hidden apps (n)" row at the
 * bottom opens the full list, and turning the toggle OFF restores
 * the full grid immediately. Usage is re-checked on every resume.
 *
 * No Accessibility, no internet. Calm muted palette, like the rest
 * of the app. Language and theme toggles are the same persisted
 * one-tap switches as on the dashboard, and are locked during Strict.
 */
class LauncherActivity : BaseActivity() {

    private lateinit var usageContainer: LinearLayout
    private lateinit var gridContainer: LinearLayout
    private lateinit var screenTimeBars: LinearLayout // v6.1.8
    private val handler = Handler(Looper.getMainLooper())
    private val iconCache = HashMap<String, Drawable?>()
    private val refreshRunnable = object : Runnable {
        override fun run() {
            if (!isFinishing) {
                refresh()
                handler.postDelayed(this, 30_000L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // v6.1.6 — THE SHADE FIX, first half: start the guard
        // BEFORE anything else, even before the layout inflates.
        // After a reboot the home screen is what the user sees
        // first, and the shade is usable from it while the grid
        // is still loading — if the boot service never started
        // (e.g. the app was force-stopped, which suppresses all
        // boot broadcasts until a manual launch), this is the
        // earliest moment enforcement can resume. Best-effort and
        // idempotent: if the service is already running, the gate
        // below is false and nothing happens.
        if (StartupGuard.shouldRestartGuard(GuardService.isRunning, Util.hasUsageAccess(this))) {
            StartupGuard.startGuardService(this)
        }
        setContentView(R.layout.activity_launcher)

        usageContainer = findViewById(R.id.launcherUsageContainer)
        gridContainer = findViewById(R.id.launcherGridContainer)
        screenTimeBars = findViewById(R.id.screenTimeBars) // v6.1.8

        findViewById<Button>(R.id.btnLauncherSettings).setOnClickListener {
            // v6.1.0 self-block: during Strict Mode this button must
            // not open the settings either — it is another path into
            // the app, so it shows the block screen like the tile tap.
            if (store.isStrictActive()) {
                store.logTamper("SELF_BLOCK Strict Guard settings blocked during Strict")
                val i = Intent(this, BlockActivity::class.java).apply {
                    putExtra(BlockActivity.EXTRA_PKG, packageName)
                    putExtra(BlockActivity.EXTRA_KIND, BlockDecider.Kind.SELF_BLOCK.name)
                }
                startActivity(i)
                return@setOnClickListener
            }
            startActivity(Intent(this, MainActivity::class.java))
        }
        findViewById<Button>(R.id.btnLauncherLang).setOnClickListener {
            if (store.settingsLocked()) {
                Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            store.lang = if (store.lang == "bn") "en" else "bn"
            Lang.applyLocaleInPlace(this, store.lang)
            refresh()
        }
        findViewById<Button>(R.id.btnLauncherTheme).setOnClickListener {
            if (store.settingsLocked()) {
                Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            store.theme = if (effectiveTheme() == "dark") "light" else "dark"
            recreate()
        }
    }

    override fun onResume() {
        super.onResume()
        // v6.1.1: same first-launch rule as MainActivity — every
        // step guarded, so one failing subsystem cannot kill the
        // launcher's first open.
        // v6.1.6 — THE SHADE FIX, second half: the guard restart
        // is FIRST now. It used to run AFTER the mirror restore
        // (MediaStore query + Keystore load + HMAC + AES-GCM,
        // ~0.5–3 s cold, on the main thread) — so when the boot
        // service had never started, enforcement resumed only
        // after that slow work, while the shade was already usable
        // and Settings was one gear-tap away. The mirror restore
        // runs on a background thread below; it only matters when
        // the Store lost Strict (Clear Data), never for blocking.
        if (isStoreReady() &&
            StartupGuard.shouldRestartGuard(GuardService.isRunning, Util.hasUsageAccess(this))
        ) {
            if (StartupGuard.startGuardService(this)) {
                StartupGuard.runSafe { store.logTamper("GUARD_RESTARTED from LauncherActivity") }
            }
        }
        StartupGuard.runSafe { store.recoverStrictAfterBoot() }
        // v6.1.0 Clear Data defence: restore Strict from the mirror
        // if the Store lost it (Clear Data was tapped during Strict).
        // v6.1.6 — off the main thread (see above): this must never
        // delay the guard restart or the first grid draw.
        Thread {
            StartupGuard.runSafe { MirrorStore.checkAndRestore(this, store) }
        }.start()
        StartupGuard.runSafe { refresh() }
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 30_000L)
        // v6.1.0 HSC live countdown (only while visible). On the
        // launcher the countdown shows ONLY the numbers — no label —
        // and in MONTHS: full calendar months + remaining days
        // ("৬ মাস ২৯ দিন"), updating at midnight, no h/m/s ticking.
        StartupGuard.runSafe {
            startHscTicker(findViewById(R.id.hscCountdownText), null, monthsOnly = true)
        }
        // v6.1.0 daily "one day less" popup, shown on next unlock.
        StartupGuard.runSafe { maybeShowDayLessAlert() }
    }

    override fun onPause() {
        stopHscTicker()
        super.onPause()
        handler.removeCallbacks(refreshRunnable)
    }

    /** The launcher is home: Back must not exit it. */
    override fun onBackPressed() {
        // No-op on purpose — pressing Back on a home screen does nothing.
    }

    private fun refresh() {
        val bn = Lang.isBengali(store.lang)
        val locale = Lang.localeFor(store.lang)
        val now = Calendar.getInstance()

        // ---- Greeting card ----
        val greetingRes = when (LauncherLogic.greetingFor(now.get(Calendar.HOUR_OF_DAY))) {
            LauncherLogic.Greeting.MORNING -> R.string.launcher_greeting_morning
            LauncherLogic.Greeting.NOON -> R.string.launcher_greeting_noon
            LauncherLogic.Greeting.AFTERNOON -> R.string.launcher_greeting_afternoon
            LauncherLogic.Greeting.EVENING -> R.string.launcher_greeting_evening
            LauncherLogic.Greeting.NIGHT -> R.string.launcher_greeting_night
        }
        findViewById<TextView>(R.id.launcherGreeting).setText(greetingRes)
        findViewById<TextView>(R.id.launcherClock).text =
            ClockFormat.format(
                now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE),
                store.clock24h, bn
            )
        findViewById<TextView>(R.id.launcherDate).text =
            SimpleDateFormat("EEEE, d MMMM yyyy", locale).format(Date())

        // ---- Strict card ----
        val strict = store.isStrictActive()
        findViewById<TextView>(R.id.launcherStrictTitle).text =
            if (strict) getString(R.string.status_strict_on)
            else getString(R.string.status_strict_off)
        findViewById<TextView>(R.id.launcherStrictRemaining).text =
            if (strict) {
                val remaining = store.strictEndElapsed() - android.os.SystemClock.elapsedRealtime()
                getString(
                    R.string.launcher_remaining,
                    Limits.formatDuration(remaining.coerceAtLeast(0L), bn)
                )
            } else {
                getString(R.string.status_limits_active)
            }

        // ---- Usage bars (real stored limits + usage) ----
        usageContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        for (group in Limits.GROUPS) {
            val used = store.usageFor(group.id)
            val pct = Limits.percent(used, store.effectiveLimitMs(group)) // v6.1.7
            // Cream rows on the warm-brown Strict card (Warm Sand, Design 3).
            val row = inflater.inflate(R.layout.item_usage_light, usageContainer, false)
            val nameRes = when (group.id) {
                "facebook" -> R.string.limit_facebook
                "chrome" -> R.string.limit_chrome
                "youtube" -> R.string.limit_youtube
                else -> R.string.limit_ai
            }
            row.findViewById<TextView>(R.id.usageName).setText(nameRes)
            // v6.1.0 Claude exemption: the AI row shows Claude is unlimited.
            val claudeSuffix = if (group.id == "ai") {
                " · " + getString(R.string.claude_unlimited_short)
            } else ""
            row.findViewById<TextView>(R.id.usageValue).text =
                LauncherLogic.usageText(used, store.effectiveLimitMs(group), bn) + claudeSuffix // v6.1.7
            val fill = row.findViewById<View>(R.id.usageFill)
            fill.post {
                val parent = fill.parent as View
                val w = (parent.width * pct / 100).coerceAtLeast(0)
                fill.layoutParams.width = w
                fill.requestLayout()
            }
            usageContainer.addView(row)
        }

        // ---- v6.1.8 Screen time (last 7 days) ----
        val history = store.last7DaysScreenTimeMs() // oldest first, today last
        val minutesPerDay = history.map { (it.second / 60_000L).toInt() }
        val maxMinutes = minutesPerDay.maxOrNull() ?: 0
        screenTimeBars.removeAllViews()
        val maxBarHeightPx = (90 * resources.displayMetrics.density).toInt() // matches screenTimeBars height
        val minBarHeightPx = (4 * resources.displayMetrics.density).toInt() // matches barFill's own height
        for ((index, entry) in history.withIndex()) {
            val (dateKey, _) = entry
            val minutes = minutesPerDay[index]
            val bar = inflater.inflate(R.layout.item_screen_time_bar, screenTimeBars, false)
            bar.findViewById<TextView>(R.id.barValue).text =
                if (minutes >= 60) "${minutes / 60}:${"%02d".format(minutes % 60)}" else "$minutes"
            val dow = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateKey)?.let {
                Calendar.getInstance().apply { time = it }.get(Calendar.DAY_OF_WEEK)
            } ?: Calendar.SUNDAY
            bar.findViewById<TextView>(R.id.barLabel).text = ScreenTimeChart.dayLabel(dow, bn)
            val fill = bar.findViewById<View>(R.id.barFill)
            fill.layoutParams.height = ScreenTimeChart.barHeightPx(
                minutes, maxMinutes, maxBarHeightPx, minBarHeightPx
            )
            screenTimeBars.addView(bar)
        }
        val avgMs = if (history.isEmpty()) 0L else history.sumOf { it.second } / history.size
        findViewById<TextView>(R.id.screenTimeAverage).text =
            getString(R.string.screen_time_average, Limits.formatDuration(avgMs, bn))

        // ---- Language / theme toggles (locked during Strict) ----
        val locked = store.settingsLocked()
        findViewById<Button>(R.id.btnLauncherLang).text = getString(R.string.lang_toggle)
        findViewById<Button>(R.id.btnLauncherTheme).text =
            if (effectiveTheme() == "dark") getString(R.string.theme_light)
            else getString(R.string.theme_dark)
        findViewById<Button>(R.id.btnLauncherLang).isEnabled = !locked
        findViewById<Button>(R.id.btnLauncherTheme).isEnabled = !locked
        findViewById<Button>(R.id.btnLauncherLang).alpha = if (locked) 0.5f else 1f
        findViewById<Button>(R.id.btnLauncherTheme).alpha = if (locked) 0.5f else 1f

        // Hint when Strict Guard is not yet the default home launcher.
        findViewById<TextView>(R.id.launcherHomeHint).visibility =
            if (Util.isDefaultLauncher(this)) View.GONE else View.VISIBLE

        // ---- App grid ----
        buildGrid()
    }

    private fun buildGrid() {
        val strict = store.isStrictActive()
        val night = store.nightEnabled && Limits.nightActive(
            Calendar.getInstance(), store.nightStartMin, store.nightEndMin
        )
        val limitReached = Limits.GROUPS
            .filter { store.usageFor(it.id) >= store.effectiveLimitMs(it) } // v6.1.7
            .map { it.id }.toSet()
        val launcherPkgs = Util.launcherPackages(this)
        val pm = packageManager

        val apps = ArrayList<LauncherLogic.AppEntry>()
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        for (ri in pm.queryIntentActivities(launchIntent, 0)) {
            val pkg = ri.activityInfo.packageName
            val label = ri.loadLabel(pm).toString()
            apps.add(LauncherLogic.AppEntry(pkg, label))
        }
        // Strict Guard itself is the pinned first cell.
        if (apps.none { it.pkg == packageName }) {
            apps.add(LauncherLogic.AppEntry(packageName, getString(R.string.app_name)))
        }
        val sorted = LauncherLogic.sortApps(apps, packageName)

        // v6.1.4 — Phone Master is invisible while Strict is on: it
        // must not appear in the grid at all (not even dimmed, not
        // even with a lock badge), and not in the hidden-apps dialog
        // either. Filter FIRST, before the unused-apps filter, so it
        // can never leak into the "hidden apps" row either. When
        // Strict ends it returns to the grid normally.
        val visible = LauncherLogic.visibleApps(sorted, strict)

        // v6.1.0 Hide Unused Apps: when the toggle is ON, the grid
        // shows only apps used in the last 30 days (new apps get a
        // 7-day grace period), plus Strict Guard pinned first. The
        // usage is re-checked on every resume (buildGrid runs from
        // refresh()), so the list is always current. Hiding is only
        // a display filter — hidden apps are not blocked. If Usage
        // Access is off, usage cannot be read, so fail open and show
        // everything rather than hiding the whole grid on a guess.
        val nowWall = System.currentTimeMillis()
        val filterOn = store.showOnlyUsedApps && Util.hasUsageAccess(this)
        val (shownApps, hiddenApps) = if (filterOn) {
            UsedApps.filterApps(
                visible, queryLastUsed(nowWall), queryInstalled(visible),
                nowWall, packageName, true
            )
        } else {
            Pair(visible, emptyList())
        }

        gridContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        var row: LinearLayout? = null
        for ((index, entry) in shownApps.withIndex()) {
            if (index % 4 == 0) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }
                gridContainer.addView(row)
            }
            val decision = LauncherLogic.tapDecision(
                entry.pkg, strict, night, store.nightAllowed, store.customBlock,
                limitReached, launcherPkgs, packageName,
                null, store.breakCycleEnabled, store.breakUntilMap(),
                System.currentTimeMillis(),
                store.studyActive, store.studyMissing,
                Util.isPhoneApp(this, entry.pkg)
            )
            val blocked = decision != null
            val cell = inflater.inflate(R.layout.item_launcher_app, row, false)
            val iconView = cell.findViewById<ImageView>(R.id.launcherAppIcon)
            val labelView = cell.findViewById<TextView>(R.id.launcherAppLabel)
            val lockView = cell.findViewById<TextView>(R.id.launcherAppLock)
            labelView.text = entry.label
            lockView.visibility = if (blocked) View.VISIBLE else View.GONE
            cell.alpha = if (blocked) 0.45f else 1f
            // "পিন করা" badge under Strict Guard, as in the v3.7 screenshot.
            val pinView = cell.findViewById<TextView>(R.id.launcherAppPin)
            pinView.visibility = if (entry.pkg == packageName) View.VISIBLE else View.GONE
            val icon = iconCache.getOrPut(entry.pkg) {
                try {
                    pm.getApplicationIcon(entry.pkg)
                } catch (e: Exception) {
                    null
                }
            }
            if (icon != null) iconView.setImageDrawable(icon)
            cell.setOnClickListener { onAppTap(entry, decision) }
            row?.addView(cell)
        }

        // Nothing must become unreachable: the hidden-apps row opens
        // the full list (shown + hidden), so a rarely-used app — a
        // banking app, for example — can still be opened without
        // turning the toggle off.
        if (hiddenApps.isNotEmpty()) {
            val dp = resources.displayMetrics.density
            val hiddenRow = TextView(this).apply {
                text = getString(R.string.hidden_apps, hiddenApps.size)
                setBackgroundResource(R.drawable.bg_badge)
                gravity = Gravity.CENTER
                setPadding((16 * dp).toInt(), (12 * dp).toInt(), (16 * dp).toInt(), (12 * dp).toInt())
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (16 * dp).toInt() }
                setOnClickListener {
                    showAllAppsDialog(visible, strict, night, limitReached, launcherPkgs)
                }
            }
            gridContainer.addView(hiddenRow)
        }
    }

    /**
     * Last foreground-use time per package over the last 30 days,
     * from UsageStats. Empty when Usage Access is off or nothing
     * was used in the window. Never throws.
     */
    private fun queryLastUsed(nowWall: Long): Map<String, Long> {
        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                nowWall - UsedApps.USED_WINDOW_MS, nowWall
            ) ?: return emptyMap()
            val map = HashMap<String, Long>()
            for (s in stats) {
                val last = s.lastTimeUsed
                if (last > 0) {
                    val prev = map[s.packageName] ?: 0L
                    if (last > prev) map[s.packageName] = last
                }
            }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    /** First-install time per package (unknown = no grace period). */
    @Suppress("DEPRECATION")
    private fun queryInstalled(apps: List<LauncherLogic.AppEntry>): Map<String, Long> {
        val map = HashMap<String, Long>()
        for (app in apps) {
            try {
                map[app.pkg] = packageManager.getPackageInfo(app.pkg, 0).firstInstallTime
            } catch (e: Exception) {
                // Unknown install time: no grace period for this app.
            }
        }
        return map
    }

    /**
     * The full app list (shown + hidden) as a tappable dialog, opened
     * from the "Hidden apps (n)" row. Tapping an app here goes through
     * the same BlockDecider rules as a grid tap: a hidden app is not
     * blocked by being hidden, but the normal Strict / Night / limit /
     * break rules still apply.
     */
    private fun showAllAppsDialog(
        allApps: List<LauncherLogic.AppEntry>,
        strict: Boolean,
        night: Boolean,
        limitReached: Set<String>,
        launcherPkgs: Set<String>
    ) {
        val labels = allApps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.all_apps))
            .setAdapter(
                ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
            ) { _, which ->
                val entry = allApps[which]
                val decision = LauncherLogic.tapDecision(
                    entry.pkg, strict, night, store.nightAllowed, store.customBlock,
                    limitReached, launcherPkgs, packageName,
                    null, store.breakCycleEnabled, store.breakUntilMap(),
                    System.currentTimeMillis(),
                    store.studyActive, store.studyMissing,
                    Util.isPhoneApp(this, entry.pkg)
                )
                onAppTap(entry, decision)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun onAppTap(entry: LauncherLogic.AppEntry, decision: BlockDecider.Decision?) {
        if (decision != null) {
            store.logTamper("LAUNCHER_BLOCKED ${entry.label} (${entry.pkg}) ${decision.kind}")
            val i = Intent(this, BlockActivity::class.java).apply {
                putExtra(BlockActivity.EXTRA_PKG, entry.pkg)
                putExtra(BlockActivity.EXTRA_KIND, decision.kind.name)
                putExtra(BlockActivity.EXTRA_GROUP, decision.groupId)
                putExtra(BlockActivity.EXTRA_BREAK_UNTIL, decision.breakUntilMs)
            }
            startActivity(i)
            return
        }
        if (entry.pkg == packageName) {
            startActivity(Intent(this, MainActivity::class.java))
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(entry.pkg)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(launch)
            } catch (e: Exception) {
                Toast.makeText(this, entry.label, Toast.LENGTH_SHORT).show()
            }
        }
    }
}

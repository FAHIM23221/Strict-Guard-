package app.strictguard

import java.util.Calendar

/**
 * v6.1.8 — pure helpers for the "last 7 days" screen-time bar chart
 * on the launcher. [Store.last7DaysScreenTimeMs] supplies the raw
 * per-day totals (it needs Context, so it is not tested here);
 * everything about turning those into bar heights and day labels is
 * pure and fully unit-testable, same split as [Limits] / [StudyLock].
 */
object ScreenTimeChart {

    private val DAY_LABELS_EN = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    private val DAY_LABELS_BN = arrayOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি")

    /** [dayOfWeek] is [java.util.Calendar.SUNDAY] (1) .. [java.util.Calendar.SATURDAY] (7). */
    fun dayLabel(dayOfWeek: Int, bn: Boolean): String {
        val i = (dayOfWeek - Calendar.SUNDAY).coerceIn(0, 6)
        return if (bn) DAY_LABELS_BN[i] else DAY_LABELS_EN[i]
    }

    /**
     * Bar height in px for one day's [minutes], scaled against the
     * tallest of the 7 days ([maxMinutes]) so the chart always fills
     * [maxHeightPx]. A day with 0 minutes still draws [minHeightPx]
     * (a visible sliver, not an invisible bar) — and so does every
     * bar when all 7 days are 0 (nothing to scale against yet).
     */
    fun barHeightPx(minutes: Int, maxMinutes: Int, maxHeightPx: Int, minHeightPx: Int): Int {
        if (maxMinutes <= 0 || maxHeightPx <= minHeightPx) return minHeightPx
        val h = (minutes.toFloat() / maxMinutes.toFloat() * maxHeightPx).toInt()
        return h.coerceIn(minHeightPx, maxHeightPx)
    }

    /** Whole-minute average across all 7 days (including days with no record, as 0). */
    fun averageMinutes(minutesPerDay: List<Int>): Int {
        if (minutesPerDay.isEmpty()) return 0
        return minutesPerDay.sum() / minutesPerDay.size
    }
}

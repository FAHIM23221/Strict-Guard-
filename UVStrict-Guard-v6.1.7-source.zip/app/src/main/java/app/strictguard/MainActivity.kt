package app.strictguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Main page (Design 1 "Warm Sand", v6.1.0): centred title with a
 * gear shortcut to Settings, the deep warm-brown Strict card with
 * today's usage bars inside it, a break-cycle status line, then the
 * Settings section (Night Lock, Break Cycle, Auto Theme, clock
 * format, language, theme), the Menu section (custom block list,
 * launcher, tamper log, diagnostics), the 7-step setup checklist
 * and the Strict button.
 *
 * Language, theme and clock format are one-tap rows in the Settings
 * section (they used to be header buttons); all choices persist.
 * The setup buttons are one-way: once a permission is granted, its
 * button is permanently dead in the app ("Allowed ✓", tap does
 * nothing) — it re-enables only if Android reports the permission
 * was revoked from outside the app, so the guard can be repaired.
 */
class MainActivity : BaseActivity() {

    companion object {
        private const val REVOKED_NOTIF_ID = 1003
    }

    private lateinit var usageContainer: LinearLayout
    private lateinit var setupContainer: LinearLayout
    private lateinit var settingsContainer: LinearLayout
    private lateinit var menuContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usageContainer = findViewById(R.id.usageContainer)
        setupContainer = findViewById(R.id.setupContainer)
        settingsContainer = findViewById(R.id.settingsContainer)
        menuContainer = findViewById(R.id.menuContainer)

        // Gear in the header: jump to the Settings section.
        findViewById<Button>(R.id.btnGear).setOnClickListener {
            val scroll = findViewById<ScrollView>(R.id.mainScroll)
            val target = findViewById<View>(R.id.settingsCard)
            scroll.post { scroll.smoothScrollTo(0, target.top) }
        }
        findViewById<TextView>(R.id.btnMonitoring).setOnClickListener {
            startMonitoring()
        }
        findViewById<Button>(R.id.btnStrict).setOnClickListener {
            if (store.isStrictActive()) {
                Toast.makeText(this, getString(R.string.status_strict_on), Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, StrictSetupActivity::class.java))
            }
        }
        findViewById<Button>(R.id.btnEndTest).setOnClickListener {
            store.endTestMode()
            refresh()
        }

        // v6.1.1: the permission request itself must never crash
        // the first launch.
        StartupGuard.runSafe {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(
                        arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // v6.1.1: first launch has no permissions and no prior data,
        // so EVERY step below runs guarded — one failing subsystem
        // (boot recovery, mirror/Keystore, guard start, refresh,
        // countdown ticker, day-less popup) must never kill the
        // launch. A step that throws is skipped, the rest still run.
        // v6.1.6 — THE SHADE FIX: the guard restart is FIRST now,
        // for the same reason as LauncherActivity — the mirror
        // restore below is slow cold work (~0.5–3 s) and used to
        // run on the main thread before the restart, so a dead
        // guard resumed only after it, while Settings was already
        // reachable. The restore now runs on a background thread.
        // v5.2.1 self-heal: XOS can kill the guard service in the
        // background. If monitoring is wanted (or Strict is on) and
        // the service is not running, restart it now — the app is in
        // the foreground here, so starting a foreground service is
        // allowed. Without this, Strict could silently stop blocking.
        // v6.1.2: the gate is now "Usage Access granted" (see
        // StartupGuard.shouldRestartGuard) — the old service-wanted
        // flag is only set by the service itself, so a guard that
        // never started, or was force-stopped, was never restarted
        // and the delay popup (and all enforcement) silently died.
        if (isStoreReady() &&
            StartupGuard.shouldRestartGuard(GuardService.isRunning, Util.hasUsageAccess(this))
        ) {
            if (StartupGuard.startGuardService(this)) {
                StartupGuard.runSafe { store.logTamper("GUARD_RESTARTED from MainActivity") }
            }
        }
        StartupGuard.runSafe { store.recoverStrictAfterBoot() }
        // v6.1.0 Clear Data defence: restore Strict from the mirror
        // if the Store lost it (Clear Data was tapped during Strict).
        // v6.1.6 — background thread, see above.
        Thread {
            StartupGuard.runSafe { MirrorStore.checkAndRestore(this, store) }
        }.start()
        StartupGuard.runSafe { refresh() }
        // v6.1.0 HSC live countdown (1-second ticker, only while visible).
        StartupGuard.runSafe {
            startHscTicker(
                findViewById(R.id.hscCountdownText),
                findViewById(R.id.hscCountdownLabel)
            )
        }
        // v6.1.0 daily "one day less" popup, shown on next unlock.
        StartupGuard.runSafe { maybeShowDayLessAlert() }
    }

    override fun onPause() {
        stopHscTicker()
        super.onPause()
    }

    private fun startGuardService() {
        // v6.1.1: a background start can be refused on Android 12+
        // (ForegroundServiceStartNotAllowedException) — that must be
        // a missed start, never a crash.
        StartupGuard.startGuardService(this)
    }

    private fun startMonitoring() {
        // v5.2.1: during Strict this button must not open the Usage
        // Access Settings screen — that would hand the user Settings
        // while Strict is on. The guard is already meant to be running.
        if (store.settingsLocked()) {
            Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
            return
        }
        if (!Util.hasUsageAccess(this)) {
            Toast.makeText(this, R.string.toast_usage, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        startGuardService()
        Toast.makeText(this, R.string.toast_service_started, Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun refresh() {
        val bn = Lang.isBengali(store.lang)
        val locale = Lang.localeFor(store.lang)
        val now = Calendar.getInstance()

        // Re-bind every static string so an in-place language switch
        // updates the whole screen without restarting the activity.
        findViewById<Button>(R.id.btnStrict).text = getString(R.string.strict_start)
        findViewById<Button>(R.id.btnEndTest).text = getString(R.string.end_test)
        findViewById<TextView>(R.id.footerText).text = getString(R.string.footer_limits_fixed)

        // ---- v5.1.0 lock during Strict ----
        // Everything already set is locked until Strict ends: language,
        // theme, clock format, Night Lock, pickers, setup steps. The
        // banner says so, and Store setters refuse writes as a second
        // layer.
        val locked = store.settingsLocked()
        findViewById<TextView>(R.id.lockBanner).visibility =
            if (locked) View.VISIBLE else View.GONE

        // ---- Status card (Design 1: title, Remaining, schedule) ----
        val strict = store.isStrictActive()
        findViewById<TextView>(R.id.statusTitle).text =
            if (strict) getString(R.string.status_card_on)
            else getString(R.string.status_card_off)
        findViewById<TextView>(R.id.statusSub).text =
            if (strict) {
                val remaining = store.strictEndElapsed() -
                    android.os.SystemClock.elapsedRealtime()
                getString(
                    R.string.launcher_remaining,
                    Limits.formatDuration(remaining.coerceAtLeast(0L), bn)
                )
            } else {
                getString(R.string.status_limits_active)
            }
        val nightState = if (store.nightEnabled) getString(R.string.on) else getString(R.string.off)
        findViewById<TextView>(R.id.statusLine).text =
            if (strict) {
                // v5.2.0: a schedule can end on another day, so show the
                // full date and time, not just the time.
                val until = SimpleDateFormat("d MMM yyyy, HH:mm", locale)
                    .format(Date(store.strictEndWall()))
                getString(R.string.strict_until, until)
            } else {
                getString(R.string.limits_always) + " - " +
                    getString(R.string.night_state, nightState)
            }

        // ---- v5.2.1: guard-not-running warning ----
        // If Usage Access is off, or the service was killed and is not
        // running although it should be, blocking is NOT active — say
        // so on the main screen instead of silently pretending. This
        // is the warning Olivia's bypass needed: with the guard dead,
        // Settings was reachable during Strict.
        // v6.1.2: matches the new self-heal rule — once Usage Access
        // is granted the guard must be running; a dead guard is a
        // warning even when Strict is off, because the delay, the
        // limits and Night Lock all depend on it.
        val guardDown = !Util.hasUsageAccess(this) || !GuardService.isRunning
        val warning = findViewById<TextView>(R.id.guardWarning)
        warning.visibility = if (guardDown) View.VISIBLE else View.GONE
        if (guardDown) {
            warning.text = getString(
                if (strict) R.string.guard_not_active_strict
                else R.string.guard_not_active
            )
        }

        // ---- Usage rows (inside the Strict card, light variant) ----
        usageContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        for (group in Limits.GROUPS) {
            val used = store.usageFor(group.id)
            val pct = Limits.percent(used, store.effectiveLimitMs(group)) // v6.1.7
            // Cream rows on the warm-brown card (Warm Sand, Design 1).
            // The Claude note is a separate right-aligned line under
            // the card (R.id.claudeNote), not a suffix on the AI row.
            val row = inflater.inflate(R.layout.item_usage_light, usageContainer, false)
            val nameRes = when (group.id) {
                "facebook" -> R.string.limit_facebook
                "chrome" -> R.string.limit_chrome
                "youtube" -> R.string.limit_youtube
                else -> R.string.limit_ai
            }
            row.findViewById<TextView>(R.id.usageName).setText(nameRes)
            val usedText = Limits.formatDuration(used, bn)
            val pctText = if (bn) Limits.toBengaliDigits("$pct%") else "$pct%"
            // v6.1.0: while a group is in a forced break, say so
            // right on its usage row, with the remaining break time.
            val breakSuffix = if (store.breakCycleEnabled) {
                val until = store.breakUntilFor(group.id)
                if (BreakCycle.isInBreak(until, System.currentTimeMillis())) {
                    " · " + getString(
                        R.string.break_remaining,
                        Limits.formatDuration(
                            BreakCycle.breakRemainingMs(until, System.currentTimeMillis()), bn
                        )
                    )
                } else ""
            } else ""
            row.findViewById<TextView>(R.id.usageValue).text = "$usedText · $pctText$breakSuffix"
            val fill = row.findViewById<View>(R.id.usageFill)
            fill.post {
                val parent = fill.parent as View
                val w = (parent.width * pct / 100).coerceAtLeast(0)
                fill.layoutParams.width = w
                fill.requestLayout()
            }
            usageContainer.addView(row)
        }

        // ---- Break-cycle status line (Design 1) ----
        // Shown only while a group is in a forced break, e.g.
        // "⏸ Break Cycle: Facebook — Break ends in 14 min".
        val breakLine = findViewById<TextView>(R.id.breakStatusLine)
        val inBreakGroup = if (store.breakCycleEnabled) {
            Limits.GROUPS.firstOrNull {
                BreakCycle.isInBreak(store.breakUntilFor(it.id), System.currentTimeMillis())
            }
        } else null
        if (inBreakGroup != null) {
            val until = store.breakUntilFor(inBreakGroup.id)
            breakLine.text = "⏸ " + getString(R.string.f_break) + ": " +
                shortGroupLabel(inBreakGroup.id, bn) + " — " + getString(
                    R.string.break_remaining,
                    Limits.formatDuration(
                        BreakCycle.breakRemainingMs(until, System.currentTimeMillis()), bn
                    )
                )
            breakLine.visibility = View.VISIBLE
        } else {
            breakLine.visibility = View.GONE
        }

        // ---- Setup rows (one-way buttons, v6.1.0) ----
        // Re-checked on every resume: a step granted before is
        // remembered in the Store; if Android now reports it
        // un-granted, it was revoked from outside the app — log it,
        // notify, and re-enable the button so the guard can be
        // repaired. (The guard service already watches Device Admin,
        // Usage Access and Overlay on every poll; this is the same
        // rule for the setup checklist itself.)
        val steps = setupSteps()
        val grantedKeys = store.setupGrantedKeys().toMutableSet()
        for (step in steps) {
            val done = step.done()
            if (done) {
                if (step.key !in grantedKeys) {
                    store.markSetupGranted(step.key)
                    grantedKeys.add(step.key)
                }
            } else if (SetupRowState.isRevocation(done, step.key in grantedKeys)) {
                store.unmarkSetupGranted(step.key)
                grantedKeys.remove(step.key)
                store.logTamper("PERMISSION_REVOKED ${step.key} ${getString(step.title)}")
                showRevokedNotification(getString(step.title))
            }
        }
        setupContainer.removeAllViews()
        var doneCount = 0
        for (step in steps) {
            val done = step.done()
            if (done) doneCount++
            val row = inflater.inflate(R.layout.item_setup, setupContainer, false)
            row.findViewById<TextView>(R.id.setupTitle).setText(step.title)
            row.findViewById<TextView>(R.id.setupDesc).setText(step.desc)
            val badge = row.findViewById<TextView>(R.id.setupBadge)
            val dot = row.findViewById<View>(R.id.setupDot)
            val chevron = row.findViewById<TextView>(R.id.setupChevron)
            when (SetupRowState.state(done, step.key in grantedKeys, locked)) {
                SetupRowState.State.GRANTED_DEAD -> {
                    // One-way: greyed out, "Allowed ✓", tap does
                    // NOTHING — it must not open Settings again.
                    badge.setText(R.string.setup_allowed)
                    dot.setBackgroundResource(R.drawable.bg_dot_done)
                    chevron.visibility = View.GONE
                    row.isEnabled = false
                    row.alpha = 0.55f
                    row.setOnClickListener { /* dead on purpose */ }
                }
                SetupRowState.State.LOCKED -> {
                    badge.setText(R.string.pending)
                    dot.setBackgroundResource(R.drawable.bg_dot)
                    chevron.visibility = View.VISIBLE
                    row.isEnabled = false
                    row.alpha = 0.5f
                    row.setOnClickListener {
                        Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
                    }
                }
                SetupRowState.State.PENDING -> {
                    badge.setText(R.string.pending)
                    dot.setBackgroundResource(R.drawable.bg_dot)
                    chevron.visibility = View.VISIBLE
                    row.isEnabled = true
                    row.alpha = 1f
                    row.setOnClickListener { step.action() }
                }
            }
            setupContainer.addView(row)
        }
        findViewById<TextView>(R.id.setupSectionTitle).text =
            getString(R.string.setup_progress, doneCount)

        // ---- Settings section (Design 1) ----
        settingsContainer.removeAllViews()
        addFeature(
            inflater, settingsContainer, R.string.f_night, R.string.f_night_desc,
            withSwitch = true, switchChecked = store.nightEnabled,
            locked = locked,
            onSwitch = { checked -> store.nightEnabled = checked; refresh() },
            onClick = { startActivity(Intent(this, NightPickerActivity::class.java)) }
        )
        addFeature(
            inflater, settingsContainer, R.string.f_night_allowed, R.string.f_night_allowed_desc,
            locked = locked,
            onClick = {
                startActivity(
                    Intent(this, AppPickerActivity::class.java)
                        .putExtra(AppPickerActivity.EXTRA_MODE, AppPickerActivity.MODE_NIGHT)
                )
            }
        )
        // v5.2.1: the YouTube Shorts feature is removed entirely
        // (Olivia asked for it to go). YouTube behaves as in v5.1.0:
        // blocked during Strict / Night / after its daily limit only.
        // v6.1.0 Break Cycle toggle (default ON, locked during Strict
        // like every other setting): after one session of use the app
        // is forced into a 20-minute break, repeating until the daily
        // limit is used up. Daily limits themselves stay fixed.
        addFeature(
            inflater, settingsContainer, R.string.f_break, R.string.f_break_desc,
            withSwitch = true, switchChecked = store.breakCycleEnabled,
            locked = locked,
            onSwitch = { checked -> store.breakCycleEnabled = checked; refresh() },
            onClick = { }
        )
        // v6.1.0 auto theme by time (default ON, locked during Strict
        // like every other setting): Dark at 18:00, Light at 06:00,
        // Asia/Dhaka. A manual theme change holds until the next
        // scheduled switch; the automatic switch itself still applies
        // during Strict (it is automatic, not a manual change).
        addFeature(
            inflater, settingsContainer, R.string.f_auto_theme, R.string.f_auto_theme_desc,
            withSwitch = true, switchChecked = store.autoTheme,
            locked = locked,
            onSwitch = { checked -> store.autoTheme = checked; refresh() },
            onClick = { }
        )
        // v6.1.0 Hide Unused Apps (default OFF, locked during Strict
        // like every other setting): the launcher grid shows only
        // apps used in the last 30 days (new apps get 7 days).
        // Hiding is only a display filter — hidden apps are not
        // blocked, and turning this OFF restores the full grid
        // immediately, no restart.
        addFeature(
            inflater, settingsContainer, R.string.f_show_used, R.string.f_show_used_desc,
            withSwitch = true, switchChecked = store.showOnlyUsedApps,
            locked = locked,
            onSwitch = { checked -> store.showOnlyUsedApps = checked; refresh() },
            onClick = { }
        )
        // v6.1.0 clock format toggle (default 24-hour). Tapping the
        // row switches 24h <-> 12h and applies immediately, no
        // restart; the launcher clock reads the same setting. The
        // description shows the current format with a live example.
        val clockExample = ClockFormat.format(
            now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE),
            store.clock24h, bn
        )
        addFeature(
            inflater, settingsContainer, R.string.f_clock, 0,
            descText = if (store.clock24h) {
                getString(R.string.clock_desc_24, clockExample)
            } else {
                getString(R.string.clock_desc_12, clockExample)
            },
            locked = locked,
            onClick = {
                store.clock24h = !store.clock24h
                refresh()
            }
        )
        // Language and theme used to be header buttons; on the
        // Design 1 page they are Settings rows (same one-tap
        // behaviour, same persistence, same lock during Strict).
        addFeature(
            inflater, settingsContainer, R.string.f_lang, 0,
            descText = getString(
                R.string.row_desc_current,
                if (bn) "বাংলা" else "English"
            ),
            locked = locked,
            onClick = {
                // Instant, no-restart switch: re-point this
                // activity's resources at the new locale, then
                // re-bind every string.
                store.lang = if (store.lang == "bn") "en" else "bn"
                Lang.applyLocaleInPlace(this, store.lang)
                refresh()
            }
        )
        addFeature(
            inflater, settingsContainer, R.string.f_theme, 0,
            descText = getString(
                R.string.row_desc_current,
                getString(
                    if (effectiveTheme() == "dark") R.string.theme_dark
                    else R.string.theme_light
                )
            ),
            locked = locked,
            onClick = {
                // One-tap override of the system theme; persists.
                store.theme = if (effectiveTheme() == "dark") "light" else "dark"
                recreate()
            }
        )
        // v6.1.3 always-unlocked apps (one line, EN + BN): Brilliant,
        // bKash, Nagad, Claude, WhatsApp and Messenger have no rules
        // at all — always unlocked, even during Strict / Night Lock /
        // Study Lock. (v6.1.0 said Claude was still blocked in
        // Strict/Night; Fahim reversed that on 2026-11-09.)
        addFeature(
            inflater, settingsContainer, R.string.f_claude_exempt, R.string.ai_claude_exempt,
            locked = locked,
            onClick = { }
        )
        // v6.1.7 — drag to set a group's daily limit anywhere from
        // its own default up to the hard 2-hour (120 min) cap.
        // Facebook's default (120) IS the cap, so it has no room to
        // raise and gets no row. Each slider is locked during Strict
        // like every other setting, so today's cap cannot be raised
        // mid-session. 5-minute steps; dragging left back to the far
        // end clears the override, back to that group's default.
        for (group in listOf(Limits.CHROME, Limits.YOUTUBE, Limits.AI)) {
            addLimitSlider(inflater, settingsContainer, group, locked)
        }
        // v6.1.0 Nightly Study Lock. The LINKED APP is still
        // permanent — no UI changes it. v6.1.7 adds an on/off switch
        // for the feature itself (default ON, same as every release
        // through v6.1.6); the switch and the time picker are both
        // locked during Strict like every other setting, so the
        // lock for tonight cannot be dodged by flipping it off
        // mid-session. Tapping the row (not the switch) still opens
        // the time picker.
        val studyTimeText = "%02d:%02d".format(
            store.studyTimeMin / 60, store.studyTimeMin % 60
        )
        addFeature(
            inflater, settingsContainer, R.string.f_study, 0,
            descText = getString(R.string.f_study_desc, studyTimeText),
            withSwitch = true, switchChecked = store.studyLockEnabled,
            locked = locked,
            onSwitch = { checked -> store.studyLockEnabled = checked; refresh() },
            onClick = { startActivity(Intent(this, StudyTimeActivity::class.java)) }
        )
        // v6.1.0 Entry Delay for social apps (default ON, locked
        // during Strict): a full-screen countdown popup appears
        // FIRST on every open of a social-feed app (Facebook,
        // Instagram, TikTok, X, Snapchat, LinkedIn, Reddit, … and
        // YouTube + YouTube Music) — WhatsApp and other messengers
        // are excluded. Strict / Night / limit / break blocks take
        // precedence; the delay never grants access when the app is
        // otherwise blocked.
        addFeature(
            inflater, settingsContainer, R.string.f_entry_delay, R.string.f_entry_delay_desc,
            withSwitch = true, switchChecked = store.entryDelayEnabled,
            locked = locked,
            onSwitch = { checked -> store.entryDelayEnabled = checked; refresh() },
            onClick = { }
        )
        // v6.1.0 Entry Delay duration: tap to cycle 10 → 15 → 30 s.
        addFeature(
            inflater, settingsContainer, R.string.f_entry_delay_seconds, 0,
            descText = getString(R.string.entry_delay_seconds_desc, store.entryDelaySeconds),
            locked = locked,
            onClick = {
                val next = when (store.entryDelaySeconds) {
                    10 -> 15
                    15 -> 30
                    else -> 10
                }
                store.entryDelaySeconds = next
                refresh()
            }
        )
        // v6.1.0 HSC exam date (default 6 June 2027 10:00 Dhaka).
        // Changeable in settings (the board may revise dates),
        // locked during Strict. Tapping opens a date picker.
        val hscDate = java.util.Date(store.hscExamMs)
        val hscDateText = java.text.SimpleDateFormat(
            "d MMMM yyyy, HH:mm",
            if (bn) java.util.Locale("bn") else java.util.Locale.ENGLISH
        ).format(hscDate)
        addFeature(
            inflater, settingsContainer, R.string.f_hsc_date, 0,
            descText = getString(R.string.f_hsc_date_desc, hscDateText),
            locked = locked,
            onClick = { showHscDatePicker() }
        )
        // v6.1.0 HSC 08:00 daily reminder (default ON, locked during Strict).
        addFeature(
            inflater, settingsContainer, R.string.f_hsc_reminder, R.string.f_hsc_reminder_desc,
            withSwitch = true, switchChecked = store.hscReminderEnabled,
            locked = locked,
            onSwitch = { checked -> store.hscReminderEnabled = checked; refresh() },
            onClick = { }
        )
        // v6.1.0 HSC daily "one day less" alert (default ON, locked
        // during Strict): a full-screen popup on next unlock + a
        // high-priority notification every midnight the days drop.
        addFeature(
            inflater, settingsContainer, R.string.f_hsc_dayless, R.string.f_hsc_dayless_desc,
            withSwitch = true, switchChecked = store.hscDayLessEnabled,
            locked = locked,
            onSwitch = { checked -> store.hscDayLessEnabled = checked; refresh() },
            onClick = { }
        )
        // v6.1.0 Friday prayer alarm (default ON, locked during
        // Strict): every Friday 09:00 an alarm rings once, plus
        // Jumu'ah countdown alerts (10:00 / 11:00 / 12:00 / 12:30 /
        // 13:00). Friday only, never daily. Turning it off cancels
        // the scheduled alarm.
        addFeature(
            inflater, settingsContainer, R.string.f_friday_alarm, R.string.f_friday_alarm_desc,
            withSwitch = true, switchChecked = store.fridayAlarmEnabled,
            locked = locked,
            onSwitch = { checked ->
                store.fridayAlarmEnabled = checked
                if (checked) PrayerAlarmScheduler.scheduleNext(this)
                else PrayerAlarmScheduler.cancel(this)
                refresh()
            },
            onClick = { }
        )

        // ---- Menu section (Design 1) ----
        menuContainer.removeAllViews()
        addFeature(
            inflater, menuContainer, R.string.f_custom, R.string.f_custom_desc,
            locked = locked,
            onClick = {
                startActivity(
                    Intent(this, AppPickerActivity::class.java)
                        .putExtra(AppPickerActivity.EXTRA_MODE, AppPickerActivity.MODE_CUSTOM)
                )
            }
        )
        // v6.0.0: the custom home launcher — open it from here too,
        // so it can be tried before it is set as the default home.
        addFeature(
            inflater, menuContainer, R.string.f_launcher, R.string.f_launcher_desc,
            locked = locked,
            onClick = { startActivity(Intent(this, LauncherActivity::class.java)) }
        )
        addFeature(
            inflater, menuContainer, R.string.f_tamper, R.string.f_tamper_desc,
            onClick = { startActivity(Intent(this, TamperLogActivity::class.java)) }
        )
        addFeature(
            inflater, menuContainer, R.string.f_diag, R.string.f_diag_desc,
            onClick = { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
        )

        findViewById<TextView>(R.id.btnMonitoring).text =
            if (store.serviceWanted) getString(R.string.monitoring_on)
            else getString(R.string.start_monitoring)
        findViewById<Button>(R.id.btnEndTest).visibility =
            if (strict && store.isTestMode()) View.VISIBLE else View.GONE
    }

    /** Short group label for the break status line ("Facebook", "AI চ্যাট"). */
    private fun shortGroupLabel(groupId: String, bn: Boolean): String = when (groupId) {
        "facebook" -> "Facebook"
        "chrome" -> "Chrome"
        "youtube" -> "YouTube"
        else -> if (bn) "AI চ্যাট" else "AI chat"
    }

    /**
     * Notify that a setup permission was revoked outside the app,
     * as the existing Device Admin monitoring does (Tamper Log +
     * high-importance notification that opens the app so the
     * permission can be granted again). Never throws.
     */
    private fun showRevokedNotification(stepTitle: String) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val ch = NotificationChannel(
                    GuardService.ADMIN_CHANNEL_ID,
                    getString(R.string.admin_lost_title),
                    NotificationManager.IMPORTANCE_HIGH
                )
                nm.createNotificationChannel(ch)
            }
            val open = Intent(this, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, GuardService.ADMIN_CHANNEL_ID)
                .setContentTitle(getString(R.string.revoked_title))
                .setContentText(getString(R.string.revoked_text, stepTitle))
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(REVOKED_NOTIF_ID, n)
        } catch (e: Exception) {
            // A missing notification permission must not break refresh.
        }
    }

    private data class SetupStep(
        val key: String,
        val title: Int, val desc: Int,
        val done: () -> Boolean, val action: () -> Unit
    )

    /**
     * v5.2.1 — second layer of the lock-during-Strict rule for the
     * setup steps. The rows are already disabled during Strict, but
     * these actions open system Settings screens (Usage Access,
     * Device Admin, Overlay, Notification Access, Battery, App info)
     * — including the Device Admin enable screen and the App info
     * screen for Strict Guard itself (force-stop / disable live
     * there). If one is ever invoked while Strict is on, refuse
     * instead of handing the user Settings.
     */
    private fun guarded(action: () -> Unit): () -> Unit = {
        if (store.settingsLocked()) {
            Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
        } else {
            action()
        }
    }

    private fun setupSteps(): List<SetupStep> = listOf(
        SetupStep("usage", R.string.s1_title, R.string.s1_desc,
            { Util.hasUsageAccess(this) },
            guarded {
                Toast.makeText(this, R.string.toast_usage, Toast.LENGTH_SHORT).show()
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }),
        SetupStep("admin", R.string.s2_title, R.string.s2_desc,
            { Util.isAdminActive(this) },
            guarded {
                val comp = ComponentName(this, GuardAdminReceiver::class.java)
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                    putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.s2_desc))
                }
                startActivity(i)
            }),
        SetupStep("overlay", R.string.s3_title, R.string.s3_desc,
            { Util.hasOverlay(this) },
            guarded {
                val i = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(i)
            }),
        SetupStep("launcher", R.string.s4_title, R.string.s4_desc,
            { Util.isDefaultLauncher(this) },
            guarded {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val role = getSystemService(ROLE_SERVICE) as android.app.role.RoleManager
                    startActivityForResult(
                        role.createRequestRoleIntent(android.app.role.RoleManager.ROLE_HOME), 10
                    )
                } else {
                    Toast.makeText(this, R.string.toast_launcher, Toast.LENGTH_LONG).show()
                }
            }),
        SetupStep("notif", R.string.s5_title, R.string.s5_desc,
            { Util.isNotificationListenerEnabled(this) },
            guarded { Util.requestNotificationListenerAccess(this) }),
        SetupStep("battery", R.string.s6_title, R.string.s6_desc,
            { Util.isIgnoringBatteryOptimizations(this) },
            guarded {
                val i = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                startActivity(i)
            }),
        SetupStep("autostart", R.string.s7_title, R.string.s7_desc,
            { store.autostartConfirmed },
            guarded {
                Toast.makeText(this, R.string.toast_autostart, Toast.LENGTH_LONG).show()
                store.autostartConfirmed = true
                Util.openAppSettings(this)
            })
    )

    private fun addFeature(
        inflater: LayoutInflater,
        container: LinearLayout,
        title: Int, desc: Int,
        descText: String? = null,
        withSwitch: Boolean = false,
        switchChecked: Boolean = false,
        locked: Boolean = false,
        onSwitch: ((Boolean) -> Unit)? = null,
        onClick: () -> Unit
    ): View {
        val row = inflater.inflate(R.layout.item_feature, container, false)
        row.findViewById<TextView>(R.id.featureTitle).setText(title)
        if (descText != null) {
            row.findViewById<TextView>(R.id.featureDesc).text = descText
        } else {
            row.findViewById<TextView>(R.id.featureDesc).setText(desc)
        }
        val sw = row.findViewById<Switch>(R.id.featureSwitch)
        val chevron = row.findViewById<TextView>(R.id.featureChevron)
        if (withSwitch) {
            sw.visibility = View.VISIBLE
            chevron.visibility = View.GONE
            sw.isChecked = switchChecked
            sw.isEnabled = !locked
            sw.setOnCheckedChangeListener { _, checked -> onSwitch?.invoke(checked) }
        }
        row.isEnabled = !locked
        row.alpha = if (locked) 0.5f else 1f
        row.setOnClickListener {
            if (locked) {
                Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
            } else onClick()
        }
        container.addView(row)
        return row
    }

    /**
     * v6.1.7 — drag-to-set daily-limit row for one [group]: from its
     * own default minutes up to [Limits.MAX_LIMIT_MINUTES], in
     * 5-minute steps. The value is only written to [Store] (and the
     * row redrawn, via [refresh]) once the user lets go of the
     * thumb — not on every pixel of the drag — so Strict's lock
     * check and the saved value agree at every point in between.
     */
    private fun addLimitSlider(
        inflater: LayoutInflater,
        container: LinearLayout,
        group: Limits.Group,
        locked: Boolean
    ): View {
        val titleRes = when (group.id) {
            "chrome" -> R.string.f_limit_slider_chrome
            "youtube" -> R.string.f_limit_slider_youtube
            else -> R.string.f_limit_slider_ai
        }
        val stepMin = 5
        val span = Limits.MAX_LIMIT_MINUTES - group.limitMinutes // 0 would mean no room
        val row = inflater.inflate(R.layout.item_limit_slider, container, false)
        row.findViewById<TextView>(R.id.sliderTitle).setText(titleRes)
        val descView = row.findViewById<TextView>(R.id.sliderDesc)
        val bar = row.findViewById<SeekBar>(R.id.sliderBar)

        fun minutesFor(progress: Int) = group.limitMinutes + progress * stepMin
        fun describe(minutes: Int) = getString(
            R.string.f_limit_slider_desc,
            minutes, group.limitMinutes, Limits.MAX_LIMIT_MINUTES
        )

        val current = Limits.effectiveLimitMinutes(
            group.limitMinutes, store.limitOverrideMinFor(group.id)
        )
        bar.max = span / stepMin
        bar.progress = (current - group.limitMinutes) / stepMin
        descView.text = describe(current)
        bar.isEnabled = !locked && span > 0
        bar.alpha = if (bar.isEnabled) 1f else 0.5f
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) descView.text = describe(minutesFor(progress))
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                if (locked) {
                    Toast.makeText(this@MainActivity, R.string.locked_strict, Toast.LENGTH_LONG).show()
                    refresh() // snaps the thumb back to the saved value
                    return
                }
                store.setLimitOverrideMinFor(group.id, minutesFor(sb.progress))
                refresh()
            }
        })
        container.addView(row)
        return row
    }

    /** HSC exam date picker: the date may be revised by the board,
     *  so it is changeable here. The time stays 10:00 Dhaka. */
    private fun showHscDatePicker() {
        if (store.settingsLocked()) {
            Toast.makeText(this, R.string.locked_strict, Toast.LENGTH_LONG).show()
            return
        }
        val cal = Calendar.getInstance().apply { timeInMillis = store.hscExamMs }
        android.app.DatePickerDialog(
            this,
            { _, year, month, day ->
                store.hscExamMs = HscCountdown.examMsForDate(year, month, day)
                store.logTamper("HSC_DATE ${store.hscExamMs}")
                refresh()
            },
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refresh()
    }
}
